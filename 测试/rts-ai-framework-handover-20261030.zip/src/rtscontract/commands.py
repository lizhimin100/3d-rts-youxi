"""命令与命令结果：AI 影响游戏的唯一出口。"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .vec import Vec2


@dataclass(frozen=True, slots=True)
class Command:
    """一条命令。

    ``units`` 与 ``building`` 二选一（生产类命令用 building）。
    ``label`` 仅供日志/调试，**不得**参与游戏或 AI 决策（用于排查与审计）。
    """

    kind: str
    issuer: str
    team: int
    units: tuple[int, ...] = ()
    building: int | None = None
    target: int | None = None
    point: Vec2 | None = None
    proto: str | None = None
    extra: tuple[int, ...] = ()
    label: str = ""
    meta: tuple[tuple[str, Any], ...] = ()

    def __post_init__(self) -> None:  # 允许传 list，统一成 tuple 保证可哈希
        if not isinstance(self.units, tuple):
            object.__setattr__(self, "units", tuple(self.units))
        if not isinstance(self.extra, tuple):
            object.__setattr__(self, "extra", tuple(self.extra))

    # ---------- 便捷构造 ----------
    @staticmethod
    def move(issuer: str, team: int, units, point: Vec2, label: str = "") -> "Command":
        return Command(kind="move", issuer=issuer, team=team, units=tuple(units), point=point, label=label)

    @staticmethod
    def attack(issuer: str, team: int, units, target: int, label: str = "") -> "Command":
        return Command(kind="attack", issuer=issuer, team=team, units=tuple(units), target=target, label=label)

    @staticmethod
    def attack_move(issuer: str, team: int, units, point: Vec2, label: str = "") -> "Command":
        return Command(kind="attack_move", issuer=issuer, team=team, units=tuple(units), point=point, label=label)

    @staticmethod
    def harvest(issuer: str, team: int, units, node: int, dropoff: int, label: str = "") -> "Command":
        return Command(
            kind="harvest", issuer=issuer, team=team, units=tuple(units),
            target=node, extra=(dropoff,), label=label,
        )

    @staticmethod
    def build(issuer: str, team: int, units, proto: str, point: Vec2, label: str = "") -> "Command":
        return Command(
            kind="build", issuer=issuer, team=team, units=tuple(units),
            proto=proto, point=point, label=label,
        )

    @staticmethod
    def train(issuer: str, team: int, building: int, proto: str, label: str = "") -> "Command":
        return Command(kind="train", issuer=issuer, team=team, building=building, proto=proto, label=label)

    @staticmethod
    def rally(issuer: str, team: int, building: int, point: Vec2, label: str = "") -> "Command":
        return Command(kind="set_rally", issuer=issuer, team=team, building=building, point=point, label=label)

    @staticmethod
    def stop(issuer: str, team: int, units, label: str = "") -> "Command":
        return Command(kind="stop", issuer=issuer, team=team, units=tuple(units), label=label)

    def describe(self) -> str:
        """一行人类可读描述（日志/失败诊断用）。"""
        return repr(self)

    def signature(self) -> tuple:
        """用于去重：同签名命令在同一 tick 不重复发送。"""
        return (
            self.kind,
            self.units,
            self.building,
            self.target,
            None if self.point is None else self.point.round(1),
            self.proto,
            self.extra,
        )

    def __repr__(self) -> str:  # pragma: no cover
        bits = [self.kind, f"i={self.issuer}", f"t={self.team}"]
        if self.units:
            bits.append(f"u={list(self.units)[:6]}{'...' if len(self.units) > 6 else ''}")
        if self.building is not None:
            bits.append(f"b={self.building}")
        if self.target is not None:
            bits.append(f"->{self.target}")
        if self.point is not None:
            bits.append(f"@{self.point.round(1)}")
        if self.proto:
            bits.append(f"p={self.proto}")
        return "<Cmd " + " ".join(bits) + ">"


@dataclass(frozen=True, slots=True)
class CommandResult:
    ok: bool
    reason: str = "ok"
    detail: str = ""
    accepted: int = 0       # 实际被接受的单位数（部分接受时 < len(units)）

    @property
    def rejected(self) -> int:
        return 0 if self.ok else 1

    def __bool__(self) -> bool:
        return self.ok


def ok(n: int = 1, detail: str = "") -> CommandResult:
    return CommandResult(True, "ok", detail, n)


OK = CommandResult(True, "ok", "", 1)


def reject(reason: str, detail: str = "") -> CommandResult:
    return CommandResult(False, reason, detail, 0)

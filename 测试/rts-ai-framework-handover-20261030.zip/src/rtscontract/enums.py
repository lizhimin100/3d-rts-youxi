"""契约层常量：命令种类、命令失败原因、控制权状态、订单种类。

刻意使用字符串常量而不是 Enum：
1) 便于序列化/日志/GUI 直接展示；
2) 真实游戏侧接入时只需实现字符串映射，不必导入本仓库的枚举类型；
3) 避免 pickle 跨进程（考试系统多进程）时的版本耦合。
"""
from __future__ import annotations

# ---------------------------------------------------------------- 阵营
TEAM_PLAYER = 0
TEAM_ENEMY = 1
TEAM_NEUTRAL = 2


class Issuer:
    """命令发起方。控制权仲裁依赖该字段。"""

    PLAYER = "player"       # 人类玩家（最高优先级）
    ADJUTANT = "adjutant"   # 玩家副官（AI 的一种角色）
    ENEMY_AI = "enemy_ai"   # 敌方人机
    SYSTEM = "system"       # 模拟器/脚本（初始化、剧情）


AI_ISSUERS = (Issuer.ADJUTANT, Issuer.ENEMY_AI)


class ControlKind:
    """单位控制权归属。玩家指令优先原则的载体（Player Intent Ownership）。

    时序::

        玩家下令 → PLAYER_ACTIVE（整组共享一次命令）
        命令组全部结束 → PLAYER_GRACE（宽限期，默认 5s）
        宽限期到 → ADJUTANT
        HOLD / STOP → PLAYER_HOLDING（STOP 有 30s 上限，HOLD 无上限）
        显式锁定 → PLAYER_LOCKED（永久）
    """

    PLAYER_ACTIVE = "player_active"     # 玩家命令正在执行（整组）
    PLAYER_GRACE = "player_grace"       # 命令刚结束，宽限期内 AI 不得接管
    PLAYER_HOLDING = "player_holding"   # 玩家要求停住（STOP 有时限，HOLD 无时限）
    PLAYER_MANUAL = "player_manual"     # 兼容旧语义（仅 TTL，无命令组信息）
    PLAYER_LOCKED = "player_locked"     # 玩家显式锁定（无时限，需解锁）
    ADJUTANT = "adjutant"               # 委托给副官
    AUTONOMOUS = "autonomous"           # 该阵营自有 AI（敌方人机）


# 所有"AI 不得下发命令"的控制权状态（AI 侧过滤 + 网关二次校验共用）
PROTECTED_CONTROL = frozenset(
    {
        ControlKind.PLAYER_ACTIVE,
        ControlKind.PLAYER_GRACE,
        ControlKind.PLAYER_HOLDING,
        ControlKind.PLAYER_MANUAL,
        ControlKind.PLAYER_LOCKED,
    }
)


class OrderKind:
    """单位当前执行中的订单（快照中暴露给 AI）。"""

    IDLE = "idle"
    MOVE = "move"
    ATTACK = "attack"
    ATTACK_MOVE = "attack_move"
    HOLD = "hold"
    STOP = "stop"
    HARVEST = "harvest"
    BUILD = "build"
    PATROL = "patrol"


# 参与「AI 不得打断」判定的订单：玩家下发的订单
ACTIVE_ORDER_KINDS = frozenset(
    {
        OrderKind.MOVE,
        OrderKind.ATTACK,
        OrderKind.ATTACK_MOVE,
        OrderKind.HOLD,
        OrderKind.HARVEST,
        OrderKind.BUILD,
        OrderKind.PATROL,
    }
)


class Cmd:
    """命令种类。AI 只能通过 Gateway.issue() 发送这些命令。"""

    MOVE = "move"
    ATTACK = "attack"
    ATTACK_MOVE = "attack_move"
    HOLD = "hold"
    STOP = "stop"
    HARVEST = "harvest"          # 采集：target=资源点, extra=(dropoff_id,)
    BUILD = "build"              # 建造：proto=建筑, point=位置
    ASSIST = "assist_build"      # 协助建造：target=在建建筑
    TRAIN = "train"              # 生产：building=建筑, proto=单位
    CANCEL_TRAIN = "cancel_train"
    SET_RALLY = "set_rally"      # point=集结点
    REPAIR = "repair"            # 预留：target=建筑
    # 控制权相关（玩家侧命令，AI 只读）
    LOCK = "lock"
    UNLOCK = "unlock"
    GRANT = "grant"              # 玩家把单位委托给副官
    SELECT = "select"            # 玩家 UI 选择（不改变控制权）


PLAYER_ONLY_CMDS = frozenset({Cmd.LOCK, Cmd.UNLOCK, Cmd.GRANT, Cmd.SELECT})

ALL_CMDS = frozenset(
    {
        Cmd.MOVE, Cmd.ATTACK, Cmd.ATTACK_MOVE, Cmd.HOLD, Cmd.STOP,
        Cmd.HARVEST, Cmd.BUILD, Cmd.TRAIN, Cmd.CANCEL_TRAIN, Cmd.SET_RALLY,
        Cmd.REPAIR, Cmd.LOCK, Cmd.UNLOCK, Cmd.GRANT, Cmd.SELECT, Cmd.ASSIST,
    }
)


class Reason:
    """命令被拒绝的原因。AI 会针对部分原因做自适应（见 sanity 模块）。"""

    OK = "ok"
    INVALID = "invalid"
    NOT_OWNED = "not_owned"
    LOCKED = "locked"                       # 玩家控制权保护
    PLAYER_ORDER_ACTIVE = "player_order_active"
    TARGET_NOT_VISIBLE = "target_not_visible"  # 反作弊：AI 不得攻击迷雾内目标
    TARGET_INVALID = "target_invalid"
    NO_RESOURCES = "no_resources"
    NO_SUPPLY = "no_supply"
    SUPPLY_BLOCKED = "supply_blocked"
    TECH_MISSING = "tech_missing"
    QUEUE_FULL = "queue_full"
    NODE_FULL = "node_full"
    PLACE_INVALID = "place_invalid"
    NOT_READY = "not_ready"
    COOLDOWN = "cooldown"
    BUSY = "busy"
    TEAM_MISMATCH = "team_mismatch"


class EventKind:
    """快照事件类型（AI 感知的离散信号）。"""

    UNIT_TRAINED = "unit_trained"
    BUILDING_COMPLETE = "building_complete"
    BUILDING_STARTED = "building_started"
    UNIT_KILLED = "unit_killed"
    BUILDING_DESTROYED = "building_destroyed"
    UNIT_UNDER_ATTACK = "unit_under_attack"
    BASE_UNDER_ATTACK = "base_under_attack"
    CONSTRUCTION_STALLED = "construction_stalled"
    SUPPLY_BLOCKED = "supply_blocked"
    RESOURCE_DEPLETED = "resource_depleted"
    COMMAND_REJECTED = "command_rejected"


class Stance:
    """战略姿态，由策略层根据声明式计划（config/plans.json）选择。"""

    ECONOMY = "economy"
    TECH = "tech"
    DEFEND = "defend"
    PRESSURE = "pressure"
    ALLIN = "allin"

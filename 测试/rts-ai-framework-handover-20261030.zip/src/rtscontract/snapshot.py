"""AI 可见的世界快照（只读、不可变、纯数据）。

这是 AI 与游戏之间的**唯一信息通道**：
- 快照由游戏侧（模拟器/真实游戏适配器）构建，AI 不能反向访问游戏对象；
- 敌方单位/建筑只包含「当前对 AI 阵营可见」的条目（战争迷雾天然生效）；
- 快照是值对象，可安全缓存、跨帧比较、跨进程传输。

真实游戏接入时需实现 ``gateway.build_snapshot(team) -> WorldSnapshot``。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .vec import Vec2


# --------------------------------------------------------------------------- 单位
@dataclass(frozen=True, slots=True)
class UnitInfo:
    uid: int
    proto: str
    team: int
    pos: Vec2
    hp: float
    hp_max: float
    order: str = "idle"
    order_target: int | None = None
    order_point: Vec2 | None = None
    order_owner: str = ""          # 当前订单的发起方（player / adjutant / enemy_ai）
    control: str = "adjutant"      # ControlKind 值
    carrying: float = 0.0
    cd_frac: float = 0.0           # 攻击冷却完成度 0..1（1=可攻击）
    stuck: bool = False            # 连续 N 秒无位移（模拟器标注，便于反愚蠢）
    resource_node: int | None = None
    home: int | None = None        # 绑定的资源点/矿点（农民）
    since_order: float = 0.0       # 当前订单已持续时间（秒）

    @property
    def alive(self) -> bool:
        return self.hp > 0.0

    @property
    def hp_pct(self) -> float:
        return self.hp / self.hp_max if self.hp_max > 0 else 0.0


# --------------------------------------------------------------------------- 建筑
@dataclass(frozen=True, slots=True)
class BuildingInfo:
    bid: int
    proto: str
    team: int
    pos: Vec2
    hp: float
    hp_max: float
    complete: bool = True
    progress: float = 1.0
    queue: tuple[str, ...] = ()
    queue_time: float = 0.0        # 队首剩余时间
    rally: Vec2 | None = None
    builders: int = 0
    control: str = "adjutant"
    on_resource: bool = False      # 是否压在资源点上（基地）

    @property
    def hp_pct(self) -> float:
        return self.hp / self.hp_max if self.hp_max > 0 else 0.0


# --------------------------------------------------------------------------- 资源点
@dataclass(frozen=True, slots=True)
class NodeInfo:
    nid: int
    pos: Vec2
    remaining: float
    max_workers: int = 5
    workers: int = 0
    kind: str = "gold"

    @property
    def free_slots(self) -> int:
        return max(0, self.max_workers - self.workers)

    @property
    def saturation(self) -> float:
        return min(1.0, self.workers / self.max_workers) if self.max_workers > 0 else 0.0


# --------------------------------------------------------------------------- 地图
@dataclass(frozen=True, slots=True)
class ExpansionSite:
    sid: int
    pos: Vec2
    node_ids: tuple[int, ...] = ()
    remaining: float = 0.0
    owner: int = -1                # 最近占据该点的阵营，-1 无
    has_building: bool = False


@dataclass(frozen=True, slots=True)
class MapInfo:
    width: int
    height: int
    tile: float = 1.0
    walkable: tuple[bytes, ...] = ()          # 每行 1 字节/格（0 不可走，1 可走）
    start_points: tuple[Vec2, ...] = ()
    enemy_start: Vec2 | None = None
    expansion_sites: tuple[ExpansionSite, ...] = ()
    macro_w: int = 12
    macro_h: int = 12

    def is_walkable(self, p: Vec2) -> bool:
        ix = int(p.x // self.tile)
        iy = int(p.y // self.tile)
        if ix < 0 or iy < 0 or iy >= len(self.walkable):
            return False
        row = self.walkable[iy]
        if ix >= len(row):
            return False
        return row[ix] == 1

    def clamp_point(self, p: Vec2) -> Vec2:
        return Vec2(
            min(max(p.x, 0.5), self.width - 0.5),
            min(max(p.y, 0.5), self.height - 0.5),
        )

    def macro_of(self, p: Vec2) -> tuple[int, int]:
        mw = max(1, self.macro_w)
        mh = max(1, self.macro_h)
        mx = int(p.x / self.width * mw)
        my = int(p.y / self.height * mh)
        return (min(max(mx, 0), mw - 1), min(max(my, 0), mh - 1))

    def macro_center(self, mx: int, my: int) -> Vec2:
        cw = self.width / max(1, self.macro_w)
        ch = self.height / max(1, self.macro_h)
        return Vec2((mx + 0.5) * cw, (my + 0.5) * ch)


# --------------------------------------------------------------------------- 迷雾
@dataclass(frozen=True, slots=True)
class FogInfo:
    explored_ratio: float = 0.0
    visible_ratio: float = 0.0
    macro_explored: tuple[float, ...] = ()     # 长度 macro_w*macro_h，0..1
    unknown_enemy_activity: bool = False       # 是否已有「看不见的敌方活动」信号

    def macro_at(self, idx: int, w: int) -> float:
        if 0 <= idx < len(self.macro_explored):
            return self.macro_explored[idx]
        del w
        return 0.0


# --------------------------------------------------------------------------- 玩家（副官专用）
@dataclass(frozen=True, slots=True)
class Intent:
    """玩家的一次高层意图（由 UI 命令转换而来，供副官理解）。"""

    tick: int
    kind: str                  # Cmd.* 的值
    units: tuple[int, ...] = ()
    target: int | None = None
    point: Vec2 | None = None
    proto: str | None = None
    ok: bool = True


@dataclass(frozen=True, slots=True)
class PlayerInfo:
    selected: frozenset[int] = frozenset()
    locked: frozenset[int] = frozenset()
    manual: frozenset[int] = frozenset()
    granted: frozenset[int] = frozenset()
    intents: tuple[Intent, ...] = ()
    autonomy: Mapping[str, Any] = field(default_factory=dict)
    presence: bool = True      # 是否有人类玩家在座（纯 AI 对局时为 False）


# --------------------------------------------------------------------------- 事件
@dataclass(frozen=True, slots=True)
class EventInfo:
    tick: int
    kind: str
    pos: Vec2 = Vec2()
    subject: int | None = None
    other: int | None = None
    proto: str | None = None
    value: float = 0.0
    team: int = -1             # 事件主体所属阵营（-1 未知）

    def __repr__(self) -> str:  # pragma: no cover
        return f"<{self.kind}@{self.tick} {self.pos}>"


# --------------------------------------------------------------------------- 快照
@dataclass(frozen=True, slots=True)
class WorldSnapshot:
    tick: int
    time: float
    dt: float
    team: int
    gold: float
    supply_used: float
    supply_cap: float
    supply_max: float
    units: tuple[UnitInfo, ...] = ()
    buildings: tuple[BuildingInfo, ...] = ()
    nodes: tuple[NodeInfo, ...] = ()
    map: MapInfo = field(default_factory=lambda: MapInfo(0, 0))
    fog: FogInfo = field(default_factory=FogInfo)
    player: PlayerInfo = field(default_factory=PlayerInfo)
    events: tuple[EventInfo, ...] = ()
    enemy_team: int = 1
    game_over: bool = False
    winner: int = -1

    # ---------- 便捷索引（构建一次，AI 多处复用） ----------
    def my_units(self) -> tuple[UnitInfo, ...]:
        return tuple(u for u in self.units if u.team == self.team)

    def my_buildings(self) -> tuple[BuildingInfo, ...]:
        return tuple(b for b in self.buildings if b.team == self.team)

    def enemies(self) -> tuple[UnitInfo, ...]:
        return tuple(u for u in self.units if u.team != self.team)

    def enemy_buildings(self) -> tuple[BuildingInfo, ...]:
        return tuple(b for b in self.buildings if b.team != self.team)

    def unit_map(self) -> dict[int, UnitInfo]:
        return {u.uid: u for u in self.units}

    def building_map(self) -> dict[int, BuildingInfo]:
        return {b.bid: b for b in self.buildings}

    def node_map(self) -> dict[int, NodeInfo]:
        return {n.nid: n for n in self.nodes}

    @property
    def supply_headroom(self) -> float:
        return max(0.0, self.supply_cap - self.supply_used)

    def of_kind(self, kind: str) -> tuple[EventInfo, ...]:
        return tuple(e for e in self.events if e.kind == kind)

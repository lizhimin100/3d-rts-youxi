"""控制权登记表：实现「玩家指令优先原则」——Player Intent Ownership。

旧实现是「玩家下过命令后 8 秒内 AI 不准动」。实测有 4 类问题
（见 `AUDIT_REPORT.md` §4）：长命令宽限期为 0、队形被逐单位劈开、
STOP 之后 8 秒就被拉走、无法表达巡逻/队列。

新实现按**命令组**跟踪生命周期：

```
玩家下令(move/attack/attack_move/harvest/build)
        → 整组 PLAYER_ACTIVE，直到组内所有单位都 idle
        → PLAYER_GRACE(grace_seconds)，默认 5 秒
        → AI_OWNED

玩家 HOLD      → PLAYER_HOLDING（无时限，直到玩家再下令/解锁）
玩家 STOP      → PLAYER_HOLDING（hold_after_stop_seconds，默认 30 秒）
玩家 LOCK      → PLAYER_LOCKED（永久）
玩家 GRANT     → AI_OWNED（立即）
玩家新命令     → 该单位从旧组移出，进入新组（旧组若空则结束）
```

要点：
1. **"结束"按组判定**，不按单位 —— 先到的单位不会把队形撕开；
2. **宽限期从"命令结束"开始算**，不从"命令下达"开始算；
3. `PLAYER_MANUAL`（纯 TTL）保留为兜底：游戏无法提供订单状态时仍能工作。

本模块只做登记与判定，不产生行为。真正执行时由 Gateway 二次校验
（纵深防御：即使 AI 逻辑写错，也不会真的抢走玩家单位）。
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping

from .enums import PROTECTED_CONTROL, ControlKind, Issuer, OrderKind

# 命令结束后进入宽限期的订单类型
_TRANSIENT_ORDERS = frozenset(
    {
        OrderKind.MOVE,
        OrderKind.ATTACK,
        OrderKind.ATTACK_MOVE,
        OrderKind.HARVEST,
        OrderKind.BUILD,
    }
)


@dataclass(slots=True)
class ControlEntry:
    kind: str = ControlKind.ADJUTANT
    until_tick: int = 0          # PLAYER_MANUAL / PLAYER_GRACE / PLAYER_HOLDING 的到期 tick；0 = 无期限
    reason: str = ""
    group: int = 0               # 所属玩家命令组（0 = 无）


@dataclass(slots=True)
class CommandGroup:
    gid: int
    units: set[int]
    order: str = OrderKind.MOVE
    started: int = 0
    deadline: int = 0            # 安全上限：再长的命令也不能无限 ACTIVE


class ControlRegistry:
    """每个单位一条控制权记录 + 一张玩家命令组表。线程不安全（单线程模拟器使用）。"""

    __slots__ = (
        "_entries", "_defaults", "_groups", "_next_gid",
        "manual_ttl_ticks", "grace_ticks", "hold_after_stop_ticks", "active_max_ticks",
        "tick_hz", "stats",
    )

    def __init__(
        self,
        manual_ttl_seconds: float = 8.0,
        tick_hz: float = 20.0,
        grace_seconds: float = 5.0,
        hold_after_stop_seconds: float = 30.0,
        active_max_seconds: float = 120.0,
    ) -> None:
        self._entries: dict[int, ControlEntry] = {}
        self._defaults: dict[int, str] = {}
        self._groups: dict[int, CommandGroup] = {}
        self._next_gid = 1
        self.tick_hz = max(1e-6, float(tick_hz))
        self.manual_ttl_ticks = max(1, int(manual_ttl_seconds * self.tick_hz))
        self.grace_ticks = max(0, int(grace_seconds * self.tick_hz))
        self.hold_after_stop_ticks = max(0, int(hold_after_stop_seconds * self.tick_hz))
        self.active_max_ticks = max(1, int(active_max_seconds * self.tick_hz))
        self.stats = {
            "player_commands": 0, "groups_finished": 0, "locks": 0,
            "unlocks": 0, "grants": 0, "ai_blocked": 0,
        }

    # ---------- 默认归属 ----------
    def set_default(self, team: int, kind: str) -> None:
        self._defaults[team] = kind

    def _entry(self, unit_id: int) -> ControlEntry:
        e = self._entries.get(unit_id)
        if e is None:
            e = ControlEntry(ControlKind.ADJUTANT)
            self._entries[unit_id] = e
        return e

    def register(self, unit_id: int, team: int, kind: str | None = None) -> None:
        self._entries[unit_id] = ControlEntry(kind or self._defaults.get(team, ControlKind.ADJUTANT))

    def forget(self, unit_id: int) -> None:
        self._entries.pop(unit_id, None)
        for g in self._groups.values():
            g.units.discard(unit_id)

    # ---------- 状态查询 ----------
    def kind_of(self, unit_id: int) -> str:
        return self._entry(unit_id).kind

    def until_of(self, unit_id: int) -> int:
        return self._entry(unit_id).until_tick

    def group_of(self, unit_id: int) -> int:
        return self._entry(unit_id).group

    def is_player_protected(self, unit_id: int, tick: int) -> bool:
        e = self._entry(unit_id)
        if e.kind == ControlKind.PLAYER_LOCKED:
            return True
        if e.kind == ControlKind.PLAYER_ACTIVE:
            # 命令还在执行：整组受保护，与时间无关
            return True
        if e.kind == ControlKind.PLAYER_MANUAL:
            return e.until_tick <= 0 or tick < e.until_tick
        if e.kind in (ControlKind.PLAYER_GRACE, ControlKind.PLAYER_HOLDING):
            return e.until_tick <= 0 or tick < e.until_tick
        return False

    # ---------- 玩家动作 ----------
    def on_player_command(
        self, unit_ids: Iterable[int], tick: int, order: str = OrderKind.MOVE, lock: bool = False
    ) -> None:
        """登记一条玩家命令。同一批单位共享一个命令组。

        重要：**显式锁定的单位不会被普通命令降级**。
        玩家「先锁定，再框选移动」是很常见的操作；如果这里把 LOCKED 改成 ACTIVE，
        锁就形同虚设（实测会让 `adj_lock_inviolable` 失败）。
        """
        self.stats["player_commands"] += 1
        requested = {uid for uid in unit_ids}
        units = {uid for uid in requested if self._entry(uid).kind != ControlKind.PLAYER_LOCKED}
        if not units:
            if lock:
                for uid in requested:
                    e = self._entry(uid)
                    e.kind = ControlKind.PLAYER_LOCKED
                    e.until_tick = 0
                    e.reason = "player_order_lock"
            return
        if lock:
            for uid in units:
                e = self._entry(uid)
                e.kind = ControlKind.PLAYER_LOCKED
                e.until_tick = 0
                e.group = 0
                e.reason = "player_order_lock"
            return

        # 从旧组移出（玩家改主意了，旧组不再拥有这批单位）
        for g in self._groups.values():
            g.units -= units
        self._gc_groups()

        if order == OrderKind.STOP:
            # 玩家要求停住：给一段"保持静止"的保护，而不是 8 秒后被拉走
            for uid in units:
                e = self._entry(uid)
                e.kind = ControlKind.PLAYER_HOLDING
                e.until_tick = tick + self.hold_after_stop_ticks
                e.group = 0
                e.reason = "player_stop"
            return

        if order == OrderKind.HOLD:
            for uid in units:
                e = self._entry(uid)
                e.kind = ControlKind.PLAYER_HOLDING
                e.until_tick = 0          # 驻守是长期意图，无时限
                e.group = 0
                e.reason = "player_hold"
            return

        if order not in _TRANSIENT_ORDERS:
            # 不改变控制权语义的命令（set_rally / train / cancel_train …）
            return

        gid = self._next_gid
        self._next_gid += 1
        g = CommandGroup(gid=gid, units=units, order=order, started=tick,
                         deadline=tick + self.active_max_ticks)
        self._groups[gid] = g
        for uid in units:
            e = self._entry(uid)
            e.kind = ControlKind.PLAYER_ACTIVE
            e.until_tick = 0
            e.group = gid
            e.reason = "player_order"

    def lock(self, unit_ids: Iterable[int], tick: int) -> None:
        self.stats["locks"] += 1
        units = set(unit_ids)
        for g in self._groups.values():
            g.units -= units
        self._gc_groups()
        for uid in units:
            e = self._entry(uid)
            e.kind = ControlKind.PLAYER_LOCKED
            e.until_tick = 0
            e.group = 0
            e.reason = "player_lock"

    def unlock(self, unit_ids: Iterable[int], tick: int) -> None:
        self.stats["unlocks"] += 1
        for uid in unit_ids:
            e = self._entry(uid)
            if e.kind == ControlKind.PLAYER_LOCKED:
                e.kind = ControlKind.PLAYER_GRACE
                e.until_tick = tick + self.grace_ticks
                e.group = 0
                e.reason = "player_unlock"

    def grant(self, unit_ids: Iterable[int]) -> None:
        self.stats["grants"] += 1
        units = set(unit_ids)
        for g in self._groups.values():
            g.units -= units
        self._gc_groups()
        for uid in units:
            e = self._entry(uid)
            e.kind = ControlKind.ADJUTANT
            e.until_tick = 0
            e.group = 0
            e.reason = "player_grant"

    # ---------- 每 tick ----------
    def tick(self, tick: int, orders: Mapping[int, str] | None = None) -> None:
        """推进状态机。

        ``orders`` 是「单位 id → 当前订单」；提供时按**整组**判定命令是否结束
        （组内全部 idle 才算结束）。不提供时退化为「到达 deadline 就结束」。
        """
        for gid, g in list(self._groups.items()):
            g.units = {uid for uid in g.units if uid in self._entries}
            if not g.units:
                self._groups.pop(gid, None)
                continue
            finished = False
            if orders is not None:
                states = [orders.get(uid, OrderKind.IDLE) for uid in g.units]
                finished = all(s in (OrderKind.IDLE, OrderKind.STOP) for s in states)
            if not finished and tick >= g.deadline:
                finished = True       # 安全上限：再长的命令也不能无限 ACTIVE
            if finished:
                for uid in g.units:
                    e = self._entry(uid)
                    if e.kind == ControlKind.PLAYER_ACTIVE and e.group == gid:
                        e.kind = ControlKind.PLAYER_GRACE
                        e.until_tick = tick + self.grace_ticks
                        e.group = 0
                        e.reason = "order_finished"
                self._groups.pop(gid, None)
                self.stats["groups_finished"] += 1

        # 到期处理
        for e in self._entries.values():
            if e.kind in (ControlKind.PLAYER_GRACE, ControlKind.PLAYER_HOLDING):
                if 0 < e.until_tick <= tick:
                    e.kind = ControlKind.ADJUTANT
                    e.until_tick = 0
                    e.reason = "grace_expired"
            elif e.kind == ControlKind.PLAYER_MANUAL and 0 < e.until_tick <= tick:
                e.kind = ControlKind.ADJUTANT
                e.until_tick = 0
                e.reason = "manual_expired"

    def _gc_groups(self) -> None:
        for gid in [g for g, v in self._groups.items() if not v.units]:
            self._groups.pop(gid, None)

    # ---------- AI 动作校验 ----------
    def allows(self, unit_id: int, tick: int, issuer: str) -> tuple[bool, str]:
        if issuer == Issuer.PLAYER:
            return True, "ok"
        e = self._entry(unit_id)
        if e.kind in PROTECTED_CONTROL and self.is_player_protected(unit_id, tick):
            return False, e.kind
        return True, "ok"

    # ---------- 视图 ----------
    def view(self) -> dict[str, frozenset[int]]:
        locked: set[int] = set()
        manual: set[int] = set()
        adjutant: set[int] = set()
        for uid, e in self._entries.items():
            if e.kind == ControlKind.PLAYER_LOCKED:
                locked.add(uid)
            elif e.kind in (ControlKind.PLAYER_ACTIVE, ControlKind.PLAYER_GRACE,
                            ControlKind.PLAYER_HOLDING, ControlKind.PLAYER_MANUAL):
                manual.add(uid)
            elif e.kind == ControlKind.ADJUTANT:
                adjutant.add(uid)
        return {
            "locked": frozenset(locked),
            "manual": frozenset(manual),
            "adjutant": frozenset(adjutant),
        }

    # ---------- 诊断 ----------
    def group_stats(self) -> dict[str, int]:
        return {
            "active_groups": len(self._groups),
            "active_units": sum(len(g.units) for g in self._groups.values()),
        }

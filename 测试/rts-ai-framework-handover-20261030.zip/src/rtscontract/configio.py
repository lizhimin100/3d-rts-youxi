"""配置读取（跨机器可用：不依赖当前工作目录）。"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


def project_root() -> Path:
    """定位仓库根目录：环境变量 > 从本文件向上查找 config/。"""
    env = os.environ.get("RTS_AI_ROOT")
    if env:
        return Path(env).resolve()
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "config" / "catalog.json").is_file():
            return parent
    # 未找到时退化为 src 的父目录（允许只拷贝 src 使用内置默认值）
    return here.parents[2] if len(here.parents) > 2 else Path.cwd()


def config_dir() -> Path:
    return project_root() / "config"


def get_path(name: str) -> Path:
    p = Path(name)
    return p if p.is_absolute() else config_dir() / p


def load_json(name: str, default: Any = None) -> Any:
    path = get_path(name)
    if not path.is_file():
        if default is not None:
            return default
        raise FileNotFoundError(f"缺少配置文件: {path}")
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def deep_merge(base: dict, override: dict | None) -> dict:
    """返回 base 的深拷贝，并叠加 override。"""
    out = {k: (deep_merge(v, {}) if isinstance(v, dict) else v) for k, v in base.items()}
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out

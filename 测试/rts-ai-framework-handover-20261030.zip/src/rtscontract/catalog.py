"""兵种/建筑原型表与战斗规则表（全部数据驱动）。

设计要点
--------
1. **AI 不认任何具体兵种名**：所有推理基于原型上的数值、标签与能力声明。
   新增兵种只需在 ``config/catalog.json`` 增加一条记录，AI 无需改动。
2. **克制关系来自"攻击类型 × 护甲类型"矩阵**（与 Warcraft III 一致），
   而不是硬编码的 "A 克 B" 表。AI 通过矩阵计算任意两个原型之间的
   DPS / 有效生命 / 交换比，因此新兵种自动纳入克制推理。
3. ``requires`` 表达科技依赖，AI 的建造/生产规划器据此自动排队。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping, Sequence


# --------------------------------------------------------------------------- 数值结构
@dataclass(frozen=True, slots=True)
class Cost:
    gold: float = 0.0
    supply: float = 0.0


@dataclass(frozen=True, slots=True)
class Attack:
    damage: float = 0.0
    range: float = 1.0
    cooldown: float = 1.0
    damage_type: str = "normal"
    targets: tuple[str, ...] = ("ground",)
    splash: float = 0.0

    @property
    def dps(self) -> float:
        return self.damage / self.cooldown if self.cooldown > 0 else 0.0

    def can_hit(self, target_flying: bool) -> bool:
        return ("air" if target_flying else "ground") in self.targets


@dataclass(frozen=True, slots=True)
class Harvest:
    carry: float = 8.0
    gather_time: float = 2.0
    resource: str = "gold"


@dataclass(frozen=True, slots=True)
class Proto:
    id: str
    name: str = ""
    is_building: bool = False
    hp: float = 100.0
    armor: float = 0.0
    armor_type: str = "unarmored"
    speed: float = 3.0
    sight: float = 8.0
    cost: Cost = Cost()
    build_time: float = 10.0
    supply_provided: float = 0.0
    footprint: tuple[int, int] = (1, 1)
    flying: bool = False
    attack: Attack | None = None
    tags: tuple[str, ...] = ()
    requires: tuple[str, ...] = ()
    produce: tuple[str, ...] = ()
    built_by: tuple[str, ...] = ()
    dropoff: bool = False
    max_queue: int = 4
    harvest: Harvest | None = None
    radius: float = 0.45
    desc: str = ""

    # ---------------- 派生属性 ----------------
    @property
    def value(self) -> float:
        """通用战力/经济估值（不依赖具体兵种）。"""
        return self.cost.gold + self.cost.supply * 18.0

    @property
    def is_worker(self) -> bool:
        return self.harvest is not None

    @property
    def is_defense(self) -> bool:
        return self.is_building and self.attack is not None

    @property
    def is_ranged(self) -> bool:
        return self.attack is not None and self.attack.range >= 3.0

    @property
    def can_hit_air(self) -> bool:
        return self.attack is not None and "air" in self.attack.targets

    @property
    def can_hit_ground(self) -> bool:
        return self.attack is not None and "ground" in self.attack.targets

    def has_tag(self, tag: str) -> bool:
        return tag in self.tags

    def tags_any(self, wanted: Iterable[str]) -> bool:
        return any(t in self.tags for t in wanted)


@dataclass(frozen=True, slots=True)
class TagBonus:
    attacker_tags: tuple[str, ...]
    defender_tags: tuple[str, ...]
    mult: float = 1.0
    note: str = ""


@dataclass(frozen=True, slots=True)
class CombatRules:
    """攻击类型 × 护甲类型 的伤害倍率表 + 标签加成 + 护甲减伤公式。"""

    matrix: Mapping[str, Mapping[str, float]] = field(default_factory=dict)
    tag_bonus: tuple[TagBonus, ...] = ()
    armor_coef: float = 0.06
    armor_types: tuple[str, ...] = ("light", "medium", "heavy", "fortified", "unarmored")
    attack_types: tuple[str, ...] = ("normal", "pierce", "siege", "magic")

    def multiplier(self, attack_type: str, armor_type: str) -> float:
        row = self.matrix.get(attack_type)
        if not row:
            return 1.0
        return float(row.get(armor_type, 1.0))

    def tag_multiplier(self, attacker_tags: Sequence[str], defender_tags: Sequence[str]) -> float:
        mult = 1.0
        for tb in self.tag_bonus:
            if any(t in attacker_tags for t in tb.attacker_tags) and any(
                t in defender_tags for t in tb.defender_tags
            ):
                mult *= tb.mult
        return mult

    def armor_reduction(self, armor: float) -> float:
        """返回受伤系数（0..1）。WC3 风格：减伤 = a*c/(1+a*c)。"""
        a = max(0.0, armor)
        c = self.armor_coef
        return 1.0 - (a * c) / (1.0 + a * c)


# --------------------------------------------------------------------------- 目录
class Catalog:
    def __init__(
        self,
        protos: Mapping[str, Proto],
        rules: CombatRules | None = None,
        supply_max: float = 60.0,
        meta: Mapping[str, Any] | None = None,
    ) -> None:
        self.protos: dict[str, Proto] = dict(protos)
        self.rules = rules or CombatRules()
        self.supply_max = supply_max
        self.meta = dict(meta or {})
        self._units = tuple(p for p in self.protos.values() if not p.is_building)
        self._buildings = tuple(p for p in self.protos.values() if p.is_building)

    # ---------- 查询 ----------
    def get(self, proto_id: str) -> Proto:
        p = self.protos.get(proto_id)
        if p is None:
            raise KeyError(f"未定义的原型: {proto_id!r}")
        return p

    def has(self, proto_id: str) -> bool:
        return proto_id in self.protos

    def units(self) -> tuple[Proto, ...]:
        return self._units

    def buildings(self) -> tuple[Proto, ...]:
        return self._buildings

    def trainable_by(self, building_id: str) -> tuple[Proto, ...]:
        b = self.protos.get(building_id)
        if b is None:
            return ()
        return tuple(self.protos[x] for x in b.produce if x in self.protos)

    def buildable_by(self, worker: Proto) -> tuple[Proto, ...]:
        return tuple(
            p for p in self._buildings if p.built_by and worker.tags_any(p.built_by)
        )

    def supply_buildings(self) -> tuple[Proto, ...]:
        return tuple(p for p in self._buildings if p.supply_provided > 0)

    def workers(self) -> tuple[Proto, ...]:
        return tuple(p for p in self._units if p.harvest is not None)

    def tech_satisfied(self, proto: Proto, completed: Iterable[str]) -> bool:
        have = set(completed)
        return all(req in have for req in proto.requires)

    def unit_by_id(self, proto_id: str) -> Proto:
        return self.get(proto_id)


def catalog_from_dict(data: Mapping[str, Any]) -> Catalog:
    protos: dict[str, Proto] = {}
    for section, is_building in (("units", False), ("buildings", True)):
        for raw in data.get(section, ()):  # type: ignore[union-attr]
            pid = str(raw["id"])
            atk = raw.get("attack")
            attack = (
                Attack(
                    damage=float(atk.get("damage", 0.0)),
                    range=float(atk.get("range", 1.0)),
                    cooldown=float(atk.get("cooldown", 1.0)),
                    damage_type=str(atk.get("damage_type", "normal")),
                    targets=tuple(atk.get("targets", ("ground",))),
                    splash=float(atk.get("splash", 0.0)),
                )
                if atk
                else None
            )
            hv = raw.get("harvest")
            harvest = (
                Harvest(
                    carry=float(hv.get("carry", 8.0)),
                    gather_time=float(hv.get("gather_time", 2.0)),
                    resource=str(hv.get("resource", "gold")),
                )
                if hv
                else None
            )
            cost_raw = raw.get("cost", {})
            fp = raw.get("footprint", (1, 1))
            footprint = (int(fp[0]), int(fp[1]))
            radius = float(
                raw.get("radius", max(footprint) * 0.5 * 0.9 if is_building else 0.45)
            )
            protos[pid] = Proto(
                id=pid,
                name=str(raw.get("name", pid)),
                is_building=is_building,
                hp=float(raw.get("hp", 100.0)),
                armor=float(raw.get("armor", 0.0)),
                armor_type=str(raw.get("armor_type", "unarmored")),
                speed=float(raw.get("speed", 0.0 if is_building else 3.0)),
                sight=float(raw.get("sight", 8.0)),
                cost=Cost(float(cost_raw.get("gold", 0.0)), float(cost_raw.get("supply", 0.0))),
                build_time=float(raw.get("build_time", 10.0)),
                supply_provided=float(raw.get("supply_provided", 0.0)),
                footprint=footprint,
                flying=bool(raw.get("flying", False)),
                attack=attack,
                tags=tuple(raw.get("tags", ())),
                requires=tuple(raw.get("requires", ())),
                produce=tuple(raw.get("produce", ())),
                built_by=tuple(raw.get("built_by", ())),
                dropoff=bool(raw.get("dropoff", False)),
                max_queue=int(raw.get("max_queue", 4)),
                harvest=harvest,
                radius=radius,
                desc=str(raw.get("desc", "")),
            )

    rules_raw = data.get("combat_rules", {})
    matrix = {str(k): {str(k2): float(v2) for k2, v2 in v.items()} for k, v in rules_raw.get("matrix", {}).items()}
    tag_bonus = tuple(
        TagBonus(
            attacker_tags=tuple(tb.get("attacker_tags", ())),
            defender_tags=tuple(tb.get("defender_tags", ())),
            mult=float(tb.get("mult", 1.0)),
            note=str(tb.get("note", "")),
        )
        for tb in rules_raw.get("tag_bonus", ())
    )
    rules = CombatRules(
        matrix=matrix,
        tag_bonus=tag_bonus,
        armor_coef=float(rules_raw.get("armor_coef", 0.06)),
        armor_types=tuple(rules_raw.get("armor_types", ("light", "medium", "heavy", "fortified", "unarmored"))),
        attack_types=tuple(rules_raw.get("attack_types", ("normal", "pierce", "siege", "magic"))),
    )
    return Catalog(
        protos=protos,
        rules=rules,
        supply_max=float(data.get("supply_max", 60.0)),
        meta=data.get("meta", {}),
    )

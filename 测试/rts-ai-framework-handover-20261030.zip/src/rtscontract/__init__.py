"""rtscontract —— RTS AI 契约层。

包含：向量/几何、兵种原型表、世界快照、命令与结果、控制权登记、网关协议、配置读取。
本包不依赖 ``rtsai`` / ``rtsim``，是整个系统的「公共语言」。
"""

from .catalog import (  # noqa: F401
    Attack,
    Catalog,
    CombatRules,
    Cost,
    Harvest,
    Proto,
    TagBonus,
    catalog_from_dict,
)
from .commands import Command, CommandResult, reject  # noqa: F401
from .configio import config_dir, deep_merge, get_path, load_json, project_root  # noqa: F401
from .control import ControlRegistry  # noqa: F401
from .enums import (  # noqa: F401
    AI_ISSUERS,
    ALL_CMDS,
    Cmd,
    ControlKind,
    EventKind,
    Issuer,
    OrderKind,
    PLAYER_ONLY_CMDS,
    Reason,
    Stance,
    TEAM_ENEMY,
    TEAM_NEUTRAL,
    TEAM_PLAYER,
)
from .gateway import IGameGateway  # noqa: F401
from .snapshot import (  # noqa: F401
    BuildingInfo,
    EventInfo,
    ExpansionSite,
    FogInfo,
    Intent,
    MapInfo,
    NodeInfo,
    PlayerInfo,
    UnitInfo,
    WorldSnapshot,
)
from .vec import EPS, Vec2, clamp, lerp, percentile, ratio, safe_div, weighted_pick  # noqa: F401

__version__ = "1.0.0"

"""向量、几何与统计小工具（纯标准库、确定性）。"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, Sequence, TypeVar

EPS = 1e-9
T = TypeVar("T")


@dataclass(frozen=True, slots=True)
class Vec2:
    x: float = 0.0
    y: float = 0.0

    # ---------------- 运算 ----------------
    def __add__(self, o: "Vec2") -> "Vec2":
        return Vec2(self.x + o.x, self.y + o.y)

    def __sub__(self, o: "Vec2") -> "Vec2":
        return Vec2(self.x - o.x, self.y - o.y)

    def __mul__(self, k: float) -> "Vec2":
        return Vec2(self.x * k, self.y * k)

    def __rmul__(self, k: float) -> "Vec2":
        return Vec2(self.x * k, self.y * k)

    def __truediv__(self, k: float) -> "Vec2":
        return Vec2(self.x / k, self.y / k)

    def __neg__(self) -> "Vec2":
        return Vec2(-self.x, -self.y)

    def __iter__(self):
        yield self.x
        yield self.y

    # ---------------- 度量 ----------------
    @property
    def length(self) -> float:
        return math.hypot(self.x, self.y)

    @property
    def length_sq(self) -> float:
        return self.x * self.x + self.y * self.y

    def dist(self, o: "Vec2") -> float:
        return math.hypot(self.x - o.x, self.y - o.y)

    def dist_sq(self, o: "Vec2") -> float:
        dx = self.x - o.x
        dy = self.y - o.y
        return dx * dx + dy * dy

    def normalized(self) -> "Vec2":
        n = math.hypot(self.x, self.y)
        if n < EPS:
            return Vec2()
        return Vec2(self.x / n, self.y / n)

    def toward(self, target: "Vec2", step: float) -> "Vec2":
        d = self.dist(target)
        if d <= step or d < EPS:
            return target
        k = step / d
        return Vec2(self.x + (target.x - self.x) * k, self.y + (target.y - self.y) * k)

    def round(self, nd: int = 2) -> tuple[float, float]:
        return (round(self.x, nd), round(self.y, nd))

    def as_tuple(self) -> tuple[float, float]:
        return (self.x, self.y)

    def rounded(self, nd: int = 2) -> tuple[float, float]:
        return (round(self.x, nd), round(self.y, nd))

    def __repr__(self) -> str:  # pragma: no cover - 仅调试
        return f"({self.x:.1f},{self.y:.1f})"


ZERO = Vec2()


def clamp(v: float, lo: float, hi: float) -> float:
    return lo if v < lo else hi if v > hi else v


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def safe_div(a: float, b: float, default: float = 0.0) -> float:
    return a / b if abs(b) > EPS else default


def ratio(a: float, b: float, default: float = 0.0) -> float:
    """a/(a+b) 形式的占比，双方都为 0 时返回 default。"""
    s = a + b
    return a / s if s > EPS else default


def weighted_pick(rng, items: Sequence[T], weights: Sequence[float]) -> T | None:
    if not items:
        return None
    total = sum(max(0.0, w) for w in weights)
    if total <= EPS:
        return items[rng.randrange(len(items))]
    r = rng.random() * total
    acc = 0.0
    for it, w in zip(items, weights):
        acc += max(0.0, w)
        if r <= acc:
            return it
    return items[-1]


def percentile(values: Sequence[float], q: float) -> float:
    """线性插值分位数，q∈[0,1]。用于报告 P50/P90 等指标。"""
    if not values:
        return 0.0
    data = sorted(values)
    if len(data) == 1:
        return float(data[0])
    pos = clamp(q, 0.0, 1.0) * (len(data) - 1)
    lo = int(math.floor(pos))
    hi = min(len(data) - 1, lo + 1)
    frac = pos - lo
    return float(data[lo] * (1 - frac) + data[hi] * frac)


def mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def dist_point_segment(p: Vec2, a: Vec2, b: Vec2) -> float:
    ab = b - a
    denom = ab.length_sq
    if denom < EPS:
        return p.dist(a)
    t = clamp(((p.x - a.x) * ab.x + (p.y - a.y) * ab.y) / denom, 0.0, 1.0)
    proj = Vec2(a.x + ab.x * t, a.y + ab.y * t)
    return p.dist(proj)


def spread_points(center: Vec2, count: int, radius: float) -> list[Vec2]:
    """在圆内均匀撒点（确定性，不带随机）。"""
    if count <= 0:
        return []
    if count == 1:
        return [center]
    out = []
    for i in range(count):
        ang = 2.0 * math.pi * i / count
        out.append(Vec2(center.x + math.cos(ang) * radius, center.y + math.sin(ang) * radius))
    return out


def flatten(items: Iterable[Iterable[T]]) -> list[T]:
    out: list[T] = []
    for it in items:
        out.extend(it)
    return out

"""网关协议：AI 与游戏之间的唯一接口。

AI 只能做两件事：
1. 读取 ``WorldSnapshot``（gateway.snapshot()）；
2. 调用 ``gateway.issue(Command)`` 下达命令。

真实游戏接入时实现 ``IGameGateway`` 即可，AI Core 不需要任何改动。
"""
from __future__ import annotations

from typing import Any, Mapping, Protocol, runtime_checkable

from .catalog import Catalog
from .commands import Command, CommandResult
from .snapshot import WorldSnapshot
from .vec import Vec2


@runtime_checkable
class IGameGateway(Protocol):
    """游戏侧需要实现的全部能力（AI 视角）。"""

    team: int
    issuer: str   # Issuer.ADJUTANT / Issuer.ENEMY_AI，AI 用它给命令署名

    def snapshot(self) -> WorldSnapshot:
        """返回该阵营视角的最新世界快照（敌方信息受战争迷雾过滤）。

        约定：``snapshot()`` 会清空并返回「自上次调用以来」的事件队列，
        因此每个 AI tick 只应调用一次。
        """

    def issue(self, cmd: Command) -> CommandResult:
        """下达命令。必须自行校验归属、资源、控制权与视野。"""

    def can_place(self, proto_id: str, point: Vec2) -> bool:
        """建筑可放置性探测。"""

    def catalog(self) -> Catalog:
        """原型表（兵种/建筑数值与战斗规则）。"""

    def match_info(self) -> Mapping[str, Any]:
        """对局元信息：tick_hz、地图尺寸、时长上限等。"""

    def suggest(self, payload: Mapping[str, Any]) -> None:
        """副官向 UI 提交建议（请求控制权、提醒等），不产生游戏内行为。"""

    def stats(self) -> Mapping[str, Any]:
        """统计信息（拒单计数等），供诊断与考试使用。"""

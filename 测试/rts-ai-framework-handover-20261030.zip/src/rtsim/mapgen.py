"""程序化地图生成（旋转对称、可复现）。

地图是 Mock Simulator 的一部分，不参与 AI 决策。AI 只能通过 ``MapInfo``
（静态地形 + 资源点位置）获取地图信息，这与真实 RTS「玩家知道地图长相、
但不知道对手在哪」的常识一致。
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import List, Tuple

from rtscontract.vec import Vec2

WALKABLE = 1
BLOCKED = 0


@dataclass
class NodeSpec:
    pos: Vec2
    amount: float
    max_workers: int
    site: int = -1


@dataclass
class SiteSpec:
    pos: Vec2
    node_indices: List[int] = field(default_factory=list)


@dataclass
class MapData:
    width: int
    height: int
    walkable: List[bytearray]
    nodes: List[NodeSpec]
    sites: List[SiteSpec]
    starts: List[Vec2]
    seed: int = 0
    layout: str = "open"


DEFAULT_SITES = (
    (0.15, 0.15),
    (0.15, 0.50),
    (0.50, 0.20),
    (0.50, 0.80),
    (0.85, 0.50),
    (0.85, 0.85),
)


def generate_map(
    seed: int,
    width: int = 96,
    height: int = 96,
    layout: str = "open",
    resources_per_node: float = 2400.0,
    node_slots: int = 5,
) -> MapData:
    """生成一张旋转对称地图。

    layout:
      - ``open``   : 少量岩石障碍，适合大军团会战
      - ``chokes`` : 更多障碍，形成若干通道
      - ``plain``  : 无障碍（用于纯数值验证）
    """
    rng = random.Random(seed ^ 0x5F3759DF)
    sites = [(int(fx * width), int(fy * height)) for fx, fy in DEFAULT_SITES]
    # 保证主基地/分矿严格对称
    sites[0] = (int(width * 0.14), int(height * 0.14))
    sites[5] = (width - 1 - sites[0][0], height - 1 - sites[0][1])
    sites[1] = (sites[0][0], height // 2)
    sites[4] = (width - 1 - sites[1][0], height - 1 - sites[1][1])
    sites[2] = (width // 2, int(height * 0.18))
    sites[3] = (width - 1 - sites[2][0], height - 1 - sites[2][1])

    for _attempt in range(12):
        grid = [bytearray([WALKABLE]) * width for _ in range(height)]
        _border(grid, width, height)
        if layout != "plain":
            blobs = 34 if layout == "chokes" else 22
            for _ in range(blobs):
                cx = rng.randrange(6, width - 6)
                cy = rng.randrange(6, height - 6)
                r = rng.randint(2, 4)
                _paint(grid, width, height, cx, cy, r, BLOCKED)
                _paint(grid, width, height, width - 1 - cx, height - 1 - cy, r, BLOCKED)
        # 保护区：基地与分矿周边必须开阔
        for i, (sx, sy) in enumerate(sites):
            _paint(grid, width, height, sx, sy, 9 if i in (0, 5) else 7, WALKABLE)

        if _connected(grid, width, height, sites):
            break
    else:
        grid = [bytearray([WALKABLE]) * width for _ in range(height)]
        _border(grid, width, height)

    nodes: List[NodeSpec] = []
    site_specs: List[SiteSpec] = []
    for i, (sx, sy) in enumerate(sites):
        spec = SiteSpec(Vec2(sx + 0.5, sy + 0.5))
        for k in range(2):
            nx = sx + (6.5 if k == 0 else -0.5)
            ny = sy + (0.5 if k == 0 else 6.5)
            ix, iy = int(nx), int(ny)
            if not (0 <= ix < width and 0 <= iy < height and grid[iy][ix]):
                nx, ny = sx + 1.5, sy + 1.5
            nodes.append(
                NodeSpec(
                    pos=Vec2(nx, ny),
                    amount=resources_per_node,
                    max_workers=node_slots,
                    site=i,
                )
            )
            spec.node_indices.append(len(nodes) - 1)
        site_specs.append(spec)

    starts = [Vec2(sites[0][0] + 0.5, sites[0][1] + 0.5), Vec2(sites[5][0] + 0.5, sites[5][1] + 0.5)]
    return MapData(
        width=width,
        height=height,
        walkable=grid,
        nodes=nodes,
        sites=site_specs,
        starts=starts,
        seed=seed,
        layout=layout,
    )


def _border(grid, width: int, height: int) -> None:
    for x in range(width):
        grid[0][x] = BLOCKED
        grid[height - 1][x] = BLOCKED
    for y in range(height):
        grid[y][0] = BLOCKED
        grid[y][width - 1] = BLOCKED


def _paint(grid, width: int, height: int, cx: int, cy: int, r: int, val: int) -> None:
    for y in range(max(1, cy - r), min(height - 1, cy + r + 1)):
        for x in range(max(1, cx - r), min(width - 1, cx + r + 1)):
            if (x - cx) ** 2 + (y - cy) ** 2 <= r * r:
                grid[y][x] = val


def _connected(grid, width: int, height: int, sites) -> bool:
    start = (sites[0][0], sites[0][1])
    if not grid[start[1]][start[0]]:
        return False
    seen = bytearray(width * height)
    stack = [start]
    seen[start[1] * width + start[0]] = 1
    while stack:
        x, y = stack.pop()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < width and 0 <= ny < height and not seen[ny * width + nx] and grid[ny][nx]:
                seen[ny * width + nx] = 1
                stack.append((nx, ny))
    for sx, sy in sites:
        if not grid[sy][sx]:
            return False
        if not seen[sy * width + sx]:
            return False
    return True

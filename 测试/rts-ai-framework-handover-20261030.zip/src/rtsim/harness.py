"""对局驱动：把 Sim + 若干 Agent 跑成一场可评测的比赛。"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Sequence

from .sim import Sim


@dataclass
class MatchResult:
    winner: int
    over: bool
    tick: int
    time: float
    samples: list[dict[str, Any]] = field(default_factory=list)
    suggestions: list[dict[str, Any]] = field(default_factory=list)
    sim_stats: dict[int, dict[str, int]] = field(default_factory=dict)
    commands: dict[int, int] = field(default_factory=dict)
    kills: dict[int, int] = field(default_factory=dict)
    losses: dict[int, int] = field(default_factory=dict)
    agent_stats: dict[int, dict[str, Any]] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)

    def series(self, key: str) -> list[float]:
        return [float(s.get(key) or 0.0) for s in self.samples]


class MatchRunner:
    def __init__(
        self,
        sim: Sim,
        agents: Mapping[int, Any] | None = None,
        ai_interval: int = 2,
        sample_interval: int = 10,
        scripts: Sequence[tuple[float, Callable[[Sim], None]]] = (),
    ) -> None:
        self.sim = sim
        self.agents = dict(agents or {})
        self.ai_interval = max(1, ai_interval)
        self.sample_interval = max(1, sample_interval)
        self.scripts = list(scripts)
        self._fired: set[int] = set()
        self.samples: list[dict[str, Any]] = []

    def run(self, duration: float | None = None, until_over: bool = True) -> MatchResult:
        sim = self.sim
        hz = sim.tick_hz
        max_ticks = int((duration or sim.cfg["max_time_seconds"]) * hz)
        self.samples = [sim.sample()]
        guard = 0
        while sim.tick < max_ticks:
            if until_over and sim.over:
                break
            sim.step()
            self._run_scripts()
            if sim.tick % self.ai_interval == 0:
                for team in sorted(self.agents):
                    agent = self.agents[team]
                    if agent is None:
                        continue
                    agent.update()
            if sim.tick % self.sample_interval == 0:
                self.samples.append(sim.sample())
            guard += 1
            if guard > 2_000_000:  # 防御性上限
                break
        if sim.tick % self.sample_interval != 0:
            self.samples.append(sim.sample())

        stats: dict[int, dict[str, Any]] = {}
        for team, agent in self.agents.items():
            if agent is not None and hasattr(agent, "stats"):
                stats[team] = dict(agent.stats())
        return MatchResult(
            winner=sim.winner,
            over=sim.over,
            tick=sim.tick,
            time=sim.time,
            samples=self.samples,
            suggestions=list(sim.suggestions),
            sim_stats={t: dict(sim.stats[t]) for t in (0, 1)},
            commands=dict(sim.command_count),
            kills=dict(sim.kills),
            losses=dict(sim.losses),
            agent_stats=stats,
        )

    def _run_scripts(self) -> None:
        t = self.sim.time
        for i, (when, fn) in enumerate(self.scripts):
            if i in self._fired:
                continue
            if t + 1e-9 >= when:
                self._fired.add(i)
                fn(self.sim)

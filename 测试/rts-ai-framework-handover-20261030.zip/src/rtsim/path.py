"""网格 A* 寻路（8 邻接，禁止穿角）。"""
from __future__ import annotations

import heapq
import math
from typing import List, Sequence, Tuple

from rtscontract.vec import Vec2

NEIGHBORS = (
    (1, 0, 1.0),
    (-1, 0, 1.0),
    (0, 1, 1.0),
    (0, -1, 1.0),
    (1, 1, 1.41421356),
    (1, -1, 1.41421356),
    (-1, 1, 1.41421356),
    (-1, -1, 1.41421356),
)


def find_path(
    walkable: Sequence[bytearray],
    width: int,
    height: int,
    start: Vec2,
    goal: Vec2,
    max_expand: int = 5000,
    max_path: int = 96,
) -> List[Vec2]:
    """返回从 start 到 goal 的路点列表（不含起点，含终点）。

    找不到路径时返回空列表（调用方退化为直线移动）。
    """
    sx, sy = int(start.x), int(start.y)
    gx, gy = int(goal.x), int(goal.y)
    if not (0 <= sx < width and 0 <= sy < height):
        return []
    if not (0 <= gx < width and 0 <= gy < height):
        return []

    def blocked(x: int, y: int) -> bool:
        return walkable[y][x] == 0

    if blocked(gx, gy):
        gx, gy = _nearest_open(walkable, width, height, gx, gy)
        if gx < 0:
            return []
    if (sx, sy) == (gx, gy):
        return [Vec2(gx + 0.5, gy + 0.5)]

    # 起点可能被建筑压住（极少见），放宽为允许离开
    open_heap: List[Tuple[float, int, int, int]] = []
    g_cost = {sy * width + sx: 0.0}
    parent: dict[int, int] = {}
    heapq.heappush(open_heap, (_h(sx, sy, gx, gy), 0, sx, sy))
    expanded = 0
    found = False

    while open_heap:
        _, g, x, y = heapq.heappop(open_heap)
        key = y * width + x
        if g > g_cost.get(key, 1e18) + 1e-9:
            continue
        if (x, y) == (gx, gy):
            found = True
            break
        expanded += 1
        if expanded > max_expand:
            break
        for dx, dy, cost in NEIGHBORS:
            nx, ny = x + dx, y + dy
            if not (0 <= nx < width and 0 <= ny < height):
                continue
            if blocked(nx, ny):
                continue
            if dx and dy:  # 禁止穿角
                if blocked(x + dx, y) or blocked(x, y + dy):
                    continue
            nk = ny * width + nx
            ng = g + cost
            if ng < g_cost.get(nk, 1e18) - 1e-9:
                g_cost[nk] = ng
                parent[nk] = key
                heapq.heappush(open_heap, (ng + _h(nx, ny, gx, gy), ng, nx, ny))

    if not found:
        return []

    cells: List[Tuple[int, int]] = []
    cur = gy * width + gx
    while cur != sy * width + sx:
        cells.append((cur % width, cur // width))
        p = parent.get(cur)
        if p is None:
            return []
        cur = p
    cells.reverse()

    pts = [Vec2(cx + 0.5, cy + 0.5) for cx, cy in cells]
    pts.append(Vec2(goal.x, goal.y))
    return _simplify(pts, walkable, width, height)[:max_path]


def _h(x: int, y: int, gx: int, gy: int) -> float:
    dx = abs(x - gx)
    dy = abs(y - gy)
    return (dx + dy) - 0.58578643 * min(dx, dy)


def _nearest_open(walkable, width, height, x: int, y: int) -> Tuple[int, int]:
    for r in range(1, 6):
        for dx in range(-r, r + 1):
            for dy in range(-r, r + 1):
                nx, ny = x + dx, y + dy
                if 0 <= nx < width and 0 <= ny < height and walkable[ny][nx]:
                    return nx, ny
    return -1, -1


def _simplify(pts: List[Vec2], walkable, width: int, height: int) -> List[Vec2]:
    """拉直路径：能直线到达就跳过中间点（减少抖动）。"""
    if len(pts) <= 2:
        return pts
    out: List[Vec2] = [pts[0]]
    i = 0
    n = len(pts)
    while i < n - 1:
        j = min(n - 1, i + 12)
        while j > i + 1 and not _clear_line(pts[i], pts[j], walkable, width, height):
            j -= 1
        out.append(pts[j])
        i = j
    # 保留首个锚点单元：它给出「绕开障碍的第一步方向」，丢掉会导致贴墙卡死
    return out


def _clear_line(a: Vec2, b: Vec2, walkable, width: int, height: int) -> bool:
    d = a.dist(b)
    steps = int(d / 0.5) + 1
    for s in range(1, steps):
        t = s / steps
        x = int(a.x + (b.x - a.x) * t)
        y = int(a.y + (b.y - a.y) * t)
        if not (0 <= x < width and 0 <= y < height) or walkable[y][x] == 0:
            return False
    return True


def path_length(start: Vec2, pts: Sequence[Vec2]) -> float:
    total = 0.0
    cur = start
    for p in pts:
        total += cur.dist(p)
        cur = p
    return total


def straight_line_clear(a: Vec2, b: Vec2, walkable, width: int, height: int) -> bool:
    return _clear_line(a, b, walkable, width, height)


def approx_travel_time(a: Vec2, b: Vec2, speed: float) -> float:
    return max(0.0, a.dist(b) / max(0.1, speed)) + 0.4 * math.sqrt(max(0.0, a.dist(b)))

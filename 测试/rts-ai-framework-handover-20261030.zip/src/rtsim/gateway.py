"""MockGateway：把 Sim 包装成 rtscontract.IGameGateway。

真实游戏接入时，需要写一个结构完全相同的适配器（见 docs/03-INTEGRATION-GUIDE.md），
把游戏引擎的查询/下达命令映射到这些方法上。
"""
from __future__ import annotations

from typing import Any, Mapping

from rtscontract.catalog import Catalog
from rtscontract.commands import Command, CommandResult, reject
from rtscontract.enums import Issuer, Reason
from rtscontract.snapshot import WorldSnapshot
from rtscontract.vec import Vec2

from .sim import Sim


class MockGateway:
    def __init__(
        self,
        sim: Sim,
        team: int,
        tick_hz: float | None = None,
        issuer: str = Issuer.ADJUTANT,
    ) -> None:
        self.sim = sim
        self.team = team
        self.issuer = issuer
        self._tick_hz = tick_hz or sim.tick_hz

    # ---------------- IGameGateway ----------------
    def snapshot(self) -> WorldSnapshot:
        return self.sim.snapshot(self.team)

    def issue(self, cmd: Command) -> CommandResult:
        if cmd.team != self.team:
            return reject(Reason.TEAM_MISMATCH, "命令阵营与网关不一致")
        return self.sim.issue(cmd)

    def can_place(self, proto_id: str, point: Vec2) -> bool:
        return self.sim.can_place(proto_id, point, self.team)

    def can_reach(self, unit_ids, point: Vec2) -> bool:
        """可选能力：这批单位能否走到该点（撤退/分矿选址用）。"""
        return self.sim.can_reach(unit_ids, point)

    def catalog(self) -> Catalog:
        return self.sim.cat

    def match_info(self) -> Mapping[str, Any]:
        return {
            "team": self.team,
            "tick_hz": self._tick_hz,
            "dt": 1.0 / self._tick_hz,
            "width": self.sim.width,
            "height": self.sim.height,
            "max_time": self.sim.cfg["max_time_seconds"],
            "seed": self.sim.seed,
            "impl": "mock",
        }

    def suggest(self, payload: Mapping[str, Any]) -> None:
        item = dict(payload)
        item.setdefault("team", self.team)
        item.setdefault("tick", self.sim.tick)
        self.sim.suggestions.append(item)

    def stats(self) -> Mapping[str, Any]:
        return {
            "rejected": dict(self.sim.stats[self.team]),
            "commands": self.sim.command_count[self.team],
            "kills": self.sim.kills[self.team],
            "losses": self.sim.losses[self.team],
        }

    # ---------------- 便捷（仅供考试/脚本使用，AI 不调用） ----------------
    def player_command(self, cmd: Command) -> CommandResult:
        return self.sim.player_command(cmd)

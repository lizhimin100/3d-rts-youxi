"""场景构建器：把「初始局势」描述变成可运行的 Sim。

考试用例通过本模块搭建场景（例如「敌方 6 只飞行单位突袭主基地」），
AI 本身完全不知道这些场景的存在。
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Iterable, Sequence

from rtscontract.catalog import Catalog
from rtscontract.vec import Vec2

from .mapgen import generate_map
from .sim import Sim


@dataclass
class ScenarioSpec:
    seed: int = 1
    layout: str = "open"
    width: int = 88
    height: int = 88
    start_gold: float = 520.0
    workers: int = 5
    enemy_workers: int = 5
    my_base: str = "townhall"        # townhall | none
    enemy_base: str = "townhall"     # townhall | weak | none
    my_units: tuple[tuple[str, int], ...] = ()
    enemy_units: tuple[tuple[str, int], ...] = ()
    enemy_near_me: bool = False
    my_buildings: tuple[str, ...] = ()
    enemy_buildings: tuple[str, ...] = ()
    require_both_teams: bool = True
    max_time: float = 600.0
    config: dict[str, Any] = field(default_factory=dict)


def build_sim(spec: ScenarioSpec, catalog: Catalog) -> Sim:
    mapdata = generate_map(spec.seed, spec.width, spec.height, layout=spec.layout)
    cfg = {
        "start_gold": spec.start_gold,
        "max_time_seconds": spec.max_time,
        "require_both_teams": spec.require_both_teams,
    }
    cfg.update(spec.config)
    sim = Sim(catalog, mapdata, cfg, seed=spec.seed)

    starts = mapdata.starts
    if spec.my_base != "none":
        _base(sim, 0, starts[0], spec.workers)
    if spec.enemy_base != "none":
        _base(sim, 1, starts[1], spec.enemy_workers)
        if spec.enemy_base == "weak":
            for b in list(sim.buildings):
                if b.team == 1:
                    b.hp = max(1.0, b.hp * 0.45)

    for bid in spec.my_buildings:
        _place_extra(sim, 0, bid, starts[0])
    for bid in spec.enemy_buildings:
        _place_extra(sim, 1, bid, starts[1])

    for proto, n in spec.my_units:
        _spawn_ring(sim, 0, proto, n, starts[0], 4.0)
    for proto, n in spec.enemy_units:
        center = _offset(starts[0], 9.0, 0.0) if spec.enemy_near_me else _offset(starts[1], 4.0, 0.0)
        _spawn_ring(sim, 1, proto, n, center, 3.0)

    sim._map_info = None
    sim.refresh_fog()
    return sim


def _base(sim: Sim, team: int, pos: Vec2, workers: int) -> None:
    sim.add_building("townhall", team, pos, complete=True)
    _spawn_ring(sim, team, "worker", workers, pos, 3.2)


def _place_extra(sim: Sim, team: int, proto_id: str, around: Vec2) -> None:
    proto = sim.cat.get(proto_id)
    for r in range(4, 12):
        for i in range(12):
            ang = 2 * math.pi * i / 12
            p = Vec2(around.x + math.cos(ang) * r, around.y + math.sin(ang) * r)
            if sim.can_place(proto_id, p, team):
                sim.add_building(proto_id, team, p, complete=True)
                return
    sim.add_building(proto_id, team, Vec2(around.x + 5.0, around.y + 5.0), complete=True)


def _spawn_ring(sim: Sim, team: int, proto_id: str, count: int, center: Vec2, radius: float) -> None:
    if count <= 0:
        return
    for i in range(count):
        ang = 2 * math.pi * i / max(1, count)
        r = radius + (i // 8) * 0.9
        p = Vec2(center.x + math.cos(ang) * r, center.y + math.sin(ang) * r)
        p = Vec2(min(max(p.x, 1.5), sim.width - 1.5), min(max(p.y, 1.5), sim.height - 1.5))
        sim.add_unit(proto_id, team, p)


def _offset(p: Vec2, dx: float, dy: float) -> Vec2:
    return Vec2(p.x + dx, p.y + dy)


def spawn_line(sim: Sim, team: int, proto_id: str, count: int, center: Vec2, step: float = 1.0) -> list[int]:
    """在指定位置排成一列，返回单位 id（供用例精确控制）。"""
    ids = []
    for i in range(count):
        p = Vec2(center.x + (i - count / 2.0) * step, center.y)
        u = sim.add_unit(proto_id, team, p)
        if u is not None:
            ids.append(u.id)
    return ids

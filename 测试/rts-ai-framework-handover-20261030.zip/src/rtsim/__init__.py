"""Mock RTS Simulator —— 无渲染、可确定性复现，用于验证 AI 战略逻辑。"""

from .gateway import MockGateway  # noqa: F401
from .harness import MatchResult, MatchRunner  # noqa: F401
from .mapgen import MapData, generate_map  # noqa: F401
from .scenarios import ScenarioSpec, build_sim, spawn_line  # noqa: F401
from .sim import Sim  # noqa: F401

__all__ = [
    "MockGateway",
    "MatchResult",
    "MatchRunner",
    "MapData",
    "generate_map",
    "ScenarioSpec",
    "build_sim",
    "spawn_line",
    "Sim",
]

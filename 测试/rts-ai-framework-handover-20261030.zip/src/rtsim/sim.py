"""Mock RTS Simulator —— 无渲染、定步长、可确定性复现。

设计约束
--------
* 不包含任何渲染 / 输入 / 引擎依赖，纯 Python 标准库，可用于批量跑考试。
* 模拟过程本身不使用随机数；地图生成使用 ``random.Random(seed)``（见 mapgen.py）。
* 与 AI 的唯一耦合是 ``rtscontract`` 中的快照/命令/控制权协议。
* 战斗、经济、迷雾都做了必要简化（见 docs/05-KNOWN-ISSUES.md），
  但保留了「克制矩阵 / 人口 / 采集饱和 / 视野」等影响 AI 决策的结构性要素。
"""
from __future__ import annotations

import math
from collections import defaultdict, deque
from dataclasses import replace
from typing import Any, Iterable, Mapping, Sequence

from rtscontract.catalog import Catalog, Proto
from rtscontract.commands import Command, CommandResult, OK, reject
from rtscontract.control import ControlRegistry
from rtscontract.enums import (
    ACTIVE_ORDER_KINDS,
    AI_ISSUERS,
    ALL_CMDS,
    Cmd,
    ControlKind,
    EventKind,
    Issuer,
    OrderKind,
    PLAYER_ONLY_CMDS,
    PROTECTED_CONTROL,
    Reason,
)
from rtscontract.snapshot import (
    BuildingInfo,
    EventInfo,
    ExpansionSite,
    FogInfo,
    Intent,
    MapInfo,
    NodeInfo,
    PlayerInfo,
    UnitInfo,
    WorldSnapshot,
)
from rtscontract.vec import Vec2

from .mapgen import MapData
from .path import find_path, straight_line_clear

ONE_SHOT_ORDERS = frozenset(
    {OrderKind.MOVE, OrderKind.ATTACK, OrderKind.ATTACK_MOVE, OrderKind.HOLD, OrderKind.PATROL}
)


class SimUnit:
    __slots__ = (
        "id", "proto", "team", "pos", "hp", "order", "target", "point", "owner",
        "path", "path_i", "cd", "carry", "node", "dropoff", "site", "gather_t",
        "order_tick", "alive", "radius", "last_pos", "stuck_t", "stuck", "hit_t",
        "phase", "home", "path_t",
    )

    def __init__(self, uid: int, proto: Proto, team: int, pos: Vec2) -> None:
        self.id = uid
        self.proto = proto
        self.team = team
        self.pos = pos
        self.hp = proto.hp
        self.order = OrderKind.IDLE
        self.target: int | None = None
        self.point: Vec2 | None = None
        self.owner = ""
        self.path: list[Vec2] = []
        self.path_i = 0
        self.cd = 0.0
        self.carry = 0.0
        self.node: int | None = None
        self.dropoff: int | None = None
        self.site: int | None = None
        self.gather_t = 0.0
        self.order_tick = 0
        self.alive = True
        self.radius = proto.radius
        self.last_pos = pos
        self.stuck_t = 0.0
        self.stuck = False
        self.hit_t = -999.0
        self.phase = 0
        self.home: int | None = None
        self.path_t = -999.0

    @property
    def flying(self) -> bool:
        return self.proto.flying


class SimBuilding:
    __slots__ = ("id", "proto", "team", "pos", "hp", "complete", "progress", "builders",
                 "queue", "rally", "prod_t", "blocked", "cd", "target", "alive", "radius", "hit_t")

    def __init__(self, bid: int, proto: Proto, team: int, pos: Vec2, complete: bool = True) -> None:
        self.id = bid
        self.proto = proto
        self.team = team
        self.pos = pos
        self.hp = proto.hp if complete else max(1.0, proto.hp * 0.12)
        self.complete = complete
        self.progress = 1.0 if complete else 0.0
        self.builders: set[int] = set()
        self.queue: list[list[Any]] = []          # [proto_id, remaining, supply_cost]
        self.rally: Vec2 | None = None
        self.prod_t = 0.0
        self.blocked = False
        self.cd = 0.0
        self.target: int | None = None
        self.alive = True
        self.radius = proto.radius
        self.hit_t = -999.0

    @property
    def flying(self) -> bool:
        return False


class SimNode:
    __slots__ = ("id", "pos", "remaining", "max_workers", "workers", "site", "kind")

    def __init__(self, nid: int, pos: Vec2, amount: float, max_workers: int, site: int = -1,
                 kind: str = "gold") -> None:
        self.id = nid
        self.pos = pos
        self.remaining = amount
        self.max_workers = max_workers
        self.workers: set[int] = set()
        self.site = site
        self.kind = kind


DEFAULT_CONFIG: dict[str, Any] = {
    "tick_hz": 10.0,
    "start_gold": 520.0,
    "start_workers": 5,
    "manual_ttl_seconds": 8.0,
    # Player Intent Ownership：命令结束后给 5 秒宽限；STOP 后保持 30 秒；
    # 单条命令最长 ACTIVE 120 秒（防止玩家忘了松手导致 AI 永久瘫痪）。
    "grace_seconds": 5.0,
    "hold_after_stop_seconds": 30.0,
    "active_max_seconds": 120.0,
    "protect_active_player_orders": True,
    "max_units_per_team": 220,
    "max_time_seconds": 900.0,
    "fog_interval_ticks": 2,
    "path_budget_per_tick": 64,
    "gather_range": 1.35,
    "dropoff_range": 2.6,
    "build_speed_cap": 3,
}


class Sim:
    """一场对局的完整状态机。"""

    def __init__(
        self,
        catalog: Catalog,
        mapdata: MapData,
        config: Mapping[str, Any] | None = None,
        seed: int = 0,
    ) -> None:
        self.cat = catalog
        self.map = mapdata
        self.cfg = dict(DEFAULT_CONFIG)
        self.cfg.update(config or {})
        self.seed = seed
        self.dt = 1.0 / float(self.cfg["tick_hz"])
        self.tick_hz = float(self.cfg["tick_hz"])
        self.tick = 0
        self.time = 0.0

        w, h = mapdata.width, mapdata.height
        self.width = w
        self.height = h

        self.gold: dict[int, float] = {0: float(self.cfg["start_gold"]), 1: float(self.cfg["start_gold"])}
        self.units: list[SimUnit] = []
        self.buildings: list[SimBuilding] = []
        self.nodes: list[SimNode] = []
        self.ents: dict[int, Any] = {}
        self._next_id = 1

        self.control = ControlRegistry(
            manual_ttl_seconds=float(self.cfg["manual_ttl_seconds"]),
            tick_hz=self.tick_hz,
            grace_seconds=float(self.cfg["grace_seconds"]),
            hold_after_stop_seconds=float(self.cfg["hold_after_stop_seconds"]),
            active_max_seconds=float(self.cfg["active_max_seconds"]),
        )
        self.control.set_default(0, ControlKind.ADJUTANT)
        self.control.set_default(1, ControlKind.AUTONOMOUS)

        self._events: dict[int, list[EventInfo]] = {0: [], 1: []}
        self._vis = {0: bytearray(w * h), 1: bytearray(w * h)}
        self._explored = {0: bytearray(w * h), 1: bytearray(w * h)}
        self._explored_count = {0: 0, 1: 0}
        self._macro_counts = {0: [0] * 144, 1: [0] * 144}
        self._blocked = bytearray(w * h)
        walk_count = sum(1 for y in range(h) for x in range(w) if mapdata.walkable[y][x])
        self._walk_count = max(1, walk_count)

        self._supply_used = {0: 0.0, 1: 0.0}
        self._supply_cap = {0: 0.0, 1: 0.0}
        self._pending: list[tuple[Any, float, Any]] = []
        self._path_budget = int(self.cfg["path_budget_per_tick"])
        self._bucket: dict[tuple[int, int], list[Any]] = {}

        self.kills = {0: 0, 1: 0}
        self.losses = {0: 0, 1: 0}
        self.worker_losses = {0: 0, 1: 0}
        self.income_total = {0: 0.0, 1: 0.0}
        self.damage_dealt = {0: 0.0, 1: 0.0}
        self.stats: dict[int, dict[str, int]] = {0: defaultdict(int), 1: defaultdict(int)}
        self.command_count = {0: 0, 1: 0}
        self.orders_log: deque = deque(maxlen=40000)

        self.players: dict[int, dict[str, Any]] = {
            0: {"selected": set(), "intents": deque(maxlen=16), "autonomy": {}, "presence": False},
            1: {"selected": set(), "intents": deque(maxlen=16), "autonomy": {}, "presence": False},
        }
        self.suggestions: list[dict[str, Any]] = []

        self.over = False
        self.winner = -1
        self._map_info: MapInfo | None = None

        for i, spec in enumerate(mapdata.nodes):
            node = SimNode(i + 1, spec.pos, spec.amount, spec.max_workers, spec.site)
            self.nodes.append(node)
            self.ents[node.id] = node
            self._next_id = max(self._next_id, node.id + 1)

        self._update_fog()

    # ------------------------------------------------------------------ 构建
    def add_unit(self, proto_id: str, team: int, pos: Vec2, issuer: str = Issuer.SYSTEM) -> SimUnit:
        proto = self.cat.get(proto_id)
        if len(self._units_of(team)) >= int(self.cfg["max_units_per_team"]):
            return None  # type: ignore[return-value]
        uid = self._new_id()
        u = SimUnit(uid, proto, team, self._nearest_walkable(Vec2(pos.x, pos.y)))
        self.units.append(u)
        self.ents[uid] = u
        self._supply_used[team] += proto.cost.supply
        self.control.register(uid, team)
        del issuer
        return u

    def add_building(self, proto_id: str, team: int, pos: Vec2, complete: bool = True) -> SimBuilding:
        proto = self.cat.get(proto_id)
        bid = self._new_id()
        b = SimBuilding(bid, proto, team, Vec2(pos.x, pos.y), complete=complete)
        self.buildings.append(b)
        self.ents[bid] = b
        if complete:
            self._supply_cap[team] += proto.supply_provided
            self._mark_footprint(b, 1)
        else:
            self._mark_footprint(b, 0)
        self._map_info = None      # 分矿归属/余量会变，缓存必须失效
        return b

    def _new_id(self) -> int:
        nid = self._next_id
        self._next_id += 1
        return nid

    def _units_of(self, team: int) -> list[SimUnit]:
        return [u for u in self.units if u.alive and u.team == team]

    # ------------------------------------------------------------------ 地形
    def _mark_footprint(self, b: SimBuilding, val: int) -> None:
        fw, fh = b.proto.footprint
        x0 = int(round(b.pos.x - fw / 2.0))
        y0 = int(round(b.pos.y - fh / 2.0))
        for yy in range(y0, y0 + fh):
            if not (0 <= yy < self.height):
                continue
            for xx in range(x0, x0 + fw):
                if 0 <= xx < self.width:
                    self._blocked[yy * self.width + xx] = val

    def _footprint_tiles(self, proto: Proto, pos: Vec2):
        fw, fh = proto.footprint
        x0 = int(round(pos.x - fw / 2.0))
        y0 = int(round(pos.y - fh / 2.0))
        for yy in range(y0, y0 + fh):
            for xx in range(x0, x0 + fw):
                yield xx, yy

    def can_place(self, proto_id: str, point: Vec2, team: int = 0) -> bool:
        proto = self.cat.get(proto_id)
        if not proto.is_building:
            return False
        del team
        for xx, yy in self._footprint_tiles(proto, point):
            if not (0 <= xx < self.width and 0 <= yy < self.height):
                return False
            if self.map.walkable[yy][xx] == 0:
                return False
            if self._blocked[yy * self.width + xx]:
                return False
        # 不能压在资源点上
        for n in self.nodes:
            if n.remaining <= 0:
                continue
            if abs(n.pos.x - point.x) <= proto.footprint[0] / 2 + 1.2 and abs(
                n.pos.y - point.y
            ) <= proto.footprint[1] / 2 + 1.2:
                return False
        return True

    # ------------------------------------------------------------------ 视野
    def _update_fog(self) -> None:
        for team in (0, 1):
            vis = self._vis[team]
            vis[:] = bytes(len(vis))
            expl = self._explored[team]
            for u in self.units:
                if u.alive and u.team == team:
                    self._paint_vision(team, vis, expl, u.pos, u.proto.sight)
            for b in self.buildings:
                if b.alive and b.team == team and b.complete:
                    self._paint_vision(team, vis, expl, b.pos, b.proto.sight)

    def _paint_vision(self, team: int, vis: bytearray, expl: bytearray, pos: Vec2, sight: float) -> None:
        r = int(math.ceil(sight))
        cx, cy = int(pos.x), int(pos.y)
        w, h = self.width, self.height
        r2 = sight * sight
        macro = self._macro_counts[team]
        mw = 12
        mh = 12
        count = self._explored_count[team]
        for yy in range(max(0, cy - r), min(h, cy + r + 1)):
            dy = yy - cy
            row = yy * w
            my = min(mh - 1, int(yy / h * mh))
            for xx in range(max(0, cx - r), min(w, cx + r + 1)):
                dx = xx - cx
                if dx * dx + dy * dy <= r2:
                    vis[row + xx] = 1
                    if expl[row + xx] == 0:
                        expl[row + xx] = 1
                        count += 1
                        mx = min(mw - 1, int(xx / w * mw))
                        macro[my * mw + mx] += 1
        self._explored_count[team] = count

    def refresh_fog(self) -> None:
        """场景构建/传送后强制刷新视野（仅供模拟器初始化使用）。"""
        self._update_fog()

    def _visible(self, team: int, pos: Vec2) -> bool:
        x = int(pos.x)
        y = int(pos.y)
        if not (0 <= x < self.width and 0 <= y < self.height):
            return False
        return self._vis[team][y * self.width + x] == 1

    def _explored_at(self, team: int, pos: Vec2) -> bool:
        x = int(pos.x)
        y = int(pos.y)
        if not (0 <= x < self.width and 0 <= y < self.height):
            return False
        return self._explored[team][y * self.width + x] == 1

    # ------------------------------------------------------------------ 命令
    def issue(self, cmd: Command) -> CommandResult:
        if cmd.kind not in ALL_CMDS:
            return reject(Reason.INVALID, f"未知命令 {cmd.kind}")
        if cmd.kind in PLAYER_ONLY_CMDS and cmd.issuer != Issuer.PLAYER:
            return reject(Reason.INVALID, "该命令仅限玩家")

        units: list[SimUnit] = []
        for uid in cmd.units:
            u = self.ents.get(uid)
            if not isinstance(u, SimUnit) or not u.alive:
                return reject(Reason.TARGET_INVALID, f"单位 {uid} 不存在")
            if u.team != cmd.team:
                return reject(Reason.NOT_OWNED, f"单位 {uid} 不属于该阵营")
            if cmd.issuer in AI_ISSUERS:
                blocked, why = self._ai_blocked(u)
                if blocked:
                    self.stats[cmd.team]["control_blocked"] += 1
                    return reject(Reason.LOCKED if why != "order" else Reason.PLAYER_ORDER_ACTIVE, why)
            units.append(u)

        if cmd.issuer in AI_ISSUERS:
            self.command_count[cmd.team] += 1

        handler = {
            Cmd.MOVE: self._cmd_move,
            Cmd.ATTACK: self._cmd_attack,
            Cmd.ATTACK_MOVE: self._cmd_attack_move,
            Cmd.HOLD: self._cmd_hold,
            Cmd.STOP: self._cmd_stop,
            Cmd.HARVEST: self._cmd_harvest,
            Cmd.BUILD: self._cmd_build,
            Cmd.ASSIST: self._cmd_assist,
            Cmd.TRAIN: self._cmd_train,
            Cmd.CANCEL_TRAIN: self._cmd_cancel_train,
            Cmd.SET_RALLY: self._cmd_set_rally,
            Cmd.REPAIR: self._cmd_repair,
            Cmd.LOCK: self._cmd_lock,
            Cmd.UNLOCK: self._cmd_unlock,
            Cmd.GRANT: self._cmd_grant,
            Cmd.SELECT: self._cmd_select,
        }.get(cmd.kind)
        if handler is None:
            return reject(Reason.INVALID, f"未实现 {cmd.kind}")
        return handler(cmd, units)

    def _ai_blocked(self, u: SimUnit) -> tuple[bool, str]:
        ok, why = self.control.allows(u.id, self.tick, Issuer.ADJUTANT)
        if not ok:
            return True, why
        # 兜底：玩家订单仍在执行，但注册表没记录（例如脚本直接改了单位状态）。
        # 注意：这里**不再**有「18 秒上限」——一句 25 秒的绕后命令不该在第 18 秒被抢。
        if (
            self.cfg.get("protect_active_player_orders", True)
            and u.owner == Issuer.PLAYER
            and u.order in ONE_SHOT_ORDERS
            and self.control.kind_of(u.id) not in PROTECTED_CONTROL
        ):
            return True, "order"
        return False, ""

    # ---------------- 移动/攻击 ----------------
    def _cmd_move(self, cmd: Command, units: list[SimUnit]) -> CommandResult:
        if cmd.point is None:
            return reject(Reason.INVALID, "缺少目标点")
        for u in units:
            self._release_harvest(u)
            self._set_order(u, OrderKind.MOVE, point=cmd.point, owner=cmd.issuer, path_to=cmd.point)
        return OK

    def _cmd_attack_move(self, cmd: Command, units: list[SimUnit]) -> CommandResult:
        if cmd.point is None:
            return reject(Reason.INVALID, "缺少目标点")
        for u in units:
            if u.proto.attack is None:
                continue
            self._release_harvest(u)
            self._set_order(u, OrderKind.ATTACK_MOVE, point=cmd.point, owner=cmd.issuer, path_to=cmd.point)
        return OK

    def _cmd_attack(self, cmd: Command, units: list[SimUnit]) -> CommandResult:
        tgt = self.ents.get(cmd.target) if cmd.target is not None else None
        if tgt is None or not getattr(tgt, "alive", False):
            return reject(Reason.TARGET_INVALID, "目标不存在")
        if tgt.team == cmd.team:
            return reject(Reason.TARGET_INVALID, "不能攻击友军")
        if cmd.issuer in AI_ISSUERS and not self._visible(cmd.team, tgt.pos):
            self.stats[cmd.team]["cheat_attempts"] += 1
            return reject(Reason.TARGET_NOT_VISIBLE, "目标在战争迷雾中")
        if all(u.proto.attack is None or not u.proto.attack.can_hit(tgt.flying) for u in units):
            return reject(Reason.TARGET_INVALID, "无法攻击该目标类型")
        for u in units:
            if u.proto.attack is None or not u.proto.attack.can_hit(tgt.flying):
                continue
            self._release_harvest(u)
            self._set_order(u, OrderKind.ATTACK, target=tgt.id, owner=cmd.issuer, path_to=tgt.pos)
        return OK

    def _cmd_hold(self, cmd: Command, units: list[SimUnit]) -> CommandResult:
        for u in units:
            self._release_harvest(u)
            self._set_order(u, OrderKind.HOLD, point=u.pos, owner=cmd.issuer)
        return OK

    def _cmd_stop(self, cmd: Command, units: list[SimUnit]) -> CommandResult:
        for u in units:
            self._release_harvest(u)
            self._set_order(u, OrderKind.IDLE, owner=cmd.issuer)
        return OK

    def _cmd_harvest(self, cmd: Command, units: list[SimUnit]) -> CommandResult:
        node = self.ents.get(cmd.target) if cmd.target is not None else None
        if not isinstance(node, SimNode) or node.remaining <= 0:
            return reject(Reason.TARGET_INVALID, "资源点无效")
        dropoff_id = int(cmd.extra[0]) if cmd.extra else None
        for u in units:
            if u.proto.harvest is None:
                return reject(Reason.INVALID, "该单位不能采集")
            if u.node != node.id and len(node.workers) >= node.max_workers:
                return reject(Reason.NODE_FULL, "资源点已满")
        for u in units:
            if u.proto.harvest is None:
                continue
            self._release_harvest(u)
            node.workers.add(u.id)
            u.node = node.id
            u.home = node.id
            u.dropoff = dropoff_id or self._nearest_dropoff(u.team, node.pos)
            u.phase = 0
            self._set_order(u, OrderKind.HARVEST, target=node.id, point=node.pos, owner=cmd.issuer, path_to=node.pos)
        return OK

    def _cmd_build(self, cmd: Command, units: list[SimUnit]) -> CommandResult:
        if cmd.proto is None or cmd.point is None:
            return reject(Reason.INVALID, "缺少建筑或位置")
        if not self.cat.has(cmd.proto):
            return reject(Reason.INVALID, "未知建筑")
        proto = self.cat.get(cmd.proto)
        workers = [u for u in units if u.proto.harvest is not None]
        if not workers:
            return reject(Reason.INVALID, "没有农民")
        if not any(w.proto.tags_any(proto.built_by) for w in workers):
            return reject(Reason.INVALID, "该单位不能建造此建筑")
        if not self.cat.tech_satisfied(proto, self._completed_protos(cmd.team)):
            return reject(Reason.TECH_MISSING, "科技不足")
        if self.gold[cmd.team] < proto.cost.gold - 1e-9:
            return reject(Reason.NO_RESOURCES, "金币不足")
        if not self.can_place(cmd.proto, cmd.point, cmd.team):
            return reject(Reason.PLACE_INVALID, "此处不能建造")

        self.gold[cmd.team] -= proto.cost.gold
        b = self.add_building(cmd.proto, cmd.team, cmd.point, complete=False)
        builder = workers[0]
        self._release_harvest(builder)
        b.builders.add(builder.id)
        builder.site = b.id
        self._set_order(builder, OrderKind.BUILD, target=b.id, point=cmd.point, owner=cmd.issuer, path_to=cmd.point)
        for w in workers[1:]:
            if len(b.builders) >= int(self.cfg["build_speed_cap"]):
                break
            self._release_harvest(w)
            b.builders.add(w.id)
            w.site = b.id
            self._set_order(w, OrderKind.BUILD, target=b.id, point=cmd.point, owner=cmd.issuer, path_to=cmd.point)
        self._emit(EventKind.BUILDING_STARTED, b.pos, subject=b.id, team=cmd.team, proto=b.proto.id)
        return OK

    def _cmd_assist(self, cmd: Command, units: list[SimUnit]) -> CommandResult:
        b = self.ents.get(cmd.building) if cmd.building is not None else None
        if not isinstance(b, SimBuilding) or b.team != cmd.team or not b.alive:
            return reject(Reason.TARGET_INVALID, "建筑无效")
        if b.complete:
            return reject(Reason.NOT_READY, "建筑已完工")
        workers = [u for u in units if u.proto.harvest is not None]
        if not workers:
            return reject(Reason.INVALID, "没有农民")
        cap = int(self.cfg["build_speed_cap"])
        for w in workers:
            if len(b.builders) >= cap:
                break
            self._release_harvest(w)
            b.builders.add(w.id)
            w.site = b.id
            self._set_order(w, OrderKind.BUILD, target=b.id, point=b.pos, owner=cmd.issuer, path_to=b.pos)
        return OK

    def _cmd_train(self, cmd: Command, units: list[SimUnit]) -> CommandResult:
        b = self.ents.get(cmd.building) if cmd.building is not None else None
        if not isinstance(b, SimBuilding) or not b.alive:
            return reject(Reason.TARGET_INVALID, "建筑不存在")
        if b.team != cmd.team:
            return reject(Reason.NOT_OWNED, "建筑不属于该阵营")
        if not b.complete:
            return reject(Reason.NOT_READY, "建筑未完工")
        proto_id = cmd.proto or ""
        if proto_id not in b.proto.produce:
            return reject(Reason.INVALID, "该建筑不能生产此单位")
        proto = self.cat.get(proto_id)
        if not self.cat.tech_satisfied(proto, self._completed_protos(cmd.team)):
            return reject(Reason.TECH_MISSING, "科技不足")
        if len(b.queue) >= b.proto.max_queue:
            return reject(Reason.QUEUE_FULL, "队列已满")
        if self.gold[cmd.team] < proto.cost.gold - 1e-9:
            return reject(Reason.NO_RESOURCES, "金币不足")
        queued_supply = sum(q[2] for q in b.queue)
        used = self._supply_used[cmd.team] + queued_supply
        if used + proto.cost.supply > self._supply_cap[cmd.team] + 1e-9:
            self.stats[cmd.team]["supply_rejected"] += 1
            return reject(Reason.NO_SUPPLY, "人口不足")
        self.gold[cmd.team] -= proto.cost.gold
        b.queue.append([proto_id, proto.build_time, proto.cost.supply])
        return OK

    def _cmd_cancel_train(self, cmd: Command, units: list[SimUnit]) -> CommandResult:
        b = self.ents.get(cmd.building) if cmd.building is not None else None
        if not isinstance(b, SimBuilding) or b.team != cmd.team:
            return reject(Reason.TARGET_INVALID, "建筑无效")
        if not b.queue:
            return reject(Reason.INVALID, "队列为空")
        proto_id, remaining, supply = b.queue.pop()
        proto = self.cat.get(proto_id)
        self.gold[cmd.team] += proto.cost.gold * 0.75
        del remaining, supply
        return OK

    def _cmd_set_rally(self, cmd: Command, units: list[SimUnit]) -> CommandResult:
        b = self.ents.get(cmd.building) if cmd.building is not None else None
        if not isinstance(b, SimBuilding) or b.team != cmd.team:
            return reject(Reason.TARGET_INVALID, "建筑无效")
        b.rally = cmd.point
        return OK

    def _cmd_repair(self, cmd: Command, units: list[SimUnit]) -> CommandResult:
        return reject(Reason.INVALID, "repair 尚未实现（见待接入清单）")

    # ---------------- 控制权（仅玩家） ----------------
    def _cmd_lock(self, cmd: Command, units: list[SimUnit]) -> CommandResult:
        self.control.lock([u.id for u in units], self.tick)
        return OK

    def _cmd_unlock(self, cmd: Command, units: list[SimUnit]) -> CommandResult:
        self.control.unlock([u.id for u in units], self.tick)
        return OK

    def _cmd_grant(self, cmd: Command, units: list[SimUnit]) -> CommandResult:
        self.control.grant([u.id for u in units])
        return OK

    def _cmd_select(self, cmd: Command, units: list[SimUnit]) -> CommandResult:
        self.players[cmd.team]["selected"] = {u.id for u in units}
        return OK

    # ------------------------------------------------------------------ 内部：订单
    def _set_order(
        self,
        u: SimUnit,
        order: str,
        target: int | None = None,
        point: Vec2 | None = None,
        owner: str = "",
        path_to: Vec2 | None = None,
    ) -> None:
        u.order = order
        u.target = target
        u.point = point
        u.owner = owner
        u.order_tick = self.tick
        # 订单日志只记录「有意义的命令」：状态机自然回落到 idle 不算某方下令
        self.orders_log.append(
            (self.tick, u.id, order, "sim" if order == OrderKind.IDLE else owner)
        )
        u.path = []
        u.path_i = 0
        u.stuck = False
        u.stuck_t = 0.0
        if path_to is not None:
            u.path = self._path(u.pos, path_to)

    def _path(self, a: Vec2, b: Vec2) -> list[Vec2]:
        if straight_line_clear(a, b, self.map.walkable, self.width, self.height):
            return []
        if self._path_budget <= 0:
            return []
        self._path_budget -= 1
        return find_path(self.map.walkable, self.width, self.height, a, b)

    def _release_harvest(self, u: SimUnit) -> None:
        if u.node is not None:
            node = self.ents.get(u.node)
            if isinstance(node, SimNode):
                node.workers.discard(u.id)
            u.node = None
        u.carry = u.carry if u.order == OrderKind.HARVEST else u.carry
        u.gather_t = 0.0
        if u.site is not None:
            b = self.ents.get(u.site)
            if isinstance(b, SimBuilding):
                b.builders.discard(u.id)
            u.site = None

    # ------------------------------------------------------------------ 内部：每帧
    def step(self) -> None:
        if self.over:
            return
        self.tick += 1
        self.time += self.dt
        # 先把上一 tick 结束时的订单状态交给控制权注册表，
        # 由它按「命令组」判定玩家命令是否整体结束（组内全 idle 才算结束）。
        self.control.tick(
            self.tick,
            {u.id: u.order for u in self.units if u.alive},
        )
        self._path_budget = int(self.cfg["path_budget_per_tick"])
        self._pending.clear()
        self._rebuild_buckets()

        for b in self.buildings:
            if b.alive:
                self._update_building(b)
        for u in self.units:
            if u.alive:
                self._update_unit(u)
        self._apply_damage()
        self._cleanup()
        if self.tick % int(self.cfg["fog_interval_ticks"]) == 0:
            self._update_fog()
        self._check_over()

    # ---------------- 单位 ----------------
    def _update_unit(self, u: SimUnit) -> None:
        dt = self.dt
        if u.cd > 0:
            u.cd = max(0.0, u.cd - dt)
        # 卡住检测
        moved = u.pos.dist(u.last_pos)
        if moved > 0.02:
            u.last_pos = u.pos
            u.stuck_t = 0.0
            u.stuck = False
        elif u.order in (OrderKind.MOVE, OrderKind.ATTACK_MOVE):
            u.stuck_t += dt
            if u.stuck_t > 1.2:
                u.stuck = True

        order = u.order
        if order == OrderKind.HARVEST:
            self._update_harvest(u)
        elif order == OrderKind.BUILD:
            self._update_builder(u)
        elif order == OrderKind.ATTACK:
            self._update_attack(u)
        elif order == OrderKind.ATTACK_MOVE:
            self._update_attack_move(u)
        elif order == OrderKind.MOVE:
            if self._advance(u, u.point, 0.15):
                self._set_order(u, OrderKind.IDLE, owner=u.owner)
        elif order == OrderKind.HOLD:
            tgt = self._acquire(u, u.proto.attack.range if u.proto.attack else 0.0)
            if tgt is not None:
                self._try_hit(u, tgt)
        # IDLE / STOP：不自动攻击

    def _update_builder(self, u: SimUnit) -> None:
        b = self.ents.get(u.target) if u.target is not None else None
        if not isinstance(b, SimBuilding) or not b.alive or b.complete:
            self._set_order(u, OrderKind.IDLE, owner=u.owner)
            return
        if u.pos.dist(b.pos) > b.radius + 1.0:
            self._advance(u, b.pos, b.radius + 0.9)

    def _update_harvest(self, u: SimUnit) -> None:
        node = self.ents.get(u.node) if u.node is not None else None
        if not isinstance(node, SimNode) or node.remaining <= 0:
            node2 = self._nearest_node(u.pos)
            if node2 is None:
                self._set_order(u, OrderKind.IDLE, owner=u.owner)
                return
            self._release_harvest(u)
            node2.workers.add(u.id)
            u.node = node2.id
            u.phase = 0
            u.point = node2.pos
            u.path = self._path(u.pos, node2.pos)
            u.path_i = 0
            return

        cap = u.proto.harvest.carry if u.proto.harvest else 8.0
        if u.carry >= cap - 1e-6:
            # 返回最近回收点
            b = self.ents.get(u.dropoff) if u.dropoff is not None else None
            if not isinstance(b, SimBuilding) or not b.alive or not b.complete:
                did = self._nearest_dropoff(u.team, u.pos)
                u.dropoff = did
                b = self.ents.get(did) if did is not None else None
            if not isinstance(b, SimBuilding):
                self._set_order(u, OrderKind.IDLE, owner=u.owner)
                return
            if u.pos.dist(b.pos) <= self.cfg["dropoff_range"] + b.radius:
                self.gold[u.team] += u.carry
                self.income_total[u.team] += u.carry
                u.carry = 0.0
                u.phase = 0
                u.path = self._path(u.pos, node.pos)
                u.path_i = 0
            else:
                u.phase = 1
                self._advance(u, b.pos, b.radius + self.cfg["dropoff_range"] * 0.8)
            return

        if u.pos.dist(node.pos) <= self.cfg["gather_range"]:
            u.gather_t += self.dt
            if u.gather_t >= (u.proto.harvest.gather_time if u.proto.harvest else 2.0):
                u.gather_t = 0.0
                take = min(cap - u.carry, node.remaining, cap)
                u.carry += take
                node.remaining -= take
                if node.remaining <= 0:
                    self._emit(EventKind.RESOURCE_DEPLETED, node.pos, subject=node.id, team=u.team)
        else:
            self._advance(u, node.pos, self.cfg["gather_range"] * 0.7)

    def _update_attack(self, u: SimUnit) -> None:
        tgt = self.ents.get(u.target) if u.target is not None else None
        if tgt is None or not getattr(tgt, "alive", False) or tgt.team == u.team:
            self._set_order(u, OrderKind.IDLE, owner=u.owner)
            return
        atk = u.proto.attack
        if atk is None:
            self._set_order(u, OrderKind.IDLE, owner=u.owner)
            return
        gap = u.pos.dist(tgt.pos) - u.radius - tgt.radius
        if gap <= atk.range:
            self._try_hit(u, tgt)
        else:
            self._advance(u, tgt.pos, max(0.1, atk.range * 0.85 + u.radius + tgt.radius - 0.2), chase=True)

    def _update_attack_move(self, u: SimUnit) -> None:
        atk = u.proto.attack
        tgt = None
        if atk is not None:
            tgt = self._acquire(u, max(4.0, atk.range + 3.5))
        if tgt is not None:
            gap = u.pos.dist(tgt.pos) - u.radius - tgt.radius
            if gap <= atk.range:
                self._try_hit(u, tgt)
            else:
                self._advance(u, tgt.pos, max(0.1, atk.range * 0.85 + u.radius + tgt.radius - 0.2), chase=True)
            return
        if self._advance(u, u.point, 0.4):
            self._set_order(u, OrderKind.IDLE, owner=u.owner)

    def _advance(self, u: SimUnit, point: Vec2 | None, stop_dist: float, chase: bool = False) -> bool:
        if point is None:
            return True
        # 逐个消费已到达的路点（路点阈值必须小，stop_dist 只对最终目标生效）
        while u.path and u.path_i < len(u.path):
            wp = u.path[u.path_i]
            if u.pos.dist(wp) <= 0.35:
                u.path_i += 1
            else:
                break
        if u.path and u.path_i < len(u.path):
            target = u.path[u.path_i]
            final = False
        else:
            target = point
            final = True
        d = u.pos.dist(target)
        if final and d <= stop_dist:
            return True
        if not final and d <= 0.02:
            u.path_i += 1
            return False
        step = u.proto.speed * self.dt
        if step <= 0:
            return False
        newpos = u.pos.toward(target, step)
        if self._walkable_pos(newpos):
            u.pos = newpos
            return False
        # 简单贴墙滑行
        slid = Vec2(newpos.x, u.pos.y)
        if self._walkable_pos(slid) and abs(newpos.x - u.pos.x) > 1e-6:
            u.pos = slid
            return False
        slid = Vec2(u.pos.x, newpos.y)
        if self._walkable_pos(slid) and abs(newpos.y - u.pos.y) > 1e-6:
            u.pos = slid
            return False
        # 被挡住：限频重寻路（chase 也允许，否则会顶墙站死）
        if self.time - u.path_t > 0.8 and self._path_budget > 0:
            u.path_t = self.time
            u.path = self._path(u.pos, point)
            u.path_i = 0
        return False

    def _nearest_walkable(self, pos: Vec2, max_radius: int = 6) -> Vec2:
        if self._walkable_pos(pos):
            return pos
        for r in range(1, max_radius + 1):
            for dx in range(-r, r + 1):
                for dy in (-r, r):
                    p = Vec2(pos.x + dx, pos.y + dy)
                    if self._walkable_pos(p):
                        return p
            for dy in range(-r + 1, r):
                for dx in (-r, r):
                    p = Vec2(pos.x + dx, pos.y + dy)
                    if self._walkable_pos(p):
                        return p
        return pos

    def _walkable_pos(self, p: Vec2) -> bool:
        x, y = int(p.x), int(p.y)
        if not (0 <= x < self.width and 0 <= y < self.height):
            return False
        return self.map.walkable[y][x] == 1

    # ---------------- 索敌 ----------------
    def _acquire(self, u: SimUnit, radius: float):
        atk = u.proto.attack
        if atk is None:
            return None
        best = None
        best_d = radius * radius
        for e in self._hostiles_near(u.pos, radius, u.team):
            if not atk.can_hit(e.flying):
                continue
            d = u.pos.dist_sq(e.pos)
            if d < best_d:
                best_d = d
                best = e
        return best

    def _hostiles_near(self, pos: Vec2, radius: float, team: int):
        r2 = radius * radius
        out = []
        cell = 6.0
        x0 = int((pos.x - radius) // cell)
        x1 = int((pos.x + radius) // cell)
        y0 = int((pos.y - radius) // cell)
        y1 = int((pos.y + radius) // cell)
        bucket = self._bucket
        for cy in range(y0, y1 + 1):
            for cx in range(x0, x1 + 1):
                for e in bucket.get((cx, cy), ()):
                    if e.team == team or not getattr(e, "alive", False):
                        continue
                    if e.pos.dist_sq(pos) <= r2 and self._visible(team, e.pos):
                        out.append(e)
        return out

    def _rebuild_buckets(self) -> None:
        cell = 6.0
        self._bucket = {}
        for u in self.units:
            if u.alive:
                key = (int(u.pos.x // cell), int(u.pos.y // cell))
                self._bucket.setdefault(key, []).append(u)
        for b in self.buildings:
            if b.alive:
                key = (int(b.pos.x // cell), int(b.pos.y // cell))
                self._bucket.setdefault(key, []).append(b)

    def _try_hit(self, u: SimUnit, tgt) -> None:
        atk = u.proto.attack
        if atk is None or u.cd > 0:
            return
        u.cd = atk.cooldown
        self._apply_hit(u, tgt, 1.0)
        if atk.splash > 0:
            for e in self._hostiles_near(tgt.pos, atk.splash, u.team):
                if e is tgt:
                    continue
                self._apply_hit(u, e, 0.55)

    def _apply_hit(self, src, tgt, mult: float) -> None:
        atk = src.proto.attack
        if atk is None:
            return
        rules = self.cat.rules
        m = rules.multiplier(atk.damage_type, tgt.proto.armor_type)
        m *= rules.tag_multiplier(src.proto.tags, tgt.proto.tags)
        dmg = atk.damage * m * rules.armor_reduction(tgt.proto.armor) * mult
        self._pending.append((tgt, dmg, src))

    def _apply_damage(self) -> None:
        for tgt, dmg, src in self._pending:
            if not getattr(tgt, "alive", False):
                continue
            tgt.hp -= dmg
            self.damage_dealt[src.team] += dmg
            if self.time - tgt.hit_t > 2.0:
                tgt.hit_t = self.time
                self._emit(
                    EventKind.UNIT_UNDER_ATTACK,
                    tgt.pos,
                    subject=tgt.id,
                    team=tgt.team,
                    other=src.id,
                    proto=tgt.proto.id,
                    value=dmg,
                )
            if tgt.hp <= 0:
                self._kill(tgt, src)

    def _kill(self, tgt, src) -> None:
        if not tgt.alive:
            return
        tgt.alive = False
        tgt.hp = 0.0
        self.losses[tgt.team] += 1
        self.kills[src.team] += 1
        if tgt.proto.harvest is not None:
            self.worker_losses[tgt.team] += 1
        self._supply_used[tgt.team] = max(0.0, self._supply_used[tgt.team] - tgt.proto.cost.supply)
        if isinstance(tgt, SimUnit):
            self._release_harvest(tgt)
            kind = EventKind.UNIT_KILLED
        else:
            kind = EventKind.BUILDING_DESTROYED
            self._map_info = None      # 分矿归属会变，缓存必须失效
            if tgt.complete:
                self._supply_cap[tgt.team] = max(
                    0.0, self._supply_cap[tgt.team] - tgt.proto.supply_provided
                )
            self._mark_footprint(tgt, 0)
            for uid in list(tgt.builders):
                b = self.ents.get(uid)
                if isinstance(b, SimUnit) and b.alive:
                    self._set_order(b, OrderKind.IDLE, owner=Issuer.SYSTEM)
            tgt.builders.clear()
        self._emit(kind, tgt.pos, subject=tgt.id, team=tgt.team, proto=tgt.proto.id, other=src.id)

    def _cleanup(self) -> None:
        if not any(not u.alive for u in self.units) and not any(not b.alive for b in self.buildings):
            return
        for u in self.units:
            if not u.alive:
                self.ents.pop(u.id, None)
                self.control.forget(u.id)
        for b in self.buildings:
            if not b.alive:
                self.ents.pop(b.id, None)
        self.units = [u for u in self.units if u.alive]
        self.buildings = [b for b in self.buildings if b.alive]

    # ---------------- 建筑 ----------------
    def _update_building(self, b: SimBuilding) -> None:
        if not b.complete:
            n = min(len(b.builders), int(self.cfg["build_speed_cap"]))
            if n > 0:
                b.progress += self.dt * n / max(1.0, b.proto.build_time)
                b.hp = min(b.proto.hp, b.hp + b.proto.hp * 0.9 * self.dt / max(1.0, b.proto.build_time) * n)
                if b.progress >= 1.0:
                    b.progress = 1.0
                    b.complete = True
                    b.hp = b.proto.hp
                    self._supply_cap[b.team] += b.proto.supply_provided
                    for uid in list(b.builders):
                        w = self.ents.get(uid)
                        if isinstance(w, SimUnit) and w.alive:
                            w.site = None
                            self._set_order(w, OrderKind.IDLE, owner=Issuer.SYSTEM)
                    b.builders.clear()
                    self._emit(EventKind.BUILDING_COMPLETE, b.pos, subject=b.id, team=b.team, proto=b.proto.id)
            return

        # 生产
        if b.queue:
            proto = self.cat.get(b.queue[0][0])
            if self._supply_used[b.team] + proto.cost.supply > self._supply_cap[b.team] + 1e-9:
                if not b.blocked:
                    b.blocked = True
                    self._emit(
                        EventKind.SUPPLY_BLOCKED,
                        b.pos,
                        subject=b.id,
                        team=b.team,
                        proto=proto.id,
                    )
                return
            b.blocked = False
            b.queue[0][1] -= self.dt
            if b.queue[0][1] <= 0:
                b.queue.pop(0)
                pos = self._spawn_point(b)
                u = self.add_unit(proto.id, b.team, pos)
                if u is None:
                    self.gold[b.team] += proto.cost.gold
                else:
                    if b.rally is not None:
                        self._set_order(u, OrderKind.MOVE, point=b.rally, owner=Issuer.SYSTEM, path_to=b.rally)
                    self._emit(EventKind.UNIT_TRAINED, pos, subject=u.id, team=b.team, proto=proto.id)

        # 静态防御
        if b.proto.attack is not None:
            if b.cd > 0:
                b.cd = max(0.0, b.cd - self.dt)
            tgt = self._acquire_building(b)
            if tgt is not None:
                self._try_hit_building(b, tgt)

    def _acquire_building(self, b: SimBuilding):
        atk = b.proto.attack
        if atk is None:
            return None
        best = None
        best_d = atk.range * atk.range
        for e in self._hostiles_near(b.pos, atk.range + 1.5, b.team):
            if not atk.can_hit(e.flying):
                continue
            d = b.pos.dist_sq(e.pos)
            if d < best_d:
                best_d = d
                best = e
        return best

    def _try_hit_building(self, b: SimBuilding, tgt) -> None:
        atk = b.proto.attack
        if atk is None or b.cd > 0:
            return
        b.cd = atk.cooldown
        self._apply_hit(b, tgt, 1.0)

    def _spawn_point(self, b: SimBuilding) -> Vec2:
        base = b.pos
        for r in range(1, 7):
            for i in range(8):
                ang = 2 * math.pi * i / 8
                p = Vec2(base.x + math.cos(ang) * (b.radius + r * 0.9), base.y + math.sin(ang) * (b.radius + r * 0.9))
                if self._walkable_pos(p):
                    return p
        return Vec2(base.x, base.y + b.radius + 1.0)

    # ---------------- 辅助 ----------------
    def _nearest_node(self, pos: Vec2) -> SimNode | None:
        best = None
        best_d = 1e18
        for n in self.nodes:
            if n.remaining <= 0:
                continue
            d = pos.dist_sq(n.pos)
            if d < best_d and len(n.workers) < n.max_workers:
                best_d = d
                best = n
        if best is None:
            for n in self.nodes:
                if n.remaining > 0 and pos.dist_sq(n.pos) < best_d:
                    best_d = pos.dist_sq(n.pos)
                    best = n
        return best

    def _nearest_dropoff(self, team: int, pos: Vec2) -> int | None:
        best = None
        best_d = 1e18
        for b in self.buildings:
            if b.alive and b.team == team and b.complete and b.proto.dropoff:
                d = pos.dist_sq(b.pos)
                if d < best_d:
                    best_d = d
                    best = b.id
        return best

    def _completed_protos(self, team: int) -> set[str]:
        return {b.proto.id for b in self.buildings if b.alive and b.team == team and b.complete}

    def _emit(
        self,
        kind: str,
        pos: Vec2,
        subject: int | None = None,
        team: int = -1,
        proto: str | None = None,
        other: int | None = None,
        value: float = 0.0,
    ) -> None:
        ev = EventInfo(self.tick, kind, pos, subject, other, proto, value, team)
        if team in (0, 1):
            self._events[team].append(ev)
            foe = 1 - team
            if self._visible(foe, pos):
                self._events[foe].append(ev)
        else:
            for t in (0, 1):
                if self._visible(t, pos):
                    self._events[t].append(ev)

    # ------------------------------------------------------------------ 玩家
    def player_command(self, cmd: Command) -> CommandResult:
        """玩家命令入口：先登记控制权，再执行。"""
        team = cmd.team
        if cmd.issuer != Issuer.PLAYER:
            return reject(Reason.INVALID, "player_command 只接受玩家命令")
        if cmd.kind == Cmd.LOCK:
            self.control.lock(cmd.units, self.tick)
            self.players[team]["intents"].append(
                Intent(self.tick, cmd.kind, cmd.units, cmd.target, cmd.point, cmd.proto, True)
            )
            return OK
        if cmd.kind == Cmd.UNLOCK:
            self.control.unlock(cmd.units, self.tick)
            return OK
        if cmd.kind == Cmd.GRANT:
            self.control.grant(cmd.units)
            return OK
        if cmd.kind == Cmd.SELECT:
            self.players[team]["selected"] = set(cmd.units)
            return OK
        if cmd.units:
            self.control.on_player_command(cmd.units, self.tick, order=cmd.kind)
        res = self.issue(cmd)
        self.players[team]["intents"].append(
            Intent(self.tick, cmd.kind, cmd.units, cmd.target, cmd.point, cmd.proto, res.ok)
        )
        return res

    def set_autonomy(self, team: int, policy: Mapping[str, Any]) -> None:
        self.players[team]["autonomy"] = dict(policy)

    # ------------------------------------------------------------------ 快照
    def map_info(self) -> MapInfo:
        if self._map_info is None:
            sites = []
            for i, s in enumerate(self.map.sites):
                node_ids = tuple(n.id for n in self.nodes if n.site == i)
                remaining = sum(n.remaining for n in self.nodes if n.site == i)
                owner = -1
                has_b = False
                for b in self.buildings:
                    if b.alive and b.team in (0, 1) and b.pos.dist(s.pos) <= 6.0:
                        if b.proto.dropoff:
                            has_b = True
                            if b.complete:
                                owner = b.team
                sites.append(ExpansionSite(i, s.pos, node_ids, remaining, owner, has_b))
            self._map_info = MapInfo(
                width=self.width,
                height=self.height,
                walkable=tuple(bytes(row) for row in self.map.walkable),
                start_points=tuple(self.map.starts),
                enemy_start=self.map.starts[1] if len(self.map.starts) > 1 else None,
                expansion_sites=tuple(sites),
                macro_w=12,
                macro_h=12,
            )
        return self._map_info

    def can_reach(self, unit_ids, point: Vec2) -> bool:
        """可达性探测：这批单位里是否**至少有一个**能走到 ``point``。

        只用于 AI 的撤退 / 分矿选址（低频），因此不计入每 tick 的寻路预算。
        ``is_walkable`` 只能回答"这格能不能站"，回答不了"走不走得到"——
        后者才是撤退算法真正需要的（见 AUDIT_REPORT §7）。
        """
        if not self.map_info().is_walkable(point):
            return False
        for uid in unit_ids:
            u = self.ents.get(uid)
            if not isinstance(u, SimUnit) or not u.alive:
                continue
            if straight_line_clear(u.pos, point, self.map.walkable, self.width, self.height):
                return True
            if find_path(self.map.walkable, self.width, self.height, u.pos, point,
                         max_expand=2000, max_path=128):
                return True
        return False

    def _fog_info(self, team: int) -> FogInfo:
        explored = self._explored_count[team]
        mw, mh = 12, 12
        cell_w = self.width / mw
        cell_h = self.height / mh
        area = max(1.0, cell_w * cell_h)
        counts = self._macro_counts[team]
        macro = tuple(min(1.0, c / area) for c in counts)
        # 可见比例用上一次 fog 更新的可见格数近似（每 2 tick 刷新）
        visible = sum(self._vis[team])
        return FogInfo(
            explored_ratio=explored / self._walk_count,
            visible_ratio=visible / self._walk_count,
            macro_explored=macro,
        )

    def snapshot(self, team: int) -> WorldSnapshot:
        evs = tuple(self._events[team])
        self._events[team].clear()

        uviews: list[UnitInfo] = []
        for u in self.units:
            if not u.alive:
                continue
            if u.team != team and not self._visible(team, u.pos):
                continue
            uviews.append(
                UnitInfo(
                    uid=u.id,
                    proto=u.proto.id,
                    team=u.team,
                    pos=u.pos,
                    hp=u.hp,
                    hp_max=u.proto.hp,
                    order=u.order,
                    order_target=u.target,
                    order_point=u.point,
                    order_owner=u.owner,
                    control=self.control.kind_of(u.id),
                    carrying=u.carry,
                    cd_frac=1.0 - min(1.0, u.cd / u.proto.attack.cooldown) if u.proto.attack else 0.0,
                    stuck=u.stuck,
                    resource_node=u.node,
                    home=u.home,
                    since_order=(self.tick - u.order_tick) * self.dt,
                )
            )
        bviews: list[BuildingInfo] = []
        for b in self.buildings:
            if not b.alive:
                continue
            if b.team != team and not self._visible(team, b.pos):
                continue
            bviews.append(
                BuildingInfo(
                    bid=b.id,
                    proto=b.proto.id,
                    team=b.team,
                    pos=b.pos,
                    hp=b.hp,
                    hp_max=b.proto.hp,
                    complete=b.complete,
                    progress=b.progress,
                    queue=tuple(q[0] for q in b.queue),
                    queue_time=b.queue[0][1] if b.queue else 0.0,
                    rally=b.rally,
                    builders=len(b.builders),
                    control=self.control.kind_of(b.id),
                    on_resource=b.proto.dropoff,
                )
            )
        nviews: list[NodeInfo] = []
        for n in self.nodes:
            if n.remaining <= 0:
                continue
            if not self._explored_at(team, n.pos):
                continue
            nviews.append(
                NodeInfo(n.id, n.pos, n.remaining, n.max_workers, len(n.workers), n.kind)
            )

        cv = self.control.view()
        pl = self.players[team]
        intents = tuple(pl["intents"])
        player = PlayerInfo(
            selected=frozenset(pl["selected"]),
            locked=cv["locked"],
            manual=cv["manual"],
            granted=frozenset(),
            intents=intents,
            autonomy=dict(pl.get("autonomy", {})),
            presence=bool(pl.get("presence", False)),
        )

        # 分矿点的「归属 / 是否有建筑」必须按迷雾过滤：
        # 敌方在未探索的分矿造基地，不能通过 expansion_sites 泄漏给 AI。
        mi = self.map_info()
        sites = tuple(
            s if (s.owner == team or self._visible(team, s.pos))
            else ExpansionSite(s.sid, s.pos, s.node_ids, s.remaining, -1, False)
            for s in mi.expansion_sites
        )
        mi = replace(mi, expansion_sites=sites)

        return WorldSnapshot(
            tick=self.tick,
            time=self.time,
            dt=self.dt,
            team=team,
            gold=self.gold[team],
            supply_used=self._supply_used[team],
            supply_cap=self._supply_cap[team],
            supply_max=self.cat.supply_max,
            units=tuple(uviews),
            buildings=tuple(bviews),
            nodes=tuple(nviews),
            map=mi,
            fog=self._fog_info(team),
            player=player,
            events=evs,
            enemy_team=1 - team,
            game_over=self.over,
            winner=self.winner,
        )

    # ------------------------------------------------------------------ 判定
    def _check_over(self) -> None:
        if self.over:
            return
        if self.time >= float(self.cfg["max_time_seconds"]):
            self.over, self.winner = True, -1
            return
        if not bool(self.cfg.get("require_both_teams", True)):
            return
        b0 = any(b.alive and b.complete for b in self.buildings if b.team == 0)
        b1 = any(b.alive and b.complete for b in self.buildings if b.team == 1)
        if not b0 and not b1:
            self.over, self.winner = True, -1
        elif not b0:
            self.over, self.winner = True, 1
        elif not b1:
            self.over, self.winner = True, 0

    # ------------------------------------------------------------------ 遥测
    def sample(self) -> dict[str, Any]:
        out: dict[str, Any] = {"tick": self.tick, "time": round(self.time, 2)}
        for t in (0, 1):
            units = [u for u in self.units if u.alive and u.team == t]
            workers = [u for u in units if u.proto.harvest is not None]
            army = [u for u in units if u.proto.harvest is None]
            idle_workers = [
                u for u in workers if u.order in (OrderKind.IDLE, OrderKind.STOP) or u.stuck
            ]
            idle_army = [u for u in army if u.order in (OrderKind.IDLE, OrderKind.STOP)]
            buildings = [b for b in self.buildings if b.alive and b.team == t]
            townhalls = [b for b in buildings if b.proto.dropoff and b.complete]
            prod = [b for b in buildings if b.proto.produce and b.complete]
            busy = [b for b in prod if b.queue]
            out[f"gold_{t}"] = round(self.gold[t], 1)
            out[f"workers_{t}"] = len(workers)
            out[f"army_{t}"] = len(army)
            out[f"army_value_{t}"] = round(sum(u.proto.value for u in army), 1)
            out[f"idle_workers_{t}"] = len(idle_workers)
            out[f"idle_army_{t}"] = len(idle_army)
            out[f"supply_used_{t}"] = self._supply_used[t]
            out[f"supply_cap_{t}"] = self._supply_cap[t]
            out[f"buildings_{t}"] = len(buildings)
            out[f"expansions_{t}"] = len(townhalls)
            out[f"prod_busy_{t}"] = len(busy)
            out[f"prod_total_{t}"] = len(prod)
            out[f"kills_{t}"] = self.kills[t]
            out[f"losses_{t}"] = self.losses[t]
            out[f"worker_losses_{t}"] = self.worker_losses[t]
            out[f"income_total_{t}"] = round(self.income_total[t], 1)
            out[f"explored_{t}"] = round(self._fog_info(t).explored_ratio, 4) if self.tick % 10 == 0 else None
            out[f"territory_{t}"] = self._territory(t)
        return out

    def _territory(self, team: int) -> float:
        """粗粒度领土控制份额（仅用于评测，不进入 AI 快照）。"""
        mw, mh = 12, 12
        mine = [0.0] * (mw * mh)
        foe = [0.0] * (mw * mh)
        for u in self.units:
            if not u.alive:
                continue
            mx = min(mw - 1, int(u.pos.x / self.width * mw))
            my = min(mh - 1, int(u.pos.y / self.height * mh))
            v = 1.0 if u.proto.harvest else u.proto.value / 60.0
            (mine if u.team == team else foe)[my * mw + mx] += v
        for b in self.buildings:
            if not b.alive:
                continue
            mx = min(mw - 1, int(b.pos.x / self.width * mw))
            my = min(mh - 1, int(b.pos.y / self.height * mh))
            (mine if b.team == team else foe)[my * mw + mx] += 2.0
        win = 0
        total = 0
        for i in range(mw * mh):
            if mine[i] <= 0 and foe[i] <= 0:
                continue
            total += 1
            if mine[i] > foe[i] * 0.8:
                win += 1
        return round(win / total, 3) if total else 0.0

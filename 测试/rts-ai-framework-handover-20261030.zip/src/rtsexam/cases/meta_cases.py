"""随机综合 / 框架约束 用例。"""
from __future__ import annotations

import hashlib
import json
import re
import time
from pathlib import Path

from rtsexam.case import Checker, case
from rtsexam.harness import run_match
from rtscontract.commands import Command
from rtscontract.configio import project_root
from rtscontract.enums import Cmd, Issuer
from rtscontract.vec import Vec2

from ._util import base_spec, outcome


@case("mix_random_1v1", "mixed", seeds=3, desc="随机对局不崩、不越权、不无限膨胀")
def mix_random_1v1(seed: int, cfg):
    ck = Checker()
    h = run_match(base_spec(layout="chokes"), seed, duration=200)
    ck.equals("cheat_attempts", h.sim_stats.get("cheat_attempts", 0), 0)
    ck.equals("control_blocked", h.sim_stats.get("control_blocked", 0), 0)
    ck.at_most("supply_rejected", h.sim_stats.get("supply_rejected", 0), 10)
    ck.at_most("entities", len(h.sim.units), 260)
    ck.at_least("game_progressed", h.result.tick, 500)
    ck.true("no_error", not h.result.errors)
    return outcome(
        "mix_random_1v1", "mixed", seed, ck,
        {"units": len(h.sim.units), "winner": h.result.winner, "kills": h.last("kills_0")},
    )


@case("mix_adjutant_disruption", "mixed", seeds=3, desc="玩家频繁干预下副官仍能运转且不越权")
def mix_adjutant_disruption(seed: int, cfg):
    ck = Checker()
    import random

    rng = random.Random(seed * 7919)

    def army(sim):
        return [u for u in sim.units if u.alive and u.team == 0 and u.proto.harvest is None]

    def chaos(sim) -> None:
        units = army(sim)
        if not units:
            return
        pick = rng.sample(units, k=min(len(units), 2))
        ids = tuple(u.id for u in pick)
        op = rng.randrange(4)
        if op == 0:
            sim.player_command(Command(Cmd.LOCK, Issuer.PLAYER, 0, ids))
        elif op == 1:
            sim.player_command(Command(Cmd.UNLOCK, Issuer.PLAYER, 0, ids))
        elif op == 2:
            p = Vec2(rng.uniform(10, sim.width - 10), rng.uniform(10, sim.height - 10))
            sim.player_command(Command(Cmd.MOVE, Issuer.PLAYER, 0, ids, point=p))
        else:
            sim.player_command(Command(Cmd.GRANT, Issuer.PLAYER, 0, ids))

    scripts = [(t, chaos) for t in (12.0, 26.0, 41.0, 57.0, 73.0, 90.0, 108.0)]
    h = run_match(base_spec(), seed, duration=150, player=True, scripts=scripts)
    ck.equals("control_blocked", h.sim_stats.get("control_blocked", 0), 0)
    ck.at_least("workers", h.last("workers_0"), 7)
    ck.at_least("army", h.last("army_0"), 3)
    ck.true("no_error", not h.result.errors)
    return outcome(
        "mix_adjutant_disruption", "mixed", seed, ck,
        {"workers": h.last("workers_0"), "army": h.last("army_0")},
    )


@case("mix_long_game_stability", "mixed", seeds=2, desc="长局稳定性（无崩溃、数值不爆）")
def mix_long_game_stability(seed: int, cfg):
    ck = Checker()
    h = run_match(base_spec(layout="open"), seed, duration=300)
    ck.true("no_error", not h.result.errors)
    ck.at_most("units", len(h.sim.units), 280)
    ck.at_least("supply_cap", h.last("supply_cap_0"), 30)
    finite = all(-1e-6 <= g <= 1e7 for g in h.series("gold_0"))
    ck.true("gold_finite", finite)
    return outcome(
        "mix_long_game_stability", "mixed", seed, ck,
        {"units": len(h.sim.units), "cap": h.last("supply_cap_0")},
    )


# --------------------------------------------------------------------------- 框架约束
@case("meta_determinism", "meta", seeds=2, desc="同种子同结果（可复现）")
def meta_determinism(seed: int, cfg):
    ck = Checker()
    h1 = run_match(base_spec(), seed, duration=100)
    h2 = run_match(base_spec(), seed, duration=100)
    d1 = hashlib.sha1(json.dumps(h1.result.samples, sort_keys=True).encode()).hexdigest()
    d2 = hashlib.sha1(json.dumps(h2.result.samples, sort_keys=True).encode()).hexdigest()
    ck.equals("sample_hash", d1, d2)
    ck.equals("kills", h1.last("kills_0"), h2.last("kills_0"))
    return outcome("meta_determinism", "meta", seed, ck, {"hash": d1[:12]})


@case("meta_no_game_dependency", "meta", seeds=1, desc="AI 源码不依赖模拟器/具体游戏代码")
def meta_no_game_dependency(seed: int, cfg):
    ck = Checker()
    root = project_root()
    bad: list[str] = []
    files = sorted((root / "src" / "rtsai").rglob("*.py"))
    pat = re.compile(r"^\s*(?:from|import)\s+(rtsim|rtsexam|godot|bpy)\b", re.M)
    for f in files:
        text = f.read_text(encoding="utf-8")
        for m in pat.finditer(text):
            bad.append(f"{f.name}: {m.group(0).strip()}")
    ck.equals("forbidden_imports", bad, [])
    ck.at_least("scanned_files", len(files), 10)
    return outcome("meta_no_game_dependency", "meta", seed, ck, {"files": len(files)})


@case("meta_no_hardcode", "meta", seeds=1, desc="AI 不含针对具体用例/种子的特殊逻辑")
def meta_no_hardcode(seed: int, cfg):
    from rtsexam.case import REGISTRY

    ck = Checker()
    root = project_root()
    ids = sorted(REGISTRY.keys())
    patterns = {
        "seed_compare": re.compile(r"\bseed\s*==\s*\d+"),
        "test_module": re.compile(r"\brtsexam\b"),
        "hash_random": re.compile(r"\brandom\.(?:random|randint|choice|shuffle)\b"),
        "wall_clock": re.compile(r"\btime\.time\(\)"),
    }
    hits: dict[str, list[str]] = {k: [] for k in patterns}
    case_hits: list[str] = []
    for f in sorted((root / "src" / "rtsai").rglob("*.py")):
        text = f.read_text(encoding="utf-8")
        for name, pat in patterns.items():
            if pat.search(text):
                hits[name].append(f.name)
        for cid in ids:
            if cid in text:
                case_hits.append(f"{f.name}:{cid}")
    ck.equals("hardcoded_refs", {k: v for k, v in hits.items() if v}, {})
    ck.equals("case_id_refs", case_hits, [])
    return outcome("meta_no_hardcode", "meta", seed, ck, {"case_ids": len(ids)})


@case("meta_performance", "meta", seeds=1, desc="模拟器+AI 的吞吐满足批量考试")
def meta_performance(seed: int, cfg):
    ck = Checker()
    t0 = time.perf_counter()
    h = run_match(base_spec(), seed, duration=120)
    dt = time.perf_counter() - t0
    speed = h.result.tick / max(1e-6, dt)
    ck.at_least("ticks_per_sec", speed, 100.0)
    ck.at_least("units_simulated", len(h.sim.units), 20)
    return outcome("meta_performance", "meta", seed, ck, {"tps": round(speed, 1)})

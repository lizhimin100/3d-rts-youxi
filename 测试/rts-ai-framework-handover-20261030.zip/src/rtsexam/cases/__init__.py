"""用例注册入口：导入所有用例模块以填充 REGISTRY。"""
from __future__ import annotations

from ..case import CATEGORIES, REGISTRY, CaseSpec  # noqa: F401
from . import adjutant_cases, eco_cases, fight_cases, map_cases, meta_cases, prod_cases  # noqa: F401

ALL_CASES = list(REGISTRY.values())

__all__ = ["REGISTRY", "CATEGORIES", "ALL_CASES"]

"""生产 / 兵种克制 用例。"""
from __future__ import annotations

from rtsexam.case import Checker, case
from rtsexam.harness import catalog, run_match
from rtsai.combatmodel import CombatModel

from ._util import base_spec, counter_quality, outcome


def _army_protos(sim, team: int = 0):
    return [u.proto for u in sim.units if u.alive and u.team == team and u.proto.harvest is None]


def _anti_air_share(sim, team: int = 0) -> float:
    army = _army_protos(sim, team)
    if not army:
        return 0.0
    return sum(1 for p in army if p.can_hit_air) / len(army)


@case("counter_adapt_ground", "counter", seeds=3, desc="面对重甲近战海，兵种构成向克制倾斜")
def counter_adapt_ground(seed: int, cfg):
    ck = Checker()
    from ._util import raid

    scripts = [
        (22.0, raid("melee", 3, offset=17.0)),
        (58.0, raid("melee", 3, offset=17.0)),
        (94.0, raid("melee", 3, offset=17.0)),
    ]
    h = run_match(
        base_spec(my_units=(("melee", 5),), my_buildings=("barracks",)),
        seed, duration=130, scripts=scripts,
    )
    cm = CombatModel(catalog())
    army = _army_protos(h.sim)
    q = counter_quality(cm, army, {"melee": 1.0})
    ck.at_least("counter_quality", q, 0.6)
    ck.at_least("army_size", len(army), 4)
    return outcome("counter_adapt_ground", "counter", seed, ck, {"quality": round(q, 3), "army": len(army)})


@case("counter_adapt_air", "counter", seeds=3, desc="面对空中单位会补对空兵种")
def counter_adapt_air(seed: int, cfg):
    ck = Checker()
    from ._util import raid

    scripts = [
        (45.0, raid("flyer", 2, offset=10.0)),
        (110.0, raid("flyer", 2, offset=10.0)),
    ]
    h = run_match(
        base_spec(my_units=(("ranged", 4), ("melee", 2)), my_buildings=("barracks",)),
        seed, duration=200, scripts=scripts,
    )
    share = _anti_air_share(h.sim)
    ck.at_least("anti_air_share", share, 0.2)
    ck.at_least("flyers_killed", h.last("kills_0"), 1)
    return outcome(
        "counter_adapt_air", "counter", seed, ck,
        {"anti_air_share": round(share, 3), "kills": h.last("kills_0")},
    )


@case("counter_no_useless_units", "counter", seeds=3, desc="不会成建制生产完全打不到敌人的兵种")
def counter_no_useless_units(seed: int, cfg):
    ck = Checker()
    scripts = [(22.0, _spawn_hold("flyer", 5, "enemy", near_base=True))]
    h = run_match(
        base_spec(my_units=(("melee", 3),), my_buildings=("barracks",)),
        seed, duration=130, scripts=scripts,
    )
    cm = CombatModel(catalog())
    army = _army_protos(h.sim)
    useless = 0
    for p in army:
        if cm.dps(p, catalog().get("flyer")) <= 1e-6 and cm.dps(p, catalog().get("melee")) <= 1e-6:
            useless += 1
    share = useless / max(1, len(army))
    ck.at_most("useless_share", share, 0.15)
    return outcome("counter_no_useless_units", "counter", seed, ck, {"useless": round(share, 3)})


@case("prod_tech_progression", "production", seeds=3, desc="科技建筑与高阶兵种会按需解锁")
def prod_tech_progression(seed: int, cfg):
    ck = Checker()
    spec = base_spec(start_gold=700.0, enemy_base="none", require_both_teams=False)
    h = run_match(spec, seed, duration=220)
    built = {b.proto for b in h.sim.buildings if b.team == 0}
    ck.at_least("building_types", len(built), 3)
    ck.at_least("army@220s", h.last("army_0"), 7)
    return outcome("prod_tech_progression", "production", seed, ck, {"types": len(built)})


def _spawn_hold(proto: str, count: int, team: str, near_base: bool = False):
    """在 AI 集结区附近刷一队「原地驻守」的敌人，用于观察 AI 的兵种选择。"""
    from rtscontract.commands import Command
    from rtscontract.enums import Cmd, Issuer
    from rtscontract.vec import Vec2
    from rtsim import spawn_line

    def action(sim) -> None:
        base = next((b.pos for b in sim.buildings if b.alive and b.team == 0 and b.proto.dropoff), None)
        if base is None:
            base = Vec2(sim.width * 0.2, sim.height * 0.2)
        offset = 12.0 if near_base else 30.0
        center = Vec2(base.x + offset, base.y + offset * 0.5)
        ids = spawn_line(sim, 1, proto, count, center, step=1.2)
        sim.refresh_fog()
        if ids:
            sim.issue(Command(Cmd.HOLD, Issuer.SYSTEM, 1, tuple(ids), point=center))

    del team
    return action

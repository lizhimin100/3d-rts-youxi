"""用例公共工具。"""
from __future__ import annotations

from typing import Any, Callable

from rtsexam.case import CaseOutcome, Checker
from rtscontract.commands import Command
from rtscontract.enums import Cmd, Issuer
from rtscontract.vec import Vec2
from rtsim import ScenarioSpec, spawn_line


def base_spec(**kwargs: Any) -> ScenarioSpec:
    """考试默认场景：88x88 开阔地图。"""
    defaults: dict[str, Any] = {
        "layout": "open",
        "width": 88,
        "height": 88,
        "start_gold": 520.0,
        "workers": 5,
        "enemy_workers": 5,
        "max_time": 400.0,
        "require_both_teams": True,
    }
    defaults.update(kwargs)
    return ScenarioSpec(**defaults)


def sandbox(**kwargs: Any) -> ScenarioSpec:
    """无敌人沙盒：用于纯运营类用例。"""
    defaults: dict[str, Any] = {
        "enemy_base": "none",
        "require_both_teams": False,
        "max_time": 400.0,
    }
    defaults.update(kwargs)
    return base_spec(**defaults)


def outcome(
    case_id: str, category: str, seed: int, ck: Checker, metrics: dict[str, Any] | None = None
) -> CaseOutcome:
    return CaseOutcome(case_id=case_id, category=category, seed=seed, checks=ck.checks, metrics=metrics or {})


def ratio_zeros(series: list[float], eps: float = 1e-6) -> float:
    if not series:
        return 0.0
    return sum(1 for v in series if v <= eps) / len(series)


def max_streak(series: list[float], pred) -> int:
    best = cur = 0
    for v in series:
        if pred(v):
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best


def mean(series: list[float]) -> float:
    return sum(series) / len(series) if series else 0.0


def count_orders(
    sim,
    *,
    owner: str | None = None,
    since_tick: int = 0,
    until_tick: int | None = None,
    uids: set[int] | None = None,
    kinds: set[str] | None = None,
) -> int:
    n = 0
    for tick, uid, kind, who in sim.orders_log:
        if tick < since_tick:
            continue
        if until_tick is not None and tick >= until_tick:
            continue
        if owner is not None and who != owner:
            continue
        if uids is not None and uid not in uids:
            continue
        if kinds is not None and kind not in kinds:
            continue
        n += 1
    return n


def base_of(sim, team: int) -> Vec2:
    for b in sim.buildings:
        if b.alive and b.team == team and b.proto.dropoff:
            return b.pos
    return Vec2(sim.width / 2, sim.height / 2)


def raid(proto: str, count: int, *, team: int = 1, target_team: int = 0, offset: float = 11.0,
         attack: bool = True) -> Callable[[Any], None]:
    """在对方基地外侧刷一支小队并命令其进攻（脚本，用于防守类用例）。"""

    def action(sim) -> None:
        target = base_of(sim, target_team)
        start = Vec2(target.x + offset, target.y + offset * 0.4)
        ids = spawn_line(sim, team, proto, count, start, step=1.1)
        sim.refresh_fog()
        if attack and ids:
            sim.issue(
                Command(Cmd.ATTACK_MOVE, Issuer.SYSTEM, team, tuple(ids), point=target)
            )

    return action


def spawn_group(proto: str, count: int, *, team: int = 1, at_point: Callable[[Any], Vec2] | None = None):
    def action(sim) -> None:
        p = at_point(sim) if at_point else Vec2(sim.width * 0.5, sim.height * 0.5)
        ids = spawn_line(sim, team, proto, count, p, step=1.1)
        sim.refresh_fog()
        del ids

    return action


def army_protos(sim, team: int = 0) -> list:
    return [u.proto for u in sim.units if u.alive and u.team == team and u.proto.harvest is None]


def counter_quality(combat, my_protos, enemy_mix: dict[str, float]) -> float:
    """军队构成相对「全用最优单位」的贴合度（0..1）。"""
    if not my_protos or not enemy_mix:
        return 0.0
    best = max(combat.score_unit(p, enemy_mix) for p in my_protos)
    if best <= 1e-6:
        return 0.0
    ideal = best * len(my_protos)
    actual = combat.army_score(my_protos, enemy_mix)
    return actual / ideal if ideal > 0 else 0.0

"""扩张 / 领土 / 战争迷雾 用例。"""
from __future__ import annotations

from rtsexam.case import Checker, case
from rtsexam.harness import run_match
from rtscontract.vec import Vec2

from ._util import base_of, base_spec, outcome, raid, sandbox


@case("exp_second_base", "expansion", seeds=3, desc="主矿饱和后开出第二片矿并投入使用")
def exp_second_base(seed: int, cfg):
    ck = Checker()
    h = run_match(sandbox(), seed, duration=240)
    exp = h.series("expansions_0")
    ck.at_least("expansions@200s", h.value_at("expansions_0", 200), 2)
    ck.at_least("workers@240s", h.last("workers_0"), 12)
    # 用「累计收入」而不是「当前金币」衡量经济规模：
    # 会花钱的 AI 金币本来就不该高（否则反而说明囤金）
    income = h.value_at("income_total_0", 240) - h.value_at("income_total_0", 120)
    ck.at_least("income_120_240s", income, 800.0)
    return outcome(
        "exp_second_base", "expansion", seed, ck,
        {
            "expansions": exp[-1] if exp else 0,
            "workers": h.last("workers_0"),
            "income": round(income, 1),
        },
    )


@case("exp_respect_pressure", "expansion", seeds=3, desc="受到持续压力时不盲目扩张")
def exp_respect_pressure(seed: int, cfg):
    ck = Checker()
    spec = base_spec(my_units=(("melee", 4),), my_buildings=("barracks",))
    h = run_match(
        spec, seed, duration=110,
        scripts=[
            (18.0, raid("melee", 2, offset=10.0)),
            (45.0, raid("melee", 2, offset=10.0)),
            (72.0, raid("melee", 2, offset=10.0)),
        ],
        enemy_ai=False,
    )
    exp = h.value_at("expansions_0", 110)
    ck.at_most("expansions_under_pressure", exp, 1)
    ck.true("main_base_alive", any(b.alive and b.team == 0 and b.proto.dropoff for b in h.sim.buildings))
    return outcome("exp_respect_pressure", "expansion", seed, ck, {"expansions": exp})


@case("exp_near_resources", "expansion", seeds=2, desc="分基地建立在资源点附近")
def exp_near_resources(seed: int, cfg):
    ck = Checker()
    h = run_match(sandbox(), seed, duration=240)
    halls = [b for b in h.sim.buildings if b.alive and b.team == 0 and b.proto.dropoff]
    best = 999.0
    for b in halls:
        for n in h.sim.nodes:
            best = min(best, b.pos.dist(n.pos))
    ck.at_least("halls", len(halls), 2)
    ck.at_most("min_node_distance", best, 12.0)
    return outcome("exp_near_resources", "expansion", seed, ck, {"halls": len(halls)})


# --------------------------------------------------------------------------- 领土
@case("ter_share_growth", "territory", seeds=3, desc="对局中保持并扩大地图控制")
def ter_share_growth(seed: int, cfg):
    ck = Checker()
    h = run_match(base_spec(), seed, duration=180)
    share = h.series("territory_0")
    early = h.value_at("territory_0", 60, 0.5)
    ck.at_least("share@180s", share[-1] if share else 0.0, 0.32)
    ck.at_least("early_share", early, 0.25)
    return outcome(
        "ter_share_growth", "territory", seed, ck,
        {"share": share[-1] if share else 0.0, "early": early},
    )


@case("ter_presence_forward", "territory", seeds=2, desc="兵力会前出到前线集结点而非龟缩")
def ter_presence_forward(seed: int, cfg):
    ck = Checker()
    h = run_match(base_spec(), seed, duration=150)
    base = base_of(h.sim, 0)
    army = [u for u in h.sim.units if u.alive and u.team == 0 and u.proto.harvest is None]
    forward = [u for u in army if u.pos.dist(base) > 14.0]
    ck.at_least("army_present", len(army), 4)
    ck.at_least("forward_units", len(forward), 2)
    return outcome("ter_presence_forward", "territory", seed, ck, {"forward": len(forward)})


# --------------------------------------------------------------------------- 迷雾
@case("fog_explore", "fog", seeds=3, desc="会派侦察兵探索地图")
def fog_explore(seed: int, cfg):
    ck = Checker()
    h = run_match(base_spec(), seed, duration=160)
    explored = h.value_at("explored_0", 160)
    ck.at_least("explored_ratio", explored, 0.2)
    ck.at_least("scout_trips", h.stats["scout"]["trips"], 1)
    return outcome("fog_explore", "fog", seed, ck, {"explored": explored})


@case("fog_no_cheat", "fog", seeds=3, desc="不对迷雾中的目标下达命令（无全图挂）")
def fog_no_cheat(seed: int, cfg):
    ck = Checker()
    h = run_match(base_spec(), seed, duration=150)
    cheat = h.sim_stats.get("cheat_attempts", 0)
    ck.equals("cheat_attempts", cheat, 0)
    return outcome("fog_no_cheat", "fog", seed, ck, {"cheat": cheat})


@case("fog_memory_of_seen_buildings", "fog", seeds=3, desc="见过的敌方建筑会留在记忆里")
def fog_memory_of_seen_buildings(seed: int, cfg):
    ck = Checker()
    store: dict = {}

    def spawn(sim):
        p = base_of(sim, 0) + Vec2(9.0, 1.0)
        b = sim.add_building("farm", 1, p, complete=True)
        sim.refresh_fog()
        store["bid"] = b.id

    def kill(sim):
        bid = store.get("bid")
        if bid is None:
            return
        b = next((x for x in sim.buildings if x.id == bid), None)
        if b is None:
            return

        class _Src:
            team = 0
            id = -1
            proto = None

        sim._kill(b, _Src())
        sim.refresh_fog()

    h = run_match(
        sandbox(enemy_base="none"),
        seed,
        duration=90,
        scripts=[(5.0, spawn), (35.0, kill)],
    )
    remembered = len(h.agent.world.enemy_buildings)
    ck.at_least("remembered_buildings", remembered, 1)
    ck.true("memory_survives_destruction", store.get("bid") in h.agent.world.enemy_buildings or remembered >= 1)
    return outcome("fog_memory_of_seen_buildings", "fog", seed, ck, {"remembered": remembered})

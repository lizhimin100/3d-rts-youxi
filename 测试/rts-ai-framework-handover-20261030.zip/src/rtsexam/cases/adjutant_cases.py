"""副官控制权 / 反愚蠢行为 用例。"""
from __future__ import annotations

from rtsexam.case import Checker, case
from rtsexam.harness import run_match
from rtscontract.commands import Command
from rtscontract.enums import Cmd, Issuer
from rtscontract.vec import Vec2

from ._util import base_of, base_spec, count_orders, outcome, raid


def _army_ids(sim, team: int = 0, n: int = 99) -> list[int]:
    return [u.id for u in sim.units if u.alive and u.team == team and u.proto.harvest is None][:n]


# --------------------------------------------------------------------------- 控制权
@case("adj_lock_inviolable", "adjutant", seeds=3, desc="被玩家锁定的单位永远不会收到 AI 命令")
def adj_lock_inviolable(seed: int, cfg):
    ck = Checker()
    holder: dict = {}
    lock_t = 20.0

    def do_lock(sim) -> None:
        ids = _army_ids(sim, 0, 3)
        if not ids:
            return
        sim.player_command(Command(Cmd.LOCK, Issuer.PLAYER, 0, tuple(ids)))
        p = base_of(sim, 0)
        sim.player_command(
            Command(Cmd.MOVE, Issuer.PLAYER, 0, tuple(ids), point=Vec2(p.x - 6.0, p.y - 6.0))
        )
        holder["ids"] = set(ids)
        holder["tick"] = sim.tick

    spec = base_spec(my_units=(("melee", 8),), my_buildings=("barracks",))
    h = run_match(spec, seed, duration=100, player=True, scripts=[(lock_t, do_lock)])
    ids = holder.get("ids", set())
    blocked = h.sim_stats.get("control_blocked", 0)
    ai_orders = count_orders(h.sim, owner="adjutant", since_tick=holder.get("tick", 0), uids=ids)
    ck.equals("control_blocked", blocked, 0)
    ck.equals("ai_orders_on_locked", ai_orders, 0)
    ck.at_least("units_locked", len(ids), 2)
    # 其余部队仍应正常工作
    ck.at_least("other_army_active", len([u for u in h.sim.units if u.alive and u.team == 0]), 4)
    return outcome(
        "adj_lock_inviolable", "adjutant", seed, ck,
        {"blocked": blocked, "ai_orders": ai_orders, "locked": len(ids)},
    )


@case("adj_manual_ttl", "adjutant", seeds=3, desc="玩家松手后（TTL 到期）副官才接管")
def adj_manual_ttl(seed: int, cfg):
    ck = Checker()
    holder: dict = {}
    ttl_ticks = 80  # 与 sim 配置一致（8s @10Hz）

    def do_move(sim) -> None:
        ids = _army_ids(sim, 0, 1)
        if not ids:
            return
        p = base_of(sim, 0)
        # 移到远离集结点的地方，这样 TTL 到期后 AI 一定有理由重新下令（拉回集结）
        target = sim._nearest_walkable(Vec2(p.x + 36.0, p.y + 6.0))
        sim.player_command(Command(Cmd.MOVE, Issuer.PLAYER, 0, tuple(ids), point=target))
        holder["uid"] = ids[0]
        holder["tick"] = sim.tick
        ttl_ticks = sim.control.manual_ttl_ticks
        holder["ttl"] = ttl_ticks

    spec = base_spec(my_units=(("melee", 6),), my_buildings=("barracks",))
    h = run_match(spec, seed, duration=70, player=True, scripts=[(20.0, do_move)])
    uid = holder.get("uid")
    t0 = holder.get("tick", 0)
    ttl = holder.get("ttl", ttl_ticks)
    if uid is None:
        ck.true("unit_found", False, "没有可用的军队单位")
        return outcome("adj_manual_ttl", "adjutant", seed, ck, {})
    during = count_orders(h.sim, owner="adjutant", since_tick=t0, until_tick=t0 + ttl, uids={uid})
    after = count_orders(h.sim, owner="adjutant", since_tick=t0 + ttl, uids={uid})
    ck.equals("no_ai_order_during_ttl", during, 0)
    ck.at_least("ai_takes_over_after_ttl", after, 1)
    ck.equals("control_blocked", h.sim_stats.get("control_blocked", 0), 0)
    return outcome("adj_manual_ttl", "adjutant", seed, ck, {"during": during, "after": after, "ttl": ttl})


@case("adj_player_order_not_cancelled", "adjutant", seeds=3, desc="玩家正在执行的命令不会被 AI 打断")
def adj_player_order_not_cancelled(seed: int, cfg):
    ck = Checker()
    holder: dict = {}

    def do_attack_move(sim) -> None:
        ids = _army_ids(sim, 0, 99)
        if len(ids) < 2:
            return
        target = Vec2(sim.width * 0.55, sim.height * 0.55)
        sim.player_command(Command(Cmd.ATTACK_MOVE, Issuer.PLAYER, 0, tuple(ids), point=target))
        holder["ids"] = set(ids)
        holder["tick"] = sim.tick

    def capture(sim) -> None:
        ids = holder.get("ids", set())
        holder["state"] = [
            (u.order, u.owner) for u in sim.units if u.id in ids and u.alive
        ]

    spec = base_spec(my_units=(("melee", 6),), my_buildings=("barracks",))
    h = run_match(
        spec, seed, duration=60, player=True,
        scripts=[(20.0, do_attack_move), (26.0, capture)],
    )
    state = holder.get("state", [])
    player_owned = sum(1 for order, owner in state if owner == Issuer.PLAYER and order == "attack_move")
    ck.at_least("still_executing_player_order", player_owned, 2)
    ck.equals("control_blocked", h.sim_stats.get("control_blocked", 0), 0)
    return outcome(
        "adj_player_order_not_cancelled", "adjutant", seed, ck,
        {"player_owned": player_owned, "n": len(state)},
    )


@case("adj_follow_player_intent", "adjutant", seeds=3, desc="玩家指定进攻点后副官协同推进")
def adj_follow_player_intent(seed: int, cfg):
    ck = Checker()
    holder: dict = {}

    def mean_dist(sim, target) -> float:
        army = [u for u in sim.units if u.alive and u.team == 0 and u.proto.harvest is None]
        return sum(u.pos.dist(target) for u in army) / max(1, len(army))

    def directive(sim) -> None:
        target = Vec2(sim.width * 0.74, sim.height * 0.74)
        sim.player_command(Command(Cmd.ATTACK_MOVE, Issuer.PLAYER, 0, (), point=target))
        holder["target"] = target
        holder["d0"] = mean_dist(sim, target)

    def capture(sim) -> None:
        holder["d1"] = mean_dist(sim, holder["target"])
        holder["n"] = len([u for u in sim.units if u.alive and u.team == 0 and u.proto.harvest is None])

    spec = base_spec(my_units=(("melee", 8),), my_buildings=("barracks",))
    h = run_match(
        spec, seed, duration=90, player=True,
        scripts=[(15.0, directive), (45.0, capture)],
    )
    d0 = holder.get("d0", 0.0)
    d1 = holder.get("d1", d0)
    ck.at_least("army_alive", holder.get("n", 0), 3)
    ck.at_least("advanced_tiles", d0 - d1, 12.0)
    return outcome(
        "adj_follow_player_intent", "adjutant", seed, ck,
        {"d0": round(d0, 1), "d1": round(d1, 1)},
    )


@case("adj_offers_suggestion", "adjutant", seeds=3, desc="冲突时给建议而不是抢控制权")
def adj_offers_suggestion(seed: int, cfg):
    ck = Checker()
    holder: dict = {}

    def do_lock(sim) -> None:
        ids = _army_ids(sim, 0, 4)
        if not ids:
            return
        sim.player_command(Command(Cmd.LOCK, Issuer.PLAYER, 0, tuple(ids)))
        holder["ids"] = set(ids)
        holder["tick"] = sim.tick

    spec = base_spec(my_units=(("melee", 6),), my_buildings=("barracks",))
    h = run_match(
        spec, seed, duration=110, player=True,
        scripts=[(12.0, do_lock), (55.0, raid("melee", 4, offset=9.0))],
    )
    suggest = h.result.suggestions
    codes = {s.get("code") for s in suggest}
    ck.at_least("suggestions", len(suggest), 1)
    ck.true("has_request_control_or_warning", bool(codes & {"request_control", "low_odds"}), str(codes))
    ck.equals("control_blocked", h.sim_stats.get("control_blocked", 0), 0)
    ck.equals(
        "ai_orders_on_locked",
        count_orders(
            h.sim, owner="adjutant", since_tick=holder.get("tick", 0) + 1, uids=holder.get("ids", set())
        ),
        0,
    )
    return outcome(
        "adj_offers_suggestion", "adjutant", seed, ck, {"suggestions": len(suggest), "codes": sorted(codes)}
    )


@case("adj_autonomy_respected", "adjutant", seeds=3, desc="关闭进攻自主权后不主动开战")
def adj_autonomy_respected(seed: int, cfg):
    ck = Checker()
    spec = base_spec(my_units=(("melee", 8),), my_buildings=("barracks",))
    h = run_match(
        spec, seed, duration=150, player=True,
        autonomy={"move_army_aggressive": False},
    )
    attacks = h.stats["combat"]["attacks"]
    ck.equals("no_self_initiated_attack", attacks, 0)
    ck.at_least("economy_still_runs", h.last("workers_0"), 7)
    return outcome("adj_autonomy_respected", "adjutant", seed, ck, {"attacks": attacks})


# --------------------------------------------------------------------------- 反愚蠢
@case("san_no_stuck_units", "sanity", seeds=3, desc="不出现长时间卡住的单位")
def san_no_stuck_units(seed: int, cfg):
    ck = Checker()
    h = run_match(base_spec(), seed, duration=160)
    issues = h.stats["sanity"]["issues"]
    ck.equals("stuck_episodes", issues.get("stuck_units", 0), 0)
    return outcome("san_no_stuck_units", "sanity", seed, ck, {"stuck": issues.get("stuck_units", 0)})


@case("san_issue_budget", "sanity", seeds=3, desc="单位时间内的愚蠢行为次数受控")
def san_issue_budget(seed: int, cfg):
    ck = Checker()
    h = run_match(base_spec(), seed, duration=180)
    ipm = h.stats["sanity"]["issues_per_minute"]
    ck.at_most("issues_per_minute", ipm, 3.0)
    return outcome("san_issue_budget", "sanity", seed, ck, {"ipm": ipm})


@case("san_army_answers_raid", "sanity", seeds=3, desc="基地遇袭时军队不会集体发呆")
def san_army_answers_raid(seed: int, cfg):
    ck = Checker()
    spec = base_spec(my_units=(("melee", 5),), my_buildings=("barracks",))
    h = run_match(spec, seed, duration=100, scripts=[(55.0, raid("melee", 3, offset=10.0))], enemy_ai=False)
    ck.at_least("kills", h.last("kills_0"), 2)
    ck.equals("idle_army_episodes", h.stats["sanity"]["issues"].get("idle_army_under_attack", 0), 0)
    return outcome("san_army_answers_raid", "sanity", seed, ck, {"kills": h.last("kills_0")})


@case("san_gold_not_hoarded", "sanity", seeds=3, desc="不会长期囤积大量金币")
def san_gold_not_hoarded(seed: int, cfg):
    ck = Checker()
    h = run_match(base_spec(), seed, duration=170)
    gold = h.series("gold_0")
    over = sum(1 for g in gold if g > 1800) / max(1, len(gold))
    ck.at_most("time_above_1800", over, 0.1)
    return outcome("san_gold_not_hoarded", "sanity", seed, ck, {"over": round(over, 3)})

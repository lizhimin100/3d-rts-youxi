"""防守 / 进攻 / 撤退 用例。"""
from __future__ import annotations

from rtsexam.case import Checker, case
from rtsexam.harness import run_match

from ._util import base_of, base_spec, outcome, raid


@case("def_base_raid", "defense", seeds=3, desc="基地被小股部队突袭时能守住")
def def_base_raid(seed: int, cfg):
    ck = Checker()
    spec = base_spec(my_units=(("melee", 3),), my_buildings=("barracks",))
    h = run_match(spec, seed, duration=145, scripts=[(45.0, raid("melee", 3, offset=9.0))], enemy_ai=False)
    alive = any(b.alive and b.team == 0 and b.proto.dropoff for b in h.sim.buildings)
    ck.true("main_base_alive", alive)
    ck.at_least("raiders_killed", h.last("kills_0"), 2)
    ck.at_most("worker_losses", h.last("worker_losses_0"), 3)
    return outcome(
        "def_base_raid", "defense", seed, ck,
        {"kills": h.last("kills_0"), "worker_losses": h.last("worker_losses_0")},
    )


@case("def_recall_from_front", "defense", seeds=3, desc="前线部队会回防被袭基地")
def def_recall_from_front(seed: int, cfg):
    ck = Checker()
    holder: dict = {}

    def capture(sim) -> None:
        base = base_of(sim, 0)
        army = [u for u in sim.units if u.alive and u.team == 0 and u.proto.harvest is None]
        holder["near"] = len([u for u in army if u.pos.dist(base) <= 26.0])
        holder["army"] = len(army)

    spec = base_spec(my_units=(("melee", 6),), my_buildings=("barracks",))
    h = run_match(
        spec, seed, duration=95,
        scripts=[(60.0, raid("melee", 3, offset=10.0)), (78.0, capture)],
        enemy_ai=False,
    )
    ck.at_least("defenders_near_base", holder.get("near", 0), 2)
    ck.at_least("raiders_killed", h.last("kills_0"), 2)
    return outcome(
        "def_recall_from_front", "defense", seed, ck,
        {"near": holder.get("near", 0), "army": holder.get("army", 0), "kills": h.last("kills_0")},
    )


@case("def_base_survives_push", "defense", seeds=3, desc="面对成建制推进能保住主基地")
def def_base_survives_push(seed: int, cfg):
    ck = Checker()
    spec = base_spec(
        my_units=(("melee", 6), ("ranged", 2)),
        my_buildings=("barracks", "tower"),
    )
    h = run_match(
        spec, seed, duration=160,
        scripts=[(50.0, raid("melee", 5, offset=11.0))],
        enemy_ai=False,
    )
    alive = any(b.alive and b.team == 0 and b.proto.dropoff for b in h.sim.buildings)
    ck.true("main_base_alive", alive)
    ck.at_least("kills", h.last("kills_0"), 3)
    return outcome("def_base_survives_push", "defense", seed, ck, {"kills": h.last("kills_0")})


@case("atk_destroy_weak_base", "attack", seeds=3, desc="兵力优势时能推平对方基地")
def atk_destroy_weak_base(seed: int, cfg):
    ck = Checker()
    spec = base_spec(
        enemy_base="weak",
        my_units=(("melee", 8),),
        my_buildings=("barracks",),
    )
    h = run_match(spec, seed, duration=260, enemy_ai=False)
    enemy_halls = [b for b in h.sim.buildings if b.alive and b.team == 1 and b.proto.dropoff]
    ck.true("enemy_base_destroyed", len(enemy_halls) == 0)
    ck.at_least("attacks_launched", h.stats["combat"]["attacks"], 1)
    return outcome(
        "atk_destroy_weak_base", "attack", seed, ck,
        {"attacks": h.stats["combat"]["attacks"], "winner": h.result.winner},
    )


@case("atk_engage_and_win", "attack", seeds=3, desc="同等规模下凭克制与微操取胜")
def atk_engage_and_win(seed: int, cfg):
    ck = Checker()
    spec = base_spec(
        my_units=(("melee", 6), ("ranged", 4)),
        my_buildings=("barracks",),
        enemy_units=(("melee", 6),),
        enemy_near_me=False,
    )
    h = run_match(spec, seed, duration=150, enemy_ai=False)
    ck.at_least("kills", h.last("kills_0"), 4)
    ck.at_most("losses", h.last("losses_0"), 6)
    return outcome(
        "atk_engage_and_win", "attack", seed, ck,
        {"kills": h.last("kills_0"), "losses": h.last("losses_0")},
    )


@case("ret_avoid_suicide", "retreat", seeds=3, desc="明显劣势时会撤退而不是送光")
def ret_avoid_suicide(seed: int, cfg):
    ck = Checker()
    spec = base_spec(my_units=(("melee", 6),), my_buildings=("barracks",))
    h = run_match(
        spec, seed, duration=110,
        scripts=[(40.0, raid("melee", 14, offset=26.0))],
        enemy_ai=False,
    )
    survivors = len([u for u in h.sim.units if u.alive and u.team == 0 and u.proto.harvest is None])
    ck.at_least("retreats", h.stats["combat"]["retreats"], 1)
    ck.at_least("survivors", survivors, 1)
    return outcome(
        "ret_avoid_suicide", "retreat", seed, ck,
        {"retreats": h.stats["combat"]["retreats"], "survivors": survivors},
    )


@case("ret_keeps_core_army", "retreat", seeds=3, desc="撤退后仍保留核心兵力")
def ret_keeps_core_army(seed: int, cfg):
    ck = Checker()
    spec = base_spec(my_units=(("melee", 5), ("ranged", 3)), my_buildings=("barracks",))
    h = run_match(
        spec, seed, duration=150,
        scripts=[(45.0, raid("melee", 12, offset=26.0))],
        enemy_ai=False,
    )
    army = [u for u in h.sim.units if u.alive and u.team == 0 and u.proto.harvest is None]
    ck.at_least("retreats", h.stats["combat"]["retreats"], 1)
    ck.at_least("survivors", len(army), 1)
    ck.at_most("losses", h.last("losses_0"), 14)
    return outcome(
        "ret_keeps_core_army", "retreat", seed, ck,
        {"survivors": len(army), "losses": h.last("losses_0")},
    )

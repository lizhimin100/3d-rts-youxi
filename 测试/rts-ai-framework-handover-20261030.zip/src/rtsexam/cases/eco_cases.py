"""经济 / 人口 / 农民 相关用例。"""
from __future__ import annotations

from rtsexam.case import Checker, case
from rtsexam.harness import run_match

from ._util import base_spec, mean, outcome, raid, ratio_zeros, sandbox


# --------------------------------------------------------------------------- 经济
@case("econ_worker_saturation", "economy", seeds=3, desc="农民持续补充并达到矿点容量")
def econ_worker_saturation(seed: int, cfg):
    ck = Checker()
    h = run_match(sandbox(), seed, duration=150)
    workers = h.series("workers_0")
    ck.at_least("workers@60s", h.value_at("workers_0", 60), 7)
    ck.at_least("workers@150s", workers[-1] if workers else 0, 9)
    idle = h.series("idle_workers_0")
    ck.at_most("avg_idle_rate", mean(idle) / max(1.0, mean(workers)), 0.15)
    ck.equals("supply_block_episodes", h.stats["sanity"]["issues"].get("supply_block", 0), 0)
    return outcome(
        "econ_worker_saturation", "economy", seed, ck,
        {"workers": round(mean(workers), 2), "idle": round(mean(idle), 2)},
    )


@case("econ_no_gold_hoard", "economy", seeds=3, desc="不囤金：有钱就转化为军队/建筑")
def econ_no_gold_hoard(seed: int, cfg):
    ck = Checker()
    h = run_match(sandbox(), seed, duration=200)
    gold = h.series("gold_0")
    used = h.series("supply_used_0")
    cap = h.series("supply_cap_0")
    # 「有钱且有余量却不花」才是愚蠢；满人口时囤金是正常的
    stuck = [
        g for g, u, c in zip(gold, used, cap) if g > 1200 and (c - u) >= 4
    ]
    ck.at_most("wasted_float_samples", len(stuck), 6)
    ck.at_least("army_count@200s", h.last("army_0"), 8)
    ck.at_most("gold_float_episodes", h.stats["sanity"]["issues"].get("gold_float", 0), 4)
    return outcome(
        "econ_no_gold_hoard", "economy", seed, ck,
        {"float_samples": len(stuck), "army": h.last("army_0")},
    )


@case("econ_supply_chain", "economy", seeds=3, desc="人口不断档（无长期供给阻塞）")
def econ_supply_chain(seed: int, cfg):
    ck = Checker()
    h = run_match(base_spec(), seed, duration=180)
    used = h.series("supply_used_0")
    cap = h.series("supply_cap_0")
    head = [c - u for u, c in zip(used, cap)]
    # 连续两个采样点（2 秒）人口为 0 视为断档
    streak = 0
    worst = 0
    for v in head:
        streak = streak + 1 if v <= 0.01 else 0
        worst = max(worst, streak)
    ck.at_most("max_supply_streak", worst, 6)
    ck.at_most("supply_rejected", h.sim_stats.get("supply_rejected", 0), 6)
    ck.at_least("supply_cap@180s", cap[-1] if cap else 0, 30)
    return outcome(
        "econ_supply_chain", "economy", seed, ck,
        {"max_streak": worst, "cap": cap[-1] if cap else 0, "rejected": h.sim_stats.get("supply_rejected", 0)},
    )


# --------------------------------------------------------------------------- 人口
@case("pop_headroom_maintained", "population", seeds=3, desc="生产期间保持人口余量")
def pop_headroom_maintained(seed: int, cfg):
    ck = Checker()
    h = run_match(base_spec(), seed, duration=180)
    used = h.series("supply_used_0")
    cap = h.series("supply_cap_0")
    head = [c - u for u, c in zip(used, cap)]
    hard_zero = sum(1 for v in head[20:] if v <= 0.01) / max(1, len(head[20:]))
    ck.at_most("hard_zero_ratio", hard_zero, 0.2)
    ck.at_least("army_supply@180s", max(0.0, (used[-1] if used else 0) - h.last("workers_0")), 16)
    return outcome(
        "pop_headroom_maintained", "population", seed, ck,
        {"hard_zero_ratio": round(hard_zero, 3), "cap": cap[-1] if cap else 0},
    )


@case("pop_recover_from_block", "population", seeds=3, desc="人口见底后能立刻补建筑")
def pop_recover_from_block(seed: int, cfg):
    ck = Checker()
    # 起始只有 10 人口上限、5 农民，AI 必须尽快补供给
    h = run_match(base_spec(start_gold=380.0), seed, duration=120)
    cap = h.series("supply_cap_0")
    ck.at_least("cap@60s", h.value_at("supply_cap_0", 60), 18)
    ck.at_least("cap@120s", cap[-1] if cap else 0, 28)
    return outcome("pop_recover_from_block", "population", seed, ck, {"cap": cap[-1] if cap else 0})


# --------------------------------------------------------------------------- 农民
@case("worker_idle_rate", "worker", seeds=3, desc="农民闲置率低")
def worker_idle_rate(seed: int, cfg):
    ck = Checker()
    h = run_match(base_spec(), seed, duration=150)
    idle = h.series("idle_workers_0")
    workers = h.series("workers_0")
    rate = mean(idle) / max(1.0, mean(workers))
    ck.at_most("avg_idle_rate", rate, 0.08)
    ck.at_most("idle_worker_episodes", h.stats["sanity"]["issues"].get("idle_workers", 0), 4)
    return outcome("worker_idle_rate", "worker", seed, ck, {"idle_rate": round(rate, 4)})


@case("worker_survive_raid", "worker", seeds=3, desc="农民遇袭避险，损失可控")
def worker_survive_raid(seed: int, cfg):
    ck = Checker()
    h = run_match(
        base_spec(),
        seed,
        duration=140,
        scripts=[(35.0, raid("melee", 3, offset=9.0))],
        enemy_ai=False,
    )
    losses = h.last("worker_losses_0")
    workers = h.last("workers_0")
    ck.at_most("worker_losses", losses, 2)
    ck.at_least("workers_alive@140s", workers, 7)
    ck.true("base_alive", any(b.alive and b.team == 0 and b.proto.dropoff for b in h.sim.buildings))
    return outcome(
        "worker_survive_raid", "worker", seed, ck, {"worker_losses": losses, "workers": workers}
    )


@case("worker_resume_after_raid", "worker", seeds=3, desc="袭击结束后农民恢复采集")
def worker_resume_after_raid(seed: int, cfg):
    ck = Checker()
    h = run_match(
        base_spec(my_units=(("melee", 3),)),
        seed,
        duration=160,
        scripts=[(30.0, raid("melee", 2, offset=12.0))],
        enemy_ai=False,
    )
    idle = h.value_at("idle_workers_0", 160)
    income = h.value_at("income_total_0", 160) - h.value_at("income_total_0", 120)
    ck.at_most("idle_after", idle, 3)
    ck.at_least("income_120_160", income, 150.0)
    return outcome(
        "worker_resume_after_raid", "worker", seed, ck,
        {"idle": idle, "income": round(income, 1)},
    )


# --------------------------------------------------------------------------- 生产
@case("prod_army_growth", "production", seeds=3, desc="军队随时间稳定成型")
def prod_army_growth(seed: int, cfg):
    ck = Checker()
    h = run_match(sandbox(), seed, duration=180)
    army = h.series("army_0")
    ck.at_least("army@90s", h.value_at("army_0", 90), 3)
    ck.at_least("army@180s", army[-1] if army else 0, 8)
    ck.at_most("production_idle_episodes", h.stats["sanity"]["issues"].get("production_idle", 0), 3)
    return outcome("prod_army_growth", "production", seed, ck, {"army": army[-1] if army else 0})


@case("prod_no_idle_buildings", "production", seeds=3, desc="生产建筑不长期空转")
def prod_no_idle_buildings(seed: int, cfg):
    ck = Checker()
    h = run_match(base_spec(), seed, duration=180)
    busy = h.series("prod_busy_0")
    total = h.series("prod_total_0")
    ratios = []
    for b, t in zip(busy, total):
        if t > 0:
            ratios.append(b / t)
    avg = mean(ratios[-90:]) if ratios else 0.0
    ck.at_least("avg_busy_ratio", avg, 0.55)
    return outcome("prod_no_idle_buildings", "production", seed, ck, {"busy_ratio": round(avg, 3)})

"""考试用对局装配：场景 + AI + 脚本化玩家。"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Sequence

from rtsai import RTSAgent
from rtsai.profile import load_profile
from rtscontract.catalog import Catalog, catalog_from_dict
from rtscontract.commands import Command
from rtscontract.configio import deep_merge, load_json
from rtscontract.enums import Cmd, Issuer
from rtscontract.vec import Vec2
from rtsim import MatchResult, MatchRunner, MockGateway, ScenarioSpec, build_sim
from rtsim.sim import Sim

_CATALOG: Catalog | None = None


def catalog() -> Catalog:
    global _CATALOG
    if _CATALOG is None:
        _CATALOG = catalog_from_dict(load_json("catalog.json"))
    return _CATALOG


def exam_config() -> dict[str, Any]:
    return load_json("exam.json", default={}) or {}


def profile(overrides: Mapping[str, Any] | None = None) -> dict[str, Any]:
    return load_profile(overrides or {})


@dataclass
class MatchHandle:
    sim: Sim
    result: MatchResult
    agent: RTSAgent
    enemy: RTSAgent | None = None
    duration: float = 0.0

    # ---------- 便捷读取 ----------
    def series(self, key: str) -> list[float]:
        return self.result.series(key)

    def last(self, key: str, default: float = 0.0) -> float:
        for s in reversed(self.result.samples):
            v = s.get(key)
            if v is not None:
                return float(v)
        return default

    def value_at(self, key: str, t: float, default: float = 0.0) -> float:
        best = None
        for s in self.result.samples:
            if s["time"] <= t + 1e-6:
                v = s.get(key)
                if v is not None:
                    best = float(v)
        return best if best is not None else default

    @property
    def stats(self) -> dict[str, Any]:
        return self.agent.stats()

    @property
    def sim_stats(self) -> dict[str, int]:
        return dict(self.result.sim_stats.get(0, {}))


def run_match(
    spec: ScenarioSpec,
    seed: int,
    *,
    duration: float = 150.0,
    subject: Mapping[str, Any] | None = None,
    enemy: Mapping[str, Any] | None = None,
    enemy_ai: bool = True,
    player: bool = False,
    autonomy: Mapping[str, Any] | None = None,
    scripts: Sequence[tuple[float, Callable[[Sim], None]]] = (),
    sample_interval: int = 10,
) -> MatchHandle:
    """跑一场考试对局：team0 = 被测 AI（副官），team1 = 敌方 AI 或脚本。"""
    cat = catalog()
    cfg = dataclasses.replace(spec, seed=seed)
    sim = build_sim(cfg, cat)
    if player:
        sim.players[0]["presence"] = True

    prof0 = profile(subject)
    if autonomy:
        prof0 = deep_merge(prof0, {"autonomy": dict(autonomy)})
    a0 = RTSAgent(MockGateway(sim, 0, issuer=Issuer.ADJUTANT), prof0)

    agents: dict[int, Any] = {0: a0}
    a1 = None
    if enemy_ai:
        prof1 = profile(enemy)
        a1 = RTSAgent(MockGateway(sim, 1, issuer=Issuer.ENEMY_AI), prof1)
        agents[1] = a1

    runner = MatchRunner(sim, agents, ai_interval=2, sample_interval=sample_interval, scripts=scripts)
    res = runner.run(duration=duration)
    return MatchHandle(sim=sim, result=res, agent=a0, enemy=a1, duration=duration)


# --------------------------------------------------------------------------- 选择器
def army(team: int = 0):
    return lambda sim: [u.id for u in sim.units if u.alive and u.team == team and u.proto.harvest is None]


def workers(team: int = 0):
    return lambda sim: [u.id for u in sim.units if u.alive and u.team == team and u.proto.harvest is not None]


def everything(team: int = 0):
    return lambda sim: [u.id for u in sim.units if u.alive and u.team == team]


def first_army(team: int = 0, n: int = 1):
    def sel(sim):
        return [u.id for u in sim.units if u.alive and u.team == team and u.proto.harvest is None][:n]

    return sel


def unit_by_proto(proto_id: str, team: int = 0, n: int = 99):
    def sel(sim):
        return [u.id for u in sim.units if u.alive and u.team == team and u.proto.id == proto_id][:n]

    return sel


# --------------------------------------------------------------------------- 玩家动作
def p_cmd(
    kind: str,
    team: int = 0,
    select: Callable[[Sim], list[int]] | None = None,
    **kwargs: Any,
) -> Callable[[Sim], None]:
    def action(sim: Sim) -> None:
        units = tuple(select(sim)) if select else ()
        sim.player_command(Command(kind, Issuer.PLAYER, team, units, **kwargs))

    return action


def p_lock(team: int = 0, select: Callable[[Sim], list[int]] | None = None):
    return p_cmd(Cmd.LOCK, team, select)


def p_unlock(team: int = 0, select: Callable[[Sim], list[int]] | None = None):
    return p_cmd(Cmd.UNLOCK, team, select)


def p_grant(team: int = 0, select: Callable[[Sim], list[int]] | None = None):
    return p_cmd(Cmd.GRANT, team, select)


def p_move(point: Vec2, team: int = 0, select=None):
    return p_cmd(Cmd.MOVE, team, select, point=point)


def p_attack_move(point: Vec2, team: int = 0, select=None):
    return p_cmd(Cmd.ATTACK_MOVE, team, select, point=point)


def p_train(building_proto: str, unit_proto: str, team: int = 0):
    def action(sim: Sim) -> None:
        for b in sim.buildings:
            if b.alive and b.team == team and b.proto.id == building_proto:
                sim.player_command(
                    Command(Cmd.TRAIN, Issuer.PLAYER, team, (), building=b.id, proto=unit_proto)
                )
                return

    return action


def nearest_enemy(team: int = 0, proto_id: str | None = None):
    """返回「距离我方基地最近的敌方单位 id」的选择器（用于断言）。"""

    def sel(sim: Sim):
        base = next((b for b in sim.buildings if b.alive and b.team == team and b.proto.dropoff), None)
        ref = base.pos if base else Vec2(sim.width / 2, sim.height / 2)
        cands = [
            u
            for u in sim.units
            if u.alive and u.team != team and (proto_id is None or u.proto.id == proto_id)
        ]
        if not cands:
            return None
        return min(cands, key=lambda u: u.pos.dist(ref)).id

    return sel

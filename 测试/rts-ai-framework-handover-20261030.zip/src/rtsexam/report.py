"""考试报告渲染（Markdown / JSON）。"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .case import CATEGORIES


def render_markdown(report: dict[str, Any], baseline: dict[str, Any] | None = None) -> str:
    s = report["summary"]
    meta = report["meta"]
    seeds = report["seeds"]
    lines: list[str] = []
    a = lines.append

    a("# RTS AI 自动化考试报告")
    a("")
    a(f"- 生成时间：{meta.get('generated_at')}")
    a(f"- 运行环境：Python {meta.get('python')} / {meta.get('platform')}")
    a(
        f"- 用例数：**{s['cases']}**，通过 **{s['cases_passed']}**"
        f"（用例通过率 **{s['case_pass_rate'] * 100:.1f}%**）"
    )
    a(
        f"- 断言数：{s['checks']}，通过 {s['checks_passed']}"
        f"（断言通过率 **{s['check_pass_rate'] * 100:.1f}%**）"
    )
    a(f"- 对局数：{s['runs']}，耗时 {s['elapsed_sec']} 秒")
    a("")

    a("## 分类得分")
    a("")
    a("| 分类 | 用例 | 通过 | 用例通过率 | 断言通过率 |")
    a("|---|---|---|---|---|")
    for key, label in CATEGORIES.items():
        st = report["categories"].get(key)
        if not st or st["cases"] == 0:
            continue
        cp = st["passed"] / st["cases"] * 100 if st["cases"] else 0
        chp = st["checks_passed"] / st["checks"] * 100 if st["checks"] else 0
        a(f"| {label} (`{key}`) | {st['cases']} | {st['passed']} | {cp:.0f}% | {chp:.1f}% |")
    a("")

    a("## 用例明细")
    a("")
    a("| 用例 | 分类 | 种子数 | 结果 | 失败断言 |")
    a("|---|---|---|---|---|")
    for c in report["cases"]:
        failed = [ck["name"] for ck in c["checks"] if not ck["ok"]]
        status = "✅ PASS" if c["passed"] else "❌ FAIL"
        fail_txt = ", ".join(failed[:4]) + (" ..." if len(failed) > 4 else "")
        a(f"| `{c['case_id']}` | {c['category']} | {len(c['seeds'])} | {status} | {fail_txt} |")
    a("")

    fails = [c for c in report["cases"] if not c["passed"]]
    if fails:
        a("## 失败详情")
        a("")
        for c in fails:
            a(f"### `{c['case_id']}`（{c['category']}）")
            if c.get("error"):
                a("```")
                a(c["error"][:2000])
                a("```")
                continue
            a("| 断言 | 实际 | 期望 |")
            a("|---|---|---|")
            for ck in c["checks"]:
                if ck["ok"]:
                    continue
                a(f"| {ck['name']} | {ck['actual']} | {ck['expected']} |")
            a("")

    if baseline:
        a("## 回归对比")
        a("")
        if baseline.get("ok"):
            a("✅ 与基线相比没有回归。")
            if not baseline.get("metric_compared", True):
                a("")
                a("> 本次使用随机种子，与基线种子池不同，因此只比较用例通过状态，不比较数值指标。")
        else:
            a("| 用例 | 类型 | 详情 |")
            a("|---|---|---|")
            for r in baseline["regressions"]:
                a(f"| `{r.get('case')}` | {r.get('kind')} | {r.get('metric', '')} {r.get('base', '')} → {r.get('now', '')} |")
        a("")

    a("## 种子")
    a("")
    a(f"- 基础种子：{seeds.get('base_seed')}（randomized={seeds.get('randomized')}）")
    a(f"- 回归种子：{seeds.get('regression_seeds')}")
    a(f"- 随机种子：{seeds.get('random_seeds')}")
    a("")

    a("## 附：用例指标（首个种子）")
    a("")
    a("| 用例 | 指标 |")
    a("|---|---|")
    for c in report["cases"]:
        m = (c.get("metrics") or [{}])[0] or {}
        if not m:
            continue
        txt = ", ".join(f"{k}={v}" for k, v in list(m.items())[:6])
        a(f"| `{c['case_id']}` | {txt} |")
    a("")
    return "\n".join(lines)


def write_reports(report: dict[str, Any], out_dir: Path, baseline: dict[str, Any] | None = None) -> tuple[Path, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    md = out_dir / "exam_report.md"
    js = out_dir / "exam_report.json"
    md.write_text(render_markdown(report, baseline), encoding="utf-8")
    js.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return md, js

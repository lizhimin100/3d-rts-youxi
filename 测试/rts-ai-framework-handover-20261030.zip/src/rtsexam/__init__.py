"""rtsexam —— 自动化考试系统（用例 + 执行器 + 报告）。"""

from .case import CATEGORIES, REGISTRY, CaseOutcome, CaseSpec, Check, Checker, case  # noqa: F401
from .harness import MatchHandle, catalog, exam_config, run_match  # noqa: F401
from .runner import ExamReport, ExamRunner, compare_baseline  # noqa: F401

__all__ = [
    "CATEGORIES",
    "REGISTRY",
    "CaseOutcome",
    "CaseSpec",
    "Check",
    "Checker",
    "case",
    "MatchHandle",
    "catalog",
    "exam_config",
    "run_match",
    "ExamReport",
    "ExamRunner",
    "compare_baseline",
]

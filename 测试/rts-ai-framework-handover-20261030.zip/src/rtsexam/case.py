"""考试用例基础设施：断言、结果、注册表。

一条硬性约束：**考试逻辑不得反向影响 AI**。
用例只能通过「场景 + 阈值」表达期望，AI 代码里不允许出现任何用例 id / 固定 seed。
（由 ``meta_no_hardcode`` 静态检查强制。）
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List


@dataclass
class Check:
    name: str
    ok: bool
    actual: Any = None
    expected: str = ""
    detail: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "ok": self.ok,
            "actual": self.actual,
            "expected": self.expected,
            "detail": self.detail,
        }


class Checker:
    """收集断言，最后统一判定。"""

    def __init__(self) -> None:
        self.checks: List[Check] = []

    # ---------- 基础断言 ----------
    def true(self, name: str, cond: bool, detail: str = "") -> None:
        self.checks.append(Check(name, bool(cond), bool(cond), "True", detail))

    def false(self, name: str, cond: bool, detail: str = "") -> None:
        self.checks.append(Check(name, not cond, bool(cond), "False", detail))

    def at_least(self, name: str, value: float, lo: float, detail: str = "") -> None:
        self.checks.append(
            Check(name, value >= lo - 1e-9, round(float(value), 3), f">= {lo}", detail)
        )

    def at_most(self, name: str, value: float, hi: float, detail: str = "") -> None:
        self.checks.append(
            Check(name, value <= hi + 1e-9, round(float(value), 3), f"<= {hi}", detail)
        )

    def between(self, name: str, value: float, lo: float, hi: float, detail: str = "") -> None:
        ok = lo - 1e-9 <= value <= hi + 1e-9
        self.checks.append(Check(name, ok, round(float(value), 3), f"[{lo}, {hi}]", detail))

    def equals(self, name: str, value: Any, expected: Any, detail: str = "") -> None:
        self.checks.append(Check(name, value == expected, value, str(expected), detail))

    def close(self, name: str, value: float, expected: float, tol: float, detail: str = "") -> None:
        ok = abs(value - expected) <= tol
        self.checks.append(Check(name, ok, round(float(value), 3), f"{expected}±{tol}", detail))

    # ---------- 汇总 ----------
    @property
    def passed(self) -> bool:
        return all(c.ok for c in self.checks) if self.checks else False

    @property
    def failed(self) -> List[Check]:
        return [c for c in self.checks if not c.ok]


@dataclass
class CaseOutcome:
    case_id: str
    category: str
    seed: int
    checks: List[Check] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)
    error: str = ""

    @property
    def passed(self) -> bool:
        return not self.error and bool(self.checks) and all(c.ok for c in self.checks)

    def as_dict(self) -> dict[str, Any]:
        return {
            "case_id": self.case_id,
            "category": self.category,
            "seed": self.seed,
            "passed": self.passed,
            "error": self.error,
            "checks": [c.as_dict() for c in self.checks],
            "metrics": self.metrics,
        }


@dataclass
class CaseSpec:
    id: str
    category: str
    fn: Callable[[int, Dict[str, Any]], CaseOutcome]
    seeds: int = 3
    weight: float = 1.0
    desc: str = ""

    def run(self, seed: int, cfg: Dict[str, Any]) -> CaseOutcome:
        try:
            return self.fn(seed, cfg)
        except Exception as exc:  # noqa: BLE001 - 用例崩溃也要产出可读结果
            import traceback

            return CaseOutcome(
                case_id=self.id,
                category=self.category,
                seed=seed,
                error=f"{type(exc).__name__}: {exc}\n{traceback.format_exc(limit=6)}",
            )


REGISTRY: Dict[str, CaseSpec] = {}
CATEGORIES: Dict[str, str] = {
    "economy": "经济运营",
    "population": "人口供给",
    "worker": "农民管理",
    "production": "生产与兵种构成",
    "counter": "兵种克制",
    "defense": "防守",
    "attack": "进攻",
    "retreat": "撤退",
    "expansion": "扩张",
    "territory": "领土控制",
    "fog": "战争迷雾",
    "adjutant": "副官控制权",
    "sanity": "反愚蠢行为",
    "mixed": "随机综合",
    "meta": "框架约束",
}


def case(case_id: str, category: str, seeds: int = 3, desc: str = ""):
    """注册用例的装饰器。"""

    def deco(fn: Callable[[int, Dict[str, Any]], CaseOutcome]):
        if case_id in REGISTRY:
            raise RuntimeError(f"重复的用例 id: {case_id}")
        REGISTRY[case_id] = CaseSpec(case_id, category, fn, seeds=seeds, desc=desc)
        return fn

    return deco

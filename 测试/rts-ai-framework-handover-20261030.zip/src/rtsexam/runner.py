"""考试执行器：发现用例、分配随机/回归种子、并行执行、汇总。"""
from __future__ import annotations

import dataclasses
import json
import os
import platform
import random
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any, Iterable, Sequence

from .case import CATEGORIES, REGISTRY, CaseOutcome, CaseSpec

DEFAULT_BASE_SEED = 20261026
DEFAULT_REGRESSION = (11, 23, 37, 41, 59)


def _run_one(task: tuple[str, int, dict]) -> dict:
    cid, seed, cfg = task
    import rtsexam.cases  # noqa: F401  确保注册表已填充

    spec = REGISTRY.get(cid)
    if spec is None:
        return {
            "case_id": cid,
            "category": "?",
            "seed": seed,
            "passed": False,
            "error": "用例未注册",
            "checks": [],
            "metrics": {},
        }
    return spec.run(seed, cfg).as_dict()


@dataclass
class ExamReport:
    summary: dict[str, Any] = field(default_factory=dict)
    categories: dict[str, dict[str, Any]] = field(default_factory=dict)
    cases: list[dict[str, Any]] = field(default_factory=list)
    seeds: dict[str, Any] = field(default_factory=dict)
    meta: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "meta": self.meta,
            "summary": self.summary,
            "categories": self.categories,
            "cases": self.cases,
            "seeds": self.seeds,
        }


class ExamRunner:
    def __init__(self, cfg: dict[str, Any] | None = None) -> None:
        from .harness import exam_config

        self.cfg = dict(cfg or exam_config())

    # ------------------------------------------------------------------ 种子
    def build_seeds(self, cases: Sequence[CaseSpec], randomize: bool, override: Sequence[int] | None = None):
        base = int(self.cfg.get("base_seed", DEFAULT_BASE_SEED))
        regression = list(self.cfg.get("regression_seeds", DEFAULT_REGRESSION))
        n_random = int(self.cfg.get("random_seeds", 6))
        rng = random.Random(base if not randomize else (base ^ int.from_bytes(os.urandom(4), "little")))
        randoms = [rng.randrange(1, 10**6) for _ in range(n_random)]
        pool = list(regression) + randoms
        if override:
            pool = list(override)
        plan = {
            "base_seed": base,
            "randomized": randomize,
            "regression_seeds": regression,
            "random_seeds": randoms,
            "pool": pool,
        }
        return pool, plan

    # ------------------------------------------------------------------ 主流程
    def run(
        self,
        case_ids: Sequence[str] | None = None,
        categories: Sequence[str] | None = None,
        jobs: int = 1,
        randomize: bool = False,
        seeds_override: Sequence[int] | None = None,
        progress: bool = True,
    ) -> ExamReport:
        import rtsexam.cases  # noqa: F401

        specs = [s for s in REGISTRY.values() if self._selected(s, case_ids, categories)]
        specs.sort(key=lambda s: (list(CATEGORIES).index(s.category) if s.category in CATEGORIES else 99, s.id))
        pool, seed_plan = self.build_seeds(specs, randomize, seeds_override)

        tasks: list[tuple[str, int, dict]] = []
        for i, spec in enumerate(specs):
            n = max(1, min(spec.seeds, len(pool)))
            start = i % max(1, len(pool))
            seeds = [pool[(start + k) % len(pool)] for k in range(n)]
            for s in seeds:
                tasks.append((spec.id, s, self.cfg))

        t0 = time.perf_counter()
        results: list[dict[str, Any]] = []
        if jobs <= 1:
            for k, task in enumerate(tasks):
                results.append(_run_one(task))
                if progress and (k + 1) % 10 == 0:
                    print(f"  ... {k + 1}/{len(tasks)}", flush=True)
        else:
            with ProcessPoolExecutor(max_workers=jobs) as pool_exec:
                futs = [pool_exec.submit(_run_one, t) for t in tasks]
                for k, fut in enumerate(as_completed(futs)):
                    results.append(fut.result())
                    if progress and (k + 1) % 10 == 0:
                        print(f"  ... {k + 1}/{len(tasks)}", flush=True)
        elapsed = time.perf_counter() - t0

        report = self._aggregate(results, seed_plan, elapsed)
        return report

    def _selected(self, spec: CaseSpec, ids: Sequence[str] | None, cats: Sequence[str] | None) -> bool:
        if ids and spec.id not in ids:
            return False
        if cats and spec.category not in cats:
            return False
        return True

    # ------------------------------------------------------------------ 汇总
    def _aggregate(self, results: list[dict], seed_plan: dict, elapsed: float) -> ExamReport:
        by_case: dict[str, list[dict]] = {}
        for r in results:
            by_case.setdefault(r["case_id"], []).append(r)

        cases: list[dict[str, Any]] = []
        cat_stats: dict[str, dict[str, Any]] = {
            c: {"cases": 0, "passed": 0, "checks": 0, "checks_passed": 0} for c in CATEGORIES
        }
        total_checks = 0
        passed_checks = 0
        for cid, runs in sorted(by_case.items()):
            runs.sort(key=lambda r: r["seed"])
            category = runs[0]["category"]
            all_pass = all(r["passed"] for r in runs)
            checks = [c for r in runs for c in r["checks"]]
            ok = sum(1 for c in checks if c["ok"])
            total_checks += len(checks)
            passed_checks += ok
            st = cat_stats.setdefault(
                category, {"cases": 0, "passed": 0, "checks": 0, "checks_passed": 0}
            )
            st["cases"] += 1
            st["passed"] += 1 if all_pass else 0
            st["checks"] += len(checks)
            st["checks_passed"] += ok
            cases.append(
                {
                    "case_id": cid,
                    "category": category,
                    "passed": all_pass,
                    "seeds": [r["seed"] for r in runs],
                    "seed_pass": [r["passed"] for r in runs],
                    "checks": checks,
                    "metrics": [r.get("metrics", {}) for r in runs],
                    "error": next((r["error"] for r in runs if r.get("error")), ""),
                }
            )

        total_cases = len(cases)
        passed_cases = sum(1 for c in cases if c["passed"])
        summary = {
            "cases": total_cases,
            "cases_passed": passed_cases,
            "case_pass_rate": round(passed_cases / total_cases, 4) if total_cases else 0.0,
            "runs": len(results),
            "checks": total_checks,
            "checks_passed": passed_checks,
            "check_pass_rate": round(passed_checks / total_checks, 4) if total_checks else 0.0,
            "elapsed_sec": round(elapsed, 1),
        }
        meta = {
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        return ExamReport(summary=summary, categories=cat_stats, cases=cases, seeds=seed_plan, meta=meta)


# --------------------------------------------------------------------------- 基线对比
def compare_baseline(report: dict[str, Any], baseline: dict[str, Any], tol: float = 0.05) -> dict[str, Any]:
    """对比基线：用例通过状态回归 + 关键指标退化。

    只有在两次运行的**种子池一致**时才比较数值指标——不同种子下的数值本来就会浮动，
    拿来做「回归判定」没有意义（这一点很容易被误用，故在实现里显式处理）。
    """
    same_seeds = (report.get("seeds", {}).get("pool") == baseline.get("seeds", {}).get("pool"))
    base_cases = {c["case_id"]: c for c in baseline.get("cases", [])}
    regressions = []
    improvements = []
    for case in report.get("cases", []):
        b = base_cases.get(case["case_id"])
        if b is None:
            continue
        if b["passed"] and not case["passed"]:
            regressions.append({"case": case["case_id"], "kind": "pass->fail"})
        elif not b["passed"] and case["passed"]:
            improvements.append({"case": case["case_id"], "kind": "fail->pass"})
        if not same_seeds:
            continue
        bm = b.get("metrics") or [{}]
        cm = case.get("metrics") or [{}]
        for key, bval in (bm[0] or {}).items():
            if not isinstance(bval, (int, float)):
                continue
            cval = (cm[0] or {}).get(key)
            if not isinstance(cval, (int, float)):
                continue
            if bval == 0:
                continue
            delta = (cval - bval) / abs(bval)
            if delta < -tol:
                regressions.append(
                    {"case": case["case_id"], "kind": "metric", "metric": key, "base": bval, "now": cval}
                )
    return {
        "regressions": regressions,
        "improvements": improvements,
        "ok": not regressions,
        "metric_compared": same_seeds,
        "baseline_generated_at": baseline.get("meta", {}).get("generated_at"),
    }

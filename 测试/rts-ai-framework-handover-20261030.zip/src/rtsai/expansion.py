"""扩张：分矿选址、派遣农民、建造基地。

**不再使用「主矿饱和 → 开矿」这种固定规则。** 每次决策计算一组效用项：

* 资源价值（余量 / 参考值）
* 地形价值（walkable 密度 → choke 路口价值 + 位于双方基地连线中段的 route 价值）
* 安全度（领土威胁）
* 军事窗口（army_ratio）
* 经济需求（农民/矿点容量、闲置农民、金库积压）
* 距离成本（越远越贵，运兵/防守成本都随距离上升）
* 敌方压力（矿点附近可见敌军 + 敌方出生点方向 + 家门口集结）

只有当「效用 ≥ 阈值」且「存在窗口（军事优势或经济需求）」时才扩张；
家门口出现成规模敌军时，无论矿是否饱和都不开新矿。
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from rtscontract.snapshot import ExpansionSite
from rtscontract.vec import Vec2

from .context import AIContext
from .placement import PlacementSolver


@dataclass
class PendingExpansion:
    site: ExpansionSite
    worker: int
    phase: str = "moving"
    since: float = 0.0
    tries: int = 0


@dataclass
class SiteScore:
    """一个矿点的完整效用分解，便于审计与调参。"""

    site: ExpansionSite
    utility: float
    parts: dict[str, float] = field(default_factory=dict)

    def as_dict(self) -> dict[str, float]:
        out = {"sid": float(self.site.sid), "utility": round(self.utility, 4)}
        out.update({k: round(v, 4) for k, v in self.parts.items()})
        return out


class ExpansionManager:
    def __init__(self, ctx: AIContext) -> None:
        self.ctx = ctx
        self.pending: PendingExpansion | None = None
        self.started = 0
        self.completed = 0
        self._done_sites: set[int] = set()
        self.solver = PlacementSolver(ctx.gateway, budget_per_tick=24)
        # 审计/调参用：最近一次评估的完整证据
        self.last_scores: list[SiteScore] = []
        self.last_context: dict[str, float] = {}
        self.last_block: str = ""
        # 压力记忆：raid 之间的空档不应被当成「安全窗口」
        self._last_pressure_time: float = -999.0

    # ------------------------------------------------------------------ 主流程
    def update(self) -> None:
        w = self.ctx.world
        post = self.ctx.posture
        self.solver.begin_tick()
        self.last_block = ""
        if not bool(self.ctx.p["autonomy"].get("expand", True)) or not post.allow_expand:
            self.last_block = "autonomy"
            return
        if w.snap.map.expansion_sites:
            for s in w.snap.map.expansion_sites:
                if s.owner == w.team:
                    self._done_sites.add(s.sid)

        demand = self._demand_pressure()
        advantage = self._advantage()
        pressure = self._home_pressure()
        p = self.ctx.p["expansion"]
        # 压力记忆：只要「持续/反复」受压，就在一段时间内冻结新扩张
        if pressure >= float(p["pressure_memory_threshold"]) or post.base_threat > 0:
            self._last_pressure_time = w.time
        recent_pressure = w.time - self._last_pressure_time < float(p["pressure_memory_seconds"])
        self.last_context = {
            "demand": round(demand, 4),
            "advantage": round(advantage, 4),
            "home_pressure": round(pressure, 4),
            "recent_pressure": 1.0 if recent_pressure else 0.0,
            "army_ratio": round(float(post.metrics.get("army_ratio", 1.0)), 3),
        }

        if self.pending is not None:
            self._advance()
            return

        current = self._hall_count()
        if current >= int(p["max_expansions"]):
            self.last_block = "max_expansions"
            return
        if pressure >= float(p["threat_gate"]):
            self.last_block = "home_pressure"
            return
        if recent_pressure:
            self.last_block = "recent_pressure"
            return
        # 「主矿饱和」只是需求信号，不代表现在就该把 400 金砸在分基地上：
        # 开局 5 农民 + 520 金时开矿会直接拖垮兵营/人口节奏。
        if not self._economy_ready():
            self.last_block = "economy_not_ready"
            return

        scores = self._score_sites(demand, advantage, pressure)
        self.last_scores = scores
        if not scores:
            self.last_block = "no_site"
            return
        best = scores[0]
        if best.utility < float(p["utility_threshold"]):
            self.last_block = "utility"
            return
        window = (
            advantage >= float(p["early_expand_advantage"])
            or demand >= float(p["demand_gate"])
        )
        if not window:
            self.last_block = "no_window"
            return
        desired = self._desired_count()
        # 超出「需求推出来的数量」时，必须是难得的高价值机会
        if current >= desired and best.utility < float(p["strong_utility"]):
            self.last_block = "above_demand"
            return
        self._start(best.site)

    # ------------------------------------------------------------------ 需求/态势
    def _demand_pressure(self) -> float:
        """0..1：现有矿位是否已经装不下农民 / 钱是否已经花不出去。"""
        w = self.ctx.world
        p = self.ctx.p["expansion"]
        n = len(w.my_workers)
        capacity = sum(w.base_worker_capacity(b) for b in w.townhalls)
        if capacity <= 0:
            return 1.0 if n >= 4 else 0.0
        sat = min(1.0, n / max(1, capacity))
        # 已经贴到容量上限：这是最硬的扩张需求
        if n >= capacity - 1:
            sat = 1.0
        idle = len(w.idle_workers) / max(1, n)
        gold_ref = max(200.0, float(p["build_buffer_gold"]) * 4.0)
        store = min(1.0, max(0.0, w.gold - float(p["build_buffer_gold"])) / gold_ref)
        return max(0.0, min(1.0, 0.62 * sat + 0.23 * idle + 0.15 * store))

    def _economy_ready(self) -> bool:
        """是否具备开分矿的经济基础（不是「矿满」就够）。"""
        w = self.ctx.world
        p = self.ctx.p["expansion"]
        hall = self._hall_proto()
        if hall is None:
            return True
        trigger = max(6, int(p["worker_trigger"]))
        enough_workers = len(w.my_workers) >= trigger * float(p["economy_ready_worker_ratio"])
        enough_gold = w.gold >= hall.cost.gold * float(p["economy_ready_gold_factor"])
        return enough_workers or enough_gold

    def _advantage(self) -> float:
        """0..1：军事优势窗口。army_ratio=1 → 0，ratio≈2.2 → 1。"""
        ratio = float(self.ctx.posture.metrics.get("army_ratio", 1.0))
        return max(0.0, min(1.0, (ratio - 1.0) / 1.2))

    def _home_pressure(self) -> float:
        """0..：可见敌军对家门口的压迫程度（相对我方军队价值）。"""
        w = self.ctx.world
        p = self.ctx.p["expansion"]
        halls = w.townhalls
        if not halls:
            return 0.0
        radius = float(p["threat_radius"])
        value = 0.0
        for u in w.enemy_units:
            proto = w.proto(u.proto)
            if proto.is_worker:
                continue
            d = min(u.pos.dist(b.pos) for b in halls)
            if d <= radius:
                value += proto.value * (1.0 - 0.5 * d / radius)
        return value / max(200.0, w.army_value)

    # ------------------------------------------------------------------ 数量
    def _desired_count(self) -> int:
        w = self.ctx.world
        p = self.ctx.p["expansion"]
        trigger = max(6, int(p["worker_trigger"]))
        n = len(w.my_workers)
        capacity = sum(w.base_worker_capacity(b) for b in w.townhalls)
        desired = 1 + int(n / trigger)
        # 主矿采饱和：这是「需求」信号，不是「结论」
        if capacity > 0 and n >= capacity - 1:
            desired = max(desired, len(w.townhalls) + 1)
        return max(1, min(int(p["max_expansions"]), desired))

    # ------------------------------------------------------------------ 选址
    def _score_sites(self, demand: float, advantage: float, pressure: float) -> list[SiteScore]:
        w = self.ctx.world
        p = self.ctx.p["expansion"]
        weights = p["weights"]
        base = w.base_pos
        m = w.snap.map
        diag = max(1.0, math.hypot(m.width, m.height))
        rem_ref = max(1.0, float(p["site_remaining_ref"]))
        min_rem = float(p["site_min_remaining"])
        strategic_ratio = float(p["strategic_min_remaining_ratio"])
        out: list[SiteScore] = []
        for s in m.expansion_sites:
            if s.sid in self._done_sites or s.owner == w.team or s.has_building:
                continue
            choke, route = self._terrain(s.pos)
            terrain = 0.6 * choke + 0.4 * route
            # 低资源但高战略价值（路口/要道）的点，降低资源门槛而不是直接排除
            if s.remaining < min_rem:
                if not (terrain >= 0.55 and s.remaining >= min_rem * strategic_ratio):
                    continue
            dist = s.pos.dist(base)
            if dist < 12.0:
                continue
            danger = self.ctx.territory.danger(s.pos)
            res = min(1.5, s.remaining / rem_ref)
            # 距离成本：运输 + 防守 + 被打时支援都随距离变贵
            prox = min(1.0, dist / diag * 2.0)
            enemy_pen = self._enemy_pressure_at(s.pos)
            parts = {
                "resource": res,
                "terrain": terrain,
                "choke": choke,
                "route": route,
                "safety": 1.0 - danger,
                "advantage": advantage,
                "demand": demand,
                "distance_cost": prox,
                "enemy_pressure": enemy_pen,
                "home_pressure": pressure,
            }
            utility = (
                float(weights["resource"]) * res
                + float(weights["terrain"]) * terrain
                + float(weights["safety"]) * (1.0 - danger)
                + float(weights["advantage"]) * advantage
                + float(weights["demand"]) * demand
                - float(weights["distance"]) * prox
                - float(weights["enemy"]) * enemy_pen
            )
            out.append(SiteScore(site=s, utility=utility, parts=parts))
        out.sort(key=lambda x: x.utility, reverse=True)
        return out

    def _terrain(self, pos: Vec2) -> tuple[float, float]:
        """返回 (choke, route)，各 0..1。

        choke：局部 walkable 密度越低越像路口/走廊（易守难攻、卡位价值高）。
        route：越接近「我方基地 ↔ 敌方出生点」连线的中段，越是要道。
        """
        m = self.ctx.world.snap.map
        if not m.walkable:
            return (0.0, 0.0)
        ring: list[Vec2] = []
        for r in (4.0, 6.5):
            for k in range(8):
                ang = k * math.pi / 4.0
                ring.append(Vec2(pos.x + math.cos(ang) * r, pos.y + math.sin(ang) * r))
        walkable = sum(1 for q in ring if m.is_walkable(q))
        openness = walkable / max(1, len(ring))
        choke = 1.0 - openness
        base = self.ctx.world.base_pos
        foe = m.enemy_start
        if foe is None:
            route = 0.0
        else:
            span = max(1.0, base.dist(foe))
            route = max(0.0, 1.0 - abs(pos.dist(base) - pos.dist(foe)) / span)
        return (choke, route)

    def _enemy_pressure_at(self, pos: Vec2) -> float:
        """0..1.5：矿点附近的敌军压力（可见敌军 + 敌方出生点方向）。"""
        w = self.ctx.world
        m = w.snap.map
        value = 0.0
        for u in w.enemy_units:
            proto = w.proto(u.proto)
            if proto.is_worker:
                continue
            d = u.pos.dist(pos)
            if d <= 22.0:
                value += proto.value * (1.0 - d / 22.0)
        if m.enemy_start is not None:
            d = pos.dist(m.enemy_start)
            value += 140.0 * max(0.0, 1.0 - d / 55.0)
        return min(1.5, value / max(300.0, w.army_value))

    def _pick_site(self) -> ExpansionSite | None:
        """兼容旧调用：返回当前效用最高的矿点。"""
        scores = self._score_sites(
            self._demand_pressure(), self._advantage(), self._home_pressure()
        )
        return scores[0].site if scores else None

    def _hall_count(self) -> int:
        w = self.ctx.world
        proto = self._hall_proto()
        if proto is None:
            return len(w.townhalls)
        return sum(1 for b in w.my_buildings if b.proto == proto.id)

    def _pick_worker(self):
        w = self.ctx.world
        cands = [
            u
            for u in w.my_workers
            if not w.player_protected(u) and u.order != "build"
        ]
        if not cands:
            return None
        # 优先用离目标最远的农民（减少对主矿采集的影响）
        best = None
        best_d = -1.0
        for u in cands:
            d = u.pos.dist(w.base_pos)
            if d > best_d:
                best_d = d
                best = u
        return best

    # ------------------------------------------------------------------ 发起
    def _start(self, site: ExpansionSite | None = None) -> None:
        w = self.ctx.world
        post = self.ctx.posture
        p = self.ctx.p["expansion"]
        if post.base_threat > 0:
            self.last_block = "base_threat"
            return
        hall_proto = self._hall_proto()
        if hall_proto is None:
            self.last_block = "no_hall_proto"
            return
        if w.gold < hall_proto.cost.gold + float(p["build_buffer_gold"]):
            self.last_block = "gold"
            return
        if site is None:
            site = self._pick_site()
        if site is None:
            self.last_block = "no_site"
            return
        worker = self._pick_worker()
        if worker is None:
            self.last_block = "no_worker"
            return
        self.ctx.sched.move([worker.uid], site.pos, label="expand:move")
        self.pending = PendingExpansion(site=site, worker=worker.uid, phase="moving", since=w.time)
        self.started += 1

    def _hall_proto(self):
        for b in self.ctx.cat.buildings():
            if b.dropoff and b.built_by:
                return b
        return None

    # ------------------------------------------------------------------ 推进
    def _advance(self) -> None:
        w = self.ctx.world
        p = self.ctx.p["expansion"]
        pend = self.pending
        assert pend is not None
        if w.time - pend.since > float(p["max_pending_seconds"]):
            self.pending = None
            return
        worker = next((u for u in w.my_workers if u.uid == pend.worker), None)
        if worker is None:
            self.pending = None
            return
        proto = self._hall_proto()
        if proto is None:
            self.pending = None
            return
        # 已经出现基地？
        for b in w.my_buildings:
            if b.proto == proto.id and b.pos.dist(pend.site.pos) <= 9.0:
                if b.complete:
                    self._done_sites.add(pend.site.sid)
                    self.completed += 1
                self.pending = None
                return
        if pend.phase == "moving":
            if worker.pos.dist(pend.site.pos) > 6.0:
                return
            if w.gold < proto.cost.gold:
                return
            point = self.solver.find(proto.id, pend.site.pos, 1.5, 8.0, span=3)
            if point is None:
                pend.tries += 1
                if pend.tries > 6:
                    self.pending = None
                return
            res = self.ctx.sched.build([worker.uid], proto.id, point, label="expand:build")
            if res is not None and res.ok:
                pend.phase = "building"
                pend.since = w.time

"""RTS AI Agent：把各子系统组装成一个 ``update()`` 驱动的智能体。

同一份核心同时服务两种角色：
* 敌方人机   —— profile 里 autonomy 全开，视作「自主 AI」；
* 玩家副官   —— profile 里可关闭进攻自主权，改由玩家意图驱动。

对外只有一个入口：``RTSAgent(gateway, profile).update()``。
"""
from __future__ import annotations

from typing import Any, Mapping

from rtscontract.configio import load_json

from .adjutant import AdjutantController
from .combat import CombatManager
from .combatmodel import CombatModel
from .context import AIContext
from .director import StrategicDirector
from .economy import EconomyManager
from .expansion import ExpansionManager
from .fog import FogTracker
from .placement import PlacementSolver
from .plans import PlanLibrary
from .production import ProductionManager
from .profile import load_profile
from .sanity import SanityAuditor
from .scheduler import CommandScheduler
from .scouting import ScoutManager
from .territory import Territory
from .world import World


class RTSAgent:
    def __init__(self, gateway, profile: Mapping[str, Any] | None = None) -> None:
        self.gw = gateway
        self.cat = gateway.catalog()
        self.p = load_profile(profile)
        self.world = World(self.cat, self.p)
        self.fog = FogTracker(self.p)
        self.territory = Territory(self.p)
        self.combat_model = CombatModel(self.cat)
        self.sched = CommandScheduler(
            gateway,
            int(self.p["tick"]["max_commands_per_tick"]),
            float(self.p["tick"].get("stuck_lock_seconds", 6.0)),
            float(self.p["tick"].get("reissue_seconds", 0.6)),
        )
        self.ctx = AIContext(
            gateway=gateway,
            cat=self.cat,
            p=self.p,
            world=self.world,
            fog=self.fog,
            territory=self.territory,
            combat=self.combat_model,
            sched=self.sched,
        )
        raw_plans = load_json("plans.json", default={"plans": []}) or {"plans": []}
        self.plans = PlanLibrary(raw_plans.get("plans", []))
        self.director = StrategicDirector(
            self.world, self.fog, self.territory, self.combat_model, self.cat, self.p, self.plans
        )
        self.adjutant = AdjutantController(self.ctx)
        self.economy = EconomyManager(self.ctx)
        self.production = ProductionManager(self.ctx)
        self.expansion = ExpansionManager(self.ctx)
        self.combat = CombatManager(self.ctx)
        self.scout = ScoutManager(self.ctx)
        self.sanity = SanityAuditor(self.ctx)
        self.ticks = 0
        self.last_plan: str = ""
        self.plan_history: list[tuple[float, str]] = []

    # ------------------------------------------------------------------ 主循环
    def update(self) -> None:
        snap = self.gw.snapshot()
        if snap.game_over:
            return
        self.world.update(snap)
        self.fog.update(snap)
        self.territory.update(snap, self.world.enemy_buildings, self.cat)
        self.sched.begin_tick(snap)

        self.adjutant.ingest()
        posture = self.director.update()
        self.adjutant.apply(posture)
        self.ctx.posture = posture
        if posture.plan_id != self.last_plan:
            self.plan_history.append((round(snap.time, 1), posture.plan_id))
            self.last_plan = posture.plan_id

        self.economy.update()
        self.production.update()
        self.expansion.update()
        self.scout.update()
        self.combat.update()
        self.ctx.combat_mode = self.combat.mode
        self.sanity.update()
        # 统一出口：同 tick 内每个单位只发一条命令（见 scheduler 模块注释）
        self.sched.flush()
        self.adjutant.maybe_suggest()
        self.ticks += 1

    # ------------------------------------------------------------------ 诊断
    def stats(self) -> dict[str, Any]:
        post = self.director.posture
        return {
            "ticks": self.ticks,
            "plan": post.plan_id,
            "plan_changes": self.director.plan_changes,
            "plan_history": list(self.plan_history),
            "stance": post.stance,
            "mode": self.combat.mode,
            "army_ratio": round(post.metrics.get("army_ratio", 0.0), 3) if post.metrics else 0.0,
            "commands": self.sched.stats(),
            "sanity": self.sanity.stats(),
            "economy": {
                "workers_trained": self.economy.workers_trained,
                "build_attempts": self.economy.build_attempts,
                "placement_hits": self.economy.placement.hits,
                "placement_misses": self.economy.placement.misses,
            },
            "production": {"trained": self.production.trained},
            "expansion": {"started": self.expansion.started, "completed": self.expansion.completed},
            "combat": dict(self.combat.stats),
            "scout": {"trips": self.scout.trips, "active": len(self.scout.scouts)},
            "adjutant": self.adjutant.stats(),
        }

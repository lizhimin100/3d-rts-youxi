"""经济运营：农民生产、人口供给、采集分配、生产建筑与基础防御的建造。

所有决策都是「相对当前状态」的：不依赖第几分钟应该有几个农民这类硬编码脚本，
而是由 Posture（计划权重）与饱和度实时推导。
"""
from __future__ import annotations

from typing import Iterable

from rtscontract.catalog import Proto
from rtscontract.enums import PROTECTED_CONTROL, OrderKind

from .context import AIContext
from .placement import PlacementSolver


class EconomyManager:
    def __init__(self, ctx: AIContext) -> None:
        self.ctx = ctx
        self.placement = PlacementSolver(ctx.gateway, budget_per_tick=36)
        self.pending_until: dict[str, float] = {}
        self.raid_seen_at: float = -999.0
        self.build_attempts = 0
        self._used_workers: set[int] = set()
        self.workers_trained = 0

    # ------------------------------------------------------------------ 主流程
    def update(self) -> None:
        p = self.ctx.p
        self.placement.begin_tick()
        self._used_workers.clear()
        if not bool(p["autonomy"].get("manage_economy", True)):
            return
        self._train_workers()
        if bool(p["autonomy"].get("manage_supply", True)):
            self._manage_supply()
        self._assign_workers()
        self._build_structures()
        self._build_defense()

    # ------------------------------------------------------------------ 农民
    def _worker_proto(self) -> Proto | None:
        ws = self.ctx.cat.workers()
        return ws[0] if ws else None

    def _queued_count(self, proto_id: str) -> int:
        n = 0
        for b in self.ctx.world.my_buildings:
            if not b.complete:
                continue
            n += sum(1 for q in b.queue if q == proto_id)
        return n

    def _train_workers(self) -> None:
        w = self.ctx.world
        p = self.ctx.p
        post = self.ctx.posture
        wp = self._worker_proto()
        if wp is None or not w.townhalls:
            return
        per_base = int(p["economy"]["worker_target_per_base"])
        capacity = sum(w.base_worker_capacity(b) for b in w.townhalls)
        target = min(int(post.worker_cap), capacity if capacity > 0 else per_base)
        have = len(w.my_workers) + self._queued_count(wp.id)
        if have >= target:
            return
        depth = int(p["economy"]["worker_queue_depth"])
        reserve = float(p["economy"]["reserve_gold"])
        for hall in sorted(w.townhalls, key=lambda b: len(b.queue)):
            if len(hall.queue) >= depth:
                continue
            if w.gold < wp.cost.gold + reserve:
                break
            if w.supply_headroom < wp.cost.supply:
                break
            if self.ctx.sched.train(hall.bid, wp.id, label="econ:worker") is not None:
                have += 1
                self.workers_trained += 1
            if have >= target:
                break

    # ------------------------------------------------------------------ 人口
    def _supply_proto(self) -> Proto | None:
        w = self.ctx.world
        completed = {b.proto for b in w.complete_buildings}
        cands = [
            b
            for b in self.ctx.cat.supply_buildings()
            if self.ctx.cat.tech_satisfied(b, completed) and bool(b.built_by)
        ]
        if not cands:
            return None
        cands.sort(key=lambda b: (b.cost.gold, b.build_time))
        return cands[0]

    def _is_pending(self, proto_id: str) -> bool:
        if self.pending_until.get(proto_id, 0.0) > self.ctx.world.time:
            return True
        return any(b.proto == proto_id for b in self.ctx.world.constructing)

    def _manage_supply(self) -> None:
        w = self.ctx.world
        p = self.ctx.p
        proto = self._supply_proto()
        if proto is None:
            return
        if w.supply_cap >= float(self.ctx.cat.supply_max) - 1e-6:
            return
        pending_cap = sum(
            w.proto(b.proto).supply_provided for b in w.constructing if w.proto(b.proto).supply_provided > 0
        )
        emergency = w.supply_headroom <= float(p["economy"]["supply_emergency_headroom"])
        # 主动型供给：人口上限要跑在「军队目标 + 农民 + 余量」之前，
        # 否则会在满人口处反复卡住（这是新手最典型的运营错误之一）。
        want = (
            self.ctx.posture.army_supply_target
            + len(w.my_workers)
            + float(p["economy"]["supply_headroom_target"])
        )
        target_cap = min(float(self.ctx.cat.supply_max), want)
        if w.supply_cap + pending_cap >= target_cap and not emergency:
            return
        # 允许同时在造的供给建筑：默认 1，囤金/断供时 2（否则人口上限涨得比收入慢）
        inflight = sum(
            1 for b in w.constructing if w.proto(b.proto).supply_provided > 0
        )
        max_inflight = 2 if (w.gold > 350.0 or emergency) else 1
        if inflight >= max_inflight:
            return
        reserve = 40.0 if emergency else 90.0
        if w.gold < proto.cost.gold + reserve:
            return
        workers = self._build_worker_ids()
        if not workers:
            return
        avoid = self._avoid_segments()
        point = self.placement.find(proto.id, w.base_pos, 4.0, 14.0, avoid_segments=avoid)
        if point is None:
            return
        res = self.ctx.sched.build(workers[:1], proto.id, point, label="econ:supply")
        if res is not None and res.ok:
            self.pending_until[proto.id] = w.time + proto.build_time + 4.0
            self.build_attempts += 1
            self._used_workers.add(workers[0])

    # ------------------------------------------------------------------ 采集
    def _free_worker_ids(self) -> list[int]:
        w = self.ctx.world
        out = []
        for u in w.my_workers:
            if u.order in (OrderKind.IDLE, OrderKind.STOP) and u.control not in PROTECTED_CONTROL:
                out.append(u.uid)
        return out

    def _build_worker_ids(self) -> list[int]:
        """建造用农民：优先空闲，其次任何不在建造中的农民（抽一个去盖房是值得的）。"""
        w = self.ctx.world
        idle: list[int] = []
        busy: list[int] = []
        for u in w.my_workers:
            if u.control in PROTECTED_CONTROL or u.order == OrderKind.BUILD:
                continue
            if u.uid in self._used_workers:
                continue
            if u.order in (OrderKind.IDLE, OrderKind.STOP):
                idle.append(u.uid)
            else:
                busy.append(u.uid)
        busy.sort(key=lambda uid: next((u.pos.dist(w.base_pos) for u in w.my_workers if u.uid == uid), 0.0))
        return idle + busy

    def _assign_workers(self) -> None:
        w = self.ctx.world
        workers = w.idle_workers
        if not workers or not w.townhalls:
            return
        reserved: dict[int, int] = {}
        for u in workers:
            best = None
            for b in w.townhalls:
                node = self._best_node(b, reserved)
                if node is None:
                    continue
                score = (node[1] * 2.0) - u.pos.dist(b.pos) / 25.0
                if best is None or score > best[0]:
                    best = (score, b, node[0])
            if best is None:
                break
            _, base, node = best
            reserved[node.nid] = reserved.get(node.nid, 0) + 1
            self.ctx.sched.harvest([u.uid], node.nid, base.bid, label="econ:harvest")

    def _best_node(self, base, reserved: dict[int, int]):
        w = self.ctx.world
        best = None
        best_score = -1e9
        for n in w.snap.nodes:
            if n.pos.dist(base.pos) > 18.0 or n.remaining <= 0:
                continue
            free = n.free_slots - reserved.get(n.nid, 0)
            if free <= 0:
                continue
            score = free * 2.0 + n.remaining / 400.0 - n.pos.dist(base.pos) / 30.0
            if score > best_score:
                best_score = score
                best = (n, free)
        return best

    # ------------------------------------------------------------------ 建筑
    def _build_structures(self) -> None:
        w = self.ctx.world
        p = self.ctx.p
        post = self.ctx.posture
        buildable = [b for b in w.buildable_protos() if b.produce and not b.dropoff]
        if not buildable:
            return
        completed = {b.proto for b in w.complete_buildings}
        tech_ok = [b for b in buildable if self.ctx.cat.tech_satisfied(b, completed)]
        if not tech_ok:
            tech_ok = buildable
        prod_ids = {b.id for b in buildable}
        have = [b for b in w.complete_buildings if b.proto in prod_ids]
        pending = [b for b in w.constructing if b.proto in prod_ids]
        target_count = max(1, min(5, 1 + int(post.army_supply_target / 12)))
        if len(have) + len(pending) >= target_count:
            return

        have_ids = {b.proto for b in have} | {b.proto for b in pending}
        pool = sorted(tech_ok, key=lambda b: (b.cost.gold, b.build_time))
        cheapest = pool[0]
        same = sum(1 for b in have if b.proto == cheapest.id)
        fresh = [b for b in pool if b.id not in have_ids]
        # 先用最便宜的生产建筑铺量，再考虑开新兵种建筑（避免过早造出不受控的兵种）
        if same < 2 or not fresh:
            proto = cheapest
        else:
            proto = fresh[0]
        if self._is_pending(proto.id):
            return
        buffer = 60.0 + float(p["economy"]["reserve_gold"])
        if w.gold < proto.cost.gold + buffer:
            return
        workers = self._build_worker_ids()
        if not workers:
            return
        avoid = self._avoid_segments()
        point = self.placement.find(proto.id, w.base_pos, 4.0, 16.0, avoid_segments=avoid)
        if point is None:
            return
        res = self.ctx.sched.build(workers[:1], proto.id, point, label="econ:production")
        if res is not None and res.ok:
            self.pending_until[proto.id] = w.time + proto.build_time + 4.0
            self.build_attempts += 1
            self._used_workers.add(workers[0])

    def _build_defense(self) -> None:
        w = self.ctx.world
        p = self.ctx.p
        if w.snap.supply_cap <= 0:
            return
        if w.threat_value_near(w.base_pos, float(p["combat"]["defense_radius"])) > 0:
            self.raid_seen_at = w.time
        if w.time - self.raid_seen_at > 100.0:
            return
        defs = [b for b in self.ctx.cat.buildings() if b.is_defense and b.built_by]
        if not defs:
            return
        defs.sort(key=lambda b: (b.cost.gold, b.build_time))
        proto = defs[0]
        completed = {b.proto for b in w.complete_buildings}
        if not self.ctx.cat.tech_satisfied(proto, completed):
            return
        near = [
            b
            for b in w.complete_buildings + w.constructing
            if b.proto == proto.id and b.pos.dist(w.base_pos) <= 20.0
        ]
        if len(near) >= 2:
            return
        if self._is_pending(proto.id):
            return
        if w.gold < proto.cost.gold + 40.0:
            return
        workers = self._build_worker_ids()
        if not workers:
            return
        point = self.placement.find(proto.id, w.base_pos, 5.0, 12.0)
        if point is None:
            return
        res = self.ctx.sched.build(workers[:1], proto.id, point, label="econ:tower")
        if res is not None and res.ok:
            self.pending_until[proto.id] = w.time + proto.build_time + 4.0
            self.build_attempts += 1
            self._used_workers.add(workers[0])

    # ------------------------------------------------------------------ 辅助
    def _avoid_segments(self) -> list[tuple]:
        """不要挡住基地到矿点的通路。"""
        w = self.ctx.world
        base = w.base_pos
        segs = []
        for n in w.snap.nodes:
            if n.pos.dist(base) <= 20.0:
                segs.append((base, n.pos))
        return segs

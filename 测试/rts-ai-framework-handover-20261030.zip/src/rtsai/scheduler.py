"""命令调度器：同 tick 合并、去重、限额、卡死锁定、失败退避。

为什么需要它
------------
* AI 每秒会跑 5 次决策，如果每次都无脑重发同样的命令，会淹没真实游戏的事件系统，
  也会造成单位抖动。这里基于「快照里单位当前的状态」做幂等过滤。
* **多个 Manager 会在同一 tick 对同一个单位下令**（经济、扩张、侦察、战斗、反愚蠢）。
  直接把命令逐条发给网关，会导致同一单位同 tick 收到 2~3 条互相覆盖的命令
  （审计发现的 duplicates）。这里改为「先登记、后统一 flush」：
  同一 tick 内每个单位只保留最后一条命令（管理器执行顺序即优先级，
  sanity 在最后 → 恢复类命令优先），再把目标完全相同的单位合并成一条命令。
* 所有命令都必须经过本调度器，从而保证：
  - 每 tick 命令数量有上限（可配置）；
  - 玩家保护单位在**AI 侧**就被过滤掉（网关侧还有第二道防线）；
  - 卡死单位在一段时间内不再被反复下令（切断 STOP→MOVE→STOP 抖动）；
  - 失败原因可统计，便于自动诊断与考试断言。
"""
from __future__ import annotations

from collections import Counter, deque
from dataclasses import replace
from typing import Iterable, Sequence

from rtscontract.commands import Command, CommandResult
from rtscontract.enums import (  # noqa: F401
    PROTECTED_CONTROL,
    Cmd,
    ControlKind,
    Issuer,
    OrderKind,
    Reason,
)
from rtscontract.vec import Vec2

# 单位已经在目标点附近时，视为"这条命令已经完成"，不再重发。
# 否则会出现「到达 → idle → 重发 → 到达」的每 tick 循环（AUDIT_REPORT P0-1）。
ARRIVE_EPS = 0.9
PLAYER_ORDERS = {
    OrderKind.MOVE,
    OrderKind.ATTACK,
    OrderKind.ATTACK_MOVE,
    OrderKind.HOLD,
    OrderKind.PATROL,
}
# 这些命令作用于单位，参与「同 tick 一单位一命令」仲裁
UNIT_ORDER_KINDS = frozenset(
    {
        Cmd.MOVE,
        Cmd.ATTACK,
        Cmd.ATTACK_MOVE,
        Cmd.HOLD,
        Cmd.STOP,
        Cmd.HARVEST,
        Cmd.ASSIST,
        Cmd.REPAIR,
    }
)
# 移动类命令：对卡死单位做退避，避免「下令→撞墙→STOP→再下令」自持循环
MOVE_KINDS = frozenset({Cmd.MOVE, Cmd.ATTACK_MOVE, Cmd.ATTACK})
# 防守/撤退/恢复类命令不参与重发节流：这些命令的延迟会直接导致基地被拆。
NO_THROTTLE_LABELS = ("combat:defend", "combat:recall", "combat:retreat",
                      "combat:unit_retreat", "sanity:")


class CommandScheduler:
    def __init__(
        self,
        gateway,
        max_per_tick: int = 48,
        stuck_lock_seconds: float = 6.0,
        reissue_seconds: float = 0.6,
    ) -> None:
        self.gw = gateway
        self.max_per_tick = max(1, int(max_per_tick))
        self.stuck_lock = max(0.0, float(stuck_lock_seconds))
        self.reissue = max(0.0, float(reissue_seconds))
        self.issued = 0
        self.sent = 0
        self.skipped = 0
        self.dropped = 0
        self.merged = 0
        self.failures: Counter[str] = Counter()
        self.recent: deque[Command] = deque(maxlen=64)
        self.tick_commands: list[Command] = []
        self.recent_failures: deque[tuple[str, str]] = deque(maxlen=32)
        self._units: dict[int, object] = {}
        self._tick = 0
        self._time = 0.0
        self._queue: dict[int, Command] = {}
        self._stuck_hits: dict[int, int] = {}
        self._stuck_level: dict[int, int] = {}
        self._stuck_until: dict[int, float] = {}
        self._stuck_recovered: dict[int, float] = {}
        self._reject_until: dict[int, float] = {}
        self._reject_reason: dict[int, str] = {}
        self._last_issue: dict[tuple[int, str], float] = {}
        self.throttled = 0
        self.unreachable = 0

    # ------------------------------------------------------------------ 生命周期
    def begin_tick(self, snapshot) -> None:
        self._tick = snapshot.tick
        self._time = float(snapshot.time)
        self._units = snapshot.unit_map()
        self.issued = 0
        self.tick_commands.clear()
        self._queue.clear()
        self._refresh_stuck_locks(snapshot)

    def _refresh_stuck_locks(self, snapshot) -> None:
        """连续两个快照都 stuck 的单位，锁定一段时间不再下移动命令。

        锁定时间按「同一个单位第几次卡住」指数退避（6 → 12 → 24 → 48 秒）。
        路径永久失败时，固定 6 秒会产生 6 秒一次的稳定抖动；
        指数退避让系统在 40 秒内收敛到「不再下令」。
        """
        for u in snapshot.units:
            uid = u.uid
            moving = getattr(u, "order", "") in (OrderKind.MOVE, OrderKind.ATTACK_MOVE, OrderKind.ATTACK)
            if moving and u.stuck:
                self._stuck_recovered.pop(uid, None)
                n = self._stuck_hits.get(uid, 0) + 1
                if n >= 2:
                    level = self._stuck_level.get(uid, 0) + 1
                    self._stuck_level[uid] = level
                    dur = min(self.stuck_lock * (2.0 ** (level - 1)), self.stuck_lock * 8.0)
                    # 网关能回答「这个点到底可不可达」时，直接用事实判定：
                    # 不可达 → 长时间不再尝试（真实游戏里等价于「这条路走不通」）。
                    point = getattr(u, "order_point", None)
                    can_reach = getattr(self.gw, "can_reach", None)
                    if point is not None and can_reach is not None:
                        try:
                            if not can_reach([uid], point):
                                dur = max(dur, 120.0)
                                self.unreachable += 1
                        except Exception:  # noqa: BLE001 - 网关不支持时退回时间退避
                            pass
                    self._stuck_until[uid] = self._time + dur
                    n = 0
                self._stuck_hits[uid] = n
            elif not u.stuck:
                self._stuck_hits.pop(uid, None)
                if moving:
                    self._stuck_recovered.pop(uid, None)
                else:
                    # 只有「连续空闲 20 秒」才算真正恢复，清零退避等级。
                    # 否则 STOP→idle 会立刻把等级清掉，指数退避永远不生效。
                    since = self._stuck_recovered.setdefault(uid, self._time)
                    if self._time - since >= 20.0:
                        self._stuck_level.pop(uid, None)

    def flush(self) -> None:
        """把本 tick 登记的单位命令合并后真正发给网关。"""
        if not self._queue:
            return
        groups: dict[tuple, list[int]] = {}
        meta: dict[tuple, Command] = {}
        for uid, cmd in self._queue.items():
            key = (
                cmd.kind,
                cmd.issuer,
                cmd.team,
                cmd.target,
                cmd.building,
                None if cmd.point is None else cmd.point.round(1),
                cmd.proto,
                cmd.extra,
                cmd.label,
            )
            groups.setdefault(key, []).append(uid)
            meta[key] = cmd
        self._queue.clear()
        for key, units in groups.items():
            cmd = meta[key]
            if self.issued >= self.max_per_tick:
                self.dropped += len(units)
                continue
            merged = replace(cmd, units=tuple(sorted(units)))
            self.issued += 1
            self.sent += 1
            self.recent.append(merged)
            res = self.gw.issue(merged)
            if not res.ok:
                self.failures[res.reason] += 1
                self.recent_failures.append((res.reason, merged.describe()))
                # 连续被拒 → 对相关单位做退避，避免每 tick 重试
                if res.reason in (Reason.PLACE_INVALID, Reason.INVALID, Reason.BUSY):
                    for uid in units:
                        self._reject_until[uid] = self._time + 2.0
                        self._reject_reason[uid] = res.reason

    # ------------------------------------------------------------------ 过滤
    def available(self, uids: Iterable[int]) -> list[int]:
        """剔除玩家保护中的单位（控制权锁 / 手动操控 / 正在执行玩家指令）。"""
        out: list[int] = []
        for uid in uids:
            u = self._units.get(uid)
            if u is None:
                continue
            if getattr(u, "control", "") in PROTECTED_CONTROL:
                continue
            if getattr(u, "order_owner", "") == Issuer.PLAYER and getattr(u, "order", "") in PLAYER_ORDERS:
                continue
            out.append(uid)
        return out

    def _blocked(self, uid: int, kind: str) -> str:
        if kind not in MOVE_KINDS:
            return ""
        if self._time < self._stuck_until.get(uid, 0.0):
            return "stuck_lock"
        if self._time < self._reject_until.get(uid, 0.0):
            return "reject_backoff"
        return ""

    def _already_doing(self, u, kind: str, target: int | None, point: Vec2 | None) -> bool:
        order = getattr(u, "order", "")
        if kind == Cmd.MOVE:
            if point is not None and getattr(u, "pos", None) is not None:
                if u.pos.dist(point) <= ARRIVE_EPS:
                    return True          # 已经站在目标点上，不必再下令
            if order != OrderKind.MOVE or point is None:
                return False
            p = getattr(u, "order_point", None)
            return p is not None and p.dist(point) <= 1.5
        if kind == Cmd.ATTACK:
            return order == OrderKind.ATTACK and getattr(u, "order_target", None) == target
        if kind == Cmd.ATTACK_MOVE:
            if point is not None and getattr(u, "pos", None) is not None:
                if u.pos.dist(point) <= ARRIVE_EPS:
                    return True
            if order != OrderKind.ATTACK_MOVE or point is None:
                return False
            p = getattr(u, "order_point", None)
            return p is not None and p.dist(point) <= 2.0
        if kind == Cmd.HARVEST:
            return order == OrderKind.HARVEST and getattr(u, "order_target", None) == target
        if kind == Cmd.HOLD:
            return order == OrderKind.HOLD
        return False

    # ------------------------------------------------------------------ 下达
    def submit(self, cmd: Command) -> CommandResult | None:
        if cmd.units and cmd.kind in UNIT_ORDER_KINDS:
            return self._enqueue(cmd)
        if self.issued >= self.max_per_tick:
            self.dropped += 1
            return None
        self.issued += 1
        self.sent += 1
        self.recent.append(cmd)
        self.tick_commands.append(cmd)
        res = self.gw.issue(cmd)
        if not res.ok:
            self.failures[res.reason] += 1
            self.recent_failures.append((res.reason, cmd.describe()))
        return res

    def _enqueue(self, cmd: Command) -> CommandResult | None:
        units: list[int] = []
        for uid in cmd.units:
            u = self._units.get(uid)
            if u is None:
                continue
            if self._blocked(uid, cmd.kind):
                self.skipped += 1
                continue
            if self._already_doing(u, cmd.kind, cmd.target, cmd.point):
                self.skipped += 1
                continue
            # 重发节流：目标每 tick 都在变的微操（集结点漂移、目标切换）
            # 不应该变成「每个单位每个 AI tick 一条命令」。
            if cmd.kind in MOVE_KINDS and not cmd.label.startswith(NO_THROTTLE_LABELS):
                last = self._last_issue.get((uid, cmd.kind), -999.0)
                if self._time - last < self.reissue:
                    self.throttled += 1
                    self.skipped += 1
                    continue
            units.append(uid)
        if not units:
            return None
        if cmd.kind in MOVE_KINDS:
            # 已经因为其它命令被本 tick 登记过？卡死/被拒的单位不再接受移动命令
            units = [uid for uid in units if not self._blocked(uid, cmd.kind)]
            if not units:
                return None
        sub = replace(cmd, units=tuple(units))
        self.tick_commands.append(sub)
        for uid in units:
            # 后登记的命令覆盖先登记的（管理器执行顺序即优先级，sanity 最后）
            self._queue[uid] = sub
            self._last_issue[(uid, cmd.kind)] = self._time
        return CommandResult(True, "queued", "", len(units))

    # ------------------------------------------------------------------ 语义化封装
    def move(self, uids: Sequence[int], point: Vec2, label: str = "") -> None:
        uids = self.available(uids)
        if uids:
            self.submit(Command(Cmd.MOVE, self._issuer(), self._team(), tuple(uids), point=point, label=label))

    def move_players_safe(self, uids: Sequence[int], point: Vec2, label: str = "") -> None:
        self.move(uids, point, label)

    def attack(self, uids: Sequence[int], target: int, label: str = "") -> None:
        uids = self.available(uids)
        if uids:
            self.submit(Command(Cmd.ATTACK, self._issuer(), self._team(), tuple(uids), target=target, label=label))

    def attack_move(self, uids: Sequence[int], point: Vec2, label: str = "") -> None:
        uids = self.available(uids)
        if uids:
            self.submit(
                Command(Cmd.ATTACK_MOVE, self._issuer(), self._team(), tuple(uids), point=point, label=label)
            )

    def hold(self, uids: Sequence[int], label: str = "") -> None:
        uids = self.available(uids)
        if uids:
            self.submit(Command(Cmd.HOLD, self._issuer(), self._team(), tuple(uids), label=label))

    def harvest(self, uids: Sequence[int], node: int, dropoff: int, label: str = "") -> None:
        uids = self.available(uids)
        if uids:
            self.submit(
                Command(
                    Cmd.HARVEST,
                    self._issuer(),
                    self._team(),
                    tuple(uids),
                    target=node,
                    extra=(dropoff,),
                    label=label,
                )
            )

    def build(self, uids: Sequence[int], proto: str, point: Vec2, label: str = "") -> CommandResult | None:
        uids = self.available(uids)
        if not uids:
            return None
        # 建造是"占位"命令：立即发出，并把该单位从本 tick 的队列里摘掉，
        # 避免后续（更晚登记的）移动命令把建造覆盖掉。
        self._queue.pop(uids[0], None)
        return self.submit(
            Command(Cmd.BUILD, self._issuer(), self._team(), (uids[0],), proto=proto, point=point, label=label)
        )

    def train(self, building: int, proto: str, label: str = "") -> CommandResult | None:
        return self.submit(
            Command(Cmd.TRAIN, self._issuer(), self._team(), building=building, proto=proto, label=label)
        )

    def rally(self, building: int, point: Vec2, label: str = "") -> CommandResult | None:
        return self.submit(
            Command(Cmd.SET_RALLY, self._issuer(), self._team(), building=building, point=point, label=label)
        )

    # ------------------------------------------------------------------ 内部
    def _team(self) -> int:
        return int(getattr(self.gw, "team", 0))

    def _issuer(self) -> str:
        return str(getattr(self.gw, "issuer", Issuer.ADJUTANT))

    # ------------------------------------------------------------------ 统计
    def stats(self) -> dict[str, object]:
        return {
            "commands_sent": self.sent,
            "commands_skipped": self.skipped,
            "commands_dropped": self.dropped,
            "failures": dict(self.failures),
            "stuck_locked_units": len(self._stuck_until),
            "unreachable_blacklists": self.unreachable,
        }

"""AI 参数档案：全部阈值/权重来自 ``config/ai_profile.json``。

设计原则：AI 的行为由配置驱动，代码里不出现「针对某个兵种/某张地图」的常量。
换一套数值即可得到风格完全不同的 AI（激进/运营/龟缩），无需改代码。
"""
from __future__ import annotations

from typing import Any, Mapping

from rtscontract.configio import deep_merge, load_json

# 兜底默认值：与 config/ai_profile.json 保持同构，缺失字段时保证 AI 仍可运行。
DEFAULTS: dict[str, Any] = {
    "version": 1,
    "tick": {
        "max_commands_per_tick": 48,
        "heavy_interval_ticks": 10,
        "sanity_interval_ticks": 5,
        "stuck_lock_seconds": 6.0,
        "reissue_seconds": 0.6,
    },
    "economy": {
        "worker_target_per_base": 11,
        "worker_hard_floor": 6,
        "worker_queue_depth": 2,
        "supply_headroom_target": 6,
        "supply_emergency_headroom": 2,
        "max_gold_float": 600,
        "reserve_gold": 30,
        "max_workers_per_node": 5,
        "build_interval_ticks": 10,
    },
    "production": {
        "queue_depth": 2,
        "army_supply_ratio": 0.72,
        "min_army_supply": 8,
        "counter_weight": 1.2,
        "role_weight": 0.65,
        "cost_weight": 0.28,
        "supply_weight": 0.55,
        "time_weight": 0.35,
        "air_counter_share": 0.28,
        "roles": [
            {"id": "frontline", "tags": ["melee", "frontline"], "share": 0.42},
            {"id": "ranged", "tags": ["ranged"], "share": 0.43},
            {"id": "siege", "tags": ["siege"], "share": 0.15},
        ],
    },
    "combat": {
        "defense_radius": 17,
        "threat_engage_radius": 22,
        "defense_commit_ratio": 0.8,
        "attack_power_ratio": 1.35,
        "retreat_power_ratio": 0.72,
        "retreat_hp_pct": 0.22,
        "regroup_seconds": 10,
        "focus_fire": True,
        "kite_ranged": True,
        "worker_flee_radius": 13,
        "max_chase_distance": 28,
        "army_gather_ratio": 0.75,
        "min_attack_units": 4,
        "retreat_cooldown": 18,
        "enemy_mix_memory_seconds": 120.0,
    },
    "expansion": {
        "max_expansions": 3,
        "worker_trigger": 14,
        "min_army_ratio": 0.9,
        "site_min_remaining": 600,
        "build_buffer_gold": 120,
        "max_pending_seconds": 60,
        # ---- 效用模型（替代「主矿饱和即开矿」）----
        "site_remaining_ref": 900,
        "strategic_min_remaining_ratio": 0.35,
        "utility_threshold": 1.05,
        "strong_utility": 1.45,
        "early_expand_advantage": 0.85,
        "demand_gate": 0.55,
        "threat_radius": 40,
        "threat_gate": 0.75,
        "pressure_memory_seconds": 25.0,
        "pressure_memory_threshold": 0.35,
        "economy_ready_worker_ratio": 0.6,
        "economy_ready_gold_factor": 2.5,
        "weights": {
            "resource": 0.85,
            "terrain": 0.55,
            "safety": 0.45,
            "advantage": 0.75,
            "demand": 0.55,
            "distance": 0.8,
            "enemy": 0.6,
        },
    },
    "scouting": {"enabled": True, "interval_seconds": 18, "max_scouts": 2, "explore_target_ratio": 0.55},
    "sanity": {
        "stuck_seconds": 2.5,
        "idle_army_alert": 8,
        "gold_float_limit": 900,
        "trickle_min_group": 3,
        "enabled": True,
    },
    "autonomy": {
        "manage_economy": True,
        "manage_supply": True,
        "manage_production": True,
        "move_army_defensive": True,
        "move_army_aggressive": True,
        "expand": True,
        "scout": True,
        "micro": True,
        "request_control": True,
        "directive_ttl_seconds": 30,
    },
    "strategy": {"plan_min_seconds": 8, "rally_offset": 0.32, "attack_advantage_hysteresis": 1.1},
}


def load_profile(overrides: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """加载档案：内置默认值 ← config/ai_profile.json ← 调用方覆盖。"""
    try:
        file_cfg = load_json("ai_profile.json", default={}) or {}
    except Exception:  # pragma: no cover - 配置文件损坏时不应让 AI 崩溃
        file_cfg = {}
    cfg = deep_merge(DEFAULTS, file_cfg)
    if overrides:
        cfg = deep_merge(cfg, dict(overrides))
    return cfg


def profile_with(base: Mapping[str, Any], patch: Mapping[str, Any]) -> dict[str, Any]:
    """在已有档案上做局部覆盖（考试用于构造不同风格的 AI）。"""
    return deep_merge(dict(base), dict(patch))

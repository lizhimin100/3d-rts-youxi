"""战斗数学：把「攻击类型 × 护甲类型」矩阵变成可比较的战力数值。

核心公式（全部来自数据，不含任何具体兵种名）
--------------------------------------------
* ``dps(a, b)``     : a 打 b 的每秒伤害（含克制倍率与护甲减伤）
* ``survival(a, b)``: a 在 b 的火力下能活多久 = hp / dps(b, a)
* ``power(a, b)``   : a 在死前能打出的总伤害 = dps(a, b) * survival(a, b)
* 军队强弱         : Σ power(unit, 敌方构成)，用「期望总输出」近似兰彻斯特交换

这样新增兵种只要填好 damage_type / armor_type / hp / dps，克制关系自动成立。
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping, Sequence

from rtscontract.catalog import Catalog, Proto

INF_SURVIVAL = 600.0


@dataclass(frozen=True, slots=True)
class BattleEstimate:
    my_score: float
    enemy_score: float
    ratio: float            # my/enemy（>1 占优）
    win_chance: float       # 0..1
    survivors: float        # 期望残存比例（我方）


class CombatModel:
    def __init__(self, catalog: Catalog) -> None:
        self.cat = catalog
        self.rules = catalog.rules

    # ------------------------------------------------------------------ 单体
    def dps(self, a: Proto, b: Proto) -> float:
        atk = a.attack
        if atk is None or not atk.can_hit(b.flying):
            return 0.0
        m = self.rules.multiplier(atk.damage_type, b.armor_type)
        m *= self.rules.tag_multiplier(a.tags, b.tags)
        return atk.dps * m * self.rules.armor_reduction(b.armor)

    def survival(self, a: Proto, b: Proto) -> float:
        incoming = self.dps(b, a)
        if incoming <= 1e-6:
            return INF_SURVIVAL
        return a.hp / incoming

    def power(self, a: Proto, b: Proto) -> float:
        return self.dps(a, b) * self.survival(a, b)

    # ------------------------------------------------------------------ 构成
    @staticmethod
    def normalize_mix(mix: Mapping[str, float]) -> dict[str, float]:
        total = sum(max(0.0, v) for v in mix.values())
        if total <= 0:
            return {}
        return {k: max(0.0, v) / total for k, v in mix.items() if v > 0}

    def score_unit(self, proto: Proto, enemy_mix: Mapping[str, float]) -> float:
        """单位在给定敌方构成下的「期望总输出」。"""
        mix = self.normalize_mix(enemy_mix)
        if not mix:
            return proto.value
        out_dps = 0.0
        in_dps = 0.0
        for eid, share in mix.items():
            if not self.cat.has(eid):
                continue
            e = self.cat.get(eid)
            out_dps += share * self.dps(proto, e)
            in_dps += share * self.dps(e, proto)
        survival = proto.hp / in_dps if in_dps > 1e-6 else INF_SURVIVAL
        return out_dps * survival

    def army_score(self, protos: Iterable[Proto], enemy_mix: Mapping[str, float]) -> float:
        return sum(self.score_unit(p, enemy_mix) for p in protos)

    def mix_of(self, protos: Iterable[Proto]) -> dict[str, float]:
        mix: dict[str, float] = {}
        for p in protos:
            mix[p.id] = mix.get(p.id, 0.0) + 1.0
        return mix

    def estimate(self, mine: Sequence[Proto], theirs: Sequence[Proto]) -> BattleEstimate:
        my_mix = self.mix_of(mine)
        enemy_mix = self.mix_of(theirs)
        sa = self.army_score(mine, enemy_mix)
        sb = self.army_score(theirs, my_mix)
        total = sa + sb
        ratio = sa / sb if sb > 1e-6 else (99.0 if sa > 0 else 1.0)
        win = sa / total if total > 1e-6 else 0.5
        survivors = max(0.0, min(1.0, 2.0 * win - 1.0))
        return BattleEstimate(sa, sb, ratio, win, survivors)

    # ------------------------------------------------------------------ 生产决策
    def role_of(self, proto: Proto, roles: Sequence[Mapping]) -> str | None:
        for r in roles:
            tags = r.get("tags", ())
            if any(t in proto.tags for t in tags):
                return str(r.get("id"))
        return None

    def anti_air_value(self, proto: Proto, enemy_mix: Mapping[str, float]) -> float:
        air = 0.0
        ground = 0.0
        for eid, share in enemy_mix.items():
            if not self.cat.has(eid):
                continue
            e = self.cat.get(eid)
            if e.flying:
                air += share * self.dps(proto, e)
            else:
                ground += share * self.dps(proto, e)
        return air / (air + ground) if (air + ground) > 1e-6 else 0.0

    def best_against(self, candidates: Sequence[Proto], enemy_mix: Mapping[str, float]) -> list[tuple[Proto, float]]:
        scored = [(p, self.score_unit(p, enemy_mix)) for p in candidates]
        scored.sort(key=lambda kv: kv[1], reverse=True)
        return scored

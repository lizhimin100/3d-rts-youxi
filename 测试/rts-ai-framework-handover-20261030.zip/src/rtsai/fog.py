"""战争迷雾推理：探索度跟踪与侦察目标选择。

AI 只能看到快照里的可见信息；本模块基于「已探索宏格」和静态地图知识
（分矿点、敌方出生点）挑选侦察目标，避免 AI 盲打或原地发呆。
"""
from __future__ import annotations

from typing import Iterable

from rtscontract.snapshot import MapInfo, WorldSnapshot
from rtscontract.vec import Vec2


class FogTracker:
    def __init__(self, profile) -> None:
        self.p = profile
        self.map: MapInfo | None = None
        self.explored: list[float] = []
        self.ratio: float = 0.0
        self._known_points: list[Vec2] = []

    def update(self, snap: WorldSnapshot) -> None:
        self.map = snap.map
        self.explored = list(snap.fog.macro_explored) if snap.fog.macro_explored else []
        self.ratio = snap.fog.explored_ratio
        if not self._known_points:
            pts = [s.pos for s in snap.map.expansion_sites]
            if snap.map.enemy_start is not None:
                pts.append(snap.map.enemy_start)
            self._known_points = pts

    # ------------------------------------------------------------------ 查询
    @property
    def mw(self) -> int:
        return self.map.macro_w if self.map else 12

    @property
    def mh(self) -> int:
        return self.map.macro_h if self.map else 12

    def is_explored(self, point: Vec2) -> bool:
        if not self.map or not self.explored:
            return True
        mx, my = self.map.macro_of(point)
        idx = my * self.mw + mx
        return 0 <= idx < len(self.explored) and self.explored[idx] >= 0.6

    def _center(self, mx: int, my: int) -> Vec2:
        assert self.map is not None
        return self.map.macro_center(mx, my)

    def targets(self, near: Vec2, limit: int = 3) -> list[Vec2]:
        """按「未探索 + 关键点 + 距离」打分，返回最值得侦察的坐标。"""
        if not self.map or not self.explored:
            return []
        scored: list[tuple[float, Vec2]] = []
        for my in range(self.mh):
            for mx in range(self.mw):
                idx = my * self.mw + mx
                val = self.explored[idx] if idx < len(self.explored) else 0.0
                if val >= 0.62:
                    continue
                p = self._center(mx, my)
                dist = near.dist(p)
                score = (1.0 - val) * 3.0 - dist / 45.0
                for kp in self._known_points:
                    if kp.dist(p) <= max(self.map.width / self.mw, self.map.height / self.mh):
                        score += 1.4 if not self.is_explored(kp) else 0.2
                scored.append((score, p))
        scored.sort(key=lambda kv: kv[0], reverse=True)
        out: list[Vec2] = []
        for _, p in scored[: limit * 2]:
            if all(p.dist(q) > 8.0 for q in out):
                out.append(p)
            if len(out) >= limit:
                break
        return out

    def frontier(self, near: Vec2) -> Vec2 | None:
        ts = self.targets(near, 1)
        return ts[0] if ts else None

    @property
    def needs_scouting(self) -> bool:
        target = float(self.p.get("scouting", {}).get("explore_target_ratio", 0.55))
        return self.ratio < target

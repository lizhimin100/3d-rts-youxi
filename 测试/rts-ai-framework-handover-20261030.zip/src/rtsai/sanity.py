"""反愚蠢审计（Anti-Stupidity）。

思路：把「新手常见错误」定义成**可检测的状态**，每 0.5 秒检查一次；
每次「错误状态开始」记为一个 episode，并立即触发修复动作。

考试系统会断言 episode 数量与具体行为（例如「基地被打时军队是否在 6 秒内回防」），
因此这里既是自检，也是自我修复的驱动。
"""
from __future__ import annotations

from collections import Counter

from rtscontract.enums import Cmd, OrderKind

from .context import AIContext


class SanityAuditor:
    def __init__(self, ctx: AIContext) -> None:
        self.ctx = ctx
        self.counts: Counter[str] = Counter()
        self.fixes: Counter[str] = Counter()
        self.episodes: list[tuple[float, str]] = []
        self._active: dict[str, float] = {}
        self._last_check = -1e9
        self._incomplete_seen: dict[int, float] = {}

    # ------------------------------------------------------------------ 主流程
    def update(self) -> None:
        w = self.ctx.world
        p = self.ctx.p["sanity"]
        if not bool(p.get("enabled", True)):
            return
        interval = max(0.2, float(self.ctx.p["tick"]["sanity_interval_ticks"]) * w.snap.dt)
        if w.time - self._last_check < interval:
            return
        self._last_check = w.time
        self._check_idle_workers()
        self._check_supply()
        self._check_production()
        self._check_gold_float()
        self._check_army_response()
        self._check_stuck()
        self._check_construction()
        self._check_trickle()

    # ------------------------------------------------------------------ 工具
    def _episode(self, name: str, active: bool) -> None:
        if active:
            if name not in self._active:
                self._active[name] = self.ctx.world.time
                self.counts[name] += 1
                self.episodes.append((round(self.ctx.world.time, 1), name))
        else:
            self._active.pop(name, None)

    def _fix(self, name: str) -> None:
        self.fixes[name] += 1

    # ------------------------------------------------------------------ 检查项
    def _check_idle_workers(self) -> None:
        w = self.ctx.world
        free_slots = sum(n.free_slots for n in w.snap.nodes if n.remaining > 0)
        idle = [u for u in w.idle_workers if not w.player_protected(u)]
        active = len(idle) >= 2 and free_slots > 0
        self._episode("idle_workers", active)
        if active:
            self._fix("idle_workers")

    def _check_supply(self) -> None:
        w = self.ctx.world
        cap = w.supply_cap
        if cap >= float(self.ctx.cat.supply_max) - 1e-6 or cap <= 0:
            self._episode("supply_block", False)
            return
        building = any(
            w.proto(b.proto).supply_provided > 0 for b in w.constructing
        )
        active = w.supply_headroom <= 1.0 and not building
        self._episode("supply_block", active)
        if active:
            self._fix("supply_block")

    def _check_production(self) -> None:
        w = self.ctx.world
        prod = w.production_buildings
        if not prod:
            self._episode("production_idle", False)
            return
        idle = all(len(b.queue) == 0 for b in prod)
        active = (
            idle
            and w.gold > 260.0
            and len(w.my_army) < 60
            and w.supply_headroom >= 2.0
        )
        self._episode("production_idle", active)
        if active:
            self._fix("production_idle")

    def _check_gold_float(self) -> None:
        w = self.ctx.world
        limit = float(self.ctx.p["sanity"]["gold_float_limit"])
        active = w.gold > limit and w.supply_headroom >= 2.0
        self._episode("gold_float", active)
        if active:
            self._fix("gold_float")

    def _check_army_response(self) -> None:
        w = self.ctx.world
        post = self.ctx.posture
        if post.base_threat <= 0:
            self._episode("idle_army_under_attack", False)
            self._idle_army_strikes = 0
            return
        in_action = getattr(self.ctx, "combat_mode", "idle") in ("defend", "attack", "retreat")
        responding = in_action or any(
            u.order in (OrderKind.ATTACK, OrderKind.ATTACK_MOVE) for u in w.my_army
        ) or any(
            c.kind in (Cmd.ATTACK, Cmd.ATTACK_MOVE) and c.units
            for c in self.ctx.sched.tick_commands
        )
        if responding:
            self._idle_army_strikes = 0
        else:
            self._idle_army_strikes = getattr(self, "_idle_army_strikes", 0) + 1
        # 给 1 秒反应时间（快照有 1 tick 延迟），不把「刚发生」算成发呆
        active = self._idle_army_strikes >= 2 and len(w.my_army) >= 2
        self._episode("idle_army_under_attack", active)
        if active:
            self._fix("idle_army_under_attack")
            center = w.base_pos
            self.ctx.sched.attack_move(
                [u.uid for u in w.my_army if not w.player_protected(u)],
                center,
                label="sanity:recall",
            )

    def _check_stuck(self) -> None:
        w = self.ctx.world
        stuck = [u for u in w.my_units if u.stuck and not w.player_protected(u)]
        active = len(stuck) > 0
        self._episode("stuck_units", active)
        if active:
            self._fix("stuck_units")
            self.ctx.sched.submit(
                self._cmd(Cmd.STOP, units=tuple(u.uid for u in stuck), label="sanity:unstuck")
            )

    def _check_construction(self) -> None:
        w = self.ctx.world
        stalled = []
        for b in w.constructing:
            prev = self._incomplete_seen.get(b.bid)
            if prev is None:
                self._incomplete_seen[b.bid] = (b.progress, w.time)
                continue
            prog, ts = prev
            if b.progress > prog + 1e-4 or b.builders > 0:
                self._incomplete_seen[b.bid] = (b.progress, w.time)
                continue
            if w.time - ts > 10.0:
                stalled.append(b)
        self._episode("construction_stalled", bool(stalled))
        if stalled:
            self._fix("construction_stalled")
            # 只派「当前不在建造」的农民，避免把另一个工地的工人抢走造成来回抖动
            free = [
                u.uid
                for u in w.my_workers
                if not w.player_protected(u) and u.order != OrderKind.BUILD
            ]
            if free:
                b = stalled[0]
                self.ctx.sched.submit(
                    self._cmd(Cmd.ASSIST, units=(free[0],), building=b.bid, label="sanity:assist")
                )

    def _check_trickle(self) -> None:
        w = self.ctx.world
        post = self.ctx.posture
        if post.base_threat > 0 or getattr(self.ctx, "combat_mode", "idle") in ("retreat", "defend"):
            self._episode("trickle", False)
            return
        if len(w.my_army) < 6 or not w.enemy_units:
            self._episode("trickle", False)
            return
        forward = [
            u for u in w.my_army if u.pos.dist(post.rally) > 26.0 and any(
                e.pos.dist(u.pos) <= 20.0 for e in w.enemy_units
            )
        ]
        active = 0 < len(forward) <= int(self.ctx.p["sanity"]["trickle_min_group"])
        self._episode("trickle", active)
        if active:
            self._fix("trickle")
            self.ctx.sched.move(
                [u.uid for u in forward], post.rally, label="sanity:regroup"
            )

    # ------------------------------------------------------------------ 统计
    def issues_per_minute(self) -> float:
        t = max(30.0, self.ctx.world.time)
        return sum(v for k, v in self.counts.items() if k in _HARD_ISSUES) / (t / 60.0)

    def stats(self) -> dict:
        return {
            "issues": dict(self.counts),
            "fixes": dict(self.fixes),
            "issues_per_minute": round(self.issues_per_minute(), 2),
        }

    def _cmd(self, kind: str, units=(), building=None, label=""):
        from rtscontract.commands import Command

        return Command(kind, self.ctx.gateway.issuer, self.ctx.team, tuple(units), building=building, label=label)


_HARD_ISSUES = frozenset(
    {
        "idle_workers",
        "supply_block",
        "production_idle",
        "gold_float",
        "idle_army_under_attack",
        "stuck_units",
        "construction_stalled",
        "trickle",
    }
)

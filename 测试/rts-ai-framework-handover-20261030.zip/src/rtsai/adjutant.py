"""副官（Adjutant）：理解玩家意图，在不越权的前提下协同作战。

玩家指令优先原则的三层保障
--------------------------
1. **登记**：玩家对某单位下过命令 → ``ControlRegistry`` 标记 PLAYER_MANUAL（TTL）；
   显式锁定 → PLAYER_LOCKED（永久）。
2. **AI 侧过滤**：所有命令通过 ``CommandScheduler.available()``，被保护单位直接剔除。
3. **网关侧拒绝**：模拟器再次校验，任何越权命令都会被拒并计数（考试断言为 0）。

副官的主动性受 ``config/ai_profile.json.autonomy`` 控制：
* ``move_army_aggressive=false`` 时，玩家没下令就不主动进攻；
* 玩家发出「打这里」的指令后，副官会把**未被锁定的**部队协同过去并补充援军；
* 冲突时只发「建议」，绝不擅自夺取控制权。
"""
from __future__ import annotations

from collections import Counter
from typing import Any

from rtscontract.enums import Cmd, Issuer
from rtscontract.vec import Vec2

from .context import AIContext


class AdjutantController:
    def __init__(self, ctx: AIContext) -> None:
        self.ctx = ctx
        self.attack_directive: tuple[Vec2, float] | None = None
        self.hold_point: Vec2 | None = None
        self.hold_until: float = -1.0
        self.train_bonus: dict[str, float] = {}
        self.build_request: tuple[str, Vec2, float] | None = None
        self.last_intent_tick = -1
        self.actions: Counter[str] = Counter()
        self.suggestions_sent = 0
        self._last_suggestion = -999.0
        self.requested_control: set[int] = set()

    # ------------------------------------------------------------------ 读取意图
    def ingest(self) -> None:
        snap = self.ctx.snap
        if not snap.player.presence:
            return
        ttl = float(self.ctx.p["autonomy"].get("directive_ttl_seconds", 30))
        now = self.ctx.world.time
        for it in snap.player.intents:
            if it.tick <= self.last_intent_tick:
                continue
            self.last_intent_tick = max(self.last_intent_tick, it.tick)
            if not it.ok:
                continue
            if it.kind in (Cmd.ATTACK, Cmd.ATTACK_MOVE) and it.point is not None:
                self.attack_directive = (it.point, now + ttl)
                self.hold_point = None
                self.actions["attack_directive"] += 1
            elif it.kind == Cmd.MOVE and it.point is not None:
                if self._is_army_scale(it.units):
                    self.hold_point = it.point
                    self.hold_until = now + ttl
                    self.attack_directive = None
                    self.actions["move_directive"] += 1
            elif it.kind == Cmd.HOLD:
                self.hold_point = it.point or self.ctx.world.base_pos
                self.hold_until = now + ttl
                self.attack_directive = None
                self.actions["hold"] += 1
            elif it.kind == Cmd.STOP:
                self.attack_directive = None
                self.hold_point = None
                self.actions["stop"] += 1
            elif it.kind == Cmd.TRAIN and it.proto:
                self.train_bonus[it.proto] = now + 25.0
                self.actions["train_request"] += 1
            elif it.kind == Cmd.BUILD and it.proto:
                if it.point is not None:
                    self.build_request = (it.proto, it.point, now + 30.0)
                self.actions["build_request"] += 1

    def _is_army_scale(self, unit_ids: tuple[int, ...]) -> bool:
        """玩家移动的是不是「一支军队」（而非单个农民/侦察兵）。"""
        if not unit_ids:
            return False
        w = self.ctx.world
        by_id = {u.uid: u for u in w.my_units}
        combat = workers = 0
        for uid in unit_ids:
            u = by_id.get(uid)
            if u is None:
                continue
            if w.proto(u.proto).is_worker:
                workers += 1
            else:
                combat += 1
        if combat == 0:
            return False
        return combat >= max(2, int(0.4 * max(1, len(w.my_army))))

    # ------------------------------------------------------------------ 影响姿态
    def apply(self, posture) -> None:
        w = self.ctx.world
        aut = self.ctx.p["autonomy"]
        now = w.time

        if not bool(aut.get("move_army_aggressive", True)):
            posture.allow_attack = False
        if not bool(aut.get("move_army_defensive", True)):
            posture.allow_expand = bool(aut.get("expand", True)) and posture.allow_expand

        if self.attack_directive is not None:
            point, until = self.attack_directive
            if now > until:
                self.attack_directive = None
            else:
                posture.attack_point = point
                posture.attack_target = None
                posture.allow_attack = True

        if self.hold_point is not None and now <= self.hold_until:
            posture.rally = self.hold_point
            if not bool(aut.get("move_army_aggressive", True)):
                posture.allow_attack = False
        elif self.hold_point is not None:
            self.hold_point = None

        if not bool(aut.get("expand", True)):
            posture.allow_expand = False

    # ------------------------------------------------------------------ 建议
    def maybe_suggest(self) -> None:
        w = self.ctx.world
        now = w.time
        aut = self.ctx.p["autonomy"]
        if not bool(aut.get("request_control", True)):
            return
        if now - self._last_suggestion < 12.0:
            return
        snap = self.ctx.snap

        # 1) 玩家下令进攻但兵力明显不足 → 提醒
        if self.attack_directive is not None:
            m = self.ctx.posture.metrics
            if m.get("army_ratio", 1.0) < 0.9:
                self._emit(
                    {
                        "code": "low_odds",
                        "severity": "warn",
                        "message": "兵力对比不利，建议先补充再推进",
                        "army_ratio": round(m.get("army_ratio", 0.0), 2),
                    }
                )
                return

        # 2) 基地被打，但玩家锁了一堆闲置单位 → 请求控制权
        if self.ctx.posture.base_threat > 0 and snap.player.locked:
            idle_locked = [
                uid
                for uid in snap.player.locked
                if any(u.uid == uid and u.order in ("idle", "stop") for u in w.my_units)
            ]
            if idle_locked:
                self._emit(
                    {
                        "code": "request_control",
                        "severity": "info",
                        "message": "基地遇袭，是否把这些单位交给副官指挥？",
                        "units": idle_locked[:8],
                    }
                )
                self.requested_control.update(idle_locked)
                return

    def _emit(self, payload: dict[str, Any]) -> None:
        self.ctx.gateway.suggest(payload)
        self.suggestions_sent += 1
        self._last_suggestion = self.ctx.world.time

    # ------------------------------------------------------------------ 统计
    def stats(self) -> dict[str, Any]:
        return {
            "actions": dict(self.actions),
            "suggestions": self.suggestions_sent,
            "has_directive": self.attack_directive is not None or self.hold_point is not None,
        }

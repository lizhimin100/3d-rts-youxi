"""世界模型（Belief State）：把快照整理成 AI 好用的派生状态。

包含：
* 己方/敌方兵力、经济、建筑的聚合视图；
* **记忆**：敌方建筑最后一次被看到的位置（战争迷雾下不会凭空消失）；
* 敌方兵力构成的短期记忆（用于克制推理）；
* 收入估计（EMA），不依赖游戏内部经济数据。
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Iterable, Mapping

from rtscontract.catalog import Catalog, Proto
from rtscontract.enums import PROTECTED_CONTROL, Issuer, OrderKind
from rtscontract.snapshot import BuildingInfo, NodeInfo, UnitInfo, WorldSnapshot
from rtscontract.vec import Vec2


@dataclass(slots=True)
class EnemyBuildingMemory:
    bid: int
    proto: str
    pos: Vec2
    last_seen: float
    hp_pct: float = 1.0


class World:
    def __init__(self, catalog: Catalog, profile: Mapping) -> None:
        self.cat = catalog
        self.p = profile
        self.snap: WorldSnapshot | None = None
        self.prev: WorldSnapshot | None = None

        self.enemy_buildings: dict[int, EnemyBuildingMemory] = {}
        self._enemy_mix_memory: dict[str, float] = {}
        self._enemy_mix_seen: float = -999.0
        self._enemy_army_value_peak: float = 0.0
        self._enemy_army_value_seen: float = -999.0

        self.income: float = 0.0
        self._last_gold: float = 0.0
        self._last_time: float = 0.0

        self._cache: dict[str, object] = {}

    # ------------------------------------------------------------------ 更新
    def update(self, snap: WorldSnapshot) -> None:
        self.prev = self.snap
        self.snap = snap
        self._cache.clear()

        dt = max(1e-6, snap.time - self._last_time)
        if snap.gold > self._last_gold:
            delta = (snap.gold - self._last_gold) / dt
            self.income = self.income * 0.85 + delta * 0.15 if self.income > 0 else delta
        self._last_gold = snap.gold
        self._last_time = snap.time

        # 敌方建筑记忆
        for b in snap.buildings:
            if b.team != snap.team:
                self.enemy_buildings[b.bid] = EnemyBuildingMemory(b.bid, b.proto, b.pos, snap.time, b.hp_pct)
        stale = [
            bid
            for bid, m in self.enemy_buildings.items()
            if snap.time - m.last_seen > 240.0
        ]
        for bid in stale:
            self.enemy_buildings.pop(bid, None)

        # 敌方兵力构成记忆（只统计有攻击力的单位，农民不算战斗力）
        visible = [
            u
            for u in snap.units
            if u.team != snap.team
            and self.cat.has(u.proto)
            and self.cat.get(u.proto).attack is not None
        ]
        if visible:
            mix: dict[str, float] = {}
            for u in visible:
                mix[u.proto] = mix.get(u.proto, 0.0) + 1.0
            self._enemy_mix_memory = mix
            self._enemy_mix_seen = snap.time
            value = sum(self.proto(u.proto).value for u in visible)
            self._enemy_army_value_peak = max(self._enemy_army_value_peak * 0.98, value)
            self._enemy_army_value_seen = snap.time

    # ------------------------------------------------------------------ 基础
    @property
    def team(self) -> int:
        return self.snap.team if self.snap else 0

    def proto(self, proto_id: str) -> Proto:
        return self.cat.get(proto_id)

    @property
    def time(self) -> float:
        return self.snap.time if self.snap else 0.0

    @property
    def tick(self) -> int:
        return self.snap.tick if self.snap else 0

    def _cached(self, key: str, fn):
        if key not in self._cache:
            self._cache[key] = fn()
        return self._cache[key]

    # ------------------------------------------------------------------ 己方
    @property
    def my_units(self) -> list[UnitInfo]:
        return self._cached("my_units", lambda: [u for u in self.snap.units if u.team == self.team])

    @property
    def my_workers(self) -> list[UnitInfo]:
        return self._cached(
            "my_workers", lambda: [u for u in self.my_units if self.proto(u.proto).is_worker]
        )

    @property
    def my_army(self) -> list[UnitInfo]:
        return self._cached(
            "my_army", lambda: [u for u in self.my_units if not self.proto(u.proto).is_worker]
        )

    @property
    def my_buildings(self) -> list[BuildingInfo]:
        return self._cached("my_buildings", lambda: [b for b in self.snap.buildings if b.team == self.team])

    @property
    def complete_buildings(self) -> list[BuildingInfo]:
        return self._cached("complete_buildings", lambda: [b for b in self.my_buildings if b.complete])

    @property
    def townhalls(self) -> list[BuildingInfo]:
        return self._cached(
            "townhalls",
            lambda: [b for b in self.complete_buildings if self.proto(b.proto).dropoff],
        )

    @property
    def main_base(self) -> BuildingInfo | None:
        halls = self.townhalls
        if not halls:
            return None
        starts = self.snap.map.start_points
        if starts:
            idx = min(self.team, len(starts) - 1)
            ref = starts[idx]
            return min(halls, key=lambda b: b.pos.dist_sq(ref))
        return min(halls, key=lambda b: b.bid)

    @property
    def base_pos(self) -> Vec2:
        b = self.main_base
        if b is not None:
            return b.pos
        starts = self.snap.map.start_points
        if starts:
            return starts[min(self.team, len(starts) - 1)]
        return Vec2(self.snap.map.width / 2, self.snap.map.height / 2)

    @property
    def expansions(self) -> list[BuildingInfo]:
        main = self.main_base
        return [b for b in self.townhalls if main is None or b.bid != main.bid]

    @property
    def production_buildings(self) -> list[BuildingInfo]:
        return self._cached(
            "prod",
            lambda: [
                b
                for b in self.complete_buildings
                if self.proto(b.proto).produce and not self.proto(b.proto).dropoff
            ],
        )

    @property
    def constructing(self) -> list[BuildingInfo]:
        return self._cached("constructing", lambda: [b for b in self.my_buildings if not b.complete])

    @property
    def idle_workers(self) -> list[UnitInfo]:
        return self._cached(
            "idle_workers",
            lambda: [
                u
                for u in self.my_workers
                if u.order in (OrderKind.IDLE, OrderKind.STOP)
                and u.control not in PROTECTED_CONTROL
            ],
        )

    @property
    def idle_army(self) -> list[UnitInfo]:
        return self._cached(
            "idle_army",
            lambda: [
                u
                for u in self.my_army
                if u.order in (OrderKind.IDLE, OrderKind.STOP)
                and u.control not in PROTECTED_CONTROL
            ],
        )

    @property
    def army_value(self) -> float:
        return sum(self.proto(u.proto).value for u in self.my_army)

    @property
    def my_mix(self) -> dict[str, float]:
        mix: dict[str, float] = {}
        for u in self.my_army:
            mix[u.proto] = mix.get(u.proto, 0.0) + 1.0
        return mix

    @property
    def supply_headroom(self) -> float:
        return self.snap.supply_headroom

    @property
    def supply_cap(self) -> float:
        return self.snap.supply_cap

    @property
    def supply_used(self) -> float:
        return self.snap.supply_used

    @property
    def gold(self) -> float:
        return self.snap.gold

    def trainable_protos(self) -> list[Proto]:
        out: list[Proto] = []
        seen: set[str] = set()
        for b in self.production_buildings:
            for p in self.cat.trainable_by(b.proto):
                if p.id not in seen:
                    seen.add(p.id)
                    out.append(p)
        return out

    def buildable_protos(self) -> list[Proto]:
        workers = self.my_workers
        if not workers:
            return []
        w = self.proto(workers[0].proto)
        return list(self.cat.buildable_by(w))

    # ------------------------------------------------------------------ 敌方
    @property
    def enemy_units(self) -> list[UnitInfo]:
        return self._cached("enemy_units", lambda: [u for u in self.snap.units if u.team != self.team])

    @property
    def visible_enemy_buildings(self) -> list[BuildingInfo]:
        return self._cached(
            "visible_enemy_buildings", lambda: [b for b in self.snap.buildings if b.team != self.team]
        )

    @property
    def known_enemy_buildings(self) -> list[EnemyBuildingMemory]:
        """记忆中的敌方建筑（含当前可见的）。"""
        return list(self.enemy_buildings.values())

    @property
    def enemy_mix(self) -> dict[str, float]:
        combat = self.enemy_combat_units
        if combat:
            cur: dict[str, float] = {}
            for u in combat:
                cur[u.proto] = cur.get(u.proto, 0.0) + 1.0
            if cur:
                return cur
        # 敌方构成记忆：raid 之间往往有几十秒空档，记忆太短会导致
        # 「看见时克制、敌人一死就忘、继续按固定配额补兵」（审计 counter_quality）。
        ttl = float(self.p.get("combat", {}).get("enemy_mix_memory_seconds", 120.0))
        if self.time - self._enemy_mix_seen < ttl:
            decay = max(0.4, 1.0 - (self.time - self._enemy_mix_seen) / (ttl * 2.0))
            return {k: v * decay for k, v in self._enemy_mix_memory.items()}
        return {}

    @property
    def enemy_combat_units(self) -> list[UnitInfo]:
        return [u for u in self.enemy_units if self.proto(u.proto).attack is not None]

    # ------------------------------------------------------------------ 空间索引
    @property
    def _foe_grid(self) -> dict[tuple[int, int], list[UnitInfo]]:
        """敌方单位的粗网格（8 格/格），避免微操里 O(我方×敌方) 的全量扫描。"""
        return self._cached("foe_grid", self._build_foe_grid)

    def _build_foe_grid(self) -> dict[tuple[int, int], list[UnitInfo]]:
        cell = 8.0
        grid: dict[tuple[int, int], list[UnitInfo]] = {}
        for u in self.enemy_units:
            key = (int(u.pos.x // cell), int(u.pos.y // cell))
            grid.setdefault(key, []).append(u)
        return grid

    def enemies_near(self, point: Vec2, radius: float) -> list[UnitInfo]:
        """返回 point 周围 radius 内（按网格粗筛）的敌方单位。"""
        cell = 8.0
        grid = self._foe_grid
        x0 = int((point.x - radius) // cell)
        x1 = int((point.x + radius) // cell)
        y0 = int((point.y - radius) // cell)
        y1 = int((point.y + radius) // cell)
        if (x1 - x0 + 1) * (y1 - y0 + 1) > 64:
            return self.enemy_units
        out: list[UnitInfo] = []
        for cx in range(x0, x1 + 1):
            for cy in range(y0, y1 + 1):
                bucket = grid.get((cx, cy))
                if bucket:
                    out.extend(bucket)
        return out

    @property
    def enemy_army_value(self) -> float:
        """敌方兵力估值：当前可见优先，否则用近期峰值衰减。"""
        visible = sum(self.proto(u.proto).value for u in self.enemy_combat_units)
        if visible > 0:
            return visible
        age = self.time - self._enemy_army_value_seen
        if age < 90.0:
            return self._enemy_army_value_peak * max(0.2, 1.0 - age / 120.0)
        return 0.0

    @property
    def enemy_air_count(self) -> int:
        return sum(1 for u in self.enemy_units if self.proto(u.proto).flying)

    @property
    def enemy_has_air(self) -> bool:
        if self.enemy_air_count > 0:
            return True
        # 记忆里也有（例如刚被打掉）
        return any(self.proto(k).flying for k, v in self._enemy_mix_memory.items() if v > 0)

    def enemy_defense_near(self, point: Vec2, radius: float = 18.0) -> float:
        return sum(
            self.proto(u.proto).value for u in self.enemy_units if u.pos.dist(point) <= radius
        )

    # ------------------------------------------------------------------ 空间
    def nodes_near(self, point: Vec2, radius: float = 16.0) -> list[NodeInfo]:
        return [n for n in self.snap.nodes if n.pos.dist(point) <= radius]

    def base_worker_capacity(self, base: BuildingInfo) -> int:
        cap = 0
        for n in self.snap.nodes:
            if n.pos.dist(base.pos) <= 18.0:
                cap += n.max_workers
        return cap

    def workers_assigned_to(self, base: BuildingInfo) -> int:
        cnt = 0
        for u in self.my_workers:
            if u.home is None:
                continue
            if u.order == OrderKind.HARVEST and u.pos.dist(base.pos) <= 18.0:
                cnt += 1
        return cnt

    def free_node_for(self, base: BuildingInfo) -> NodeInfo | None:
        best = None
        best_score = -1.0
        for n in self.snap.nodes:
            if n.pos.dist(base.pos) > 18.0 or n.remaining <= 0:
                continue
            if n.free_slots <= 0:
                continue
            score = n.remaining / max(1.0, n.pos.dist(base.pos))
            if score > best_score:
                best_score = score
                best = n
        return best

    def threat_near(self, point: Vec2, radius: float) -> list[UnitInfo]:
        return [u for u in self.enemy_units if u.pos.dist(point) <= radius]

    def threat_value_near(self, point: Vec2, radius: float) -> float:
        return sum(self.proto(u.proto).value for u in self.threat_near(point, radius))

    def player_protected(self, u: UnitInfo) -> bool:
        if u.control in PROTECTED_CONTROL:
            return True
        return u.order_owner == Issuer.PLAYER and u.order in (
            OrderKind.MOVE,
            OrderKind.ATTACK,
            OrderKind.ATTACK_MOVE,
            OrderKind.HOLD,
            OrderKind.PATROL,
        )

    def controllable(self, units: Iterable[UnitInfo]) -> list[UnitInfo]:
        return [u for u in units if not self.player_protected(u)]

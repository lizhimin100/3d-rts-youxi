"""声明式战略计划库（config/plans.json）。

计划 = 「条件 + 权重 + 参数」，不含任何代码。新增战术风格只需往 JSON 里加一条，
例如「双矿龟缩流」「速科技」都可以用同一套指标表达。

条件 DSL
--------
::

    {"metric": "army_ratio", "op": ">=", "value": 1.3}
    {"all": [cond, cond]}
    {"any": [cond, cond]}
    {"not": cond}

可用指标见 ``rtsai.director.build_metrics``。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence


@dataclass(frozen=True, slots=True)
class Plan:
    id: str
    priority: int = 0
    stance: str = "balanced"
    when: Mapping[str, Any] = field(default_factory=dict)
    weights: Mapping[str, float] = field(default_factory=dict)
    params: Mapping[str, Any] = field(default_factory=dict)
    desc: str = ""


class PlanLibrary:
    def __init__(self, raw_plans: Sequence[Mapping[str, Any]]) -> None:
        self.plans: list[Plan] = []
        for raw in raw_plans:
            self.plans.append(
                Plan(
                    id=str(raw.get("id", "plan")),
                    priority=int(raw.get("priority", 0)),
                    stance=str(raw.get("stance", "balanced")),
                    when=dict(raw.get("when", {}) or {}),
                    weights={k: float(v) for k, v in (raw.get("weights") or {}).items()},
                    params=dict(raw.get("params", {}) or {}),
                    desc=str(raw.get("desc", "")),
                )
            )
        self.plans.sort(key=lambda p: p.priority, reverse=True)

    def matching(self, metrics: Mapping[str, float]) -> list[Plan]:
        out = []
        for p in self.plans:
            if not p.when or evaluate(p.when, metrics):
                out.append(p)
        return out

    def best(self, metrics: Mapping[str, float]) -> Plan | None:
        for p in self.plans:
            if not p.when or evaluate(p.when, metrics):
                return p
        return None

    def get(self, plan_id: str) -> Plan | None:
        for p in self.plans:
            if p.id == plan_id:
                return p
        return None


def evaluate(cond: Mapping[str, Any], metrics: Mapping[str, float]) -> bool:
    if not cond:
        return True
    if "all" in cond:
        return all(evaluate(c, metrics) for c in cond["all"])
    if "any" in cond:
        return any(evaluate(c, metrics) for c in cond["any"])
    if "not" in cond:
        return not evaluate(cond["not"], metrics)
    metric = str(cond.get("metric", ""))
    op = str(cond.get("op", ">"))
    value = float(cond.get("value", 0.0))
    x = float(metrics.get(metric, 0.0))
    if op in (">", "gt"):
        return x > value
    if op in (">=", "ge"):
        return x >= value
    if op in ("<", "lt"):
        return x < value
    if op in ("<=", "le"):
        return x <= value
    if op in ("==", "eq"):
        return abs(x - value) < 1e-9
    if op in ("!=", "ne"):
        return abs(x - value) >= 1e-9
    if op == "between":
        lo = float(cond.get("min", 0.0))
        hi = float(cond.get("max", 1e18))
        return lo <= x <= hi
    return False

"""rtsai —— 通用 RTS AI 框架。

依赖：仅 ``rtscontract``（契约层）+ Python 标准库。
**不允许** import ``rtsim``（Mock 模拟器）或任何具体游戏代码，
这条约束由考试系统里的静态检查强制保证。
"""

from .agent import RTSAgent  # noqa: F401
from .combatmodel import BattleEstimate, CombatModel  # noqa: F401
from .context import AIContext  # noqa: F401
from .plans import Plan, PlanLibrary  # noqa: F401
from .profile import DEFAULTS, load_profile  # noqa: F401
from .scheduler import CommandScheduler  # noqa: F401
from .world import World  # noqa: F401

__all__ = [
    "RTSAgent",
    "CombatModel",
    "BattleEstimate",
    "AIContext",
    "Plan",
    "PlanLibrary",
    "CommandScheduler",
    "World",
    "DEFAULTS",
    "load_profile",
]
__version__ = "1.0.0"

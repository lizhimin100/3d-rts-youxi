"""AI 公共上下文：把各模块需要的依赖打包，避免模块之间互相 import。"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from rtscontract.catalog import Catalog

from .combatmodel import CombatModel
from .fog import FogTracker
from .scheduler import CommandScheduler
from .territory import Territory
from .world import World


@dataclass
class AIContext:
    gateway: Any
    cat: Catalog
    p: dict
    world: World
    fog: FogTracker
    territory: Territory
    combat: CombatModel
    sched: CommandScheduler
    posture: Any = None
    combat_mode: str = "idle"
    stats: dict[str, Any] = field(default_factory=dict)

    @property
    def team(self) -> int:
        return self.world.team

    @property
    def snap(self):
        return self.world.snap

    def can_reach(self, point, units=()) -> bool:
        """这批单位能否走到 ``point``。

        优先问网关（真实游戏应该用引擎寻路回答）；
        网关没实现该能力时退化为「该格可走」——这是旧行为，会低估死路风险。
        """
        fn = getattr(self.gateway, "can_reach", None)
        if fn is not None:
            ids = [getattr(u, "uid", 0) for u in units]
            try:
                return bool(fn(ids, point))
            except Exception:  # noqa: BLE001 - 适配器实现有问题时不能让 AI 崩
                pass
        m = self.snap.map
        return bool(m.is_walkable(point))

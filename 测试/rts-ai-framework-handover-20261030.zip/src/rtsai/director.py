"""战略导演：把「世界状态」压缩成指标，选计划，产出姿态（Posture）。

Posture 是经济/生产/战斗/扩张四个模块的共同输入，保证它们朝同一个方向用力。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from rtscontract.catalog import Catalog
from rtscontract.snapshot import MapInfo
from rtscontract.vec import Vec2

from .combatmodel import CombatModel
from .fog import FogTracker
from .plans import Plan, PlanLibrary
from .territory import Territory
from .world import World


@dataclass
class Posture:
    plan_id: str = "default"
    stance: str = "balanced"
    since: float = 0.0
    aggression: float = 0.5
    weights: dict[str, float] = field(default_factory=dict)
    worker_cap: int = 18
    army_supply_ratio: float = 0.72
    army_supply_target: float = 30.0
    allow_expand: bool = True
    allow_attack: bool = False
    attack_ratio_needed: float = 1.35
    attack_target: int | None = None
    attack_point: Vec2 = Vec2()
    rally: Vec2 = Vec2()
    defend_center: Vec2 = Vec2()
    base_threat: float = 0.0
    enemy_ratio: float = 1.0
    my_score: float = 0.0
    enemy_score: float = 0.0
    metrics: dict[str, float] = field(default_factory=dict)

    def weight(self, key: str, default: float = 1.0) -> float:
        return float(self.weights.get(key, default))


class StrategicDirector:
    def __init__(
        self,
        world: World,
        fog: FogTracker,
        territory: Territory,
        combat: CombatModel,
        catalog: Catalog,
        profile: Mapping[str, Any],
        plans: PlanLibrary,
    ) -> None:
        self.world = world
        self.fog = fog
        self.territory = territory
        self.combat = combat
        self.cat = catalog
        self.p = profile
        self.plans = plans
        self.posture = Posture()
        self.plan_changes = 0
        self._plan_since = -999.0
        self._attacked_since: float = -999.0

    # ------------------------------------------------------------------ 指标
    def build_metrics(self) -> dict[str, float]:
        w = self.world
        snap = w.snap
        my_protos = [w.proto(u.proto) for u in w.my_army]
        enemy_units = w.enemy_units
        enemy_protos = [w.proto(u.proto) for u in enemy_units]
        enemy_mix = w.enemy_mix

        my_score = self.combat.army_score(my_protos, enemy_mix) if enemy_mix else sum(
            p.value for p in my_protos
        )
        if enemy_protos:
            # 双方都可见：用同一套战力模型，可比
            enemy_score = self.combat.army_score(enemy_protos, w.my_mix)
            ratio = my_score / enemy_score if enemy_score > 1e-6 else 8.0
        elif w.enemy_army_value > 0:
            # 只有记忆：退化为金币价值比（同一尺度）
            enemy_score = w.enemy_army_value
            ratio = w.army_value / max(80.0, enemy_score) * 0.9
        else:
            # 完全没情报：有军队就按「略占优」推进（侦察兵会带回真实情报）
            enemy_score = w.army_value / 1.4 if w.army_value > 0 else 1.0
            ratio = 1.4 if w.army_value > 500.0 else 1.0
        if not enemy_units and w.time > 45.0:
            ratio *= 0.9  # 没视野时略保守
        ratio = max(0.05, min(8.0, ratio))

        radius = float(self.p["combat"]["defense_radius"])
        threat_units = []
        for b in w.townhalls:
            threat_units.extend(w.threat_near(b.pos, radius))
        threat_value = sum(w.proto(u.proto).value for u in threat_units)

        army_supply = sum(w.proto(u.proto).cost.supply for u in w.my_army)
        static_def = 0.0
        for mem in w.known_enemy_buildings:
            if w.time - mem.last_seen > 150.0:
                continue
            proto = w.proto(mem.proto)
            if proto.attack is not None:
                static_def += proto.value
        self._scores = (my_score, enemy_score)

        return {
            "time": w.time,
            "gold": snap.gold,
            "income": w.income,
            "workers": float(len(w.my_workers)),
            "army_count": float(len(w.my_army)),
            "army_supply": army_supply,
            "army_value": w.army_value,
            "supply_used": snap.supply_used,
            "supply_cap": snap.supply_cap,
            "supply_headroom": snap.supply_headroom,
            "base_threat": float(len(threat_units)),
            "threat_value": threat_value,
            "expansions": float(len(w.expansions)),
            "buildings": float(len(w.complete_buildings)),
            "army_ratio": ratio,
            "enemy_army_value": w.enemy_army_value,
            "explored": self.fog.ratio,
            "idle_workers": float(len(w.idle_workers)),
            "enemy_static_defense": static_def,
        }

    # ------------------------------------------------------------------ 主流程
    def update(self) -> Posture:
        metrics = self.build_metrics()
        my_score, enemy_score = getattr(self, "_scores", (0.0, 1.0))
        candidates = self.plans.matching(metrics)
        chosen = self._select_with_hysteresis(candidates)

        params = chosen.params
        weights = dict(chosen.weights) if chosen.weights else {
            "economy": 1.0,
            "military": 1.0,
            "expansion": 0.7,
            "tech": 0.7,
        }
        base_aggr = float(params.get("aggression", 0.5))
        threat = metrics["base_threat"]
        if threat > 0:
            base_aggr = min(base_aggr, 0.15)

        cap = float(self.world.supply_cap) or float(self.cat.supply_max)
        army_target = min(
            float(self.cat.supply_max) - 2.0,
            cap * float(params.get("army_supply_ratio", 0.72)),
        )

        target_id, target_point = self._pick_attack_target()
        rally = self._rally_point(target_point)

        eager_attack = (
            # 打有静态防御的基地需要更多兵力（别往箭塔阵里送）
            metrics["army_value"] >= 820.0 + 1.2 * metrics.get("enemy_static_defense", 0.0)
            and metrics["army_ratio"] >= 0.95
            and metrics["base_threat"] < 1.0
            and base_aggr >= 0.35
        )
        allow_attack = eager_attack or (
            metrics["army_count"] >= float(self.p["combat"]["min_attack_units"])
            and metrics["army_ratio"] >= float(self.p["combat"]["attack_power_ratio"])
            and metrics["base_threat"] < 1.0
            and base_aggr >= 0.5
        )

        posture = Posture(
            plan_id=chosen.id,
            stance=chosen.stance,
            since=self._plan_since,
            aggression=base_aggr,
            weights=weights,
            worker_cap=int(params.get("worker_cap", 18)),
            army_supply_ratio=float(params.get("army_supply_ratio", 0.72)),
            army_supply_target=army_target,
            allow_expand=bool(params.get("allow_expand", True)),
            allow_attack=allow_attack,
            attack_ratio_needed=float(self.p["combat"]["attack_power_ratio"]),
            attack_target=target_id,
            attack_point=target_point,
            rally=rally,
            defend_center=self.world.base_pos,
            base_threat=threat,
            enemy_ratio=metrics["army_ratio"],
            my_score=my_score,
            enemy_score=enemy_score,
            metrics=metrics,
        )
        self.posture = posture
        return posture

    # ------------------------------------------------------------------ 选择
    def _select_with_hysteresis(self, candidates: list[Plan]) -> Plan:
        if not candidates:
            fallback = self.plans.get("default_mid")
            assert fallback is not None
            return fallback
        top = candidates[0]
        cur = self.plans.get(self.posture.plan_id)
        now = self.world.time
        min_sec = float(self.p["strategy"]["plan_min_seconds"])
        if cur is None:
            self._plan_since = now
            return top
        if top.id == cur.id:
            return cur
        if top.priority >= 90 or now - self._plan_since >= min_sec:
            self._plan_since = now
            self.plan_changes += 1
            return top
        return cur

    # ------------------------------------------------------------------ 目标
    def _pick_attack_target(self) -> tuple[int | None, Vec2]:
        w = self.world
        base = w.base_pos
        best: tuple[float, int | None, Vec2] | None = None
        for mem in w.known_enemy_buildings:
            try:
                proto = w.proto(mem.proto)
            except KeyError:
                continue
            defense = w.enemy_defense_near(mem.pos, 22.0)
            dist = base.dist(mem.pos)
            value = proto.value + (90.0 if proto.dropoff else 0.0)
            score = value / (1.0 + defense / 160.0) / (1.0 + dist / 55.0)
            if best is None or score > best[0]:
                best = (score, mem.bid, mem.pos)
        if best is not None:
            return best[1], best[2]
        if w.snap.map.enemy_start is not None:
            return None, w.snap.map.enemy_start
        return None, Vec2(w.snap.map.width * 0.85, w.snap.map.height * 0.85)

    def _rally_point(self, target: Vec2) -> Vec2:
        base = self.world.base_pos
        offset = float(self.p["strategy"]["rally_offset"])
        p = Vec2(base.x + (target.x - base.x) * offset, base.y + (target.y - base.y) * offset)
        return self._nearest_walkable(p)

    def _nearest_walkable(self, p: Vec2) -> Vec2:
        m: MapInfo = self.world.snap.map
        if m.is_walkable(p):
            return p
        for r in range(1, 9):
            for dx in range(-r, r + 1):
                for dy in (-r, r):
                    q = Vec2(p.x + dx, p.y + dy)
                    if m.is_walkable(q):
                        return q
            for dy in range(-r + 1, r):
                for dx in (-r, r):
                    q = Vec2(p.x + dx, p.y + dy)
                    if m.is_walkable(q):
                        return q
        return p

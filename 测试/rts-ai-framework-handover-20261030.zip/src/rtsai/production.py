"""生产与兵种构成：从「敌方构成 + 角色配额 + 成本」推导该造什么。

这里没有任何具体兵种名：
* 克制来自 ``CombatModel``（攻击类型×护甲类型矩阵）；
* 角色配额来自 ``config/ai_profile.json.production.roles``（用标签声明）；
* 对空需求由「敌人有飞行单位」这一事实触发，而不是判断「是不是狮鹫」。
"""
from __future__ import annotations

from typing import Iterable, Mapping, Sequence

from rtscontract.catalog import Proto

from .context import AIContext


class CompositionSolver:
    def __init__(self, ctx: AIContext) -> None:
        self.ctx = ctx
        # 审计/调参：最近一次打分的明细（兵种 → 各分项），不参与决策
        self.last_scores: dict[str, dict[str, float]] = {}

    def _role_shares(self) -> dict[str, float]:
        roles = self.ctx.p["production"].get("roles", ())
        return {str(r["id"]): float(r.get("share", 0.0)) for r in roles}

    def _current_role_share(self) -> dict[str, float]:
        roles = self.ctx.p["production"].get("roles", ())
        counts: dict[str, int] = {str(r["id"]): 0 for r in roles}
        total = 0
        for u in self.ctx.world.my_army:
            try:
                proto = self.ctx.world.proto(u.proto)
            except KeyError:
                continue
            total += 1
            rid = self.ctx.combat.role_of(proto, roles)
            if rid in counts:
                counts[rid] += 1
        if total == 0:
            return {k: 0.0 for k in counts}
        return {k: v / total for k, v in counts.items()}

    def choose(self, candidates: Sequence[Proto]) -> Proto | None:
        if not candidates:
            return None
        w = self.ctx.world
        p = self.ctx.p["production"]
        enemy_mix = w.enemy_mix
        roles = p.get("roles", ())
        target_shares = self._role_shares()
        cur_shares = self._current_role_share()

        # 每个候选的「每金战力」
        eff: dict[str, float] = {}
        for proto in candidates:
            if enemy_mix:
                power = self.ctx.combat.score_unit(proto, enemy_mix)
            else:
                atk = proto.attack.dps if proto.attack else 0.0
                power = atk * proto.hp * 0.5 + proto.hp * 0.25
            eff[proto.id] = power / max(1.0, proto.cost.gold)
        max_eff = max(eff.values()) if eff else 1.0
        if max_eff <= 0:
            max_eff = 1.0
        max_cost = max((c.cost.gold for c in candidates), default=1.0) or 1.0

        # 对空需求
        air_share = 0.0
        if enemy_mix:
            total = sum(enemy_mix.values()) or 1.0
            air = sum(
                v for k, v in enemy_mix.items() if self.ctx.cat.has(k) and self.ctx.cat.get(k).flying
            )
            air_share = air / total
        my_aa = sum(1 for u in w.my_army if w.proto(u.proto).can_hit_air)
        my_total = max(1, len(w.my_army))
        aa_target = max(2, int(float(p.get("air_counter_share", 0.28)) * my_total))
        # 只要敌人有空中单位，就保证「至少 N 个能对空」的底线
        need_aa = air_share > 0.05 and my_aa < aa_target

        cw = float(p.get("counter_weight", 1.0))
        rw = float(p.get("role_weight", 0.9))
        costw = float(p.get("cost_weight", 0.28))
        supplyw = float(p.get("supply_weight", 0.55))
        timew = float(p.get("time_weight", 0.35))
        max_supply = max((c.cost.supply for c in candidates), default=1.0) or 1.0
        max_time = max((c.build_time for c in candidates), default=1.0) or 1.0

        counts_now: dict[str, int] = {}
        for u in w.my_army:
            counts_now[u.proto] = counts_now.get(u.proto, 0) + 1
        total_now = sum(counts_now.values())
        best: tuple[float, Proto] | None = None
        scores: dict[str, dict[str, float]] = {}
        for proto in candidates:
            counter_term = cw * (eff[proto.id] / max_eff) if enemy_mix else 0.35 * (eff[proto.id] / max_eff)
            role_term = 0.0
            rid = self.ctx.combat.role_of(proto, roles)
            # 角色配额只在「知道对面是什么」时生效。
            # 完全没情报时硬凑 43% 远程，会造出一支没有前排的军队：
            # 既打不过近战海，也无法根据对手调整（审计 counter_quality）。
            if rid is not None and enemy_mix:
                want = target_shares.get(rid, 0.0)
                cur = cur_shares.get(rid, 0.0)
                if want > 0:
                    role_term = rw * min(0.6, max(0.0, (want - cur) / want))
            aa_term = 1.2 if (need_aa and proto.can_hit_air) else 0.0
            if enemy_mix and not proto.can_hit_air and air_share > 0.5:
                aa_term -= 0.8
            dup_term = -0.35 * (counts_now.get(proto.id, 0) / total_now) if total_now > 0 else 0.0
            cost_term = -costw * (proto.cost.gold / max_cost) * 0.6
            # 人口占用与训练时长：真实 RTS 里这两个约束经常比金币更紧。
            # 旧实现只有一个 "supply >= 3 就 -0.05" 的阶跃，导致 3 人口与 10 人口同分。
            supply_term = -supplyw * (proto.cost.supply / max_supply) * 0.8
            time_term = -timew * (proto.build_time / max_time) * 0.8
            score = (
                counter_term + role_term + aa_term + dup_term
                + cost_term + supply_term + time_term
            )
            scores[proto.id] = {
                "counter": round(counter_term, 4),
                "role": round(role_term, 4),
                "aa": round(aa_term, 4),
                "duplicate": round(dup_term, 4),
                "cost": round(cost_term, 4),
                "supply": round(supply_term, 4),
                "time": round(time_term, 4),
                "total": round(score, 4),
            }
            if best is None or score > best[0]:
                best = (score, proto)
        self.last_scores = scores
        return best[1] if best else None


class ProductionManager:
    def __init__(self, ctx: AIContext) -> None:
        self.ctx = ctx
        self.solver = CompositionSolver(ctx)
        self.trained = 0

    def update(self) -> None:
        if not bool(self.ctx.p["autonomy"].get("manage_production", True)):
            return
        w = self.ctx.world
        post = self.ctx.posture
        p = self.ctx.p["production"]
        depth = int(p.get("queue_depth", 2))
        reserve = float(self.ctx.p["economy"]["reserve_gold"])

        target_supply = post.army_supply_target
        cur_supply = sum(w.proto(u.proto).cost.supply for u in w.my_army)
        queued_supply = 0.0
        for b in w.my_buildings:
            if b.complete:
                for q in b.queue:
                    if self.ctx.cat.has(q):
                        queued_supply += self.ctx.cat.get(q).cost.supply
        allowed = cur_supply + queued_supply < target_supply
        # 钱花不出去时允许超编，避免囤金（反愚蠢）
        if not allowed and w.gold > float(self.ctx.p["economy"]["max_gold_float"]):
            allowed = True

        for b in w.production_buildings:
            if len(b.queue) >= depth:
                continue
            if not allowed:
                break
            base_proto = w.proto(b.proto)
            cands = list(self.ctx.cat.trainable_by(base_proto.id))
            completed = {x.proto for x in w.complete_buildings}
            cands = [c for c in cands if self.ctx.cat.tech_satisfied(c, completed)]
            if not cands:
                continue
            proto = self.solver.choose(cands)
            if proto is None:
                continue
            if w.gold < proto.cost.gold + reserve:
                continue
            if w.supply_cap - w.supply_used - queued_supply < proto.cost.supply:
                continue
            res = self.ctx.sched.train(b.bid, proto.id, label="prod:army")
            if res is not None and res.ok:
                self.trained += 1
                cur_supply += proto.cost.supply
                queued_supply += proto.cost.supply
                if cur_supply >= target_supply and w.gold <= float(
                    self.ctx.p["economy"]["max_gold_float"]
                ):
                    allowed = False

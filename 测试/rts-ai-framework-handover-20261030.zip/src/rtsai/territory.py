"""领土控制估计：把「我的存在 / 敌方存在」投影到粗粒度宏格上。

用途：
* 选择扩张点、防守点、进攻路线；
* 评估地图控制率（考试指标之一）；
* 判断某片区域是否「敌方腹地」（避免孤军深入）。
"""
from __future__ import annotations

from rtscontract.snapshot import MapInfo, WorldSnapshot
from rtscontract.vec import Vec2


class Territory:
    def __init__(self, profile) -> None:
        self.p = profile
        self.map: MapInfo | None = None
        self.mine: list[float] = []
        self.foe: list[float] = []
        self.mw = 12
        self.mh = 12

    def update(self, snap: WorldSnapshot, enemy_memory: dict, catalog) -> None:
        self.map = snap.map
        self.mw = snap.map.macro_w or 12
        self.mh = snap.map.macro_h or 12
        n = self.mw * self.mh
        self.mine = [0.0] * n
        self.foe = [0.0] * n

        def cell(p: Vec2) -> int:
            mx = min(self.mw - 1, int(p.x / max(1, snap.map.width) * self.mw))
            my = min(self.mh - 1, int(p.y / max(1, snap.map.height) * self.mh))
            return my * self.mw + mx

        for u in snap.units:
            idx = cell(u.pos)
            try:
                proto = catalog.get(u.proto)
            except KeyError:
                continue
            weight = 0.5 if proto.is_worker else max(0.6, proto.value / 70.0)
            (self.mine if u.team == snap.team else self.foe)[idx] += weight
        for b in snap.buildings:
            idx = cell(b.pos)
            (self.mine if b.team == snap.team else self.foe)[idx] += 2.0
        for mem in enemy_memory.values():
            if snap.time - mem.last_seen < 60.0:
                self.foe[cell(mem.pos)] += 1.2

    # ------------------------------------------------------------------ 指标
    @property
    def share(self) -> float:
        """我方控制宏格 / 双方有争夺的宏格。"""
        mine = foe = 0
        for i in range(len(self.mine)):
            if self.mine[i] <= 0 and self.foe[i] <= 0:
                continue
            if self.mine[i] > self.foe[i] * 1.1:
                mine += 1
            elif self.foe[i] > self.mine[i] * 1.1:
                foe += 1
        total = mine + foe
        return mine / total if total else 0.5

    def cell_of(self, point: Vec2) -> int:
        if not self.map:
            return 0
        mx = min(self.mw - 1, int(point.x / max(1, self.map.width) * self.mw))
        my = min(self.mh - 1, int(point.y / max(1, self.map.height) * self.mh))
        return my * self.mw + mx

    def danger(self, point: Vec2) -> float:
        """0..1，越大越危险（敌方存在远超我方）。

        使用 3×3 加权邻域，而不是只看点所在的单个宏格：
        敌人常常正好落在相邻格，单格取值会让「5 格外的驻军」完全不计。
        权重：中心 1.0，正交邻居 0.6，对角 0.3。
        """
        idx = self.cell_of(point)
        if idx >= len(self.mine):
            return 0.0
        cx, cy = idx % self.mw, idx // self.mw
        f = m = 0.0
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dx == 0 and dy == 0:
                    w = 1.0
                elif dx == 0 or dy == 0:
                    w = 0.6
                else:
                    w = 0.3
                x, y = cx + dx, cy + dy
                if 0 <= x < self.mw and 0 <= y < self.mh:
                    j = y * self.mw + x
                    f += self.foe[j] * w
                    m += self.mine[j] * w
        return max(0.0, min(1.0, (f - m * 1.2) / (f + 1.0)))

    def contested_points(self, limit: int = 4) -> list[Vec2]:
        scored: list[tuple[float, Vec2]] = []
        assert self.map is not None
        for i in range(len(self.mine)):
            m, f = self.mine[i], self.foe[i]
            if m > 0 and f > 0:
                scored.append((min(m, f) / max(m, f), self.map.macro_center(i % self.mw, i // self.mw)))
        scored.sort(key=lambda kv: kv[0], reverse=True)
        return [p for _, p in scored[:limit]]

"""战斗管理：防守、进攻、撤退、微操。

全部阈值来自配置，且以「战力估值」而非「单位数量」为判据：
同样 10 个兵，克制关系不同，AI 的决策会不同。
"""
from __future__ import annotations

from typing import Iterable, Sequence

from rtscontract.snapshot import UnitInfo
from rtscontract.vec import Vec2

from .context import AIContext


class CombatManager:
    def __init__(self, ctx: AIContext) -> None:
        self.ctx = ctx
        self.mode = "idle"
        self.retreat_until = -999.0
        self.attack_started = -999.0
        self.stats = {"defends": 0, "attacks": 0, "retreats": 0, "micro": 0, "flee": 0}
        self._fleeing: dict[int, float] = {}
        self.retreat_point: Vec2 | None = None
        self.retreat_until: float = -999.0
        self._defending_since: float = -1.0
        self.attack_until: float = -999.0

    # ------------------------------------------------------------------ 主流程
    def update(self) -> None:
        w = self.ctx.world
        post = self.ctx.posture
        army = [u for u in w.my_army if not w.player_protected(u)]
        threats = self._threats()
        self._flee_workers(threats)
        if not army:
            self.mode = "idle"
            return
        if w.time < self.retreat_until and self.retreat_point is not None:
            self._continue_retreat(army)
            self.mode = "retreat"
            return
        if self._should_retreat(army):
            self._retreat(army)
            self.mode = "retreat"
            return
        if threats:
            self._defend(threats, army, post)
            self.mode = "defend"
            self.attack_until = -999.0
        elif w.time < self.attack_until or (post.allow_attack and self._gathered(army, post)):
            self._attack(army, post)
            self.mode = "attack"
        else:
            self._gather(army, post)
            self.mode = "gather"
        self._micro(army)

    # ------------------------------------------------------------------ 防守
    def _threats(self) -> list[UnitInfo]:
        w = self.ctx.world
        radius = float(self.ctx.p["combat"]["defense_radius"])
        seen: dict[int, UnitInfo] = {}
        for b in w.townhalls:
            for e in w.threat_near(b.pos, radius):
                if w.proto(e.proto).attack is None:
                    continue  # 敌方农民/侦察兵不构成威胁
                seen[e.uid] = e
        for u in w.my_workers:
            for e in w.enemies_near(u.pos, radius * 0.75):
                if w.proto(e.proto).attack is None:
                    continue
                if e.pos.dist(u.pos) <= radius * 0.75:
                    seen[e.uid] = e
        return list(seen.values())

    def _defend(self, threats: Sequence[UnitInfo], army: Sequence[UnitInfo], post) -> None:
        w = self.ctx.world
        p = self.ctx.p["combat"]
        if self._defending_since < 0:
            self._defending_since = w.time
            self.stats["defends"] += 1

        # 威胁中心与主目标
        cx = sum(e.pos.x for e in threats) / len(threats)
        cy = sum(e.pos.y for e in threats) / len(threats)
        center = Vec2(cx, cy)
        threat_value = sum(w.proto(e.proto).value for e in threats)
        full_recall = threat_value >= 140.0 or len(threats) >= 4

        target = max(
            threats,
            key=lambda e: w.proto(e.proto).value / (1.0 + e.pos.dist(center)),
        )
        near = [u for u in army if u.pos.dist(center) <= 34.0]
        if full_recall:
            defenders = list(army)
        else:
            defenders = near
            if not defenders:
                defenders = sorted(army, key=lambda u: u.pos.dist(center))[:4]
        cap = max(1, int(len(army) * float(p["defense_commit_ratio"])))
        if len(defenders) > max(cap, len(near)):
            defenders = sorted(defenders, key=lambda u: u.pos.dist(center))[: max(cap, len(near))]

        in_range = [
            u.uid
            for u in defenders
            if w.proto(u.proto).attack is not None and u.pos.dist(target.pos) <= 16.0
        ]
        far = [
            u.uid
            for u in defenders
            if w.proto(u.proto).attack is not None and u.pos.dist(target.pos) > 16.0
        ]
        if in_range:
            self.ctx.sched.attack(in_range, target.uid, label="combat:defend")
        if far:
            self.ctx.sched.attack_move(far, center, label="combat:defend")

        if full_recall:
            rest = [u for u in army if u not in defenders]
            if rest:
                self.ctx.sched.attack_move([u.uid for u in rest], center, label="combat:recall")
        # 生产建筑集结点拉回基地
        for b in w.production_buildings:
            if b.rally is None or b.rally.dist(w.base_pos) > 30.0:
                self.ctx.sched.rally(b.bid, w.base_pos, label="combat:rally_home")

    # ------------------------------------------------------------------ 撤退
    def _nearby_enemies(self, army: Sequence[UnitInfo], margin: float) -> list[UnitInfo]:
        """用军队包围盒预筛敌人，避免 O(我方×敌方) 全量扫描（1,000 单位时的热点）。"""
        w = self.ctx.world
        if not army:
            return []
        xs = [u.pos.x for u in army]
        ys = [u.pos.y for u in army]
        x0, x1 = min(xs) - margin, max(xs) + margin
        y0, y1 = min(ys) - margin, max(ys) + margin
        return [e for e in w.enemy_units if x0 <= e.pos.x <= x1 and y0 <= e.pos.y <= y1]

    def _should_retreat(self, army: Sequence[UnitInfo]) -> bool:
        w = self.ctx.world
        p = self.ctx.p["combat"]
        if w.time < self.retreat_until:
            return False
        if len(army) < 3:
            return False
        # 用「战场附近双方全部兵力」估计，而不是只看已经接触的几个单位
        enemies = {
            e.uid: e
            for e in self._nearby_enemies(army, 40.0)
            if any(e.pos.dist(u.pos) <= 40.0 for u in army)
        }
        if len(enemies) < 2:
            return False
        # 已经脱战就别再折腾（否则会在敌人附近来回横跳）
        if min(min(u.pos.dist(e.pos) for e in enemies.values()) for u in army) > 32.0:
            return False
        near_army = [
            u for u in army if any(u.pos.dist(e.pos) <= 40.0 for e in enemies.values())
        ]
        if len(near_army) < 2:
            return False
        est = self.ctx.combat.estimate(
            [w.proto(u.proto) for u in near_army],
            [w.proto(e.proto) for e in enemies.values()],
        )
        hp_avg = sum(u.hp_pct for u in near_army) / len(near_army)
        if est.ratio < float(p["retreat_power_ratio"]):
            return True
        return hp_avg < 0.42 and est.ratio < 1.05

    def _retreat(self, army: Sequence[UnitInfo]) -> None:
        w = self.ctx.world
        p = self.ctx.p["combat"]
        # 撤退点：远离威胁源（而不是朝敌人方向退回基地）
        threats = [
            e for e in self._nearby_enemies(army, 32.0)
            if any(e.pos.dist(u.pos) <= 32.0 for u in army)
        ]
        if threats:
            acx = sum(u.pos.x for u in army) / len(army)
            acy = sum(u.pos.y for u in army) / len(army)
            cx = sum(e.pos.x for e in threats) / len(threats)
            cy = sum(e.pos.y for e in threats) / len(threats)
            # 从「军队自己」朝远离威胁的方向撤，而不是一律退回基地
            away = Vec2(acx - cx, acy - cy).normalized()
            if away.length < 0.1:
                away = (w.base_pos - Vec2(cx, cy)).normalized()
            if away.length < 0.1:
                away = Vec2(-1.0, -1.0).normalized()
            target = self._safe_point(Vec2(acx + away.x * 22.0, acy + away.y * 22.0), army)
        else:
            target = w.base_pos
        for u in army:
            if u.pos.dist(target) > 26.0:
                self.ctx.sched.attack_move([u.uid], target, label="combat:retreat")
            else:
                self.ctx.sched.move([u.uid], target, label="combat:retreat")
        self.retreat_point = target
        self.retreat_until = w.time + max(6.0, float(p["regroup_seconds"]))
        self.stats["retreats"] += 1
        self.attack_started = -999.0

    def _continue_retreat(self, army: Sequence[UnitInfo]) -> None:
        assert self.retreat_point is not None
        for u in army:
            if u.pos.dist(self.retreat_point) > 8.0:
                self.ctx.sched.move([u.uid], self.retreat_point, label="combat:retreat")

    # ------------------------------------------------------------------ 进攻
    def _gathered(self, army: Sequence[UnitInfo], post) -> bool:
        if not army:
            return False
        near = [u for u in army if u.pos.dist(post.rally) <= 20.0]
        need = max(
            float(self.ctx.p["combat"]["min_attack_units"]),
            len(army) * float(self.ctx.p["combat"]["army_gather_ratio"]),
        )
        return len(near) >= need

    def _gather(self, army: Sequence[UnitInfo], post) -> None:
        rally = post.rally
        for u in army:
            if u.pos.dist(rally) > 9.0:
                self.ctx.sched.attack_move([u.uid], rally, label="combat:gather")
        for b in self.ctx.world.production_buildings:
            if b.rally is None or b.rally.dist(rally) > 6.0:
                self.ctx.sched.rally(b.bid, rally, label="combat:rally")

    def _attack(self, army: Sequence[UnitInfo], post) -> None:
        w = self.ctx.world
        if self.attack_started < 0:
            self.attack_started = w.time
            self.stats["attacks"] += 1
        # 一次进攻至少坚持 20 秒，避免计划抖动导致「出发-回撤」来回拉扯。
        # 注意：这条自续**不是**命令风暴的原因——风暴已由 scheduler 的
        # "已在目标点就不再下令" 修掉（AUDIT_REPORT P0-1）。
        self.attack_until = max(self.attack_until, w.time + 20.0)
        point = post.attack_point
        target_id = post.attack_target
        visible_ids = {b.bid for b in w.visible_enemy_buildings}
        if target_id is not None and target_id in visible_ids:
            siege = [u.uid for u in army if u.pos.dist(point) <= 22.0]
            push = [u.uid for u in army if u.pos.dist(point) > 22.0]
            if siege:
                self.ctx.sched.attack(siege, target_id, label="combat:siege")
            if push:
                self.ctx.sched.attack_move(push, point, label="combat:push")
        else:
            self.ctx.sched.attack_move([u.uid for u in army], point, label="combat:push")

    # ------------------------------------------------------------------ 微操
    def _micro(self, army: Sequence[UnitInfo]) -> None:
        w = self.ctx.world
        p = self.ctx.p["combat"]
        if not bool(p.get("focus_fire", True)):
            return
        if not w.enemy_units:
            return
        base = w.base_pos
        # 按目标聚合后再下发：既减少命令量，也避免「同一个目标被 10 个单位各发一条」造成的重复失败
        assign: dict[int, list[int]] = {}
        retreat: list[int] = []
        for u in army:
            proto = w.proto(u.proto)
            if proto.attack is None:
                continue
            # 网格粗筛后再算距离：1,000 单位时把 O(我方×敌方) 降到 O(我方×邻域)
            cands = [
                e
                for e in w.enemies_near(u.pos, 15.0)
                if e.pos.dist(u.pos) <= 15.0 and proto.attack.can_hit(w.proto(e.proto).flying)
            ]
            if not cands:
                continue
            if u.hp_pct < float(p["retreat_hp_pct"]) and u.pos.dist(base) > 12.0:
                retreat.append(u.uid)
                continue
            if u.order == "attack" and u.order_target in {e.uid for e in cands}:
                continue
            target = max(
                cands,
                key=lambda e: w.proto(e.proto).value
                * (1.0 + 0.8 * (1.0 - e.hp_pct))
                / (1.0 + u.pos.dist(e.pos) / 10.0),
            )
            assign.setdefault(target.uid, []).append(u.uid)
        for tid, uids in assign.items():
            res = self.ctx.sched.attack(uids, tid, label="combat:focus")
            if res is not None:
                self.stats["micro"] += len(uids)
        if retreat:
            self.ctx.sched.move(retreat, base, label="combat:unit_retreat")

    # ------------------------------------------------------------------ 农民避险
    def _flee_workers(self, threats: Sequence[UnitInfo]) -> None:
        w = self.ctx.world
        now = w.time
        # 清理过期/已死亡的避险记录
        for uid in list(self._fleeing):
            if now > self._fleeing[uid] or not any(x.uid == uid for x in w.my_workers):
                self._fleeing.pop(uid, None)
        if not threats:
            return
        radius = float(self.ctx.p["combat"]["worker_flee_radius"])
        # 小股骚扰不值得让整个经济停摆：只有威胁够大才「全员避险」
        threat_value = sum(w.proto(e.proto).value for e in threats)
        mass_flee = threat_value >= 250.0
        for u in w.my_workers:
            if w.player_protected(u) or u.uid in self._fleeing:
                continue
            limit = 3.0 if u.order == "build" else (radius if mass_flee else 5.0)
            near = [e for e in threats if e.pos.dist(u.pos) <= limit]
            if not near:
                continue
            # 朝「远离威胁」的方向跑，而不是傻站在基地里
            threat_center = Vec2(
                sum(e.pos.x for e in near) / len(near), sum(e.pos.y for e in near) / len(near)
            )
            away = (u.pos - threat_center).normalized()
            if away.length < 0.1:
                away = (w.base_pos - threat_center).normalized()
            p = u.pos + away * 9.0
            p = self._safe_point(p, [u], strict=False)
            self.ctx.sched.move([u.uid], p, label="combat:flee")
            self._fleeing[u.uid] = now + 5.0
            self.stats["flee"] += 1

    def _safe_point(self, p: Vec2, units: Sequence[UnitInfo] = (), strict: bool = True) -> Vec2:
        """把点修正到「可站且（strict 时）可达」的位置。

        旧实现只查 ``is_walkable``：撤退点可能落在封闭房间里（可走、不可达），
        单位会朝墙里走并被判 stuck（AUDIT_REPORT §7 r1）。
        """
        m = self.ctx.world.snap.map
        if m.is_walkable(p) and (not strict or self.ctx.can_reach(p, units)):
            return p
        probes = 0
        for r in range(2, 12, 2):
            for dx, dy in ((r, 0), (-r, 0), (0, r), (0, -r)):
                q = Vec2(p.x + dx, p.y + dy)
                if not m.is_walkable(q):
                    continue
                probes += 1
                if not strict or self.ctx.can_reach(q, units):
                    return q
                if probes >= 6:
                    break
            if probes >= 6:
                break
        base = self.ctx.world.base_pos
        if strict and not self.ctx.can_reach(base, units):
            return base          # 连基地都不可达：只能回基地，交给引擎处理
        return base

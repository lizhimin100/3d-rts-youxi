"""侦察：用低价值单位探索迷雾，为战略层提供敌方信息。

侦察兵选择完全基于「当前没有更重要任务的单位」，不写死兵种。
"""
from __future__ import annotations

from rtscontract.enums import OrderKind
from rtscontract.vec import Vec2

from .context import AIContext


class ScoutManager:
    def __init__(self, ctx: AIContext) -> None:
        self.ctx = ctx
        self.scouts: dict[int, Vec2] = {}
        self.next_at: float = 0.0
        self.trips = 0

    def update(self) -> None:
        w = self.ctx.world
        p = self.ctx.p["scouting"]
        if not bool(self.ctx.p["autonomy"].get("scout", True)) or not bool(p.get("enabled", True)):
            return
        # 清理已失效的侦察兵
        for uid in list(self.scouts):
            u = next((x for x in w.my_units if x.uid == uid), None)
            if u is None or u.order not in (OrderKind.MOVE, OrderKind.ATTACK_MOVE):
                if u is None or u.pos.dist(self.scouts[uid]) <= 6.0:
                    self.scouts.pop(uid, None)
        if self.scouts and not self.ctx.fog.needs_scouting:
            return
        limit = int(p.get("max_scouts", 2))
        if len(w.my_workers) < 9:
            limit = 1
        if len(self.scouts) >= limit:
            return
        if w.time < self.next_at:
            return
        target = self.ctx.fog.frontier(w.base_pos)
        if target is None:
            return
        unit = self._pick_scout()
        if unit is None:
            return
        self.ctx.sched.move([unit.uid], target, label="scout")
        self.scouts[unit.uid] = target
        self.trips += 1
        self.next_at = w.time + float(p.get("interval_seconds", 18))

    def _pick_scout(self):
        w = self.ctx.world
        cands = [
            u
            for u in w.my_workers
            if not w.player_protected(u)
            and u.uid not in self.scouts
            and u.order in (OrderKind.IDLE, OrderKind.STOP, OrderKind.HARVEST)
        ]
        if not cands:
            return None
        # 选离基地最近的（减少往返时间），且优先级：空闲 > 采集中
        cands.sort(key=lambda u: (0 if u.order in (OrderKind.IDLE, OrderKind.STOP) else 1, u.pos.dist(w.base_pos)))
        return cands[0]

"""建筑选址求解器。

真实游戏里「能不能放」由引擎说了算（地形/遮挡/碰撞），所以 AI 只负责**提议**，
并通过 ``gateway.can_place`` 探测，避免把地图知识硬编码进 AI。
"""
from __future__ import annotations

import math
from typing import Iterable, Sequence

from rtscontract.vec import Vec2, dist_point_segment

ANGLES = 16


def _stable_hash(text: str) -> int:
    """与 PYTHONHASHSEED 无关的稳定哈希（保证跨进程可复现）。"""
    h = 0
    for i, ch in enumerate(text):
        h = (h * 131 + ord(ch) * (i + 1)) & 0x7FFFFFFF
    return h


class PlacementSolver:
    def __init__(self, gateway, budget_per_tick: int = 40) -> None:
        self.gw = gateway
        self.budget = budget_per_tick
        self.used = 0
        self.hits = 0
        self.misses = 0

    def begin_tick(self) -> None:
        self.used = 0

    def probe(self, proto_id: str, point: Vec2) -> bool:
        if self.used >= self.budget:
            return False
        self.used += 1
        ok = bool(self.gw.can_place(proto_id, point))
        if ok:
            self.hits += 1
        else:
            self.misses += 1
        return ok

    def find(
        self,
        proto_id: str,
        center: Vec2,
        min_radius: float = 3.0,
        max_radius: float = 16.0,
        avoid_segments: Sequence[tuple[Vec2, Vec2]] = (),
        span: int = 4,
    ) -> Vec2 | None:
        """在 center 周围环形搜索合法落点。返回 None 表示本 tick 探测预算内没找到。"""
        r = min_radius
        while r <= max_radius:
            for i in range(ANGLES):
                ang = 2 * math.pi * (i / ANGLES) + (_stable_hash(proto_id) % 7) * 0.11
                p = Vec2(center.x + math.cos(ang) * r, center.y + math.sin(ang) * r)
                if avoid_segments and any(dist_point_segment(p, a, b) < 2.2 for a, b in avoid_segments):
                    continue
                if self.probe(proto_id, p):
                    return p
            r += max(1.5, (max_radius - min_radius) / max(1, span))
        return None

    def find_near(self, proto_id: str, point: Vec2, radius: float = 6.0) -> Vec2 | None:
        return self.find(proto_id, point, min_radius=1.5, max_radius=radius, span=3)

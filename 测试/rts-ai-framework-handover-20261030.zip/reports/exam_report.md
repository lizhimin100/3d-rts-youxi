# RTS AI 自动化考试报告

- 生成时间：2026-10-28 21:08:28
- 运行环境：Python 3.13.14 / Windows-10-10.0.19045-SP0
- 用例数：**46**，通过 **46**（用例通过率 **100.0%**）
- 断言数：302，通过 302（断言通过率 **100.0%**）
- 对局数：128，耗时 127.3 秒

## 分类得分

| 分类 | 用例 | 通过 | 用例通过率 | 断言通过率 |
|---|---|---|---|---|
| 经济运营 (`economy`) | 3 | 3 | 100% | 100.0% |
| 人口供给 (`population`) | 2 | 2 | 100% | 100.0% |
| 农民管理 (`worker`) | 3 | 3 | 100% | 100.0% |
| 生产与兵种构成 (`production`) | 3 | 3 | 100% | 100.0% |
| 兵种克制 (`counter`) | 3 | 3 | 100% | 100.0% |
| 防守 (`defense`) | 3 | 3 | 100% | 100.0% |
| 进攻 (`attack`) | 2 | 2 | 100% | 100.0% |
| 撤退 (`retreat`) | 2 | 2 | 100% | 100.0% |
| 扩张 (`expansion`) | 3 | 3 | 100% | 100.0% |
| 领土控制 (`territory`) | 2 | 2 | 100% | 100.0% |
| 战争迷雾 (`fog`) | 3 | 3 | 100% | 100.0% |
| 副官控制权 (`adjutant`) | 6 | 6 | 100% | 100.0% |
| 反愚蠢行为 (`sanity`) | 4 | 4 | 100% | 100.0% |
| 随机综合 (`mixed`) | 3 | 3 | 100% | 100.0% |
| 框架约束 (`meta`) | 4 | 4 | 100% | 100.0% |

## 用例明细

| 用例 | 分类 | 种子数 | 结果 | 失败断言 |
|---|---|---|---|---|
| `adj_autonomy_respected` | adjutant | 3 | ✅ PASS |  |
| `adj_follow_player_intent` | adjutant | 3 | ✅ PASS |  |
| `adj_lock_inviolable` | adjutant | 3 | ✅ PASS |  |
| `adj_manual_ttl` | adjutant | 3 | ✅ PASS |  |
| `adj_offers_suggestion` | adjutant | 3 | ✅ PASS |  |
| `adj_player_order_not_cancelled` | adjutant | 3 | ✅ PASS |  |
| `atk_destroy_weak_base` | attack | 3 | ✅ PASS |  |
| `atk_engage_and_win` | attack | 3 | ✅ PASS |  |
| `counter_adapt_air` | counter | 3 | ✅ PASS |  |
| `counter_adapt_ground` | counter | 3 | ✅ PASS |  |
| `counter_no_useless_units` | counter | 3 | ✅ PASS |  |
| `def_base_raid` | defense | 3 | ✅ PASS |  |
| `def_base_survives_push` | defense | 3 | ✅ PASS |  |
| `def_recall_from_front` | defense | 3 | ✅ PASS |  |
| `econ_no_gold_hoard` | economy | 3 | ✅ PASS |  |
| `econ_supply_chain` | economy | 3 | ✅ PASS |  |
| `econ_worker_saturation` | economy | 3 | ✅ PASS |  |
| `exp_near_resources` | expansion | 2 | ✅ PASS |  |
| `exp_respect_pressure` | expansion | 3 | ✅ PASS |  |
| `exp_second_base` | expansion | 3 | ✅ PASS |  |
| `fog_explore` | fog | 3 | ✅ PASS |  |
| `fog_memory_of_seen_buildings` | fog | 3 | ✅ PASS |  |
| `fog_no_cheat` | fog | 3 | ✅ PASS |  |
| `meta_determinism` | meta | 2 | ✅ PASS |  |
| `meta_no_game_dependency` | meta | 1 | ✅ PASS |  |
| `meta_no_hardcode` | meta | 1 | ✅ PASS |  |
| `meta_performance` | meta | 1 | ✅ PASS |  |
| `mix_adjutant_disruption` | mixed | 3 | ✅ PASS |  |
| `mix_long_game_stability` | mixed | 2 | ✅ PASS |  |
| `mix_random_1v1` | mixed | 3 | ✅ PASS |  |
| `pop_headroom_maintained` | population | 3 | ✅ PASS |  |
| `pop_recover_from_block` | population | 3 | ✅ PASS |  |
| `prod_army_growth` | production | 3 | ✅ PASS |  |
| `prod_no_idle_buildings` | production | 3 | ✅ PASS |  |
| `prod_tech_progression` | production | 3 | ✅ PASS |  |
| `ret_avoid_suicide` | retreat | 3 | ✅ PASS |  |
| `ret_keeps_core_army` | retreat | 3 | ✅ PASS |  |
| `san_army_answers_raid` | sanity | 3 | ✅ PASS |  |
| `san_gold_not_hoarded` | sanity | 3 | ✅ PASS |  |
| `san_issue_budget` | sanity | 3 | ✅ PASS |  |
| `san_no_stuck_units` | sanity | 3 | ✅ PASS |  |
| `ter_presence_forward` | territory | 2 | ✅ PASS |  |
| `ter_share_growth` | territory | 3 | ✅ PASS |  |
| `worker_idle_rate` | worker | 3 | ✅ PASS |  |
| `worker_resume_after_raid` | worker | 3 | ✅ PASS |  |
| `worker_survive_raid` | worker | 3 | ✅ PASS |  |

## 种子

- 基础种子：20261026（randomized=False）
- 回归种子：[11, 23, 37, 41, 59, 71, 83]
- 随机种子：[118989, 838777, 238679, 705595, 139454, 862068]

## 附：用例指标（首个种子）

| 用例 | 指标 |
|---|---|
| `adj_autonomy_respected` | attacks=0 |
| `adj_follow_player_intent` | d0=32.1, d1=7.5 |
| `adj_lock_inviolable` | blocked=0, ai_orders=0, locked=3 |
| `adj_manual_ttl` | during=0, after=1, ttl=80 |
| `adj_offers_suggestion` | suggestions=1, codes=['request_control'] |
| `adj_player_order_not_cancelled` | player_owned=6, n=6 |
| `atk_destroy_weak_base` | attacks=1, winner=0 |
| `atk_engage_and_win` | kills=5.0, losses=0.0 |
| `counter_adapt_air` | anti_air_share=0.294, kills=7.0 |
| `counter_adapt_ground` | quality=0.792, army=11 |
| `counter_no_useless_units` | useless=0.0 |
| `def_base_raid` | kills=5.0, worker_losses=0.0 |
| `def_base_survives_push` | kills=6.0 |
| `def_recall_from_front` | near=9, army=9, kills=3.0 |
| `econ_no_gold_hoard` | float_samples=0, army=17.0 |
| `econ_supply_chain` | max_streak=0, cap=50.0, rejected=0 |
| `econ_worker_saturation` | workers=8.68, idle=0.03 |
| `exp_near_resources` | halls=2 |
| `exp_respect_pressure` | expansions=1.0 |
| `exp_second_base` | expansions=2.0, workers=20.0, income=3048.0 |
| `fog_explore` | explored=0.3835 |
| `fog_memory_of_seen_buildings` | remembered=1 |
| `fog_no_cheat` | cheat=0 |
| `meta_determinism` | hash=9c02c8287d65 |
| `meta_no_game_dependency` | files=19 |
| `meta_no_hardcode` | case_ids=46 |
| `meta_performance` | tps=254.5 |
| `mix_adjutant_disruption` | workers=10.0, army=10.0 |
| `mix_long_game_stability` | units=63, cap=80.0 |
| `mix_random_1v1` | units=50, winner=-1, kills=5.0 |
| `pop_headroom_maintained` | hard_zero_ratio=0.0, cap=50.0 |
| `pop_recover_from_block` | cap=40.0 |
| `prod_army_growth` | army=13.0 |
| `prod_no_idle_buildings` | busy_ratio=0.761 |
| `prod_tech_progression` | types=4 |
| `ret_avoid_suicide` | retreats=5, survivors=6 |
| `ret_keeps_core_army` | survivors=10, losses=6.0 |
| `san_army_answers_raid` | kills=3.0 |
| `san_gold_not_hoarded` | over=0.0 |
| `san_issue_budget` | ipm=1.67 |
| `san_no_stuck_units` | stuck=0 |
| `ter_presence_forward` | forward=9 |
| `ter_share_growth` | share=0.733, early=0.667 |
| `worker_idle_rate` | idle_rate=0.0038 |
| `worker_resume_after_raid` | idle=0.0, income=664.0 |
| `worker_survive_raid` | worker_losses=0.0, workers=10.0 |

# 通用 RTS AI 框架（含 Mock Simulator 与自动化考试）

> **交接入口（先读这三份）**
>
> | 文档 | 用途 |
> |---|---|
> | `FIX_LOG.md` | 审计发现的问题**是怎么修的**：每个 P0 的根因、改动、修复前后实测 |
> | `AUDIT_REPORT.md` | 交接前工程审计：25 项清单、网关审查、控制权重设计、故障注入、性能、最终判定 |
> | `HANDOVER_FINAL.md` | 25 项交接包：架构 / 启动 / 成绩 / 接口 / 接入 / 扩展点 / 验收 |
> | `PORTING_GUIDE.md` | 移植到 Godot 4.7 / GDScript 的完整指南（7 里程碑 + 五关验收） |
>
> **当前状态：`NEEDS_REFACTOR_BEFORE_INTEGRATION`。**
> 这套代码是"AI 原型 + 验证环境"，**不是**可直接嵌入游戏的运行代码。
>
> 不过 P0 阻断项已全部修复：**46/46 用例、302/302 断言（固定种子与随机种子均通过）**，
> 审计 43 项 **FAIL 0** / WARNING 8 / PASS 33 / N/A 2。
> 「还需要重构」现在只指**移植工作量**（Python → GDScript）与 3 个协议缺口（事件通道 / patrol / repair）。

一套面向「类《魔兽争霸 3》RTS」的**通用 AI 框架**，同时服务两种角色：

* **敌方人机**：完全自主的 AI 对手；
* **玩家副官**：听从玩家指挥、绝不抢夺玩家控制的协同 AI。

框架本身**不依赖任何具体兵种、建筑或游戏引擎**。当前开发机没有真实游戏工程，
因此仓库内含一个无渲染、可确定性复现的 **Mock Simulator**，用于批量验证战略逻辑；
接入真实游戏只需实现一个网关接口（见 `docs/03-INTEGRATION-GUIDE.md`）。

> 交付物清单：源码、Mock Simulator、Test Runner、配置文件、测试报告、接口协议、
> 架构说明、接入指南、待接入功能清单、已知问题、Handover 文档。

---

## 30 秒上手

```bash
# 1）列出全部考试用例（46 个 / 15 个分类）
python run_exam.py --list

# 2）跑一遍（8 进程并行，回归种子 + 随机种子）
python run_exam.py --jobs 8

# 3）只看某一类
python run_exam.py --category economy --category adjutant --seeds 1

# 4）单用例调试
python run_exam.py --case adj_lock_inviolable --seeds 3

# 5）与基线对比（回归检查）
python run_exam.py --baseline reports/baseline.json
```

运行环境：**Python 3.10+，仅标准库**（无第三方依赖，Windows / Linux / macOS 均可）。

```bash
# 可视化演示：跑一场 AI vs AI，输出 SVG 战报（不需要图形库）
python run_demo.py --seed 7 --duration 180
```

---

## 目录结构

```
rts-ai-framework/
├── src/
│   ├── rtscontract/          # 契约层：AI 与游戏的唯一公共语言（纯数据 + 协议）
│   ├── rtsai/               # AI 核心（只依赖 rtscontract，绝不 import rtsim）
│   ├── rtsim/               # Mock Simulator（无渲染、定步长、确定性）
│   └── rtsexam/             # 考试系统（用例 + 执行器 + 报告）
├── config/
│   ├── catalog.json         # 兵种/建筑原型 + 攻击护甲克制矩阵（数据驱动）
│   ├── ai_profile.json      # AI 阈值与权重
│   ├── plans.json           # 声明式战略计划（DSL）
│   └── exam.json            # 考试配置（种子池、通过线）
├── docs/                    # 架构 / 协议 / 接入 / 待办 / 已知问题 / Handover
├── reports/                 # 考试报告（md + json）与基线
├── scripts/                 # 诊断脚本（smoke / debug）
├── run_exam.py              # 考试入口
└── run_demo.py              # 演示入口（生成 SVG 战报）
```

**依赖方向（单向，可静态检查）**：

```
rtsexam ──▶ rtsai ──▶ rtscontract ◀── rtsim
                （rtsai 不得 import rtsim / godot / 任何具体游戏代码）
```

---

## 三个能力域

| 方向 | 模块 | 关键决策 |
|---|---|---|
| **运营** | `rtsai/economy.py` `production.py` | 农民持续补充到矿点容量、主动补人口、按「每金战力」选兵、囤金时扩产 |
| **战斗** | `rtsai/combat.py` `combatmodel.py` | 防守/进攻/撤退/焦点火力；战力估算来自「攻击类型×护甲类型」矩阵 |
| **扩张** | `rtsai/expansion.py` `territory.py` | 主矿饱和即开矿、按资源/距离/危险度选址、压力下禁止扩张 |

四者共享同一个 `Posture`（战略姿态），由 `rtsai/director.py` 从**声明式计划**
（`config/plans.json`）中选出，保证「经济/军事/扩张」朝同一方向用力。

---

## 为什么新增兵种不需要改 AI

1. **原型表驱动**：兵种只有数值与标签（`config/catalog.json`），AI 不认名字；
2. **克制来自矩阵**：`damage_type × armor_type` 的倍率表 + 标签加成，
   AI 用同一张表计算任意两个原型的 DPS / 有效生命 / 交换比；
3. **角色配额来自配置**：`ai_profile.production.roles` 用标签声明「前排/远程/攻城」占比；
4. **战略计划是 DSL**：新流派只需往 `plans.json` 加一条条件-权重。

新增一个兵种 = 在 `catalog.json` 增加一条记录（+ 若需要，在新地图/新场景里出现）。

---

## 副官：玩家指令优先原则

三道防线（任一道都能独立阻止 AI 抢控制权）：

1. **登记**：玩家下令 → 整组进入 `PLAYER_ACTIVE`，组内全部单位 idle 后转入
   `PLAYER_GRACE`（5 秒）；显式锁定 → `PLAYER_LOCKED`（永久）；STOP → `PLAYER_HOLDING`（30 秒）；
2. **AI 侧过滤**：所有命令走 `CommandScheduler.available()`，被保护单位直接剔除；
3. **网关侧拒绝**：模拟器/真实游戏再次校验，越权命令被拒并计入 `control_blocked`。

> 这是 **Player Intent Ownership**，不是「玩家下令后 8 秒内不准动」。
> 宽限期从**命令结束**开始算，且按**命令组**判定，所以 30 秒的绕后命令
> 不会中途被抢、先到的单位也不会把队形撕开（`AUDIT_REPORT.md` §4）。

考试用例 `adj_lock_inviolable`、`adj_manual_ttl`、`adj_player_order_not_cancelled`
断言 `control_blocked == 0` 且被锁单位**零条** AI 命令。

副官的主动性由 `autonomy` 配置控制（`move_army_aggressive` / `expand` / `scout` …）；
与玩家意图冲突时只发**建议**（`gateway.suggest()`），不擅自行动。

---

## 考试系统

* 46 个用例 / 15 个分类：经济、人口、农民、生产、克制、防守、进攻、撤退、扩张、领土、
  迷雾、副官控制权、反愚蠢、随机综合、框架约束。
* **禁止针对用例硬编码**：`meta_no_hardcode` 会扫描 AI 源码，出现任何用例 id / `seed == N`
  / `rtsexam` 引用即判失败。
* **每轮跑随机种子 + 固定回归种子**，并可与基线对比（`--baseline`）。
* 每个用例都声明「场景 + 阈值」，AI 不知道考试的存在。

当前结果见 `reports/exam_report.md`（最近一次全量运行）。

---

## 文档索引

| 文档 | 内容 |
|---|---|
| `docs/01-ARCHITECTURE.md` | 分层、数据流、模块职责、关键设计取舍 |
| `docs/02-INTERFACE-PROTOCOL.md` | 契约层逐字段说明 + 语义约定 |
| `docs/03-INTEGRATION-GUIDE.md` | 接入真实游戏的分步指南（含检查清单） |
| `docs/04-TODO-INTEGRATION.md` | 待接入功能清单与扩展点 |
| `docs/05-KNOWN-ISSUES.md` | 已知问题与模拟器简化项 |
| `docs/06-HANDOVER.md` | 交接说明：从哪读起、怎么改、下一步 |
| `docs/07-TEST-REPORT.md` | 考试报告摘要与解读 |
| `docs/08-OPTIMIZATION-LOG.md` | 五轮优化的「问题→诊断→改动→双跑验证」记录 |

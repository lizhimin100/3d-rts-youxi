#!/usr/bin/env python
"""演示：跑一场 AI vs AI，并把战况渲染成一份自带样式的 HTML/SVG 战报。

    python run_demo.py --seed 7 --duration 240

不依赖任何图形库：直接生成 SVG 片段并内联进 HTML。
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from rtsai import RTSAgent  # noqa: E402
from rtscontract.catalog import catalog_from_dict  # noqa: E402
from rtscontract.configio import load_json  # noqa: E402
from rtscontract.enums import Issuer  # noqa: E402
from rtsim import MockGateway, ScenarioSpec, build_sim  # noqa: E402

TEAM_COLORS = {0: "#4EA1FF", 1: "#FF6B6B"}
BG = "#12141a"
GRID = "#1d2230"
ROCK = "#2b3242"
NODE = "#E7C65B"


def run(seed: int, duration: float, layout: str) -> tuple[Any, list[dict], float, dict]:
    cat = catalog_from_dict(load_json("catalog.json"))
    sim = build_sim(
        ScenarioSpec(seed=seed, width=88, height=88, layout=layout, max_time=duration + 30), cat
    )
    a0 = RTSAgent(MockGateway(sim, 0, issuer=Issuer.ADJUTANT))
    a1 = RTSAgent(MockGateway(sim, 1, issuer=Issuer.ENEMY_AI))
    frames: list[dict] = []
    hz = sim.tick_hz
    step = max(1, int(hz * 60))
    t0 = time.perf_counter()
    total = int(duration * hz)
    for tick in range(total):
        sim.step()
        if tick % 2 == 0:
            a0.update()
            a1.update()
        if tick % step == 0:
            frames.append(capture(sim))
    frames.append(capture(sim))
    dt = time.perf_counter() - t0
    return sim, frames, dt, {"a0": a0.stats(), "a1": a1.stats()}


def capture(sim) -> dict:
    units = [
        (u.pos.x, u.pos.y, u.team, u.proto.id, u.proto.harvest is not None, u.hp / max(1.0, u.proto.hp))
        for u in sim.units
        if u.alive
    ]
    buildings = [(b.pos.x, b.pos.y, b.team, b.proto.id, b.complete) for b in sim.buildings if b.alive]
    return {
        "time": sim.time,
        "units": units,
        "buildings": buildings,
        "gold": dict(sim.gold),
        "workers": {t: len([u for u in sim.units if u.alive and u.team == t and u.proto.harvest]) for t in (0, 1)},
        "army": {t: len([u for u in sim.units if u.alive and u.team == t and not u.proto.harvest]) for t in (0, 1)},
        "supply": {t: (sim._supply_used[t], sim._supply_cap[t]) for t in (0, 1)},
    }


def render_svg(sim, frames: list[dict], width: int = 360, gap: int = 16, per_row: int = 3) -> str:
    scale = width / sim.width
    height = int(sim.height * scale)
    rows = (len(frames) + per_row - 1) // per_row
    total_h = rows * (height + 34) + 10
    total_w = per_row * width + (per_row + 1) * gap

    parts: list[str] = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{total_w}" height="{total_h}" '
        f'viewBox="0 0 {total_w} {total_h}" font-family="ui-sans-serif,system-ui,Segoe UI,Helvetica,Arial">'
    ]
    parts.append(f'<rect width="{total_w}" height="{total_h}" fill="{BG}"/>')

    for i, f in enumerate(frames):
        r, c = divmod(i, per_row)
        ox = gap + c * (width + gap)
        oy = gap + r * (height + 34)
        parts.append(f'<g transform="translate({ox},{oy})">')
        parts.append(f'<rect width="{width}" height="{height}" rx="6" fill="#0d1017" stroke="{GRID}"/>')

        # 地形
        step = 2
        for y in range(0, sim.height, step):
            for x in range(0, sim.width, step):
                if sim.map.walkable[y][x] == 0:
                    parts.append(
                        f'<rect x="{x*scale:.1f}" y="{y*scale:.1f}" width="{step*scale+0.4:.1f}" '
                        f'height="{step*scale+0.4:.1f}" fill="{ROCK}"/>'
                    )
        # 资源点
        for n in sim.nodes:
            if n.remaining <= 0:
                continue
            parts.append(
                f'<circle cx="{n.pos.x*scale:.1f}" cy="{n.pos.y*scale:.1f}" r="3" fill="{NODE}" opacity="0.75"/>'
            )
        # 建筑
        for bx, by, team, proto, complete in f["buildings"]:
            color = TEAM_COLORS[team]
            size = 9 if complete else 6
            parts.append(
                f'<rect x="{bx*scale-size/2:.1f}" y="{by*scale-size/2:.1f}" width="{size}" height="{size}" '
                f'rx="2" fill="{color}" opacity="{0.95 if complete else 0.45}"/>'
            )
        # 单位
        for ux, uy, team, proto, is_worker, hp in f["units"]:
            color = TEAM_COLORS[team]
            r_ = 1.9 if is_worker else 2.8
            op = 0.55 if is_worker else 1.0
            parts.append(
                f'<circle cx="{ux*scale:.1f}" cy="{uy*scale:.1f}" r="{r_}" fill="{color}" opacity="{op}"/>'
                + (
                    f'<circle cx="{ux*scale:.1f}" cy="{uy*scale:.1f}" r="{r_+1.4}" fill="none" '
                    f'stroke="#ffffff" stroke-opacity="{0.5*(1-hp):.2f}" stroke-width="0.8"/>'
                    if hp < 0.99
                    else ""
                )
            )
        # 标题
        parts.append(
            f'<text x="10" y="-8" fill="#c9d4e6" font-size="12">t={f["time"]:.0f}s</text>'
        )
        parts.append("</g>")

    parts.append("</svg>")
    return "".join(parts)


def render_html(sim, frames, stats, wall: float, seed: int) -> str:
    svg = render_svg(sim, frames)
    last = frames[-1]
    rows = ""
    for team, name in ((0, "副官 (Team 0)"), (1, "敌方人机 (Team 1)")):
        s = stats[f"a{team}"]
        rows += (
            f"<tr><td><span class='dot' style='background:{TEAM_COLORS[team]}'></span>{name}</td>"
            f"<td>{last['workers'][team]}</td><td>{last['army'][team]}</td>"
            f"<td>{last['supply'][team][0]:.0f}/{last['supply'][team][1]:.0f}</td>"
            f"<td>{last['gold'][team]:.0f}</td>"
            f"<td>{s.get('plan')}</td><td>{s.get('mode')}</td>"
            f"<td>{s.get('commands', {}).get('commands_sent', 0)}</td>"
            f"<td>{s.get('sanity', {}).get('issues_per_minute', 0)}</td></tr>"
        )
    meta0 = stats["a0"]
    return f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<title>RTS AI 战报 · seed {seed}</title>
<style>
  :root {{ color-scheme: dark; }}
  body {{ margin:0; background:{BG}; color:#dfe7f5;
         font-family:ui-sans-serif,system-ui,"Segoe UI",Helvetica,Arial,"Microsoft YaHei",sans-serif; }}
  .wrap {{ max-width:1240px; margin:0 auto; padding:28px 24px 48px; }}
  h1 {{ font-size:22px; font-weight:650; margin:0 0 6px; letter-spacing:.2px; }}
  .sub {{ color:#8b98ad; font-size:13px; margin-bottom:20px; }}
  .card {{ background:#151922; border:1px solid {GRID}; border-radius:10px; padding:16px 18px; margin-bottom:18px; }}
  table {{ border-collapse:collapse; width:100%; font-size:13px; }}
  th, td {{ text-align:left; padding:7px 10px; border-bottom:1px solid #1e2431; }}
  th {{ color:#8b98ad; font-weight:500; }}
  .dot {{ display:inline-block; width:9px; height:9px; border-radius:50%; margin-right:7px; }}
  .kpi {{ display:flex; gap:26px; flex-wrap:wrap; font-size:13px; color:#a9b6ca; }}
  .kpi b {{ color:#eaf1ff; font-size:16px; font-weight:600; }}
  .legend {{ font-size:12px; color:#8b98ad; margin-top:8px; }}
  code {{ background:#1b2130; padding:1px 5px; border-radius:4px; font-size:12px; }}
</style></head>
<body><div class="wrap">
  <h1>RTS AI 对局战报</h1>
  <div class="sub">seed={seed} · 地图 88×88 · 定步长 10Hz · 纯 Python 无渲染模拟</div>

  <div class="card"><div class="kpi">
    <div><b>{wall:.1f}s</b><div>模拟墙钟</div></div>
    <div><b>{len(frames)}</b><div>采样帧</div></div>
    <div><b>{last['time']:.0f}s</b><div>对局时长</div></div>
    <div><b>{meta0.get('plan_changes', 0)}</b><div>战略切换</div></div>
    <div><b>{meta0.get('commands', {}).get('commands_sent', 0)}</b><div>AI 命令数</div></div>
    <div><b>{meta0.get('commands', {}).get('failures', {})}</b><div>命令失败</div></div>
  </div></div>

  <div class="card">
    <table>
      <tr><th>阵营</th><th>农民</th><th>军队</th><th>人口</th><th>金币</th><th>计划</th><th>状态</th><th>命令</th><th>问题/分</th></tr>
      {rows}
    </table>
    <div class="legend">
      <span class="dot" style="background:{TEAM_COLORS[0]}"></span>Team 0（副官）
      <span class="dot" style="background:{TEAM_COLORS[1]};margin-left:14px"></span>Team 1（敌方人机）
      <span style="margin-left:14px">方块=建筑，小点=农民，大点=战斗单位，黄点=资源点，灰块=不可通行</span>
    </div>
  </div>

  <div class="card">{svg}</div>
</div></body></html>"""


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="RTS AI 演示战报")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--duration", type=float, default=240.0)
    ap.add_argument("--layout", default="open", choices=["open", "chokes", "plain"])
    ap.add_argument("--out", default="reports/demo.html")
    args = ap.parse_args(argv)

    sim, frames, wall, stats = run(args.seed, args.duration, args.layout)
    html = render_html(sim, frames, stats, wall, args.seed)
    out = Path(args.out)
    if not out.is_absolute():
        out = ROOT / out
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")
    print(f"导出：{out}")
    print(
        f"seed={args.seed} 时长={args.duration:.0f}s 墙钟={wall:.1f}s "
        f"速度={args.duration / max(1e-6, wall):.1f}x 实时"
    )
    for t, name in ((0, "副官"), (1, "敌方")):
        s = stats[f"a{t}"]
        print(
            f"  {name}: plan={s.get('plan')} mode={s.get('mode')} "
            f"命令={s.get('commands', {}).get('commands_sent')} "
            f"失败={s.get('commands', {}).get('failures')} "
            f"问题/分={s.get('sanity', {}).get('issues_per_minute')}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# HANDOVER_FINAL — 正式交接包

> 生成时间：2026-10-26
> 交付对象：另一台机器上的开发者 / Agent（**没有任何本次对话的上下文**）
> 配套文档：`AUDIT_REPORT.md`（审计结论）、`PORTING_GUIDE.md`（怎么移植）
> 机读证据：`audit/audit_result.json`、`reports/exam_report.json`

---

## 0. 先读这一页

| 问题 | 答案 |
|---|---|
| 这是什么 | 一个类《魔兽争霸 3》的 **RTS AI 原型**：敌方人机 + 玩家副官，共用一套决策核心 |
| 能跑吗 | 能。`python run_exam.py --jobs 8`，纯标准库，Python 3.10+ |
| 能直接进游戏吗 | **不能。** 这是 Python，你的游戏是 Godot/GDScript |
| 那它有什么用 | 它是**算法规格书 + 验证环境**。移植时照它写 GDScript，并用它的场景定义做验收 |
| 当前状态 | **`NEEDS_REFACTOR_BEFORE_INTEGRATION`**（P0 已全部修复；剩下的是移植工作量 + 3 个协议缺口） |
| 最该先做什么 | 按 `PORTING_GUIDE.md` 移植；`FIX_LOG.md` 记录了每个 P0 的修法与前后实测 |
| 现在的验证成绩 | 46/46 用例、302/302 断言；审计 43 项：**FAIL 0** / WARNING 8 / PASS 33 / N/A 2 |

**如果你只想读三份东西**：
1. `FIX_LOG.md` —— 审计发现的问题**是怎么修的、修完实测如何**；
2. `AUDIT_REPORT.md` §11 —— 当前还需要处理什么（8 个 WARNING 的性质）；
3. `PORTING_GUIDE.md` —— 到 Godot 那边按什么顺序、接哪些接口。

> **重要**：本文件后面记录的是「审计当时」的缺陷清单（§22 的 E1–E10）。
> 那些阻断项**已经修复**，保留在这里是为了让你知道「哪些地方曾经错过、移植时不要再犯」。

---

## 1. 项目架构

```
                ┌──────────────────────────────────────────┐
                │  rtsexam   考试系统（46 用例 / 302 断言） │
                └───────┬──────────────────────┬───────────┘
                        │ 驱动                  │ 驱动
        ┌───────────────▼──────────┐  ┌────────▼────────────────┐
        │  rtsai   AI 核心          │  │  rtsim  Mock 模拟器      │
        │  只依赖 rtscontract       │  │  实现 IGameGateway       │
        └───────────────┬──────────┘  └────────┬────────────────┘
                        │    rtscontract（契约层）│
                        └──────────┬────────────┘
                                   ▼
        Vec2 / Catalog / WorldSnapshot / Command / ControlRegistry / IGameGateway
```

| 包 | 行数 | 职责 | 移植时 |
|---|---|---|---|
| `src/rtscontract` | 1,263 | 纯数据 + 协议。无业务分支 | 字段语义要抄，代码不用 |
| `src/rtsai` | 3,049 | 决策。只读快照，只写命令 | **全部重写** |
| `src/rtsim` | 2,041 | 无渲染、定步长、确定性模拟器 | 不移植 |
| `src/rtsexam` | 1,844 | 用例 + 执行器 + 报告 | 不移植（场景定义可抄） |
| `scripts/` | 525 | 诊断脚本 | 不移植 |

依赖方向是**单向强制**的，有静态用例守着：
`rtsexam → rtsai → rtscontract ← rtsim`，`rtsai` 里出现 `import rtsim/rtsexam/godot` 即判失败。

---

## 2. Python 版本与依赖

```
Python >= 3.10（实测 3.13.12）
依赖：无。纯标准库（json / math / heapq / dataclasses / concurrent.futures）
平台：Windows / Linux / macOS 均可
```

**没有任何第三方包**，没有 `requirements.txt`，没有虚拟环境要求。
这也是它作为"算法实验室"的最大优点：换机器零配置。

---

## 3. 启动方式

```bash
cd rts-ai-framework

# 1) 看有哪些用例
python run_exam.py --list

# 2) 全量考试（8 进程并行，约 2.5 分钟）
python run_exam.py --jobs 8

# 3) 与基线对比（有回归会列出来）
python run_exam.py --jobs 8 --baseline reports/baseline.json

# 4) 随机种子（每轮 6 个新种子）
python run_exam.py --jobs 8 --random

# 5) 单用例 / 单分类
python run_exam.py --case adj_lock_inviolable --seeds 3
python run_exam.py --category economy --category adjutant --seeds 1

# 6) 可视化战报（生成 reports/demo.html）
python run_demo.py --seed 7 --duration 180

# 7) 本次新增：交接前审计套件
python audit/run_audit.py
```

`run_exam.py` 内部会 `sys.path.insert(0, "src")`，不需要设 `PYTHONPATH`。

---

## 4. 测试方式

三层，互不替代：

| 层 | 命令 | 覆盖 | 判定 |
|---|---|---|---|
| **回归考试** | `run_exam.py --jobs 8` | 46 用例 / 302 断言，15 个分类 | 通过率 ≥ 90% 用例、≥ 95% 断言（`config/exam.json`） |
| **基线对比** | `--baseline reports/baseline.json` | 用例级 pass→fail + 指标退化 >5% | `regressions` 为空 |
| **交接审计** | `audit/run_audit.py` | 25 项清单、11 控制权场景、14 故障注入、战术/扩张/撤退、4 档性能 | 见 `audit/AUDIT_SUMMARY.md` |

考试的设计约束（重要）：

1. **禁止针对用例硬编码**：`meta_no_hardcode` 扫描 `src/rtsai/**`，出现用例 id、`seed == N`、
   `import rtsexam`、`random.*`、`time.time()` 即失败。
2. **禁止 AI 依赖模拟器**：`meta_no_game_dependency` 扫描 import。
3. **确定性可复现**：`meta_determinism` 比对两次运行的 SHA1。

---

## 5. 当前测试成绩（实测，2026-10-27 修复后）

| 运行方式 | 用例 | 断言 | 耗时 | 结果 |
|---|---|---|---|---|
| 固定回归种子（7 个，共 128 局） | **46 / 46** | **302 / 302** | 131 s | 与文档一致 |
| 随机种子（6 个，共 128 局） | **46 / 46** | **302 / 302** | 117 s | 通过（修复前为 45/46） |

> 修复前的记录（保留对照）：固定种子 46/46、随机种子 **45/46**（`ret_keeps_core_army`，seed 170953）。

失败明细：

```
case:  ret_keeps_core_army (retreat)
seed:  170953
check: retreats >= 1   →  actual 0
其余： survivors 8 (>=1 通过), losses 2 (<=14 通过)
```

也就是说该局 AI 没撤退但也没亏 —— 是"断言绑定了必须触发撤退"，还是"该地形下撤退阈值确实失效"，
需要单独判定（`AUDIT_REPORT.md` §10.1）。

**审计套件的实测状态分布**（修复前）：共 **43** 项 —— FAIL 10 / WARNING 7 / PASS 24 / NOT_SUPPORTED 2。
修复后：**FAIL 0 / WARNING 8 / PASS 33 / NOT_SUPPORTED 2**（明细见 `FIX_LOG.md` 末尾）。

> **不要引用"46/46 全绿"当作质量结论。** 它只说明"在固定种子池上没有回归"。

---

## 6. 哪些功能是 Mock 已验证的

| 已验证 | 证据 |
|---|---|
| 经济循环：农民补充、采集分配、人口不断档、不囤金 | `econ_*` / `pop_*` / `worker_*` 共 8 例 |
| 生产：军队成型、生产建筑不空转、科技解锁 | `prod_*` 3 例 |
| 兵种克制：对重甲/对空转型、不造无效兵 | `counter_*` 3 例 |
| 防守：小股突袭、前线回防、成建制推进 | `def_*` 3 例 |
| 进攻：推平弱基地、同等规模取胜 | `atk_*` 2 例 |
| 撤退：劣势会撤、保留核心兵力 | `ret_*` 2 例（随机种子下 1 例不稳） |
| 扩张：能开第二片矿、压力下不扩张、靠近资源点 | `exp_*` 3 例 |
| 领土/侦察：控制份额、前出、探索率 | `ter_*` / `fog_*` 5 例 |
| 控制权：锁定不可侵犯、TTL 接管、不打断玩家命令 | `adj_*` 6 例（**但语义有问题，见 §23**） |
| 反愚蠢：不卡单位、问题配额、军队响应、不囤金 | `san_*` 4 例 |
| 框架：确定性、无游戏依赖、无硬编码、性能 | `meta_*` 4 例 |
| 故障恢复：14 项注入中 11 项无损 | `audit/` → `group=fault` |

---

## 7. 哪些功能**没有**真实游戏验证

| 未验证 | 为什么 |
|---|---|
| 真实寻路 / 单位碰撞 / 拥堵 | Mock 里单位可重叠、建筑不挡路 |
| 微操（拉扯、卡位、齐射、风筝） | 无弹道、无前摇、伤害瞬时结算 |
| 战争迷雾的真实实现 | Mock 用半径圆，无遮挡、无高地 |
| 真实地图（大小、地形、路口） | 只有 88×88 / 96×96 程序化地图 |
| 多资源经济 | 只有金币 |
| 建筑学（堵口、塔阵） | Mock 里建筑不挡路，验证不了 |
| 英雄 / 技能 / 物品 / 升级 | 未实现 |
| 野怪 / 中立目标 | 未实现 |
| 联机同步 / 存档读档 | 未实现（连 `reset()` 都没有） |
| 帧率影响 | AI 在独立循环里跑，没和渲染/物理同帧 |
| 1,000 单位实战 | 只在合成场景压测过（§9），没打过完整对局 |

---

## 8. 哪些逻辑必须重新调参

**所有阈值都是按 `config/catalog.json` 的数值 + 88×88 地图校准的。** 换数值/换地图必须重标：

| 参数 | 当前值 | 依赖什么 | 换什么要重标 |
|---|---|---|---|
| `combat.defense_radius` | 17 格 | 地图尺寸、建筑间距 | 换地图尺寸 |
| `combat.attack_power_ratio` | 1.35 | 兵种数值、克制矩阵 | 换数值 |
| `combat.retreat_power_ratio` | 0.72 | 同上 | 同上 |
| `combat.army_gather_ratio` | 0.75 | 军队规模 | 换人口上限 |
| `economy.worker_target_per_base` | 11 | 矿点 `max_workers` | 改矿点容量 |
| `economy.supply_headroom_target` | 6 | 人口上限、建造时长 | 改供给建筑 |
| `expansion.worker_trigger` | 14 | 农民目标数 | 同上 |
| `expansion.site_min_remaining` | 600 | 矿点总量 | 改资源量 |
| `production.counter_weight` 等 | 1.2 / 0.65 / 0.28 | 打分尺度 | 改打分公式时必须一起改 |
| `strategy.rally_offset` | 0.32 | 地图尺寸 | 换地图 |
| `strategy.plan_min_seconds` | 8 | 计划切换频率 | 觉得抖动就调大 |

**重标方法**：改完 → `run_exam.py --seeds 1 --jobs 8` 快速看 → 全量 → `--random` → `--save-baseline`。

---

## 9. 哪些模块未来可能需要移植 / 重写

| 模块 | 移植必要性 | 说明 |
|---|---|---|
| `rtsai/*`（全部） | **必须** | GDScript 重写，约 3,000 行 |
| `rtscontract/*` 的类型 | **必须** | 抄字段，不抄实现 |
| `rtscontract/control.py` | **必须，且要重写** | 换成 Player Intent Ownership（`AUDIT_REPORT.md` §4.3） |
| `rtsai/economy.py` | **必须，且要重构** | 缺第二资源 |
| `rtsai/production.py` | **必须，且要重构** | 缺 supply / build_time（§5） |
| `rtsai/expansion.py` | **必须，且要重构** | 规则 → 效用（§6） |
| `rtsai/combat.py`（撤退部分） | **必须，且要重写** | 需要 `can_reach`（§7） |
| `rtsai/adjutant.py` | **必须，且要重写** | 控制权语义（§4） |
| `rtsai/combatmodel.py` | 可**逐行翻译** | 纯数学，最容易移植 |
| `rtsai/plans.py` | 可**逐行翻译** | 60 行 DSL 求值器 |
| `rtsai/world.py` / `fog.py` / `territory.py` | 可**逐行翻译** | 注意 `MapInfo` 冻结问题 |
| `rtsai/scheduler.py` | 可翻译但要加退避 | 见 §23 P0-1 |
| `rtsim/` `rtsexam/` | **不要移植** | 留在 Python 做算法实验室 |

---

## 10. `IGameGateway` 完整接口协议

### 10.1 方法签名（7 个）

```python
class IGameGateway(Protocol):
    team: int          # 本 AI 所属阵营
    issuer: str        # "adjutant" | "enemy_ai"，AI 用它给命令署名

    def snapshot(self) -> WorldSnapshot: ...
    def issue(self, cmd: Command) -> CommandResult: ...
    def can_place(self, proto_id: str, point: Vec2) -> bool: ...
    def catalog(self) -> Catalog: ...
    def match_info(self) -> Mapping[str, Any]: ...
    def suggest(self, payload: Mapping[str, Any]) -> None: ...
    def stats(self) -> Mapping[str, Any]: ...
```

### 10.2 快照结构

```python
WorldSnapshot:
    tick:int  time:float  dt:float  team:int
    gold:float  supply_used:float  supply_cap:float  supply_max:float
    units:tuple[UnitInfo]        # 己方全部 + 敌方可见
    buildings:tuple[BuildingInfo]
    nodes:tuple[NodeInfo]        # 只含已探索的资源点
    map:MapInfo  fog:FogInfo  player:PlayerInfo
    events:tuple[EventInfo]      # 自上次 snapshot() 以来
    enemy_team:int  game_over:bool  winner:int

UnitInfo:   uid proto team pos hp hp_max order order_target order_point
            order_owner control carrying cd_frac stuck resource_node home since_order
BuildingInfo: bid proto team pos hp hp_max complete progress queue queue_time
            rally builders control on_resource
NodeInfo:   nid pos remaining max_workers workers kind
MapInfo:    width height tile walkable start_points enemy_start
            expansion_sites macro_w macro_h
FogInfo:    explored_ratio visible_ratio macro_explored unknown_enemy_activity
PlayerInfo: selected locked manual granted intents autonomy presence
EventInfo:  tick kind pos subject other proto value team
Intent:     tick kind units target point proto ok
```

### 10.3 命令结构

```python
Command:
    kind:str  issuer:str  team:int
    units:tuple[int]  building:int|None  target:int|None
    point:Vec2|None  proto:str|None  extra:tuple[int]  label:str
```

命令种类（15）：`move / attack / attack_move / hold / stop / harvest / build / assist_build /
train / cancel_train / set_rally / repair / lock / unlock / grant / select`
（`repair` 未实现；`lock/unlock/grant/select` 只允许玩家）

拒绝原因（19）：`invalid / not_owned / locked / player_order_active / target_not_visible /
target_invalid / no_resources / no_supply / supply_blocked / tech_missing / queue_full /
node_full / place_invalid / not_ready / cooldown / busy / team_mismatch`

详见 `docs/02-INTERFACE-PROTOCOL.md`（逐字段说明）。

### 10.4 已知的接口缺口（移植时必须补）

见 `AUDIT_REPORT.md` §3.3：`can_reach`、`Command.order_id`、`UnitInfo.order_id`、4 个事件类型。

---

## 11. 游戏侧**最低**需要提供的数据

| 数据 | 字段 | 不给会怎样 |
|---|---|---|
| 己方单位 | `uid/proto/team/pos/hp/hp_max/order` | AI 无法去重，每 tick 重发 |
| 己方建筑 | `bid/proto/pos/complete/queue` | 无法判断产能、无法训练 |
| 金币 | `gold` | 无法下单 |
| 人口 | `supply_used/cap/max` | 无法补人口，会卡死 |
| 可见敌人 | `uid/proto/pos/hp`（**已按迷雾过滤**） | 不能评估战力 |
| 资源点 | `nid/pos/remaining/max_workers`（已探索的） | 无法分配农民 |
| 地图 | `width/height/walkable/start_points` | 无法选址、无法判断方向 |
| 分矿点 | `pos`（`owner/remaining` 必须过滤） | 无法扩张 |
| 玩家意图 | `PlayerInfo.intents`（最近 16 条） | 副官听不懂玩家 |
| 控制权 | `UnitInfo.control` / `order_owner` | 无法做到"不抢玩家单位" |

**可选但强烈建议**：`order_point`、`since_order`、`stuck`、`queue_time`、`fog.macro_explored`。

---

## 12. 游戏侧**最低**需要提供的命令

| 命令 | AI 用在哪 | 不给会怎样 |
|---|---|---|
| `move` | 侦察、撤退、农民避险 | 部队无法机动 |
| `attack` | 防守、集火 | 无法战斗 |
| `attack_move` | 集结、推进、防守回援 | 主力战术全失效 |
| `hold` | 驻守 | 可选，但缺了少一种姿态 |
| `stop` | 解卡 | 卡住的单位救不回来 |
| `harvest` | 采集 | 经济停摆 |
| `build` | 造人口/兵营/分基地/塔 | 无法发展 |
| `train` | 造农民/兵 | 无法发展 |
| `set_rally` | 集结点 | 新兵会站原地 |
| `lock/unlock/grant` | 玩家控制权 | 副官无法无风险使用 |
| `select` | UI（AI 不用） | 可省 |

---

## 13. 玩家控制权接入方式

**三步**：

1. **注册表放游戏侧**（不是 AI 侧），并支持存档序列化。
2. **玩家命令走唯一入口**：
   ```gdscript
   func player_issue(cmd: Command) -> CommandResult:
       control.on_player_command(cmd.units, tick)   # 先登记
       var r := gateway.issue(cmd)                   # 再执行
       intents.append(Intent.new(tick, cmd.kind, cmd.units, cmd.target, cmd.point, cmd.proto, r.ok))
       return r
   ```
3. **网关二次校验**：`issuer` 是 AI 时，注册表说"不许动"就拒绝，并计入 `control_blocked`。

**状态机**用 `AUDIT_REPORT.md` §4.3 的 Player Intent Ownership，**不要**照抄 TTL=8s。
判"命令是否结束"必须来自游戏（`order == idle` 或订单完成事件），不能靠计时器。

**验收**：`audit/audit_control.py` 的 11 个场景搬到游戏里跑。

---

## 14. 战争迷雾接入方式

1. 每阵营一张 **可见位图**（`PackedByteArray`，长度 = w×h），每次视野变化重算。
   不要用渲染遮罩反推逻辑迷雾。
2. `snapshot()` 构造时用**该阵营**的位图过滤 `units` / `buildings` / `nodes` / `events`。
3. `expansion_sites` 的 `owner` / `has_building` / `remaining` **必须过滤或模糊化** ——
   Python 版在这里泄漏（`AUDIT_REPORT.md` §1 第 22/23 项）。
4. `fog.macro_explored`：把可见位图降采样成 12×12，或按单位视野累加。
5. `enemy_start`、`start_points` 属于静态地图知识，可以无条件给。

---

## 15. 路径系统接入方式

**AI 不寻路。** AI 只发"去哪"，游戏负责怎么去。

但必须补两件事（否则真实游戏会比 Mock 更糟）：

| 要补 | 为什么 | 怎么补 |
|---|---|---|
| **不可达反馈** | AI 现在发完 `move` 就以为会到；目标不可达时会原地卡死并反复发命令（f8：90 秒 324 条） | 加 `EventKind.PATH_FAILED`，或加 `gateway.can_reach(units, point)` |
| **卡住反馈** | `stuck` 现在是模拟器标注的；真实游戏要自己算 | 连续 N 秒位移 < ε 就置 `stuck=True`（建议 N=1.5s，ε=0.15 格） |

**撤退/扩张选址必须用 `can_reach`**，不能只用 `is_walkable`（r1 实测：撤退点落进封闭房间）。

---

## 16. 单位 Catalog 接入方式

最小字段集（`config/catalog.json` 的 `units[]`）：

```json
{"id":"footman","name":"步兵","hp":420,"armor":2,"armor_type":"heavy",
 "speed":3.0,"sight":7,"cost":{"gold":135,"supply":2},"build_time":20,
 "attack":{"damage":13,"range":1.0,"cooldown":1.1,"damage_type":"normal","targets":["ground"]},
 "tags":["melee","frontline","ground"],"flying":false}
```

| 字段 | 必填 | 说明 |
|---|---|---|
| `id` | ✔ | 全局唯一，和游戏内一致 |
| `hp/armor/armor_type` | ✔ | `armor_type` 必须命中 `combat_rules.armor_types` |
| `speed/sight` | ✔ | 格/秒、格 |
| `cost.gold` / `cost.supply` | ✔ | **只有这两种资源**（要加木材得改 `Cost`） |
| `build_time` | ✔ | 秒 |
| `attack.damage_type` | ✔ | 必须命中 `combat_rules.attack_types` |
| `attack.targets` | ✔ | `["ground"]` / `["ground","air"]` |
| `tags` | ✔ | AI 只认标签，不认 id |
| `requires` | 按需 | 建筑前置（科技） |
| `harvest` | 农民专用 | `carry / gather_time / resource` |

**生成方式**：写个 EditorScript 从你的单位资源批量导出这份 JSON，保证只维护一份数值。

---

## 17. 建筑 Catalog 接入方式

```json
{"id":"barracks","hp":900,"armor":3,"armor_type":"fortified","sight":7,
 "cost":{"gold":200},"build_time":32,"footprint":[3,3],"supply_provided":0,
 "built_by":["worker"],"produce":["footman","archer"],"dropoff":false,
 "requires":[],"tags":["production","ground"]}
```

AI 靠这 5 个字段**自动**识别建筑用途，不需要你告诉它"这是兵营"：

| 字段 | AI 的解读 |
|---|---|
| `produce` 非空 | 这是生产建筑（用来造兵） |
| `dropoff=true` | 这是资源回收点 / 主基地（决定分矿选址） |
| `supply_provided>0` | 这是人口建筑（AI 会自动补） |
| `attack` 非空 + `is_building` | 这是防御建筑（受袭时会造） |
| `built_by` | 谁能造它 |

`requires` 构成科技树；AI 的 `tech_satisfied` 只检查"前置建筑是否已完工"。

---

## 18. 新兵种加入流程

**情况 A：有现成角色标签（推荐）**

1. 在 `catalog.json` 的 `units[]` 加一条；
2. 确保 `tags` 里至少有一个能命中 `ai_profile.production.roles[].tags`
   （当前是 `frontline` / `ranged` / `siege`）；
3. 把它的 id 加进对应生产建筑的 `produce[]`；
4. 重跑考试，必要时重标阈值。

**不需要改 AI 代码。**

**情况 B：新角色（比如"治疗兵""侦测兵"）**

1. 上面 4 步；
2. 在 `ai_profile.production.roles` 加一条 `{id, tags, share}`；
3. 如果新角色有**特殊能力**（治疗/驱散/侦测），`production.choose` 里没有对应的能力需求项 →
   需要改代码（`AUDIT_REPORT.md` §5.2）。

**情况 C：第二种农民**

**当前会静默失效**：`economy._worker_proto()` 恒取 `workers()[0]`（x3 实测）。
必须先把"选哪种农民"变成配置项。

---

## 19. 新建筑加入流程

1. `catalog.json` 的 `buildings[]` 加一条；
2. 填 `built_by`（谁能造）、`produce`（能造什么）、`dropoff`（是否回收点）、
   `supply_provided`（提供多少人口）、`footprint`（占地）；
3. 如果有前置，填 `requires`；
4. 重跑考试。

**注意**：
- 人口建筑：AI 自动选**最便宜**的（`_supply_proto` 按 `(gold, build_time)` 排序）；
- 生产建筑：AI 先铺最便宜的，够 2 个后再开新类型（`_build_structures`）；
- 主基地：AI 选**第一个** `dropoff=true` 且 `built_by` 非空的建筑（`_hall_proto`）——
  如果你有两种基地（主堡/分堡），这里会选错，需要改配置或代码。

---

## 20. 未来英雄系统扩展点

当前 `Proto` **没有** `abilities / hero / level` 字段，`Cmd` 里没有 `cast / learn`。
要加英雄，需要动这 6 处：

| 层 | 要加什么 |
|---|---|
| `catalog.Proto` | `hero: bool`、`abilities: tuple[str]`、`max_level`、`xp_curve` |
| `snapshot.UnitInfo` | `level`、`xp`、`abilities_ready: tuple[str]`、`items` |
| `snapshot` | `heroes: tuple[HeroInfo]`（或直接扩展 UnitInfo） |
| `commands.Cmd` | `cast(target, ability)`、`learn(ability)`、`use_item` |
| `rtsai` | 新增 `heroes.py`：技能期望值、等级曲线、保命优先 |
| `combatmodel` | 技能伤害并入 `dps` 期望；`power()` 增加"技能价值"项 |

**设计建议**：英雄不要进 `CompositionSolver`（它不是"造什么兵"的问题），
单独做一个 `HeroManager`，由 `Posture` 给权重。否则会污染现有的兵种打分。

`docs/01-ARCHITECTURE.md` §7 有预留位置说明。

---

## 21. 未来中立野怪扩展点

当前 `TEAM_NEUTRAL = 2` 常量存在，但**没有任何实现**：`snapshot.enemy_team = 1-team`，
`World.enemy_units` 把所有非己方都当敌人。

要加野怪，需要动这 5 处：

| 层 | 要加什么 |
|---|---|
| `snapshot` | `creep_camps: tuple[CampInfo]`（位置、等级、掉落、是否已清） |
| `World` | `creep_camps` 记忆 + 打野收益估计（经验/宝物/时间成本） |
| `plans.json` | 新增 `creep_farm` 计划（条件：有英雄、野怪等级 ≤ 英雄等级、地图安全） |
| `combat` | 目标类型区分：野怪不触发"回防"；打野要控制损耗 |
| `territory` | 野怪点算"中立控制区"，不算敌方领土 |

**关键**：`enemy_units` 的语义是"非我即敌"，加中立阵营时必须改成显式三态，
否则野怪会触发 `base_threat`、被算进 `army_ratio`，AI 会以为敌人打过来了。

---

## 22. 当前已知限制

### 22.1 模拟器简化（影响 AI 在真实游戏的表现）

| # | 简化 | 影响 |
|---|---|---|
| S1 | 建筑不阻挡寻路 | 堵口/建筑学无效；单位会穿建筑 |
| S2 | 无弹道 / 无前摇 / 伤害瞬结 | 齐射、走位、卡位的价值被低估 |
| S3 | **只有一种资源** | 运营压力偏低，AI 容易"不缺钱" |
| S4 | 无地形高低差 | 高地优势不存在 |
| S5 | 无维修 / 无升级 | `Cmd.REPAIR` 返回"未实现" |
| S6 | 单位可重叠 | 大军团会叠在一起，战力略高估 |
| S7 | 寻路有全局预算（64 次/tick） | 超预算的单位本 tick 不动 |
| S8 | 队列上限固定 | 与真实游戏可能不同 |

### 22.2 AI 能力边界

| # | 限制 |
|---|---|
| A1 | 没有长期规划（贪心 + 8 秒滞回，不做多步推演） |
| A2 | 兵种构成逐单位贪心，小样本会抖动 |
| A3 | 没有阵型（一字长蛇） |
| A4 | 撤退只是"少送一点"，没有殿后/减速/地形 |
| A5 | 侦察只看探索度，不针对"敌方是否开矿/升本" |
| A6 | 不会堵口/塔阵 |
| A7 | 不预测对手（只反应已看到的） |
| A8 | 没有微操技巧 |

### 22.3 工程限制（本次审计新增）

| # | 限制 | 证据 | 状态 |
|---|---|---|---|
| E1 | **命令风暴**：到达点后每 tick 重发 | s11：3.96 条/秒/单位 | ✅ 已修（0.00） |
| E2 | 控制权是 TTL 模型，长命令 0 宽限 | s1/s6/s10 | ✅ 已修（命令组生命周期） |
| E3 | 巡逻/队列**无法表达** | s2/s4 | ⬜ 未做（协议缺口） |
| E4 | `MapInfo` 永久缓存，分矿归属不刷新 | x4 | ✅ 已修 |
| E5 | 分矿 `owner/remaining` 泄漏迷雾 | x2 | ✅ 已修 |
| E6 | 12 个配置键是死的 | 静态扫描 | ⬜ 未做（P1） |
| E7 | 8 种事件 AI 一个都没读 | `snapshot.events` 引用次数 0 | ⬜ 未做（P1） |
| E8 | 1,020 单位时 239.8 ms/次，超 200 ms 预算 | 性能实测 | ✅ 已修（151.9 ms） |
| E9 | 无 `reset()` / 无存档序列化 | 代码检查 | ⬜ 未做（P1） |
| E10 | 随机种子下 45/46 | 全量实测 | ✅ 已修（46/46） |

---

## 23. 当前所有 WARNING / FAIL

> 完整机器可读版本：`audit/audit_result.json`；人读摘要：`audit/AUDIT_SUMMARY.md`。

### 23.1 当前状态（修复后，最终实测）

共 **43** 项：**FAIL 0** / WARNING 8 / PASS 33 / NOT_SUPPORTED 2

| 状态 | 项 |
|---|---|
| WARNING（8） | `s8_partial_formation`、`f5_nodes_depleted`、`r2_surrounded`、`r3_retreat_away_from_home`、`x1_multi_manager_conflict`、`x3_second_worker_ambiguous`、`torture_adjutant`、`perf_1000` |
| NOT_SUPPORTED（2） | `s2_patrol`（协议无 PATROL 命令）、`s4_shift_queue`（无命令队列语义） |

> 8 个 WARNING 全部是「已知取舍」或「只能真机验证」，逐条解释见 `FIX_LOG.md` 末尾。
> 其中 `perf_1000`：1,017 单位 151.9 ms/次，在 200 ms 预算内，但超过保守的半预算线。

### 23.2 审计当时的 FAIL 清单（保留对照，均已于 2026-10-27 修复）

共 **43** 项：FAIL 10 / WARNING 7 / PASS 24 / NOT_SUPPORTED 2

| 组 | 用例 | 状态 | 说明 |
|---|---|---|---|
| control | `s11_destination_command_loop` | **FAIL** | 部队抵达攻击点后仍在以 59.4 条/秒（每单位 3.96 条/秒）重发 ['attack_move']：到达→idle→重发的循环没有任何「已在目标点」判定。 |
| control | `s1_long_move_30s` | **FAIL** | 7/8 个单位还没等整条命令结束就被 AI 接管；最后一个单位到达后 0.0s AI 重新下令。 |
| control | `s6_stop_not_honoured` | **FAIL** | STOP 之后 order 变成 idle，不再受「玩家订单执行中」保护；只剩 TTL 兜底，约 8 秒后 AI 就把人拉回集结点。 |
| expansion | `e1_massing_army_ignored` | **FAIL** | 12 个重甲在 30 格外集结（base_threat=0.0，defense_radius=17），扩张数量与控制组完全一致（3 vs 3）→ 「是否扩张」不看战略压力。 |
| expansion | `e3_danger_quantized` | **FAIL** | 4 个可见敌人距矿点 ≤5 格，但 danger=0.0：危险度按 12×12 宏格（7.3 格/格）**单格取值**，敌人落在相邻宏格就完全不计；3×3 邻域求和才 = 6.63。 |
| expansion | `e4_no_choke_value` | **FAIL** | _pick_site 只有「余量 / 距离 / danger」三项；没有可通行性、路口、路径长度、高地、防守成本。低资源但高战略价值的点会被 site_min_remaining=600 直接排除。 |
| fault | `f10_units_frozen` | **FAIL** | 单位永久无法移动时 sanity 反复触发：22 个 stuck episode / 40 秒，命令率 4.42/s 不收敛（STOP→MOVE 抖动）。 |
| fault | `f8_path_fail_long` | **FAIL** | 路径永久失败时 AI 不会收敛：90 秒内 324 条命令 / 437 条 STOP，STOP→idle→MOVE→stuck 形成自持循环；协议里没有「路径不可达」这一状态可供退出。 |
| performance | `perf_100` | **FAIL** | AI 决策 9.43 ms + 网关处理命令 30.87 ms = 40.3 ms/次（5.6 条命令/次）；快照 0.49 ms；热点 combat 34.79 ms；命令预算耗尽，本段被丢弃 16 条 |
| performance | `perf_1000` | **FAIL** | AI 决策 142.58 ms + 网关处理命令 97.2 ms = 239.78 ms/次（47.9 条命令/次）；快照 3.81 ms；热点 combat 208.4 ms；命令预算耗尽，本段被丢弃 9350 条 |
| performance | `perf_300` | **FAIL** | AI 决策 30.9 ms + 网关处理命令 78.14 ms = 109.04 ms/次（25.0 条命令/次）；快照 1.49 ms；热点 combat 97.32 ms；命令预算耗尽，本段被丢弃 220 条 |
| performance | `perf_500` | **FAIL** | AI 决策 51.67 ms + 网关处理命令 75.71 ms = 127.38 ms/次（35.1 条命令/次）；快照 1.68 ms；热点 combat 110.8 ms；命令预算耗尽，本段被丢弃 2784 条 |
| production | `p1_cost_dimensions` | **FAIL** | supply：3 人口与 10 人口同分（只有一个 >=3 的固定 -0.05，与真实人口占用无关）；build_time：15 秒与 60 秒同分（训练时长完全不进打分）；gold：便宜者恒胜 → 「每金战力」是主导项 |
| retreat | `r1_retreat_into_dead_end` | **FAIL** | 撤退点只做 is_walkable 判定，不查可达性：本次撤退点落进封闭房间（可走、不可达），单位会朝墙里走并被判 stuck。 |
| structure | `x2_fog_leak_site_owner` | **FAIL** | expansion_sites 的 owner / has_building 由全图建筑表直接算出，没有做迷雾过滤：敌方在从未探索的分矿造基地，AI 也能直接读到。remaining 同样是真实余量（矿量透视）。 |
| structure | `x4_mapinfo_frozen` | **FAIL** | Sim.map_info() 只构建一次并永久缓存：分矿 owner / has_building / remaining 在整局中不再刷新。AI 的「这个矿点已经被占了」永远基于第 0 秒的事实。 |
| torture | `torture_adjutant` | **FAIL** | 失败：no_command_storm(steady=3.57 cmd/unit/s)；no_duplicate_orders(duplicates=44) |
| control | `s2_patrol` | **NOT_SUPPORTED** | OrderKind 声明了 patrol，但 Cmd 没有 PATROL、Sim 也没有处理器；玩家/AI 都无法下达巡逻命令，控制权语义里的 patrol 分支是死代码。 |
| control | `s4_shift_queue` | **NOT_SUPPORTED** | Command 没有队列语义：第二条命令直接覆盖第一条（order_point 变成 p2），快照也只暴露单个 order/order_point，无法表达「正在执行第 2/3 条」。 |
| control | `s10_short_move_grace` | **WARNING** | 短命令（4 秒）享受约 6 秒宽限，长命令（30 秒）宽限为 0 —— 宽限期取决于「命令到达时 TTL 还剩多少」，不是玩家意图是否结束。 |
| control | `s3_target_dies_mid_order` | **WARNING** | 玩家攻击目标提前死亡 → 单位 idle → AI 立刻回收（无空闲宽限期） |
| control | `s8_partial_formation` | **WARNING** | 5/12（41%）达到 _is_army_scale 门槛 → 玩家这一下移动被当成全军级指令：副官把 rally 改到玩家点击处，剩下 7 个兵被一起拽过去；而 5 个被移动的兵到达后同样被立刻回收。 |
| control | `s9_target_invalid` | **WARNING** | 目标失效后单位变 idle，AI 在 TTL 剩余时间内不动，TTL 一过立刻接管；「已失效」与「正常执行完」两种情况被同等对待。 |
| expansion | `e2_no_opportunistic_expand` | **WARNING** | 60 秒时 1074.0 金 + 30 兵 + 无敌情，仍未扩张：「是否扩张」由 worker 数/矿点饱和决定，军事优势与安全窗口不参与。 |
| fault | `f5_nodes_depleted` | **WARNING** | 资源枯竭后农民全部 idle，AI 没有「无矿可采」的处置策略 |
| retreat | `r2_surrounded` | **WARNING** | 四面包围时「远离质心」向量≈0，退化为「朝基地」的直线方向 —— 等于从敌人中间穿过去；没有突破点 / 薄弱侧评估。 |
| retreat | `r3_retreat_away_from_home` | **WARNING** | 敌人位于「部队—基地」连线上时，远离威胁向量把部队推得离基地更远；算法完全不考虑友方控制区 / 防御建筑 / 基地方向。 |
| structure | `x1_multi_manager_conflict` | **WARNING** | 180 秒内 9 次「同一 tick 同一单位被下 ≥2 条命令」（占 AI 命令 0.30%）；执行顺序 economy→production→expansion→scout→combat，后写的覆盖先写的（例如侦察会覆盖刚落下的建造指令）。 |
| structure | `x3_second_worker_ambiguous` | **WARNING** | economy._worker_proto() 与 world.buildable_protos() 都取 workers()[0]（Cookbook 插入序）；新增第二种农民后，AI 仍然只造第一种，没有任何「按场景选农民」的配置入口。 |
| control | `s5_hold_forever` | **PASS** | HOLD 属于 ACTIVE_ORDER_KINDS，玩家驻守会被无限期尊重 |
| control | `s7_permanent_lock` | **PASS** | PLAYER_LOCKED 无期限，100 秒内零条 AI 命令 |
| fault | `f11_stale_snapshot` | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| fault | `f12_state_jitter` | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| fault | `f13_dead_ids` | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| fault | `f14_player_takeover` | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| fault | `f1_target_dies_before_issue` | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| fault | `f2_building_dies` | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| fault | `f3_production_cancelled` | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| fault | `f4_construction_cancelled` | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| fault | `f6_enemies_vanish` | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| fault | `f7_path_fail` | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| fault | `f9_move_rejected` | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| production | `p2_score_terms` | **PASS** | 打分确有 7 个因子，不是单变量；但主导项是「每金战力」，且 supply / build_time / 科技成本 / 射程 / 机动性 / 攻城 / 辅助能力均未进入打分。 |

---

## 24. 真实游戏首次集成步骤

**顺序不能变。** 每一步不通过，不要进下一步。

| 步 | 做什么 | 通过标准 | 失败回滚到 |
|---|---|---|---|
| 0 | ~~在 Python 侧修 P0~~ **已完成**（`FIX_LOG.md`）：重跑 `run_exam.py --jobs 8` + `--random` + `audit/run_audit.py` | **46/46、302/302（两种种子）；审计 FAIL 0** | — |
| 1 | 写 `snapshot_dump.gd`，导出 3 分钟对局的快照 JSON | 字段齐全、无 null | — |
| 2 | 在 GDScript 里实现 `Catalog` + `WorldSnapshot` + `Command` 类型 | 能和 Python 的 JSON 互相读通 | 步 1 |
| 3 | 实现 `snapshot()`（含迷雾过滤） | 敌方可见数 == 实际可见数 | 步 1 |
| 4 | 实现 `issue()` 的 8 步校验 + `stats()` | 构造 10 种非法命令，reason 全对 | 步 3 |
| 5 | 移植 `world/fog/territory/director/plans` | 只读运行 3 分钟，指标与游戏一致 | 步 4 |
| 6 | 移植 `economy` + `production` + `scheduler`（**只在沙盒**，关闭军队） | 5 分钟不卡人口、不抢玩家农民 | 步 5 |
| 7 | 移植 `combat`（**先只防守**） | 小股骚扰能守住 | 步 6 |
| 8 | 开进攻 + 撤退 | 三场景各 3 次，行为合理 | 步 7 |
| 9 | 移植 `expansion` | 分矿选址合理、不在敌方驻军点上开矿 | 步 8 |
| 10 | 接 `ControlRegistry`（Player Intent Ownership）+ 副官 | 11 个控制权场景全过 | 步 9 |
| 11 | 跑"玩家折磨副官"脚本 | 8 项检查全过（`PORTING_GUIDE.md` §13） | 步 10 |

**每一步都要能单独回滚。** 建议用 feature flag 控制"AI 是否可发命令"。

---

## 25. 真实游戏首轮验收测试

### 25.1 只读关（最重要）

| 指标 | 通过标准 |
|---|---|
| 己方单位数 | 与游戏完全一致，连续 3 分钟 |
| 农民数 / 建筑数 | 完全一致 |
| 金币 / 人口上限 / 人口占用 | 完全一致 |
| 敌方可见单位数 | 完全一致 |
| 敌方"记忆中的建筑" | ≥ 当前可见数（允许更多） |
| `army_ratio` | 趋势一致（不要求数值相同） |
| 快照耗时 | < 8ms @ 1,000 单位 |
| AI 决策耗时 | < 100ms @ 1,000 单位 |

### 25.2 运营关

- 连续 5 分钟 `supply_block` 事件 = 0
- 农民闲置率 < 10%
- 人口 10 → 40 不卡壳
- AI 不抢玩家手动拉走的农民（`control_blocked = 0`）
- 不出现"满人口还在造人口"

### 25.3 军队关

| 场景 | 通过标准 |
|---|---|
| 小股骚扰（3 兵打基地） | 主基地存活、击杀 ≥ 2、农民损失 ≤ 3 |
| 成建制推进（5 兵） | 主基地存活、击杀 ≥ 3 |
| 明显劣势（14 兵打 6 兵） | 触发撤退 ≥ 1 次、存活 ≥ 1 |
| 同等规模 | 交换比 ≥ 1:1（含克制） |

### 25.4 扩张关

- 能开出第二片矿并投入使用
- 不在敌方可见驻军点上开矿（`danger > 0` 的点应避开）
- 敌方在迷雾中占了矿 → AI 不应"知道"（`owner` 不泄漏）

### 25.5 副官关（11 个场景）

直接复用 `audit/audit_control.py` 的 11 个场景，期望结果：

| 场景 | 期望 |
|---|---|
| s1 长距离移动 | 行军期间 0 条 AI 命令；**整组到达后** ≥ 5 秒宽限 |
| s2 巡逻 | 应该能下达并被执行（需要补 `Cmd.PATROL`） |
| s3 目标中途死亡 | 宽限 ≥ 5 秒 |
| s4 Shift 队列 | 应该能表达并按序执行（需要补 `Command.queue`） |
| s5 驻守 | 60 秒 0 条 AI 命令 |
| s6 Stop | 30 秒内 0 条 AI 命令 |
| s7 永久锁定 | 100 秒 0 条 AI 命令 |
| s8 部分编队 | 不应把其余单位一起拽走 |
| s9 目标立即失效 | 宽限 ≥ 5 秒 |
| s10 短命令 | 宽限 ≥ 5 秒 |
| s11 到达后 | **≤ 0.2 条/秒/单位** |

### 25.6 折磨关

按 `PORTING_GUIDE.md` §13 的 11 步脚本执行，8 项检查全部通过。

---

## 附录 A：文件清单

```
rts-ai-framework/
├── AUDIT_REPORT.md          ← 审计结论（先读这个）
├── HANDOVER_FINAL.md        ← 本文件
├── PORTING_GUIDE.md         ← 怎么移植（Godot/GDScript）
├── README.md
├── run_exam.py / run_demo.py
├── src/
│   ├── rtscontract/         契约层（9 文件 / 1,263 行）
│   ├── rtsai/               AI 核心（19 文件 / 3,049 行）
│   ├── rtsim/               Mock 模拟器（7 文件 / 2,041 行）
│   └── rtsexam/             考试系统（13 文件 / 1,844 行）
├── config/                  catalog / ai_profile / plans / exam
├── docs/                    01~08（架构/协议/接入/待办/已知问题/交接/测试/优化）
├── reports/                 exam_report.md/json、baseline.json、demo.html
├── scripts/                 诊断脚本
└── audit/                   ← 本次新增
    ├── run_audit.py         入口
    ├── audit_control.py     控制权 11 场景
    ├── audit_faults.py      故障注入 14 项
    ├── audit_tactics.py     生产/扩张/撤退/结构 13 项
    ├── audit_perf.py        性能 4 档
    ├── audit_static.py      静态扫描
    ├── audit_result.json    机读全量结果
    └── AUDIT_SUMMARY.md     自动摘要
```

## 附录 B：一句话交接

> 把这套东西当成**一份写得很细的 AI 设计稿 + 一套能跑的验证环境**，
> 而不是一段可以直接拷贝进游戏的代码。
> 6 个 P0 已经修完并验证（`FIX_LOG.md`）；现在按 `PORTING_GUIDE.md` 翻译成 GDScript，最后按五关验收。

#!/usr/bin/env python
"""RTS AI 自动化考试入口。

示例
----
::

    python run_exam.py --list
    python run_exam.py --jobs 8                     # 全量（回归 + 随机种子）
    python run_exam.py --category economy --seeds 1
    python run_exam.py --case adj_lock_inviolable --seeds 2
    python run_exam.py --baseline reports/exam_report.json
    python run_exam.py --save-baseline             # 运行并把结果写成新基线
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from rtsexam.case import CATEGORIES, REGISTRY  # noqa: E402
from rtsexam.report import write_reports  # noqa: E402
from rtsexam.runner import ExamRunner, compare_baseline  # noqa: E402


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="RTS AI 自动化考试")
    ap.add_argument("--list", action="store_true", help="列出所有用例")
    ap.add_argument("--case", action="append", default=None, help="只跑指定用例（可重复）")
    ap.add_argument("--category", action="append", default=None, help="只跑指定分类（可重复）")
    ap.add_argument("--seeds", type=int, default=None, help="覆盖每个用例的种子数")
    ap.add_argument("--seed", action="append", type=int, default=None, help="显式指定种子（可重复）")
    ap.add_argument("--random", action="store_true", help="使用随机种子基准")
    ap.add_argument("--jobs", type=int, default=1, help="并行进程数（-1 = CPU 数量）")
    ap.add_argument("--out", default="reports", help="报告输出目录")
    ap.add_argument("--baseline", default=None, help="与基线 JSON 对比")
    ap.add_argument("--save-baseline", action="store_true", help="把本次结果保存为基线")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args(argv)

    import rtsexam.cases  # noqa: F401

    if args.list:
        print(f"{'用例':44s} {'分类':12s} 种子  说明")
        for cid in sorted(REGISTRY):
            spec = REGISTRY[cid]
            print(f"{cid:44s} {spec.category:12s} {spec.seeds:<4d} {spec.desc}")
        print(f"\n共 {len(REGISTRY)} 个用例，{len(set(s.category for s in REGISTRY.values()))} 个分类")
        return 0

    if args.seeds:
        for spec in REGISTRY.values():
            spec.seeds = min(spec.seeds, args.seeds)

    cfg = ExamRunner().cfg
    if args.seeds:
        cfg["random_seeds"] = max(1, args.seeds)
    runner = ExamRunner(cfg)

    jobs = args.jobs
    if jobs < 0:
        jobs = max(1, (os.cpu_count() or 4))

    print(f"开始考试：{len(args.case) if args.case else '全部'} 用例 / jobs={jobs}", flush=True)
    report = runner.run(
        case_ids=args.case,
        categories=args.category,
        jobs=jobs,
        randomize=args.random,
        seeds_override=args.seed,
        progress=not args.quiet,
    )

    out_dir = Path(args.out)
    if not out_dir.is_absolute():
        out_dir = ROOT / out_dir

    baseline_obj = None
    baseline_path = Path(args.baseline) if args.baseline else None
    if baseline_path is not None and baseline_path.is_file():
        baseline_obj = compare_baseline(report.as_dict(), json.loads(baseline_path.read_text(encoding="utf-8")))

    md, js = write_reports(report.as_dict(), out_dir, baseline_obj)
    if args.save_baseline:
        (out_dir / "baseline.json").write_text(
            json.dumps(report.as_dict(), ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(f"基线已保存: {out_dir / 'baseline.json'}")

    s = report.summary
    print("")
    print(f"用例通过：{s['cases_passed']}/{s['cases']} ({s['case_pass_rate'] * 100:.1f}%)")
    print(f"断言通过：{s['checks_passed']}/{s['checks']} ({s['check_pass_rate'] * 100:.1f}%)")
    print(f"耗时：{s['elapsed_sec']}s")
    fails = [c for c in report.cases if not c["passed"]]
    if fails:
        print("失败用例：")
        for c in fails:
            bad = [ck["name"] for ck in c["checks"] if not ck["ok"]]
            print(f"  - {c['case_id']} ({c['category']}) -> {', '.join(bad[:5])}")
    if baseline_obj is not None:
        print(
            "回归对比：",
            "OK" if baseline_obj["ok"] else f"{len(baseline_obj['regressions'])} 项回归",
            f"(指标对比={'开' if baseline_obj.get('metric_compared') else '关（种子池不同）'})",
        )
    print(f"报告：{md}")
    print(f"数据：{js}")

    thresholds = cfg.get("pass_thresholds", {})
    ok = (
        s["case_pass_rate"] >= float(thresholds.get("case_pass_rate", 0.9))
        and s["check_pass_rate"] >= float(thresholds.get("check_pass_rate", 0.95))
        and (baseline_obj is None or baseline_obj["ok"])
    )
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())

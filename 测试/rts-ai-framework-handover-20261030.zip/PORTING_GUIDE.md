# PORTING GUIDE — 把 `rts-ai-framework` 接到真实 RTS（Godot 4.7 / GDScript）

> 读者假设：你没有读过本项目任何一次对话，只拿到这个文件夹。
> 目标：读完之后，你能独立判断**要不要接、怎么接、接完怎么验**，不需要再问原作者。

---

## 0. 先确认一件事：目标引擎

本指南按 **Godot 4.7 + GDScript（SVC 架构，模拟核心在 `模拟核心/`）** 写。

如果你的项目其实是 Unity/C#、Unreal/C++ 或自研 C++，请只替换第 3 节的语言与第 5 节的数据结构映射，
其余所有结论（网关契约、控制权、五关验收、移植顺序）**完全不变**。

如果目标确实是 Godot，那么有一个结论必须先说清楚：

> **`src/` 下 8,978 行 Python 不能"塞进" Godot 运行。**
> 它不是"正式 AI"，而是"非常完整的 AI 原型 + 一套验证环境"。
> 正式集成 = 把 `rtsai` 的算法**重写**为 GDScript，同时把 `rtscontract` 的数据结构映射成 Godot 类型。

---

## 1. 你拿到了什么 / 没拿到什么

| 拿到 | 说明 |
|---|---|
| `src/rtscontract/` | AI 与游戏的唯一契约（快照、命令、控制权、原型表）。**这是最有价值的部分**，可以当成需求规格直接抄。 |
| `src/rtsai/` | AI 决策核心，约 3,000 行。只依赖契约层，不 import 模拟器（有静态用例强制）。 |
| `src/rtsim/` | Mock 模拟器，约 2,000 行。**不进游戏**，只用于离线回归。 |
| `src/rtsexam/` | 46 个用例 / 302 条断言的自动考试。**不进游戏**，但可以当"行为基线"。 |
| `config/*.json` | 原型表、AI 参数、战略计划 DSL。**可原样复用**（改成你的数值）。 |
| `audit/` | 交接前审计套件（本次新增）。含 25 项清单取证、11 类控制权场景、14 项故障注入、性能曲线。 |

| 没拿到 | 影响 |
|---|---|
| 真实游戏适配器 | 需要你写（第 6 节，约 400–700 行 GDScript）。 |
| 真实数值验证 | 所有阈值都是按 Mock 数值校准的，换数值必须重标。 |
| 英雄 / 技能 / 野怪 / 升级 | 只有扩展点，没有实现。 |
| 微操（拉扯/卡位/阵型） | Mock 无碰撞、无弹道，**这部分从未验证过**。 |

---

## 2. 三条路线，先选一条

| 路线 | 做法 | 适合 | 代价 |
|---|---|---|---|
| **A. GDScript 重写（推荐）** | 把 `rtsai` 逐模块翻译成 GDScript，跑在游戏进程内 | 单机 / 联机 / 手机 / 主机全都要发 | 前期 3,000 行翻译 + 逐关验证；之后零运行时开销 |
| B. Python 子进程（sidecar） | 游戏通过 socket/共享内存把快照发给 Python，收回命令 | 只想快速试玩、PC only | 打包、延迟、存档同步、崩溃恢复、联机同步、反作弊全部要额外处理；Godot 侧仍需写序列化层 |
| C. 先只在编辑器里跑 | 用 Godot 导出快照 JSON，Python 离线算，人工回放 | 调参 / 研究 | 不能实时 |

**给这个项目的建议：A，但分两步走。**

```
第一步（现在，仍在本仓库）：先在 Python 里修掉 6 个 P0 缺陷（见 AUDIT_REPORT 第 11 节）
第二步（换机器后）：再按本指南翻译成 GDScript
```

理由很直接：把已知有缺陷的逻辑翻译一遍，等于把缺陷复制一份，还要在两处同时修。
Python 里改一行、跑 2 分钟考试就能验证；GDScript 里改一行、要开游戏、摆场景、打 10 分钟。

**明确不推荐 B**：Godot 4.x 没有官方 Python 运行时；`godot-python` 这类 GDExtension 在 4.x 上是实验状态。
即便跑通，你也要自己解决：Python 崩溃不能让游戏崩、存档要同时存两份状态、联机时两端 Python 版本必须一致、
导出模板要带解释器。这些成本远高于 3,000 行翻译。

---

## 3. 移植顺序（7 个里程碑，每个都能独立验收）

> 原则：**先只读，后写入；先静态，后动态；先单人，后联机。**
> 任何一个里程碑不通过，不要进入下一个。

### M0 契约落地（不接 AI）

1. 在 `模拟核心/` 下新建 `ai/contract/`：`vec2.gd`（直接用 `Vector2`）、`snapshot.gd`、`command.gd`、`catalog.gd`、`enums.gd`。
2. 用 `class_name` + `@export` 定义，全部是 `RefCounted`（可变）或 `Resource`（只读配置）。
3. 写一个 `snapshot_dump.gd`：把当前对局状态导出成 `WorldSnapshot` 并 `print`/存 JSON。

**验收**：导出 3 分钟对局的快照，字段齐全率 100%，无 `null` 崩溃；`snapshot.units` 里敌方单位数 == 你实际能看见的敌方单位数。

### M1 只读镜像（AI 跑起来但不发命令）

1. 翻译 `world.gd`（信念状态聚合）、`fog.gd`、`territory.gd`。
2. 翻译 `director.gd` + `plans.gd`，读 `config/plans.json`。
3. `issue()` 直接 `return CommandResult.reject("read_only")`，并把每次想发的命令写进日志。

**验收（这是最重要的一关）**：连续 3 分钟，每 200ms 打印一次 AI 的 `metrics`，
与游戏自身统计逐项对齐：

| 指标 | 允许误差 |
|---|---|
| 我的单位数 / 农民数 | 0 |
| 我的建筑数（含在建） | 0 |
| 金币 / 人口上限 / 人口占用 | 0 |
| 敌方可见单位数 | 0 |
| 敌方"记忆中的建筑"数 | ≥ 当前可见数（允许更多，因为含记忆） |
| `army_ratio` | 只做趋势检查（同向变化） |

**这一步错了，后面全部没有意义。** 常见错因见第 12 节。

### M2 命令通道（只发"无害命令"）

1. 翻译 `scheduler.gd`（去重 + 每 tick 预算 + 失败统计）。
2. 实现 `issue()` 的完整校验链（第 11 节）。
3. 只开放 `set_rally`（集结点）这一种命令，验证：接受、拒绝原因、`stats()` 计数。

**验收**：构造 10 种非法命令（别人的兵、迷雾里的目标、钱不够、人口不够、位置非法…），
每种都被正确拒绝且 `reason` 与契约一致；AI 侧 `failures` 计数与游戏侧 `rejected` 完全对得上。

### M3 经济（五关里的"第二关"）

开放：`harvest` / `train`(农民) / `build`(人口、生产建筑) / `set_rally`。
禁止：一切军队命令。

**验收**：连续 5 分钟，`supply_block` 事件为 0；农民闲置率 < 10%；人口从 10 涨到 40 不卡壳；
AI 不抢玩家手动拉走的农民（`control_blocked` 必须为 0）。

### M4 战斗

开放：`move` / `attack` / `attack_move` / `hold`。
**验收**：三场固定场景（小股骚扰、成建制推进、明显劣势）各跑 3 次，
`retreats` / `kills` / `losses` 落在合理区间；**并且**至少一次"撤退后没有被追杀到全灭"。

### M5 扩张 + 副官全开

开放：`build`(分基地) + 玩家控制权 + `suggest`。
**验收**：跑"玩家故意折磨副官"脚本（见第 13 节），
`control_blocked == 0`、无重复命令风暴、玩家拉走的单位不会被拉回。

---

## 4. 文件映射表

| Python | 目标（Godot） | 备注 |
|---|---|---|
| `rtscontract/vec.py` | — | 直接用 `Vector2`；`round()` 换成自定义 `snap()` |
| `rtscontract/enums.py` | `ai/contract/enums.gd` | 建议用 `const` 字符串 + `@warning_ignore`，不要用 `enum`（序列化更麻烦） |
| `rtscontract/catalog.py` | `ai/contract/catalog.gd` + `catalog_loader.gd` | 从你的单位 `.tres` / 表格生成同一份 `catalog.json` |
| `rtscontract/snapshot.py` | `ai/contract/snapshot.gd` | `PackedInt32Array` / `Array[UnitView]`，不要用 `Dictionary` |
| `rtscontract/commands.py` | `ai/contract/command.gd` | 冻结对象 → `RefCounted` + 只读约定 |
| `rtscontract/control.py` | `ai/control_registry.gd`（游戏侧） | **不要放在 AI 里**，见第 10 节 |
| `rtscontract/gateway.py` | `ai/game_gateway.gd` | 你自己实现，AI 只认这 7 个方法 |
| `rtsai/world.py` | `ai/world.gd` | 信念状态 + 敌方记忆 |
| `rtsai/fog.py` | `ai/fog.gd` | 宏格探索度 |
| `rtsai/territory.py` | `ai/territory.gd` | 12×12 宏格投影 |
| `rtsai/combatmodel.py` | `ai/combat_model.gd` | 纯数学，最好移植的一块 |
| `rtsai/plans.py` | `ai/plans.gd` | DSL 求值器（约 60 行） |
| `rtsai/director.py` | `ai/director.gd` | 指标 + 计划选择 + 姿态 |
| `rtsai/economy.py` | `ai/economy.gd` | 最需要重写的一块（见 AUDIT_REPORT §5） |
| `rtsai/production.py` | `ai/production.gd` | 同上（§5） |
| `rtsai/expansion.py` | `ai/expansion.gd` | 同上（§6） |
| `rtsai/combat.py` | `ai/combat.gd` | 撤退必须重写（§7） |
| `rtsai/adjutant.py` | `ai/adjutant.gd` | 必须按 §4 的方案重写，不要照抄 TTL |
| `rtsai/sanity.py` | `ai/sanity.gd` | 反愚蠢自检，建议保留 |
| `rtsai/scheduler.py` | `ai/scheduler.gd` | 去重 + 预算 |
| `rtsai/placement.py` | `ai/placement.gd` | 依赖 `can_place`，本身很薄 |
| `rtsai/scouting.py` | `ai/scouting.gd` | 注意 scout 泄漏（§8.3） |
| `rtsai/profile.py` | `ai/profile.gd` | 读 `ai_profile.json` |
| `rtsai/agent.py` | `ai/agent.gd` | 唯一入口 `update()` |
| `rtsim/` `rtsexam/` | **不移植** | 留在 Python 侧当"算法实验室" |

---

## 5. 数据结构映射

| 契约 | Godot | 注意 |
|---|---|---|
| `Vec2(x,y)` | `Vector2` | 坐标系一致（左上原点、y 向下），无需翻转 |
| 时间 `float` 秒 | `float` 秒 | 不要用 `Time.get_ticks_msec()`；用你自己累加的 `match_time` |
| `tick: int` | `int` | 固定步长计数的**逻辑 tick**，不是帧号 |
| `dt: float` | `float` | 必须等于 `1/tick_hz`，不要传 `delta` |
| `units: tuple[UnitInfo]` | `Array[UnitView]` | 用 typed array，比 `Array` 快 2–3 倍 |
| `map.walkable: bytes` | `PackedByteArray` | 长度 = w*h，索引 `y*w+x` |
| `frozenset[int]`（锁定集合） | `Dictionary`（当 set 用） | 或 `PackedInt32Array` + `has()` |
| `Command` | `RefCounted` + 字段 | 建议池化，避免每 tick new |
| `Mapping`（`match_info`） | `Dictionary` | 只在启动时读一次 |

**性能提示**：Godot 里 `Dictionary` 的字符串键很慢。快照里不要用 `{"uid":..,"pos":..}`，
用 `UnitView` 类 + 字段。1,000 单位 × 5 Hz 的快照构造，`Dictionary` 方案很可能吃掉 10ms 以上。

---

## 6. 网关实现清单（8 个方法，逐个说坑）

### 6.1 `snapshot() -> WorldSnapshot`

| 项 | 要求 |
|---|---|
| 频率 | 每个 AI tick 一次（5 Hz）。**不要每帧调**。 |
| 数据来源 | 你的 `模拟核心` 的实体表；不要读渲染节点 |
| 迷雾 | 必须用**该阵营**的可见性过滤（不是玩家视角）。见第 9 节 |
| 值拷贝 | 必须是拷贝。AI 会跨 tick 持有；直接传引用会在下一帧被改掉 |
| 事件 | 调用即清空队列（契约约定）。如果你不想清空，就自己维护"上次读到的游标" |
| 性能 | 1,000 单位 O(n) 构造，目标 < 8ms |

**必填字段的常见遗漏**：`order_owner`（玩家还是 AI 下的令）、`since_order`、`control`。
这三个缺一个，控制权判断就会退化到纯 TTL。

### 6.2 `issue(cmd) -> CommandResult`

必须按这个顺序校验，**任一失败立刻返回，不要部分执行**：

```
1. kind 合法性
2. issuer 权限（lock/unlock/grant/select 只允许 player）
3. 单位/建筑归属（team）
4. 控制权（AI 阵营 → 查 ControlRegistry + 玩家订单是否活跃）
5. 目标存在且存活
6. 目标可见（AI 阵营）
7. 科技 / 资源 / 人口 / 队列
8. 可放置性（build）
```

**返回 `reason` 必须用契约里的字符串**，否则 AI 的自适应逻辑（`sanity`）会失效。
`accepted` 字段要填"实际接受了几个单位"，部分接受时 AI 依赖它。

### 6.3 `can_place(proto_id, point) -> bool`

- 只探测，**绝对不能有副作用**（不要真的扣钱、不要生成幽灵建筑）。
- AI 每 tick 最多探测 36–40 次；你的实现必须是 O(格子数) 而不是 O(全场单位)。
- 允许保守（返回 false 但实际能放），不允许乐观（返回 true 但放不下）。

### 6.4 `catalog() -> Catalog`

- **启动时构建一次**，之后只读。
- 注意：Python 版 `Catalog` 在构造时缓存了 `units()/buildings()`，运行期再加原型不会生效。
  移植时要么每次重建，要么提供 `reload()`。

### 6.5 `match_info()`

至少给：`tick_hz`、`dt`、`width`、`height`、`seed`。
如果 AI 的频率和游戏 tick 不一致（例如游戏 60Hz、AI 5Hz），**必须显式告诉它**，
否则 `ControlRegistry` 的 TTL 换算会错。

### 6.6 `suggest(payload)`

只投递给 UI，**不得产生游戏行为**。`code` 要稳定（`request_control` / `low_odds`），`message` 可本地化。

### 6.7 `stats()`

至少返回 `rejected`（按 reason 计数）。这是你在真实游戏里排查"AI 为什么不动"的第一现场。

### 6.8 `can_reach(unit_ids, point) -> bool` **（新增，强烈建议实现）**

回答一个问题：**这组单位现在能不能走到这个点**。

| 用途 | 没有它会怎样 |
|---|---|
| 撤退点选择（`combat._safe_point`） | 撤退点可能落进封闭房间：可走、不可达，单位朝墙里走 |
| 卡死恢复（`scheduler`） | 只能靠时间退避（6→12→24→48s），收敛更慢；f8 实测 44 条 → 138 条命令 |

实现要点：

- 内部就是一次 A*（`max_expand≈2000`、`max_path≈128`），**不要**做完整寻路后再丢弃；
- 允许保守（返回 false 但实际能走），不允许乐观；
- 调用频率很低：只在「选撤退点」和「单位已经卡死」时调用，不是每 tick 每单位；
- 如果没有这个方法，`AIContext.can_reach` 会降级为 true（即"假定可达"），
  不会崩，但撤退/卡死恢复会退化。**Godot 侧请务必实现。**

---

### 6.9 命令调度器：不要跳过这一节

Python 版的 `rtsai/scheduler.py` 不是"工具类"，它是**防止命令风暴的核心**。
移植时如果只翻译各个 Manager 而跳过调度器，会立刻复现审计里最严重的问题：

| 机制 | 作用 | 不做的后果 |
|---|---|---|
| 同 tick 合并 | 一个单位每 tick 只发一条命令；目标相同的单位合并成一条 | 5 个 Manager 抢同一单位，同 tick 2~3 条互相覆盖 |
| 到达判定 | 单位已在目标点 0.9 格内 → 不再下令 | `到达→idle→重发` 死循环（实测 3.96 条/秒/单位） |
| 重发节流 | 同类移动命令 0.6s 内不重复（防守/撤退/恢复类**豁免**） | 集结点漂移导致每 tick 一条命令 |
| 卡死锁定 | 连续两个快照 stuck → 一段时间不再下移动命令 | `STOP→idle→MOVE→撞墙` 自持循环 |
| 玩家保护过滤 | AI 侧先剔除 `PLAYER_*` 单位 | 依赖网关兜底，越权计数飙升 |

> 节流的豁免名单很关键：`combat:defend` / `combat:recall` / `combat:retreat` / `sanity:*`
> 不能节流。审计中曾因节流误伤防守命令，导致一个种子的主基地被拆。

---

## 7. Catalog 落地：把你的数值变成 AI 能读的表

AI 不认识"步兵""狮鹫"，只认识字段。最小字段集：

```json
{
  "id": "footman",
  "hp": 420, "armor": 2, "armor_type": "heavy",
  "speed": 3.0, "sight": 7,
  "cost": {"gold": 135, "supply": 2},
  "build_time": 20,
  "attack": {"damage": 13, "range": 1.0, "cooldown": 1.1,
              "damage_type": "normal", "targets": ["ground"]},
  "tags": ["melee", "frontline", "ground"],
  "requires": ["barracks"],
  "produce": [], "built_by": ["worker"],
  "dropoff": false, "supply_provided": 0,
  "max_queue": 4, "footprint": [1, 1], "flying": false
}
```

**注意 `cost` 只有 `gold` 和 `supply` 两个字段。**
如果你的 RTS 有木材/水晶/瓦斯，**必须先扩展 `Cost`**，否则 AI 会在"看起来有钱、其实没木头"的地方反复下单。
这是本次审计认定的 P0 缺陷之一（AUDIT_REPORT §5.1）。

**生成方式建议**：写一个 Godot EditorScript，把你的单位 `.tres` 批量导出成这个 JSON。
这样数值只维护一份，AI 侧永远和游戏一致。

---

## 8. 快照构造：性能与正确性

### 8.1 预算

| 单位规模 | 目标 `snapshot()` | 目标 `AI.update()` | 合计（5Hz） |
|---|---|---|---|
| 100 | < 1 ms | < 5 ms | 占 200ms 预算 < 3% |
| 300 | < 3 ms | < 12 ms | < 8% |
| 500 | < 5 ms | < 25 ms | < 15% |
| 1000 | < 10 ms | < 60 ms | < 35% |

本次审计在 Python 上的实测见 AUDIT_REPORT §9；GDScript 通常快 2–5 倍，但**不要假设**，用你的真机测。

### 8.2 三个必须避免的写法

1. 在 `snapshot()` 里 `get_tree().get_nodes_in_group("units")` —— 每帧反射，1,000 单位会炸。
2. 每个单位 `Dictionary` —— 见第 5 节。
3. 在 AI 线程里读 `Node` —— 快照必须是纯数据，否则线程安全无从谈起。

### 8.3 已知的"状态泄漏"要一起修

Python 版有三处跨 tick 状态只增不减，移植时**顺手修掉**：

| 位置 | 问题 | 修法 |
|---|---|---|
| `scouting.scouts` | 侦察兵中途被别的模块改令后，永远留在表里，占满 `max_scouts` 后不再侦察 | 定期清理：只要 `order` 不是 `move/attack_move` 就移出 |
| `sanity._incomplete_seen` | 按建筑 id 记录，建筑完工/被拆后不清理 | 完工或死亡时 `erase` |
| `world.enemy_buildings` | 记忆保留 240 秒（设计如此），但被摧毁后无法立即失效 | 消费 `building_destroyed` 事件立刻删除（见 §9.3） |

---

## 9. 迷雾接入

### 9.1 三种实现，选一种

| 方案 | 做法 | 适合 |
|---|---|---|
| A. 位图 | 每阵营一张 `PackedByteArray` 可见位图，每次视野变化重算 | 单位多、查询频繁（推荐） |
| B. 逐单位查询 | `is_visible(team, pos)` 遍历该阵营单位 | 单位少（< 100） |
| C. 引擎遮挡 | 用 Godot 的 `Light2D`/`CanvasModulate` 或自定义 shader | 只解决"画面"，**不能**用于逻辑判断 |

**逻辑迷雾必须自己算**，不要用渲染遮罩反推。

### 9.2 过滤规则

```
snapshot.units       ：己方全部 + 敌方"当前可见"
snapshot.buildings   ：己方全部 + 敌方"当前可见"
snapshot.nodes       ：只含"已探索"过的资源点
snapshot.events      ：按事件发生地当时是否可见投递
map.start_points     ：无条件给（玩家本来就知道）
map.enemy_start      ：无条件给（同上）
map.expansion_sites  ：位置无条件给；**owner / has_building / remaining 必须过滤或模糊化**
```

最后一条是本次审计发现的真实泄漏（`AUDIT_REPORT.md` §1 第 22/23 项）：
Python 版把"敌方在哪个分矿造了基地"直接算进快照，AI 等于开图。
移植时要么不给 `owner`，要么只在"该点可见"时才填。

**还有一个坑必须一起躲开**：Python 版的 `Sim.map_info()` 只构建一次并永久缓存，
所以分矿归属/余量在整局里根本不刷新（`AUDIT_REPORT.md` §1 第 21 项）。
你的适配器必须**每次 `snapshot()` 都重算 `expansion_sites`**，否则 AI 会一直以为
"所有分矿都是空的"，反复往同一个已被占的点派农民。

### 9.3 事件通道：必须用起来

Python 版定义了 8 种事件，但 **AI 一个都没读**（`snapshot.events` 引用次数 = 0）。
结果就是：资源枯竭、建筑被拆、生产被卡，全靠 AI 每 tick 轮询状态猜。

移植时建议至少消费这 4 个：

| 事件 | AI 应该做什么 |
|---|---|
| `resource_depleted` | 立刻把该矿点的农民改派，而不是等下一轮 `idle` |
| `building_destroyed` | 立刻从 `enemy_buildings` 记忆里删除，避免继续打空气 |
| `supply_blocked` | 提高补人口的优先级（当前靠 `sanity` 事后补救） |
| `unit_under_attack` | 局部拉响防守，而不是等 `base_threat` 统计出来 |

---

## 10. 控制权接入（最容易做错的一块）

### 10.1 谁来持有 `ControlRegistry`

**游戏侧，不是 AI 侧。** 原因：

- AI 可能被重启/热重载，玩家锁定状态不能丢；
- 存档必须包含控制权；
- 网关要用它做最后一道校验（防止 AI 代码 bug 越权）。

建议放在 `match_controller.gd`（或 `模拟核心/match_state.gd`），并 `to_dict()/from_dict()` 支持存档。

### 10.2 玩家命令必须走同一个入口

```gdscript
func player_issue(cmd: Command) -> CommandResult:
    control.on_player_command(cmd.units, tick)   # 先登记
    var r := gateway.issue(cmd)                   # 再执行
    intents.append(Intent.new(tick, cmd.kind, cmd.units, cmd.target, cmd.point, cmd.proto, r.ok))
    return r
```

**不要**在 UI 里直接改单位状态绕过这个入口，否则 AI 永远不知道玩家动过。

### 10.3 不要照抄 TTL

Python 版的 `PLAYER_MANUAL + TTL 8s` 在实测中失败 4/10 个场景（AUDIT_REPORT §4）。
移植时直接实现 **Player Intent Ownership**：

```
状态：AI_OWNED / PLAYER_ACTIVE(group) / PLAYER_HOLDING / PLAYER_GRACE(until) / PLAYER_LOCKED

玩家下令        → PLAYER_ACTIVE，登记一个命令组（整组共享）
组内全部 idle   → PLAYER_GRACE(now + 5s)                # 按组判定，不按单个单位
命令被取消/失效 → PLAYER_GRACE(now + 5s)
命令超 120s 未结束 → PLAYER_GRACE(now + 5s)              # 安全上限，防玩家忘松手
玩家 STOP       → PLAYER_HOLDING(now + 30s)
玩家 HOLD       → PLAYER_HOLDING（无期限，直到玩家再下令）
玩家 LOCK       → PLAYER_LOCKED（永久）
玩家 GRANT      → AI_OWNED
GRACE 到期      → AI_OWNED
```

判定"订单是否结束"**必须来自游戏**（`unit.order == idle` 或订单完成事件），
不能靠"下了令之后过了 N 秒"。**"结束"要按命令组判定**：组里还有一个人在动，整组都不算结束。

TTL 只在一种情况下保留：**游戏无法提供 `order_owner` / 订单完成事件时**，作为兜底。

### 10.4 一个必须避开的陷阱

**旧版**模拟器里曾有一个 `player_order_block_cap_seconds = 18`：玩家订单执行超过 18 秒后，
网关就不再阻拦 AI。它当时没炸，是因为 AI 侧还有一道无上限的过滤。

现在这个上限**已经从网关和配置里删除**（`PLAYER_ACTIVE` 只受 120 秒安全上限约束，
且 120 秒只防"玩家忘松手"，到点进入 `PLAYER_GRACE` 而不是立刻被接管）。

**如果你在网关里加"过了 N 秒就放行"的逻辑，玩家一条 25 秒的绕后命令会在第 N 秒被副官抢走。**

移植时：网关只做"是否允许"的最终裁决；时间只应该影响 `PLAYER_GRACE`
（命令结束后的宽限），不应该影响 `PLAYER_ACTIVE`。

---

## 11. 命令校验：7 项，顺序不能变

已在 §6.2 列出。这里补三条实战经验：

1. **先校验控制权，再校验资源。** 否则玩家锁住的单位会先扣钱再被拒，玩家会看到资源跳动。
2. **部分接受要如实返回。** 10 个兵里有 3 个在迷雾中，就接受 7 个、`accepted=7`；
   全拒会让 AI 误判为"命令系统坏了"。
3. **拒绝原因不要合并。** `no_supply` 和 `no_resources` 必须分开，AI 的修复动作完全不同
   （补人口 vs 等钱）。

---

## 12. 只读关（M1）常见错因对照表

| 症状 | 最可能的原因 |
|---|---|
| AI 认为农民数比实际少 | `snapshot.units` 漏了正在建造的农民 / 或者把已死单位也算进去 |
| 敌方单位数偏多 | 迷雾没过滤，把全图敌方单位都塞进去了 |
| `army_ratio` 长期 1.4（无论实际强弱） | 敌方不可见 → AI 退化成"按自己军队估值"，这是设计行为，不是 bug |
| AI 不进攻 | `allow_attack` 需要同时满足兵力比 / 最小兵力 / 静态防御估值 / 计划 aggression |
| AI 疯狂造人口 | `supply_cap` 传的是"已用"而不是"上限" |
| AI 一直采不到矿 | `nodes.max_workers` 传了 0，或 `remaining` 传了 0 |
| `order` 字段全是 `"idle"` | 你没有把游戏订单映射到 `OrderKind`，AI 的去重全部失效（会疯狂重发） |

最后一条最致命：**`order` 映射错了，AI 会每 tick 重发同一条命令**。

---

## 13. 五关验收 + "玩家折磨"脚本

### 关卡

| 关 | 开放 | 通过标准 | 失败就回滚到 |
|---|---|---|---|
| 1 只读 | 无 | 第 12 节所有指标对齐 | — |
| 2 运营 | 采集/农民/人口/建筑/训练 | 5 分钟 `supply_block=0`、闲置率<10%、不抢玩家农民 | 关 1 |
| 3 军队 | + move/attack/hold | 三场景各 3 次，胜负合理、撤退不被全灭 | 关 2 |
| 4 扩张 | + 分基地 | 分矿选址合理、不在敌方驻军点上开矿 | 关 3 |
| 5 副官 | + 玩家控制权 + 建议 | 折磨脚本全部通过 | 关 4 |

### 折磨脚本（比再刷 100 个"1000 vs 800 该不该打"更有价值）

```text
t=10s  让部队进攻
t=15s  5 秒后改成撤退
t=20s  拆掉一个人口建筑
t=25s  手动拉走 5 个农民
t=30s  锁定 10 个士兵（LOCK）
t=35s  取消正在建造的兵营
t=45s  把主力调到地图另一头（30 秒长距离）
t=60s  解锁
t=70s  连续 Shift 排 3 个移动点
t=80s  把 3 个兵单独拉去送死
t=90s  恢复副官全权
```

观察这 8 项，任一出现即不通过：

- [ ] 抢控制（`control_blocked > 0`）
- [ ] 死循环 / 帧率下降
- [ ] 重复下令（同一单位 > 2 条/秒）
- [ ] 继续引用旧任务（攻击已死目标、往已拆建筑派农民）
- [ ] 把玩家刚拉走的单位拉回来
- [ ] 因人口变化疯狂造房（10 秒内 > 5 个）
- [ ] 战略系统崩掉（`plan` 高频抖动）
- [ ] 崩溃 / 报错

---

## 14. 存档与联机（易被忽略）

| 问题 | 要求 |
|---|---|
| 存档 | AI 的跨 tick 状态必须可序列化：`pending_expansion`、`retreat_until`、`_fleeing`、`scouts`、`sanity counts`、`world.enemy_buildings`。Python 版**没有** `to_dict()`，移植时要补 |
| 读档 | 恢复后第一帧必须能容忍"快照里的 tick 比记忆里的新" |
| 联机 | AI 必须在**所有客户端**上确定性运行，或只在主机运行并把命令广播。前者要求 AI 不用随机、不读墙钟（Python 版已满足）；后者要求命令带 `issuer + tick` 以去重 |
| 重开一局 | 需要 `agent.reset()`；Python 版没有，直接复用会带上一局的计时器和 pending 状态 |

---

## 15. 不要做的事

1. **不要**把 `rtsim`（Mock 模拟器）一起塞进游戏。它只是验证工具。
2. **不要**在 AI 里 `get_node()` / 读场景树。AI 只能看快照。
3. **不要**为了"让某个用例过"改 AI 里的常量。改配置，或者承认这是真实弱点。
4. **不要**在真实游戏里直接沿用 Mock 的阈值（`defense_radius=17`、`attack_power_ratio=1.35`…）。
   这些是 88×88 地图、1 格=1 单位的假设下的数，换地图尺寸就失效。
5. **不要**相信"46/46 全绿"能推出"能打"。本次审计的随机种子跑出 45/46（AUDIT_REPORT §10.1）。
6. **不要**先开副官全权。按第 13 节的五关走。

---

## 16. 出问题时先看哪里

| 现象 | 先看 |
|---|---|
| AI 完全不动 | `agent.stats().commands.failures` → 全被拒？看 reason |
| AI 每 tick 重发命令 | `unit.order` 映射是否生效；`scheduler.commands_skipped` 是否接近 0 |
| AI 不造兵 | `posture.army_supply_target`、`allowed` 条件、`no_supply` 拒绝 |
| AI 不扩张 | `posture.allow_expand`、`base_threat`、`expansion.started` |
| AI 不撤退 | `combat.stats.retreats`、`_should_retreat` 的三个前置条件 |
| AI 撤退后全灭 | 撤退点可达性（AUDIT_REPORT §7） |
| 帧率下降 | `snapshot()` 耗时；`AI.update()` 耗时；命令数/秒 |
| 结果不可复现 | 是否用了 `randf()` / `Time`；`Dictionary` 迭代顺序 |

---

_本指南与 `AUDIT_REPORT.md`、`HANDOVER_FINAL.md` 配套使用。_
_若三者冲突：以代码与 `audit/audit_result.json` 的实测为准，并更新文档。_

# 交接文档（HANDOVER）

> 目标：让另一台机器上的另一位工程师（或另一个 Agent）**不依赖任何上下文**就能接手。

---

## 0. 一页纸摘要

* **这是什么**：一套与具体游戏解耦的 RTS AI 框架 + 一套无渲染模拟器 + 一套自动化考试系统。
* **能做什么**：AI 会运营（农民/人口/科技）、会根据敌方兵种构成本能地转型、会开矿、
  会防守/进攻/撤退、会在迷雾下侦察、会遵守「玩家指令优先」。
* **当前状态**：Mock 上 46 个用例 / **302 条断言**全部通过（固定回归种子与随机种子各 128 局）；
  审计套件 43 项 **FAIL 0**；单进程 ~200–300 tick/s，1,017 单位时 AI 决策 116.6 ms/次。
* **没做什么**：没有真实游戏适配器（本机没有游戏工程）、没有英雄/野怪/技能/升级。
* **最先要做的三件事**：
  1. 按 `docs/03-INTEGRATION-GUIDE.md` 实现 `GameGateway`；
  2. 在真实游戏上跑 `fog_no_cheat` / `adj_lock_inviolable` / `meta_no_game_dependency`；
  3. 用真实数值重写 `config/catalog.json` 后重跑考试并**重新校准阈值**。

---

## 1. 五分钟读懂这个项目

```
玩家/敌方 ──▶ 游戏 ──(WorldSnapshot)──▶ RTSAgent ──(Command)──▶ 游戏
                                        │
                                        ├─ world：信念状态（含敌方记忆）
                                        ├─ director：选战略计划 → Posture
                                        ├─ economy / production / expansion / combat：执行
                                        ├─ sanity：反愚蠢自检
                                        └─ adjutant：玩家意图 + 控制权
```

三条主线：

1. **AI 只认数据**：兵种是 `config/catalog.json` 里的数值 + 标签；克制来自
   「攻击类型 × 护甲类型」矩阵；战略来自 `config/plans.json` 的声明式计划。
2. **AI 只通过网关说话**：读 `snapshot()`、写 `issue()`；不能碰游戏对象。
3. **考试驱动迭代**：每次改动都跑 `run_exam.py`；失败用例即「回归」。

---

## 2. 阅读顺序（建议 60–90 分钟）

| 顺序 | 文件 | 为什么读 |
|---|---|---|
| 1 | `README.md` | 全局印象 + 命令 |
| 2 | `docs/01-ARCHITECTURE.md` | 分层、数据流、设计取舍 |
| 3 | `src/rtscontract/snapshot.py` + `commands.py` | **最重要**：AI 能看到什么、能做什么 |
| 4 | `src/rtsai/agent.py` | 一个 tick 里发生了什么（14 步） |
| 5 | `src/rtsai/director.py` + `config/plans.json` | 战略是怎么选的 |
| 6 | `src/rtsai/economy.py` + `production.py` | 运营与兵种构成 |
| 7 | `src/rtsai/combat.py` | 防守/进攻/撤退/微操 |
| 8 | `src/rtsai/adjutant.py` + `rtscontract/control.py` | 控制权三道防线 |
| 9 | `src/rtsim/sim.py` | 模拟器规则（想改规则时看这里） |
| 10 | `src/rtsexam/case.py` + `cases/` | 考试怎么写、怎么写新用例 |
| 11 | `docs/03-INTEGRATION-GUIDE.md` | 接真实游戏时逐条照做 |

---

## 3. 目录地图（改什么去哪个文件）

| 你想改… | 去… | 注意 |
|---|---|---|
| 兵种/建筑数值、克制关系 | `config/catalog.json` | 改完必须重跑考试（阈值可能要重标） |
| AI 的激进/保守程度 | `config/ai_profile.json` + `config/plans.json` | 先改计划参数，再改 profile |
| 战略流派（速攻/龟缩/双矿） | `config/plans.json` | 纯数据，不用改代码 |
| 农民/人口逻辑 | `src/rtsai/economy.py` | `_manage_supply` 是主动补人口的关键 |
| 造什么兵 | `src/rtsai/production.py` | `CompositionSolver.choose` |
| 战斗决策 | `src/rtsai/combat.py` | `_should_retreat` 用的是「战场双方总兵力」 |
| 副官的行为边界 | `src/rtsai/adjutant.py` + `autonomy` 配置 | 别在这里放松控制权检查 |
| 控制权规则 | `src/rtscontract/control.py` + 游戏的 `ControlRegistry` | 改这里会影响合规用例 |
| 模拟器规则 | `src/rtsim/sim.py` | 改完必须重跑全部用例 |
| 新增考试用例 | `src/rtsexam/cases/*.py` | 用 `@case(...)` 注册；**不要**在 AI 里写用例特判 |
| 考试配置（种子/通过线） | `config/exam.json` | |

---

## 4. 常用命令

```bash
# 环境
python -V                       # 需要 3.10+
export PYTHONPATH=src           # 或直接用 run_exam.py（内部已加）

# 考试
python run_exam.py --list
python run_exam.py --jobs 8                                   # 全量（推荐）
python run_exam.py --seeds 1 --jobs 8                         # 快速冒烟（~50s）
python run_exam.py --category adjutant --category sanity
python run_exam.py --case adj_lock_inviolable --seeds 6
python run_exam.py --random --baseline reports/baseline.json  # 随机种子 + 回归
python run_exam.py --jobs 8 --save-baseline                   # 更新基线

# 演示 / 诊断
python run_demo.py --seed 7 --duration 240        # 生成 reports/demo.html
python scripts/smoke_sim.py                       # 模拟器冒烟
python scripts/smoke_ai.py 3 300                  # AI 对战曲线
python scripts/debug_econ.py 5 240                # 经济曲线
python scripts/debug_pvp.py 11                    # 1v1 曲线
python scripts/debug_counter.py                   # 克制场景
```

---

## 5. 当前状态（截至交接）

| 项目 | 数值 |
|---|---|
| 用例 / 断言 / 分类 | 46 / 302 / 15 |
| 每用例种子 | 2–3（默认 3） |
| 最近一次全量（固定种子） | **46/46、302/302**，131 s |
| 最近一次全量（随机种子） | **46/46、302/302**，117 s |
| 审计套件（43 项） | **FAIL 0** / WARNING 8 / PASS 33 / N/A 2 |
| 单局模拟速度 | ~200–300 tick/s（约 20–30 倍实时） |
| 全量考试耗时 | ~2.2 分钟（8 进程） |
| 依赖 | 无（纯标准库） |

**基线**：`reports/baseline.json`。每次改动后：

```bash
python run_exam.py --jobs 8 --baseline reports/baseline.json
```

若出现回归（`pass->fail` 或关键指标下降 > 5%），报告里会列出具体用例与指标。

---

## 6. 工作方式约定（重要）

1. **不许针对用例/种子写特判**。
   `meta_no_hardcode` 会扫描 `src/rtsai/**/*.py`，出现任何用例 id、`seed == N`、
   `import rtsexam` 都会失败。想让某个用例过，就改策略或改场景的**通用**规则。
2. **AI 不许 import 模拟器**。`meta_no_game_dependency` 会检查。
3. **每次改动跑两类测试**：固定回归种子（`--save-baseline` 后对比）+ 随机种子（`--random`）。
4. **加用例的方式**：
   ```python
   @case("atk_xxx", "attack", seeds=3, desc="...")
   def atk_xxx(seed, cfg):
       ck = Checker()
       h = run_match(base_spec(...), seed, duration=120, scripts=[...])
       ck.at_least("kills", h.last("kills_0"), 2)
       return outcome("atk_xxx", "attack", seed, ck, {...})
   ```
   场景只能用 `ScenarioSpec` + `scripts` 表达，不要修改 AI。
5. **调参顺序**：先看报告里失败用例的 `actual/expected` → 判断是「AI 弱」还是「阈值不合理」
   → 若 AI 弱就改策略（并解释为什么更优）→ 若阈值不合理就改阈值（并在 commit 说明里写清楚）。

---

## 7. 关键决策记录（ADR 摘要）

| 决策 | 原因 | 代价 |
|---|---|---|
| 用「快照 + 命令」而不是直接调用游戏 API | 强制迷雾隔离、可跨进程、防作弊 | 每 tick 要构造快照（有开销） |
| 克制用矩阵而非克制表 | 新兵种零成本纳入推理 | 需要游戏数值能映射到矩阵 |
| 战略用声明式计划 | 策划可调、易扩展 | 复杂条件表达能力有限 |
| 控制权用「命令组生命周期」而不是「TTL + 显式锁」 | TTL 模型在 11 个场景实测中失败 4 个（长命令 0 宽限、队形被劈开、STOP 被抢） | 需要游戏侧能提供"订单是否结束"，实现比 TTL 复杂 |
| AI 不用随机数 | 可复现、可回归 | 缺少随机扰动（用确定性打分代替） |
| 反愚蠢做成「检测 + 修复」而非「避免」 | 任何策略都可能出错，兜底更可靠 | 会掩盖部分根因（靠报告里的 issue 计数暴露） |

---

## 8. 排障手册

| 症状 | 先看 | 可能原因 |
|---|---|---|
| AI 完全不动 | `agent.stats()["commands"]`、`sched.failures` | 快照字段没填（`order`/`control`）、命令全被拒 |
| 经济不增长 | `scripts/debug_econ.py` | 农民没分配（`NODE_FULL`）、人口卡住、采集命令被拒 |
| 一直不进攻 | `agent.stats()["plan"]`、`posture.metrics` | `allow_attack` 条件不满足（ratio/静态防御/自治策略） |
| 军队被白打 | `agent.stats()["combat"]`、`sanity.issues` | 撤退阈值、反应延迟、`_defend` 的威胁过滤 |
| 控制权用例失败 | `sim_stats["control_blocked"]` | 网关没做二次校验，或 AI 侧过滤没生效 |
| 考试结果不可复现 | `meta_determinism` | AI 里用了随机数/时间，或选址用了 `hash()` |
| 性能骤降 | `meta_performance` | 单位过多、快照构造过重、A* 预算过大 |

---

## 9. 交接清单

- [ ] 代码：`src/`、`config/`、`run_exam.py`、`run_demo.py`、`docs/`、`reports/`
- [ ] 环境：Python 3.10+（无第三方依赖）
- [ ] 基线：`reports/baseline.json`（与当前代码同源）
- [ ] 报告：`reports/exam_report.md` / `.json`
- [ ] 演示：`reports/demo.html`
- [ ] 已知问题：`docs/05-KNOWN-ISSUES.md`
- [ ] 待办：`docs/04-TODO-INTEGRATION.md`

---

## 10. 下一步（按优先级）

1. **P0**：实现真实游戏 `GameGateway`，跑通三个合规用例；
2. **P0**：用真实数值重写 `catalog.json`，重跑考试并重标阈值；
3. **P1**：英雄 + 野怪 + 升级（`docs/04-TODO-INTEGRATION.md` 的 A1/A2/A3）；
4. **P1**：阵型与针对性侦察（B1/B4）；
5. **P2**：其余。

> 每次迭代请保持这个闭环：
> **改策略 → `--seeds 1` 快速验证 → `--jobs 8` 全量 → `--random` 随机回归 → 更新基线 → 记录到报告**。

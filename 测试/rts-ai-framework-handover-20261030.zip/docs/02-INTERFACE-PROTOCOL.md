# 接口协议（INTERFACE PROTOCOL）

本文件是 **AI 与游戏之间的唯一契约**。实现方（真实游戏适配器）只需满足这里的语义，
不需要理解 AI 内部实现；AI 侧也不会读取任何未在此声明的信息。

> 代码即协议：`src/rtscontract/`。本文件与代码冲突时，以代码为准，并请更新本文件。

---

## 0. 两个方向

```
游戏 ──(WorldSnapshot)──▶ AI        # 只读，AI 决策的唯一信息来源
AI   ──(Command)───────▶ 游戏       # 唯一写通道，必须逐条校验
AI   ──(suggest payload)▶ UI        # 副官建议，不产生游戏行为
```

强制约定：

1. **快照必须已按战争迷雾过滤**：敌方单位/建筑/资源点，只有「该阵营当前可见」才可出现。
2. **快照必须是值拷贝**：AI 会跨 tick 持有、比较、序列化；不得包含引擎对象引用。
3. **命令必须被独立校验**：归属、控制权、资源、人口、科技、视野、可放置性。
   即使 AI 有 bug，游戏也不能执行越权命令。
4. **`snapshot()` 会消费事件队列**：每个 AI tick 只调用一次；再次调用返回空事件。

---

## 1. 基础类型

### 1.1 `Vec2`

```python
@dataclass(frozen=True, slots=True)
class Vec2:
    x: float = 0.0
    y: float = 0.0
```

单位：**世界格（tile）**。地图坐标原点在左上角，x 向右、y 向下（与 Godot 2D 一致）。
AI 只用它做距离/方向计算，不假设地图内部结构。

### 1.2 常量（`rtscontract.enums`）

| 名称 | 值 | 说明 |
|---|---|---|
| `Issuer.PLAYER` | `"player"` | 人类玩家，最高优先级 |
| `Issuer.ADJUTANT` | `"adjutant"` | 副官（AI 的一种角色） |
| `Issuer.ENEMY_AI` | `"enemy_ai"` | 敌方人机 |
| `Issuer.SYSTEM` | `"system"` | 脚本/模拟器 |
| `ControlKind.PLAYER_ACTIVE` | `"player_active"` | 玩家命令正在执行（**整组**，直到组内全部 idle） |
| `ControlKind.PLAYER_GRACE` | `"player_grace"` | 命令刚结束，宽限期内 AI 不得接管（默认 5s） |
| `ControlKind.PLAYER_HOLDING` | `"player_holding"` | 玩家要求停住（STOP 30s / HOLD 无期限） |
| `ControlKind.PLAYER_MANUAL` | `"player_manual"` | 兼容旧语义：仅 TTL，无命令组信息（兜底） |
| `ControlKind.PLAYER_LOCKED` | `"player_locked"` | 玩家显式锁定（永久） |
| `ControlKind.ADJUTANT` | `"adjutant"` | 委托给副官 |
| `ControlKind.AUTONOMOUS` | `"autonomous"` | 该阵营自有 AI |

> `rtscontract.enums.PROTECTED_CONTROL` 是「AI 不得下令」的完整集合，
> AI 侧过滤与网关校验都必须用它，不要各自维护一份字面量。

`OrderKind`（单位当前订单，供 AI 判断「是否已在做同一件事」）：
`idle / move / attack / attack_move / hold / stop / harvest / build / patrol`

---

## 2. 原型表（`Catalog`）

```python
@dataclass(frozen=True, slots=True)
class Proto:
    id: str
    name: str
    is_building: bool
    hp: float
    armor: float
    armor_type: str          # light / medium / heavy / fortified / unarmored
    speed: float             # 格/秒；建筑为 0
    sight: float             # 视野半径（格）
    cost: Cost               # gold / supply
    build_time: float        # 秒
    supply_provided: float   # 建筑提供的人口
    footprint: tuple[int, int]
    flying: bool
    attack: Attack | None
    tags: tuple[str, ...]    # 供 AI 的「角色」配置引用，AI 本身不认具体名字
    requires: tuple[str, ...]      # 科技依赖（建筑 id）
    produce: tuple[str, ...]       # 该建筑能生产的单位 id
    built_by: tuple[str, ...]      # 哪些标签的单位能建造它
    dropoff: bool                  # 是否资源回收点
    max_queue: int
    harvest: Harvest | None        # 采集能力（有则为农民）
```

```python
@dataclass(frozen=True, slots=True)
class Attack:
    damage: float
    range: float
    cooldown: float
    damage_type: str              # normal / pierce / siege / magic
    targets: tuple[str, ...]      # ("ground",) / ("ground","air")
    splash: float
```

```python
@dataclass(frozen=True, slots=True)
class CombatRules:                # 克制矩阵（AI 与游戏共用同一张表）
    matrix: Mapping[str, Mapping[str, float]]   # attack_type → armor_type → 倍率
    tag_bonus: tuple[TagBonus, ...]             # 标签加成（如 anti_air vs air）
    armor_coef: float                            # 护甲减伤系数
```

**接入要求**：真实游戏的数值必须能映射为上述字段。若游戏的伤害公式完全不同，
请把等效数值填进来（例如「实际每秒伤害」折算成 `damage/cooldown`），
或在适配层提供一个「等效矩阵」，并同步修改 `rtsai/combatmodel.py` 的公式。

---

## 3. 世界快照（`WorldSnapshot`）

```python
@dataclass(frozen=True, slots=True)
class WorldSnapshot:
    tick: int
    time: float
    dt: float
    team: int                     # 快照所属阵营
    gold: float
    supply_used: float
    supply_cap: float
    supply_max: float
    units: tuple[UnitInfo, ...]        # 己方全部 + 敌方可见
    buildings: tuple[BuildingInfo, ...]
    nodes: tuple[NodeInfo, ...]        # 只含已探索的资源点
    map: MapInfo
    fog: FogInfo
    player: PlayerInfo
    events: tuple[EventInfo, ...]      # 自上次 snapshot() 以来
    enemy_team: int
    game_over: bool
    winner: int
```

### 3.1 `UnitInfo`

| 字段 | 语义 | 备注 |
|---|---|---|
| `uid` | 全局唯一 id | 与建筑共用 id 空间更佳（便于 `target` 复用） |
| `proto` | 原型 id | 必须在 Catalog 中存在 |
| `team` | 阵营 | |
| `pos` | 位置 | |
| `hp` / `hp_max` | 当前/最大生命 | `hp_max` 也用于算血量比例 |
| `order` | 当前订单 `OrderKind` | AI 用它做幂等过滤 |
| `order_target` | 订单目标 id | 攻击/采集目标 |
| `order_point` | 订单目标点 | 移动/建造位置 |
| `order_owner` | 订单发起方 `Issuer` | **关键**：判断是否玩家正在执行 |
| `control` | `ControlKind` | 由游戏的 `ControlRegistry` 给出 |
| `carrying` | 携带资源量 | 无则为 0 |
| `cd_frac` | 攻击冷却完成度 0..1 | 可用于微操；缺失可填 0 |
| `stuck` | 是否卡住 | 游戏可提供，AI 也会用位置差自行判断 |
| `resource_node` | 正在采集的资源点 | 可为 None |
| `home` | 绑定的资源点 | 可为 None |
| `since_order` | 当前订单持续秒数 | |

### 3.2 `BuildingInfo`

`bid, proto, team, pos, hp, hp_max, complete, progress(0..1), queue(tuple[proto_id,...]),
queue_time(队首剩余秒), rally(Vec2|None), builders(int), control, on_resource(bool)`

> `queue` 只放**队首之后的生产项顺序**即可；`queue_time` 用于 AI 估算产能。

### 3.3 `NodeInfo`

`nid, pos, remaining, max_workers, workers, kind`

`max_workers` 是硬约束：AI 在分配农民时会检查 `free_slots`，超过会被游戏拒绝（`NODE_FULL`）。

### 3.4 `MapInfo`

| 字段 | 语义 |
|---|---|
| `width/height/tile` | 地图尺寸（格） |
| `walkable` | 每行一个 `bytes`，`1` 可走、`0` 不可走 |
| `start_points` | 各阵营出生点（依次对应 team 0/1） |
| `enemy_start` | 敌方出生点（**静态地图知识**，不算迷雾作弊） |
| `expansion_sites` | 分矿点（位置、节点 id、剩余资源、归属） |
| `macro_w/macro_h` | 粗粒度宏格数（默认 12×12） |

> 约定：`start_points`、`expansion_sites` 属于「玩家本来就知道的地图信息」，
> 可以无条件提供；**敌方单位/建筑的存在与位置绝对不能在未探索时出现**。

### 3.5 `FogInfo`

`explored_ratio, visible_ratio, macro_explored(长度 macro_w*macro_h 的 0..1), unknown_enemy_activity`

`macro_explored[i]` 表示该宏格被探索过的比例。真实游戏可以提供迷雾贴图的降采样，
也可以由适配层根据单位视野自行累加。

### 3.6 `PlayerInfo`（副官专用）

```python
@dataclass(frozen=True, slots=True)
class PlayerInfo:
    selected: frozenset[int]
    locked: frozenset[int]
    manual: frozenset[int]
    granted: frozenset[int]
    intents: tuple[Intent, ...]     # 最近 N 条玩家意图（建议保留 16 条）
    autonomy: Mapping[str, Any]
    presence: bool                  # 是否有人类玩家
```

```python
@dataclass(frozen=True, slots=True)
class Intent:
    tick: int
    kind: str                 # Cmd.* 的值
    units: tuple[int, ...]
    target: int | None
    point: Vec2 | None
    proto: str | None
    ok: bool                  # 该命令是否被游戏接受
```

> `intents` 是副官理解「玩家想干什么」的关键。UI 层的高层指令（例如「进攻这里」）
> 建议以 `kind="attack_move"`、`units=()`、`point=...` 的形式写入。

### 3.7 `EventInfo`

`tick, kind, pos, subject, other, proto, value, team`

| kind | 触发时机 | AI 用途 |
|---|---|---|
| `unit_killed` / `building_destroyed` | 单位/建筑死亡 | 战损评估 |
| `unit_trained` | 训练完成 | 人口/产能核对 |
| `building_complete` / `building_started` | 建造进度 | 建筑统计 |
| `unit_under_attack` | 受到伤害（每 2 秒最多一次） | 拉响防守 |
| `supply_blocked` | 人口不足导致生产阻塞 | 反愚蠢：补供给 |
| `resource_depleted` | 资源点枯竭 | 重配农民 |
| `command_rejected` | 命令被拒 | 诊断 |

事件同样**必须按迷雾过滤**：敌方单位死亡事件只在「该阵营当时能看见」时才投递。

---

## 4. 命令（`Command`）

```python
@dataclass(frozen=True, slots=True)
class Command:
    kind: str
    issuer: str
    team: int
    units: tuple[int, ...] = ()
    building: int | None = None
    target: int | None = None
    point: Vec2 | None = None
    proto: str | None = None
    extra: tuple[int, ...] = ()
    label: str = ""      # 仅日志，不得影响行为
```

### 4.1 命令语义与必做校验

| kind | 字段 | 语义 | 必须校验 |
|---|---|---|---|
| `move` | units, point | 移动到点 | 归属、控制权 |
| `attack` | units, target | 攻击目标 | 归属、控制权、**目标可见**、能否命中该目标类型 |
| `attack_move` | units, point | 攻击移动 | 归属、控制权 |
| `hold` | units | 原地警戒 | 归属、控制权 |
| `stop` | units | 停止 | 归属、控制权 |
| `harvest` | units, target(节点), extra=(回收点 id,) | 采集 | 归属、控制权、节点余量、节点工位 |
| `build` | units(1 农民), proto, point | 建造 | 归属、控制权、科技、金币、可放置性 |
| `assist_build` | units, building | 协助在建建筑 | 归属、控制权、建筑未完工 |
| `train` | building, proto | 训练 | 归属、建筑完工、科技、金币、**人口**、队列上限 |
| `cancel_train` | building | 取消队尾 | 归属 |
| `set_rally` | building, point | 设置集结点 | 归属 |
| `lock` / `unlock` / `grant` | units | 玩家控制权操作 | **仅玩家** |
| `select` | units | UI 选择 | 仅玩家，不改变控制权 |

### 4.2 拒绝原因（`Reason`）

`invalid / not_owned / locked / player_order_active / target_not_visible /
target_invalid / no_resources / no_supply / tech_missing / queue_full / node_full /
place_invalid / not_ready / cooldown / busy / team_mismatch`

AI 会对 `no_supply`、`node_full`、`place_invalid` 做自适应（见 `sanity` / `economy`）。
**`target_not_visible` 与 `locked` 必须是 0 次**——这是硬性合规指标，考试会断言。

### 4.3 `CommandResult`

```python
@dataclass(frozen=True, slots=True)
class CommandResult:
    ok: bool
    reason: str = "ok"
    detail: str = ""
    accepted: int = 0     # 实际被接受的单位数
```

---

## 5. 控制权（`ControlRegistry`）—— Player Intent Ownership

游戏侧应维护一份「单位 → 控制权」登记表，并维护**玩家命令组**（同一批单位共享一个 `order_id` 语义）。

| 时机 | 动作 |
|---|---|
| 玩家对单位下达 move/attack/attack_move/harvest/build | 这批单位进入 `PLAYER_ACTIVE`，登记为一个命令组 |
| 组内**全部**单位 `order == idle` | 整组转入 `PLAYER_GRACE`（默认 5 秒） |
| 命令超过 `active_max_seconds`（默认 120s）仍未结束 | 强制转 `PLAYER_GRACE`（防止玩家忘松手） |
| 玩家下达 STOP | `PLAYER_HOLDING`，`hold_after_stop_seconds`（默认 30 秒） |
| 玩家下达 HOLD | `PLAYER_HOLDING`，无期限 |
| 玩家显式锁定 | `PLAYER_LOCKED`，永久 |
| 玩家解锁 | `PLAYER_GRACE`（再过 5 秒才交还 AI） |
| 玩家委托给副官 | `ADJUTANT`，立即 |
| 每 tick | 推进命令组状态 + 处理 GRACE/HOLDING 到期 |

AI 的 `issuer` 为 `adjutant`/`enemy_ai` 时，`allows(unit_id, tick, issuer)` 必须返回 false 的情形：

* `PLAYER_LOCKED`；
* `PLAYER_ACTIVE`（命令仍在执行，**与时间无关**）；
* `PLAYER_HOLDING` / `PLAYER_GRACE` 且未到期；
* `PLAYER_MANUAL`（仅当适配器只实现了 TTL 兜底）。

**关键：不要用「玩家下令后 N 秒」来判断可否接管。** 判断依据必须是「命令组是否已经结束」。
`AUDIT_REPORT.md` §4 记录了旧 TTL 模型在 11 个场景里失败 4 个的实测。

**AI 侧同样会过滤**（`CommandScheduler.available`），所以即使游戏侧漏判，
AI 也不会主动越权；游戏侧校验是为了防止 AI 代码 bug 造成的越权。

---

## 6. 网关协议（`IGameGateway`）

```python
class IGameGateway(Protocol):
    team: int
    def snapshot(self) -> WorldSnapshot: ...
    def issue(self, cmd: Command) -> CommandResult: ...
    def can_place(self, proto_id: str, point: Vec2) -> bool: ...
    def can_reach(self, unit_ids: Sequence[int], point: Vec2) -> bool: ...
    def catalog(self) -> Catalog: ...
    def match_info(self) -> Mapping[str, Any]: ...
    def suggest(self, payload: Mapping[str, Any]) -> None: ...
    def stats(self) -> Mapping[str, Any]: ...
```

| 方法 | 要求 |
|---|---|
| `snapshot()` | 见 §3；**消费事件队列**；同一 tick 内重复调用返回空事件 |
| `issue()` | 逐条校验；拒绝时返回 `CommandResult(ok=False, reason=...)` |
| `can_place()` | 只做探测，不产生副作用；可能被高频调用（AI 每 tick 最多 40 次） |
| `can_reach()` | 选撤退点 / 卡死恢复时调用；内部一次 A*，允许保守。**缺失会退化为「假定可达」** |
| `catalog()` | 返回静态原型表；可在启动时构建一次 |
| `match_info()` | 至少包含 `tick_hz`、`dt`、`width`、`height`、`seed` |
| `suggest()` | 把副官建议投递给 UI；**不得产生游戏行为** |
| `stats()` | 至少包含 `rejected`（按原因计数），供诊断与考试断言 |

### 6.1 `suggest` 负载约定

```json
{"code": "request_control", "severity": "info", "message": "...", "units": [12, 15]}
{"code": "low_odds", "severity": "warn", "message": "...", "army_ratio": 0.7}
```

`code` 是稳定标识（UI 可本地化），`message` 是兜底文案。

---

## 7. 副官自治策略（`autonomy`）

```json
{
  "manage_economy": true,
  "manage_supply": true,
  "manage_production": true,
  "move_army_defensive": true,
  "move_army_aggressive": false,
  "expand": true,
  "scout": true,
  "micro": true,
  "request_control": true,
  "directive_ttl_seconds": 30
}
```

| 键 | 含义 |
|---|---|
| `move_army_aggressive` | 是否允许副官**主动**发起进攻（玩家没下令时）。关闭后只在防守/执行玩家指令时移动部队 |
| `move_army_defensive` | 是否允许回防 |
| `expand` | 是否允许自主开矿 |
| `request_control` | 是否允许发「请求控制权」建议 |
| `directive_ttl_seconds` | 玩家高层指令的有效期（之后恢复自主判断） |

---

## 8. 版本与兼容

* 契约层版本见 `rtscontract.__version__`。
* 新增字段一律带默认值，保证旧适配器仍可运行。
* 破坏性变更必须提升主版本号，并在 `docs/04-TODO-INTEGRATION.md` 记录迁移方法。

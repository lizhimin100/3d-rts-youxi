# 接入指南（INTEGRATION GUIDE）

目标：把本框架接到**真实游戏工程**（例如 Godot 4.x 的 2D RTS），
让同一份 AI 代码同时驱动敌方人机与玩家副官，并复用整套自动化考试。

预计工作量（单人）：

| 步骤 | 内容 | 预估 |
|---|---|---|
| 0 | 跑通 Mock（验证环境） | 10 分钟 |
| 1 | 引入源码 | 5 分钟 |
| 2 | 编写 `catalog.json` | 0.5–1 天（取决于兵种数量） |
| 3 | 实现 `GameGateway` | 2–4 天（最难的一步） |
| 4 | 接入主循环与控制权 | 1 天 |
| 5 | 用考试系统跑真实对局 | 1–2 天 |

---

## Step 0：先跑通 Mock

在拥有本仓库的机器上：

```bash
python run_exam.py --list
python run_exam.py --seeds 1 --jobs 8
python run_demo.py --seed 7 --duration 120
```

能跑通说明 Python 环境与代码完整。**不要在没跑通 Mock 的情况下直接接真实游戏**，
否则无法区分「AI 的问题」和「适配器的问题」。

---

## Step 1：引入源码

三种方式，任选其一：

```bash
# A. 直接把 src/ 与 config/ 拷进工程（最简单）
cp -r rts-ai-framework/src ./ai
cp -r rts-ai-framework/config ./ai_config

# B. 作为子模块
git submodule add <repo> third_party/rts-ai

# C. 只拷贝纯 Python 包（无外部依赖）
cp -r rts-ai-framework/src/rtscontract ./ai/
cp -r rts-ai-framework/src/rtsai ./ai/
cp -r rts-ai-framework/config ./ai/config
```

然后设置：

```bash
export RTS_AI_ROOT=/path/to/project      # config/ 所在目录的父目录
```

> 不需要 `rtsim` 与 `rtsexam` 也能跑 AI；它们只用于自测。
> 但**强烈建议**把 `rtsexam` 一起带上，这样才能在真实游戏上复用同一批用例。

---

## Step 2：编写 `catalog.json`

把游戏的兵种/建筑数值映射到 `Proto`（字段见 `docs/02-INTERFACE-PROTOCOL.md`）。

要点：

1. **`damage_type` / `armor_type`** 必须能落到 `combat_rules.matrix` 的行列上。
   如果游戏没有这套概念，请**造一张等效表**：让「A 打 B 的实际倍率」与矩阵一致。
2. **`tags`** 只用于 `ai_profile.production.roles` 的角色归类（如 `melee`/`ranged`/`siege`），
   AI 不会因为标签名而特殊对待任何兵种。
3. **`built_by`** 用标签匹配（例如 `["worker"]`），决定哪些单位能造它。
4. **`requires`** 是建筑 id 列表，AI 据此判断科技是否就绪。
5. **`produce`** 是建筑能生产的单位 id 列表。

最小校验脚本（可直接跑）：

```python
from rtscontract.catalog import catalog_from_dict
from rtscontract.configio import load_json
cat = catalog_from_dict(load_json("catalog.json"))
for p in cat.protos.values():
    assert p.hp > 0 and p.build_time > 0
    if p.attack:
        assert p.attack.damage_type in cat.rules.matrix, p.id
        assert p.attack.targets, p.id
print("ok", len(cat.protos))
```

---

## Step 3：实现 `GameGateway`

这是**唯一**需要写「游戏相关代码」的地方。完整骨架：

```python
# game_ai/gateway.py
from rtscontract.catalog import Catalog, catalog_from_dict
from rtscontract.commands import Command, CommandResult, reject
from rtscontract.configio import load_json
from rtscontract.control import ControlRegistry
from rtscontract.enums import Issuer, Reason
from rtscontract.snapshot import (WorldSnapshot, UnitInfo, BuildingInfo, NodeInfo,
                                 MapInfo, FogInfo, PlayerInfo, Intent, ExpansionSite, EventInfo)
from rtscontract.vec import Vec2


class GodotGateway:
    """把引擎世界包装成 IGameGateway。"""

    def __init__(self, world, team: int, issuer: str, catalog_path="catalog.json"):
        self.world = world                 # 你的游戏世界对象
        self.team = team
        self.issuer = issuer               # Issuer.ADJUTANT / ENEMY_AI
        self._cat = catalog_from_dict(load_json(catalog_path))
        self._map = self._build_map()      # 静态地图，只构建一次
        self._events: list[EventInfo] = [] # 由游戏事件回调填充
        self._control = ControlRegistry(manual_ttl_seconds=8.0, tick_hz=world.tick_hz)

    # ---------- 静态 ----------
    def catalog(self) -> Catalog:
        return self._cat

    def match_info(self):
        return {"team": self.team, "tick_hz": self.world.tick_hz,
                "dt": 1.0 / self.world.tick_hz, "impl": "godot"}

    def _build_map(self) -> MapInfo:
        # 从 TileMap 生成 walkable 行字节；expansion_sites 用策划配置
        ...

    # ---------- 快照 ----------
    def snapshot(self) -> WorldSnapshot:
        events, self._events = tuple(self._events), []
        units, buildings, nodes = [], [], []
        for u in self.world.units:                       # 己方单位全部可见
            if u.team == self.team:
                units.append(self._unit(u))
        for u in self.world.enemy_units:                 # 敌方只在可见时出现
            if self.world.is_visible(self.team, u.pos):
                units.append(self._unit(u))
        ...  # buildings / nodes 同理
        return WorldSnapshot(
            tick=self.world.tick, time=self.world.time, dt=1.0 / self.world.tick_hz,
            team=self.team, gold=self.world.gold[self.team],
            supply_used=self.world.supply_used(self.team),
            supply_cap=self.world.supply_cap(self.team),
            supply_max=self._cat.supply_max,
            units=tuple(units), buildings=tuple(buildings), nodes=tuple(nodes),
            map=self._map, fog=self._fog(), player=self._player(),
            events=events, enemy_team=1 - self.team,
            game_over=self.world.game_over, winner=self.world.winner,
        )

    # ---------- 命令 ----------
    def issue(self, cmd: Command) -> CommandResult:
        if cmd.team != self.team:
            return reject(Reason.TEAM_MISMATCH)
        # 1) 归属
        # 2) 控制权（AI 发起时逐单位校验）
        # 3) 资源/人口/科技/队列/放置
        # 4) 目标可见性（AI 攻击迷雾内目标 → 必须拒绝并计数）
        # 5) 执行
        ...

    def can_place(self, proto_id: str, point: Vec2) -> bool:
        ...

    def suggest(self, payload) -> None:
        # 交给 UI 层；不要产生游戏行为
        self.world.ui.push_suggestion(payload)

    def stats(self):
        return {"rejected": dict(self._rejected)}
```

### 3.1 三条不可妥协的规则

1. **迷雾过滤**：敌方单位/建筑/资源点，只有 `is_visible(team, pos)` 为真才写进快照。
   漏一处就等于给 AI 开全图，`fog_no_cheat` 会立刻抓到（`cheat_attempts > 0`）。
2. **控制权二次校验**：AI 发起的命令必须逐单位检查 `ControlRegistry.allows()`；
   被拒时累加 `stats["control_blocked"]`。这是「玩家指令优先」的最后一道防线。
3. **`snapshot()` 消费事件**：每次调用后清空事件队列，否则 AI 会重复处理同一事件。

### 3.2 单位订单字段怎么填

| 字段 | 来源 |
|---|---|
| `order` | 你的单位状态机当前状态，映射到 `OrderKind` |
| `order_owner` | 该订单是谁下的（玩家/AI/脚本），用于「不打断玩家命令」 |
| `control` | `ControlRegistry.kind_of(uid)` |
| `stuck` | 可选：连续 N 秒位移小于阈值 |

---

## Step 4：接入主循环

```python
# 每帧（或固定 tick）
def _physics_process(delta):
    world.step(delta)
    if world.tick % AI_INTERVAL == 0:        # 例如 10Hz 模拟、5Hz AI
        for team, gateway in gateways.items():
            agent = agents[team]
            agent.update()                    # 只读快照 + 下达命令
```

约定：

* **AI 频率低于模拟频率**（推荐 5 Hz vs 10 Hz）：AI 不需要每帧决策，
  且 `CommandScheduler` 会做幂等过滤，重复命令不会造成抖动。
* **玩家输入要走 `player_command()`**：先 `ControlRegistry.on_player_command()` 再执行，
  这样 AI 立刻知道「这些单位归玩家」。
* **UI 要把高层意图写进 `snapshot.player.intents`**：
  「进攻这里」「防守这里」「造这个东西」都应该以 `Intent` 形式让副官看到。

---

## Step 5：用考试系统跑真实对局

1. 复制 `rtsexam`，把 `harness.run_match()` 换成你的真实游戏初始化：

```python
def run_match(spec, seed, **kw):
    game = MyGame(seed=seed, map=spec.layout)   # 你的引擎入口
    gw0 = GodotGateway(game, 0, Issuer.ADJUTANT)
    gw1 = GodotGateway(game, 1, Issuer.ENEMY_AI)
    a0, a1 = RTSAgent(gw0), RTSAgent(gw1)
    while game.time < duration:
        game.step()
        if game.tick % 2 == 0:
            a0.update(); a1.update()
    return MatchHandle(game=game, agent=a0, ...)
```

2. 先跑**纯 AI 用例**（economy / production / counter / meta）——它们不依赖脚本注入；
3. 再跑需要脚本注入的用例（defense / adjutant / sanity）——把 `scripts` 里的
   `sim.add_unit(...)` 换成引擎的「创建单位」接口；
4. 最后跑 `meta_determinism`：如果失败，多半是引擎里有未固定种子的随机数。

> 建议在真实游戏上先只跑 `meta_no_game_dependency`、`fog_no_cheat`、
> `adj_lock_inviolable` 三个用例——它们能最快暴露适配层的问题。

---

## 适配检查清单

- [ ] `catalog.json` 覆盖所有兵种/建筑，`damage_type`/`armor_type` 都能在矩阵中查到
- [ ] `MapInfo.walkable` 与真实地形一致（建筑放置、寻路都依赖它）
- [ ] 敌方信息严格按迷雾过滤（含事件）
- [ ] `ControlRegistry` 在玩家下令/锁定/解锁/委托时更新
- [ ] AI 命令逐单位校验控制权，拒绝时计数
- [ ] AI 攻击不可见目标时返回 `target_not_visible` 并计数
- [ ] `snapshot()` 每次调用清空事件
- [ ] `can_place()` 无副作用、可高频调用
- [ ] 训练命令返回 `no_supply` 时，AI 的补人口逻辑能被触发
- [ ] `suggest()` 只推 UI，不产生游戏行为
- [ ] AI tick 频率 ≤ 模拟频率，且 `dt` 一致
- [ ] 长时间运行无内存增长（快照不持有引擎引用）
- [ ] `meta_determinism` 在真实游戏上通过（或明确记录为「引擎不确定性」）

---

## 常见坑

| 现象 | 原因 | 处理 |
|---|---|---|
| AI 一直不进攻 | 快照里 `enemy_start` 为空且从未见过敌方建筑 | 提供静态地图信息（出生点/分矿） |
| AI 疯狂重复下令 | `order` 字段没填或永远为 `idle` | 正确映射单位状态机 |
| AI 抢玩家单位 | 只做了 AI 侧过滤，没做网关侧校验 | 补 `ControlRegistry.allows()` |
| 攻击命令全被拒 | 目标不可见时没有正确返回 | 用 `Reason.TARGET_NOT_VISIBLE` |
| 经济停摆 | 农民采集命令被拒（`NODE_FULL`）而 AI 不知情 | 检查 `NodeInfo.workers/max_workers` 是否实时 |
| 性能骤降 | `snapshot()` 每帧构造大量对象 | 降低 AI 频率、复用不可变对象 |
| 结果不可复现 | 引擎内使用了全局随机数 | 固定种子；或接受并在报告中标注 |

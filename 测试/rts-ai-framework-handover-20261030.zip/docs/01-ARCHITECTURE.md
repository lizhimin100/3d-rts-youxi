# 架构说明（ARCHITECTURE）

## 1. 设计目标与约束

| 目标 | 落实方式 |
|---|---|
| AI 不得硬编码到具体兵种/建筑 | 原型表 + 标签 + 克制矩阵 + 声明式计划，全部数据驱动 |
| 同时服务敌方人机与玩家副官 | 同一套 `RTSAgent`，两种 `profile` + `autonomy` 策略 |
| 玩家指令绝对优先 | 控制权登记表 + AI 侧过滤 + 网关侧拒绝（三道防线） |
| 当前没有真实游戏工程 | 自带无渲染 Mock Simulator，可确定性复现 |
| 游戏相关功能走抽象接口 | `rtscontract.IGameGateway` 单向依赖，AI 不 import 模拟器 |
| 可持续演进（英雄/野怪/新机制） | 契约层留扩展位，计划 DSL 与原型表可增量扩展 |

## 2. 分层

```
┌──────────────────────────────────────────────────────────────┐
│  rtsexam  考试系统（场景、断言、随机+回归种子、报告）        │
└───────────────┬──────────────────────────────┬───────────────┘
                │ 驱动                          │ 驱动
┌───────────────▼──────────────┐  ┌────────────▼───────────────┐
│  rtsai   AI 核心             │  │  rtsim  Mock Simulator      │
│  （只依赖 rtscontract）      │  │  （实现 IGameGateway）      │
└───────────────┬──────────────┘  └────────────┬───────────────┘
                │      rtscontract（契约层）    │
                └──────────────┬───────────────┘
                               ▼
        Vec2 / Catalog / WorldSnapshot / Command / ControlRegistry / IGameGateway
```

* **rtscontract**：纯数据与协议，无逻辑分支。真实游戏接入时这一层**不需要改**，
  只需要实现 `IGameGateway`。
* **rtsai**：决策。只读 `WorldSnapshot`，只写 `Command`。
* **rtsim**：模拟器。负责规则、迷雾、控制权校验、遥测。
* **rtsexam**：用例与执行器。可以同时依赖 AI 与模拟器（它是「考试院」，不是 AI 的一部分）。

`meta_no_game_dependency` 用例会扫描 `src/rtsai/**/*.py`，
一旦出现 `import rtsim` / `import rtsexam` / `import godot` 即判失败。

## 3. 一次 AI tick 的数据流

`RTSAgent.update()`（默认 5 Hz；模拟器 10 Hz，每 2 tick 调一次）：

```
snapshot = gateway.snapshot()            # ① 只读快照（敌方受迷雾过滤）
world.update(snapshot)                   # ② 信念状态：聚合 + 敌方建筑/构成记忆 + 收入 EMA
fog.update(snapshot); territory.update() # ③ 探索度、领土控制估计
sched.begin_tick(snapshot)               # ④ 命令预算/去重上下文
adjutant.ingest()                        # ⑤ 消化玩家意图（有玩家时）
posture = director.update()              # ⑥ 指标 → 选计划 → 产出 Posture
adjutant.apply(posture)                  # ⑦ 玩家意图/自治策略修正姿态
economy.update()                         # ⑧ 农民、人口、采集、生产建筑、静态防御
production.update()                      # ⑨ 兵种构成 → 训练队列
expansion.update()                       # ⑩ 分矿选址与建造
scout.update()                           # ⑪ 侦察
combat.update()                          # ⑫ 防守/进攻/撤退/微操/农民避险
sanity.update()                          # ⑬ 反愚蠢审计 + 即时修复
adjutant.maybe_suggest()                 # ⑭ 建议（不产生游戏行为）
```

顺序不是随意的：**经济先于生产**（先保证人口与农民），**生产先于扩张**（钱花在刀刃上），
**战斗在最后**（可以用到本 tick 最新的姿态），**审计在战斗之后**（能看到本 tick 已发的命令）。

## 4. 模块职责

### 4.1 契约层 `rtscontract`

| 文件 | 职责 |
|---|---|
| `vec.py` | `Vec2` 与几何/统计工具（分位数等，供报告使用） |
| `enums.py` | 命令种类、拒绝原因、控制权状态、订单种类、事件种类（全部字符串常量） |
| `catalog.py` | `Proto`（兵种/建筑原型）、`Attack`、`CombatRules`（克制矩阵）、`Catalog` |
| `snapshot.py` | `WorldSnapshot` 与 `UnitInfo/BuildingInfo/NodeInfo/MapInfo/FogInfo/PlayerInfo/EventInfo` |
| `commands.py` | `Command` / `CommandResult`（AI 的唯一出口） |
| `control.py` | `ControlRegistry`：玩家优先的控制权登记与判定 |
| `gateway.py` | `IGameGateway` 协议（`snapshot/issue/can_place/catalog/match_info/suggest/stats`） |
| `configio.py` | 配置定位与深合并（跨机器可用，不依赖 CWD） |

### 4.2 AI 核心 `rtsai`

| 文件 | 职责 | 关键点 |
|---|---|---|
| `agent.py` | 组装与主循环 | 唯一入口 `RTSAgent(gateway, profile).update()` |
| `world.py` | 信念状态 | 敌方建筑记忆（带 last_seen）、敌方构成记忆、收入 EMA |
| `fog.py` | 探索度/侦察目标 | 宏格未探索度 + 关键点加权的目标打分 |
| `territory.py` | 领土控制估计 | 宏格上「我方存在 vs 敌方存在」投影 |
| `combatmodel.py` | 战斗数学 | `dps / survival / power / army_score / estimate` |
| `plans.py` | 计划 DSL | `all/any/not` + 比较算子，纯数据 |
| `director.py` | 指标与姿态 | 计划选择带滞回、进攻目标打分（含敌方静态防御） |
| `economy.py` | 运营 | 农民/人口/采集/生产建筑/静态防御；主动补人口 |
| `production.py` | 生产与构成 | 每金战力 + 角色配额 + 对空底线 + 同兵种过载惩罚 |
| `combat.py` | 战斗 | 威胁过滤（只算有攻击力的敌人）、按「战场双方总兵力」估交换比、撤退点远离威胁 |
| `expansion.py` | 扩张 | 饱和触发、资源/距离/危险度选址、待建状态机 |
| `scouting.py` | 侦察 | 用低价值单位探索，按间隔换目标 |
| `sanity.py` | 反愚蠢 | 9 类问题检测 + 即时修复 + episode 计数 |
| `adjutant.py` | 副官 | 意图解析、姿态修正、建议 |
| `placement.py` | 建筑选址 | 环形探测 + 稳定哈希（跨进程确定性） |
| `scheduler.py` | 命令调度 | 幂等过滤、每 tick 预算、失败统计 |
| `profile.py` | 参数档案 | 内置默认 ← `config/ai_profile.json` ← 调用方覆盖 |

### 4.3 模拟器 `rtsim`

| 文件 | 职责 |
|---|---|
| `mapgen.py` | 旋转对称地图、岩石障碍、主矿/分矿、连通性校验 |
| `path.py` | 网格 A*（8 邻接、禁穿角）+ 路径拉直 |
| `sim.py` | 全部规则：采集、建造、生产、人口、战斗、迷雾、控制权、遥测 |
| `gateway.py` | `MockGateway` 实现 `IGameGateway` |
| `scenarios.py` | 场景装配（初始基地、额外单位/建筑、布局） |
| `harness.py` | `MatchRunner`：定步长循环 + 脚本事件 + 采样 |

### 4.4 考试系统 `rtsexam`

| 文件 | 职责 |
|---|---|
| `case.py` | `Check/Checker/CaseOutcome/CaseSpec` + 注册装饰器 |
| `harness.py` | `run_match()`：场景 + AI + 脚本化玩家 |
| `runner.py` | 种子池、并行执行、聚合、基线对比 |
| `report.py` | Markdown/JSON 报告 |
| `cases/*.py` | 15 个分类的 46 个用例 |

## 5. 关键设计取舍

### 5.1 为什么用「快照」而不是直接引用游戏对象

* 强制 AI 只能看到「该阵营能看到的信息」，战争迷雾天然生效；
* 快照是值对象，可缓存、可比较、可跨进程（考试并行）；
* 真实游戏接入时不需要暴露内部对象，降低耦合与作弊面。

### 5.2 为什么克制关系用矩阵而不是「A 克 B」表

WC3 的战斗本质是 `攻击类型 × 护甲类型` 的倍率。用矩阵后：

* 新增兵种自动纳入克制推理，无需维护 O(n²) 的克制表；
* AI 可以用同一套数学计算「任意两支部队的交换比」，用于进攻/撤退判断；
* 平衡性调整只改配置，不改代码。

### 5.3 为什么战略用「声明式计划」而不是硬编码状态机

```json
{"id": "press_advantage", "priority": 60, "stance": "pressure",
 "when": {"all": [{"metric": "army_ratio", "op": ">=", "value": 1.3},
                  {"metric": "army_supply", "op": ">=", "value": 16}]},
 "params": {"aggression": 0.8, "allow_expand": true}}
```

* 新流派（速攻/龟缩/双矿）只是新增一条数据；
* 阈值可被策划直接调，无需程序介入；
* 计划之间用 `priority + 滞回（plan_min_seconds）` 避免抖动。

### 5.4 控制权为什么改成「命令组生命周期」而不是 TTL

早期实现是 `PLAYER_MANUAL + TTL 8s`，外加一个「玩家订单 18 秒上限」的网关兜底。
实测（`AUDIT_REPORT.md` §4）暴露 4 个问题：

* 30 秒的长距离移动：TTL 在 8 秒就过期，命令一结束 AI **立刻**接管（宽限 0 秒）；
* 8 个单位一起走，**先到的先被接管**，一条命令被从中间劈开；
* 玩家按 Stop 之后 8 秒，AI 就把人拉走；
* 「18 秒上限」如果只实现在网关侧，25 秒的绕后命令会在第 18 秒被抢。

现在按**命令组**跟踪：

| 状态 | 进入条件 | 退出条件 |
|---|---|---|
| `PLAYER_ACTIVE` | 玩家下令（move/attack/attack_move/harvest/build） | **组内全部**单位 idle，或超过 120s 安全上限 |
| `PLAYER_GRACE` | 命令组结束 | 5 秒后 → `ADJUTANT` |
| `PLAYER_HOLDING` | STOP（30s）/ HOLD（无期限） | 到期或玩家再下令 |
| `PLAYER_LOCKED` | 显式锁定 | 解锁（→ `PLAYER_GRACE`） |

要点：**宽限期从"命令结束"开始算，不从"命令下达"开始算**；
**"结束"按组判定**，不按单个单位。TTL 只保留为"游戏无法提供订单状态"时的兜底。

### 5.5 命令调度器：为什么 AI 不直接调网关

`RTSAgent.update()` 里五个 Manager 依次运行，每个都可能对同一单位下令。如果直接
`gateway.issue()`，同一 tick 会出现 2~3 条互相覆盖的命令（审计实测 torture 场景 28 条），
而且「到达点后重发」会形成命令风暴（3.96 条/秒/单位）。

因此所有单位命令先进入 `CommandScheduler` 的 tick 队列，`agent.update()` 末尾统一 `flush()`：

| 机制 | 规则 |
|---|---|
| 同 tick 仲裁 | 每个单位只保留**最后一条**命令；管理器顺序即优先级（`sanity` 最后 → 恢复类命令最优先） |
| 合并 | 目标、类型、点位完全相同的单位合并成一条命令（1,017 单位时命令数从 47.9 降到 3.5） |
| 到达判定 | 单位已在目标点 0.9 格内 → 不再下令 |
| 重发节流 | 同类移动命令 0.6s 内不重复；`combat:defend/recall/retreat`、`sanity:*` **豁免** |
| 卡死锁定 | 连续两个快照 `stuck` → 暂停移动命令；网关支持 `can_reach` 且目标不可达时锁 120s |
| 失败退避 | 命令被 `place_invalid/invalid/busy` 拒绝 → 该单位 2s 内不再重试 |

建造类命令（`BUILD`/`TRAIN`/`SET_RALLY`）立即发出，不从队列走；`BUILD` 会把工人从
本 tick 队列里摘掉，避免被后续移动命令覆盖。

### 5.6 确定性

* 模拟器：固定 `dt`、种子化 RNG、无 wall-clock；
* AI：**不使用随机数**，选址角度用稳定哈希（不是 Python `hash()`，避免 `PYTHONHASHSEED`）；
* 快照/遥测都是可 JSON 序列化的纯数据 → `meta_determinism` 用 SHA1 比对两次运行。

## 6. 性能

单进程实测（88×88 地图、双方各 ~25 兵 + ~20 农民）：

| 指标 | 数值 |
|---|---|
| 模拟 + AI 吞吐 | 约 200–300 tick/s（10 Hz 下约 20–30 倍实时） |
| 6 分钟对局 | 约 2–3 秒 |
| 全量考试（128 局，8 进程） | 约 2 分钟 |

主要开销：每 tick 的单位状态机、每 2 tick 的视野重建、每 tick 一次的敌方目标搜索
（已用 6 格空间哈希 + 路径预算限制）。

## 7. 扩展点（面向未来）

| 未来需求 | 扩展位置 |
|---|---|
| 英雄（等级/技能/物品） | `catalog.Proto` 增加 `abilities`/`hero` 字段；`combatmodel` 增加技能期望值；新增 `rtsai/heroes.py` |
| 中立野怪/中立目标 | `snapshot` 增加 `neutral` 阵营与 `creep_camps`；`World` 增加打野收益评估；`plans.json` 增加「打野」计划 |
| 新机制（维护费/日夜/高地） | 在 `economy`/`combat` 增加独立评估器，通过 `Posture` 权重接入，不影响既有模块 |
| 更聪明的编队/包抄 | 新增 `rtsai/formation.py`，由 `combat._attack` 调用 |
| 学习型参数 | `ai_profile.json` 即参数向量，可被外部优化器直接搜索 |

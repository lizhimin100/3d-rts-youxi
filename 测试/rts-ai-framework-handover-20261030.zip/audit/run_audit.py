#!/usr/bin/env python
"""交接前工程审计入口。

用法::

    python audit/run_audit.py                  # 全量
    python audit/run_audit.py --only control   # 只跑某一组
    python audit/run_audit.py --skip perf      # 跳过性能

产出::

    audit/audit_result.json    机读全量结果
    audit/AUDIT_SUMMARY.md     人读摘要（自动生成）
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ROOT / "src"))

from audit_common import CaseResult, guard            # noqa: E402
import audit_control                                  # noqa: E402
import audit_faults                                   # noqa: E402
import audit_tactics                                  # noqa: E402
import audit_static                                   # noqa: E402


def run_group(name: str, fns, group: str) -> list[CaseResult]:
    out: list[CaseResult] = []
    for fn in fns:
        t0 = time.perf_counter()
        res = guard(fn, getattr(fn, "__name__", name), group)
        res.metrics["_elapsed_ms"] = round((time.perf_counter() - t0) * 1000, 1)
        out.append(res)
        print(f"  [{res.status:13s}] {res.name}  ({res.metrics['_elapsed_ms']} ms)", flush=True)
    return out


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default=None, help="control,fault,tactic,perf,static（逗号分隔）")
    ap.add_argument("--skip", default=None)
    args = ap.parse_args(argv)

    skip = {s.strip() for s in (args.skip or "").split(",") if s.strip()}
    only = {s.strip() for s in (args.only or "").split(",") if s.strip()} or None

    def want(k: str) -> bool:
        if only is not None:
            return k in only
        return k not in skip

    results: list[CaseResult] = []
    static: dict = {}

    if want("static"):
        print("== 静态审计 ==", flush=True)
        t0 = time.perf_counter()
        static = audit_static.collect()
        print(f"  完成 ({round((time.perf_counter() - t0) * 1000)} ms)", flush=True)

    if want("control"):
        print("== 副官控制权（10 场景）==", flush=True)
        results += run_group("control", audit_control.SCENARIOS, "control")

    if want("fault"):
        print("== 故障注入（14 项）==", flush=True)
        results += run_group("fault", audit_faults.FAULTS, "fault")

    if want("tactic"):
        print("== 生产/扩张/撤退/结构 ==", flush=True)
        results += run_group("tactic", audit_tactics.TACTIC_CASES, "tactic")

    if want("torture"):
        print("== 玩家折磨副官（11 步脚本 / 10 项检查）==", flush=True)
        import audit_torture
        results += run_group("torture", [audit_torture.torture], "torture")

    if want("perf"):
        print("== 性能（100/300/500/1000 单位）==", flush=True)
        from audit_perf import run_perf
        for r in run_perf():
            results.append(r)
            print(f"  [{r.status:13s}] {r.name}: {r.detail}", flush=True)

    payload = {
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "static": static,
        "cases": [r.as_dict() for r in results],
        "summary": {},
    }
    by_status: dict[str, int] = {}
    for r in results:
        by_status[r.status] = by_status.get(r.status, 0) + 1
    payload["summary"] = {
        "total": len(results),
        "by_status": by_status,
        "by_group": {g: sum(1 for r in results if r.group == g)
                     for g in sorted({r.group for r in results})},
    }
    out = HERE / "audit_result.json"
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    md = render_md(payload)
    (HERE / "AUDIT_SUMMARY.md").write_text(md, encoding="utf-8")
    print(f"\n结果：{out}")
    print(f"摘要：{HERE / 'AUDIT_SUMMARY.md'}")
    print("状态分布：" + ", ".join(f"{k}={v}" for k, v in sorted(by_status.items())))
    return 0


_ORDER = ["FAIL", "NOT_SUPPORTED", "WARNING", "PASS", "NOT_TESTABLE"]


def render_md(payload: dict) -> str:
    rows = payload["cases"]
    lines = ["# 审计实测摘要（自动生成）", "",
             f"生成时间：{payload['generated_at']}", "",
             "| 状态 | 数量 |", "|---|---|"]
    for st in _ORDER:
        n = sum(1 for r in rows if r["status"] == st)
        if n:
            lines.append(f"| {st} | {n} |")
    lines += ["", "## 明细", "", "| # | 用例 | 组 | 状态 | 说明 |", "|---|---|---|---|---|"]
    for i, r in enumerate(rows, 1):
        lines.append(f"| {i} | `{r['name']}` | {r['group']} | **{r['status']}** | "
                     f"{r['detail'].replace('|', '/').replace(chr(10), ' ')} |")
    lines += ["", "## 关键指标", ""]
    for r in rows:
        keep = {k: v for k, v in r["metrics"].items()
                if k not in ("traceback", "_elapsed_ms") and not isinstance(v, (list, dict))}
        if keep:
            lines.append(f"### {r['name']} ({r['status']})")
            lines.append("")
            lines.append("```")
            lines.append(", ".join(f"{k}={v}" for k, v in keep.items()))
            lines.append("```")
            lines.append("")
    return "\n".join(lines) + "\n"


if __name__ == "__main__":
    raise SystemExit(main())

"""第八部分：破坏性 / Fault Injection 测试。

目标不是「让 AI 赢」，而是回答四个问题：
1. 会不会崩？
2. 会不会死循环 / 永久卡在某状态？
3. 会不会无限刷命令？
4. 能不能取消或重新规划？

每个用例都用一个 ``FaultGateway`` 或猴子补丁注入单点故障，跑 40–90 秒，
统计：异常、命令数/秒、拒单原因分布、卡住 episode、恢复情况。
"""
from __future__ import annotations

import time
from typing import Any, Callable

from audit_common import (
    CaseResult, HZ, agent_for, army_ids, base_pos, make_sim, orders_of, profile,
)
from rtsai import RTSAgent
from rtscontract.commands import Command, CommandResult, reject
from rtscontract.enums import Cmd, Issuer, Reason
from rtsim import MockGateway
from rtsim.sim import Sim
import rtsim.sim as simmod


class _Src:
    team = 0
    id = -1
    proto = None


# --------------------------------------------------------------------------- 故障网关
class FaultGateway:
    """可注入故障的网关代理：AI 仍只能看到快照 / 发命令。"""

    def __init__(self, inner: MockGateway) -> None:
        self._inner = inner
        self.team = inner.team
        self.issuer = inner.issuer
        self.snapshot_hook: Callable[[Any], Any] | None = None
        self.issue_hook: Callable[[Command, MockGateway], CommandResult | None] | None = None
        self.snapshot_calls = 0
        self.issue_calls = 0

    def snapshot(self):
        self.snapshot_calls += 1
        snap = self._inner.snapshot()
        if self.snapshot_hook is not None:
            out = self.snapshot_hook(snap)
            if out is not None:
                snap = out
        return snap

    def issue(self, cmd: Command) -> CommandResult:
        self.issue_calls += 1
        if self.issue_hook is not None:
            out = self.issue_hook(cmd, self._inner)
            if out is not None:
                return out
        return self._inner.issue(cmd)

    def can_place(self, proto_id, point):
        return self._inner.can_place(proto_id, point)

    def can_reach(self, unit_ids, point):
        return self._inner.can_reach(unit_ids, point)

    def catalog(self):
        return self._inner.catalog()

    def match_info(self):
        return self._inner.match_info()

    def suggest(self, payload):
        return self._inner.suggest(payload)

    def stats(self):
        return self._inner.stats()


# --------------------------------------------------------------------------- 驱动
def run_guarded(sim: Sim, ag: RTSAgent, duration: float,
                on_tick: Callable[[Sim], None] | None = None) -> str:
    """跑一段，捕获 AI 侧任何异常；返回错误字符串（空=没崩）。"""
    max_ticks = int(duration * sim.tick_hz)
    while sim.tick < max_ticks and not sim.over:
        sim.step()
        if on_tick is not None:
            on_tick(sim)
        if sim.tick % 2 == 0:
            try:
                ag.update()
            except Exception as exc:  # noqa: BLE001
                import traceback
                return f"{type(exc).__name__}: {exc}\n{traceback.format_exc(limit=6)}"
    return ""


def _snapshot_metrics(sim: Sim, ag: RTSAgent, gw: FaultGateway, err: str,
                      duration: float, label: str) -> CaseResult:
    stats = ag.stats()
    cmds = stats["commands"]
    sent = cmds["commands_sent"]
    per_sec = sent / max(1e-6, duration)
    rej = dict(cmds.get("failures", {}))
    issues = stats["sanity"]["issues"]
    stuck = issues.get("stuck_units", 0)
    hard = sum(issues.values())
    status = "PASS"
    reasons = []
    if err:
        status = "FAIL"
        reasons.append("AI 抛异常")
    if per_sec > 40.0:
        status = "FAIL"
        reasons.append(f"命令风暴 {per_sec:.1f}/s")
    if stuck > 12:
        status = "WARNING" if status == "PASS" else status
        reasons.append(f"卡住 episode {stuck}")
    if rej.get(Reason.TARGET_INVALID, 0) > 80:
        status = "WARNING" if status == "PASS" else status
        reasons.append("大量 target_invalid（引用已失效目标）")
    if rej.get(Reason.LOCKED, 0) or rej.get(Reason.PLAYER_ORDER_ACTIVE, 0):
        status = "FAIL"
        reasons.append("越权触碰玩家单位")
    return CaseResult(
        label, "fault", status,
        "；".join(reasons) or "系统自行恢复，无崩溃/无命令风暴",
        {
            "exception": err.splitlines()[0] if err else "",
            "commands_sent": sent,
            "commands_per_sec": round(per_sec, 2),
            "commands_dropped": cmds.get("commands_dropped", 0),
            "rejections": rej,
            "sanity_episodes": hard,
            "stuck_episodes": stuck,
            "army_alive": len(army_ids(sim, 0)),
            "workers_alive": len([u for u in sim.units if u.alive and u.team == 0
                                  and u.proto.harvest is not None]),
            "snapshot_calls": gw.snapshot_calls,
            "issue_calls": gw.issue_calls,
        },
    )


def _kill_unit(sim: Sim, uid: int) -> bool:
    u = sim.ents.get(uid)
    if u is None or not getattr(u, "alive", False):
        return False
    sim._kill(u, _Src())
    return True


def _kill_any(sim: Sim, pred) -> bool:
    for e in list(sim.units) + list(sim.buildings):
        if e.alive and pred(e):
            sim._kill(e, _Src())
            return True
    return False


# --------------------------------------------------------------------------- 1
def f1_unit_dies_between_snapshot_and_issue() -> CaseResult:
    """AI 刚决定攻击某单位，该单位在命令下达前死亡。"""
    sim = make_sim(my_units=(("melee", 6),), enemy_units=(("melee", 3),),
                   enemy_base="none", workers=6)
    gw = FaultGateway(MockGateway(sim, 0))
    ag = RTSAgent(gw, profile())
    state = {"n": 0}

    def hook(cmd: Command, inner: MockGateway):
        if cmd.kind == Cmd.ATTACK and cmd.target is not None and state["n"] < 6:
            if _kill_unit(sim, cmd.target):
                state["n"] += 1
        return None

    gw.issue_hook = hook
    err = run_guarded(sim, ag, 50)
    return _snapshot_metrics(sim, ag, gw, err, 50, "f1_target_dies_before_issue")


# --------------------------------------------------------------------------- 2
def f2_building_dies_under_ai() -> CaseResult:
    """AI 正在生产/集结点所在的建筑被摧毁。"""
    sim = make_sim(my_units=(("melee", 5),), enemy_units=(("melee", 4),),
                   enemy_base="none", workers=6)
    gw = FaultGateway(MockGateway(sim, 0))
    ag = RTSAgent(gw, profile())
    state = {"n": 0}

    def hook(cmd: Command, inner: MockGateway):
        if cmd.building is not None and state["n"] < 3:
            b = sim.ents.get(cmd.building)
            if b is not None and getattr(b, "alive", False):
                sim._kill(b, _Src())
                state["n"] += 1
        return None

    gw.issue_hook = hook
    err = run_guarded(sim, ag, 50)
    res = _snapshot_metrics(sim, ag, gw, err, 50, "f2_building_dies")
    res.metrics["buildings_killed"] = state["n"]
    return res


# --------------------------------------------------------------------------- 3
def f3_production_cancelled() -> CaseResult:
    """每 tick 清空生产队列（相当于玩家/系统不断取消生产）。"""
    sim = make_sim(my_units=(("melee", 4),), workers=6)
    gw = FaultGateway(MockGateway(sim, 0))
    ag = RTSAgent(gw, profile())
    st = {"max_q": 0, "clears": 0}

    def on_tick(s: Sim) -> None:
        for b in s.buildings:
            if b.alive and b.team == 0 and b.queue:
                st["max_q"] = max(st["max_q"], len(b.queue))
                b.queue.clear()
                st["clears"] += 1

    err = run_guarded(sim, ag, 50, on_tick=on_tick)
    res = _snapshot_metrics(sim, ag, gw, err, 50, "f3_production_cancelled")
    res.metrics.update({"queue_clears": st["clears"], "max_queue_observed": st["max_q"],
                        "trained": ag.production.trained})
    if st["max_q"] > 4:
        res.status = "WARNING"
        res.detail += "；队列超过 catalog max_queue 说明去重依赖过期快照"
    return res


# --------------------------------------------------------------------------- 4
def f4_construction_cancelled() -> CaseResult:
    """在建建筑不断被摧毁（相当于建造被取消）。"""
    sim = make_sim(my_units=(), workers=6, start_gold=900.0)
    gw = FaultGateway(MockGateway(sim, 0))
    ag = RTSAgent(gw, profile())
    st = {"kills": 0, "attempts": 0}

    def on_tick(s: Sim) -> None:
        if s.tick % 20 == 0 and st["kills"] < 8:
            if _kill_any(s, lambda e: e.team == 0 and hasattr(e, "complete") and not e.complete):
                st["kills"] += 1
                st["attempts"] = ag.economy.build_attempts

    err = run_guarded(sim, ag, 80, on_tick=on_tick)
    res = _snapshot_metrics(sim, ag, gw, err, 80, "f4_construction_cancelled")
    res.metrics.update({"construction_killed": st["kills"],
                        "build_attempts": ag.economy.build_attempts})
    if st["kills"] >= 8 and ag.economy.build_attempts < 10:
        res.status = "WARNING"
        res.detail = "被摧毁 8 次后建造尝试明显减少 → 可能长期卡在「pending」"
    return res


# --------------------------------------------------------------------------- 5
def f5_resource_nodes_vanish() -> CaseResult:
    """所有资源点在 20 秒时枯竭。"""
    sim = make_sim(my_units=(("melee", 4),), workers=8)
    gw = FaultGateway(MockGateway(sim, 0))
    ag = RTSAgent(gw, profile())
    st = {"done": False}

    def on_tick(s: Sim) -> None:
        if s.tick == 200 and not st["done"]:
            st["done"] = True
            for n in s.nodes:
                n.remaining = 0.0
            s.refresh_fog()

    err = run_guarded(sim, ag, 60, on_tick=on_tick)
    res = _snapshot_metrics(sim, ag, gw, err, 60, "f5_nodes_depleted")
    res.metrics["idle_workers"] = len([u for u in sim.units if u.alive and u.team == 0
                                       and u.proto.harvest is not None
                                       and u.order in ("idle", "stop")])
    if res.metrics["idle_workers"] > 6:
        res.status = "WARNING"
        res.detail = "资源枯竭后农民全部 idle，AI 没有「无矿可采」的处置策略"
    return res


# --------------------------------------------------------------------------- 6
def f6_all_enemies_vanish() -> CaseResult:
    """AI 锁定的攻击目标全部消失。"""
    sim = make_sim(my_units=(("melee", 8),), enemy_units=(("melee", 6),),
                   enemy_base="none", workers=6)
    gw = FaultGateway(MockGateway(sim, 0))
    ag = RTSAgent(gw, profile())
    st = {"done": False}

    def on_tick(s: Sim) -> None:
        if s.tick == 300 and not st["done"]:
            st["done"] = True
            for u in list(s.units):
                if u.alive and u.team == 1:
                    s._kill(u, _Src())

    err = run_guarded(sim, ag, 70, on_tick=on_tick)
    res = _snapshot_metrics(sim, ag, gw, err, 70, "f6_enemies_vanish")
    res.metrics["attack_mode_after"] = ag.combat.mode
    return res


# --------------------------------------------------------------------------- 7
def f7_path_request_fails() -> CaseResult:
    """寻路彻底失败（引擎返回空路径），持续 40 秒。"""
    sim = make_sim(my_units=(("melee", 8),), workers=6)
    gw = FaultGateway(MockGateway(sim, 0))
    ag = RTSAgent(gw, profile())
    orig_fp, orig_sl = simmod.find_path, simmod.straight_line_clear
    simmod.find_path = lambda *a, **k: []
    simmod.straight_line_clear = lambda *a, **k: False
    try:
        err = run_guarded(sim, ag, 45)
    finally:
        simmod.find_path, simmod.straight_line_clear = orig_fp, orig_sl
    res = _snapshot_metrics(sim, ag, gw, err, 45, "f7_path_fail")
    res.metrics["stuck_flag"] = sum(1 for u in sim.units if u.alive and u.stuck)
    return res


# --------------------------------------------------------------------------- 8
def f8_path_fail_long() -> CaseResult:
    """连续路径失败 90 秒：观察 STOP→MOVE 抖动循环。"""
    sim = make_sim(my_units=(("melee", 8),), workers=4)
    gw = FaultGateway(MockGateway(sim, 0))
    ag = RTSAgent(gw, profile())
    orig_fp, orig_sl = simmod.find_path, simmod.straight_line_clear
    simmod.find_path = lambda *a, **k: []
    simmod.straight_line_clear = lambda *a, **k: False
    try:
        err = run_guarded(sim, ag, 90)
    finally:
        simmod.find_path, simmod.straight_line_clear = orig_fp, orig_sl
    res = _snapshot_metrics(sim, ag, gw, err, 90, "f8_path_fail_long")
    res.metrics["stop_orders"] = len(orders_of(sim, who=Issuer.ADJUTANT, t0=0))

    # 判据不是「绝对命令数」，而是「是否收敛」：
    # 前 30 秒会反复尝试，后 30 秒在指数退避下应显著下降。
    def window(t0: float, t1: float) -> int:
        return len(orders_of(sim, who=Issuer.ADJUTANT, t0=int(t0 * HZ), t1=int(t1 * HZ)))

    w1, w2, w3 = window(0, 30), window(30, 60), window(60, 90)
    res.metrics["cmd_windows"] = [w1, w2, w3]
    converged = w3 <= max(4, int(w1 * 0.5))
    ok = converged and res.metrics["commands_sent"] <= 200
    res.status = "PASS" if ok else ("WARNING" if w3 <= w1 else "FAIL")
    res.detail = (
        f"路径永久失败 90 秒：命令 {res.metrics['commands_sent']} 条 / STOP {res.metrics['stop_orders']} 条；"
        f"每 30 秒命令数 {w1} → {w2} → {w3}，"
        + ("指数退避生效，系统收敛（后 30 秒 ≤ 前 30 秒的一半）。"
           if converged else "未收敛：后 30 秒命令数没有下降。")
    )
    return res


# --------------------------------------------------------------------------- 9
def f9_commands_rejected() -> CaseResult:
    """网关持续拒绝 MOVE（例如真实游戏里地形不可达）。"""
    sim = make_sim(my_units=(("melee", 8),), workers=6)
    gw = FaultGateway(MockGateway(sim, 0))
    ag = RTSAgent(gw, profile())

    def hook(cmd: Command, inner: MockGateway):
        if cmd.kind == Cmd.MOVE:
            return reject(Reason.PLACE_INVALID, "injected")
        return None

    gw.issue_hook = hook
    err = run_guarded(sim, ag, 40)
    res = _snapshot_metrics(sim, ag, gw, err, 40, "f9_move_rejected")
    res.metrics["move_rejects"] = res.metrics["rejections"].get(Reason.PLACE_INVALID, 0)
    if res.metrics["commands_per_sec"] > 20:
        res.status = "FAIL"
        res.detail = "命令被持续拒绝时 AI 每 tick 重试，没有任何退避"
    return res


# --------------------------------------------------------------------------- 10
def f10_units_cannot_move() -> CaseResult:
    """单位完全无法移动（speed=0 / 被墙卡死）。"""
    sim = make_sim(my_units=(("melee", 6),), workers=4)
    gw = FaultGateway(MockGateway(sim, 0))
    ag = RTSAgent(gw, profile())
    orig = Sim._advance

    def frozen(self, u, point, stop_dist, chase=False):  # noqa: ANN001
        return False

    Sim._advance = frozen
    try:
        err = run_guarded(sim, ag, 40)
    finally:
        Sim._advance = orig
    res = _snapshot_metrics(sim, ag, gw, err, 40, "f10_units_frozen")
    if err == "" and res.metrics["stuck_episodes"] >= 10:
        res.status = "FAIL"
        res.detail = (f"单位永久无法移动时 sanity 反复触发：{res.metrics['stuck_episodes']} 个 stuck episode / "
                      f"40 秒，命令率 {res.metrics['commands_per_sec']}/s 不收敛（STOP→MOVE 抖动）。")
    return res


# --------------------------------------------------------------------------- 11
def f11_stale_snapshot() -> CaseResult:
    """网关返回 3 秒前的快照（网络/线程/双缓冲延迟）。"""
    sim = make_sim(my_units=(("melee", 6),), workers=6)
    gw = FaultGateway(MockGateway(sim, 0))
    buf: list[Any] = []

    def hook(snap):
        buf.append(snap)
        if len(buf) <= 15:
            return snap
        return buf[-16]

    gw.snapshot_hook = hook
    ag = RTSAgent(gw, profile())
    err = run_guarded(sim, ag, 50)
    res = _snapshot_metrics(sim, ag, gw, err, 50, "f11_stale_snapshot")
    res.metrics["ai_time_lag_sec"] = round(sim.time - (ag.world.time or 0.0), 2)
    return res


# --------------------------------------------------------------------------- 12
def f12_state_inconsistent() -> CaseResult:
    """同一单位连续两 tick 状态不一致（传送 / 位置跳变）。"""
    sim = make_sim(my_units=(("melee", 6),), workers=6)
    gw = FaultGateway(MockGateway(sim, 0))
    ag = RTSAgent(gw, profile())
    n = {"i": 0}

    def hook(cmd: Command, inner: MockGateway):
        n["i"] += 1
        if n["i"] % 7 == 0 and cmd.units:
            u = sim.ents.get(cmd.units[0])
            if u is not None and getattr(u, "alive", False):
                u.pos = sim._nearest_walkable(u.pos + __import__("rtscontract.vec", fromlist=["Vec2"]).Vec2(6.0, -4.0))
        return None

    gw.issue_hook = hook
    err = run_guarded(sim, ag, 50)
    return _snapshot_metrics(sim, ag, gw, err, 50, "f12_state_jitter")


# --------------------------------------------------------------------------- 13
def f13_dead_ids() -> CaseResult:
    """玩家/AI 引用不存在的单位 id。"""
    sim = make_sim(my_units=(("melee", 4),), enemy_units=(("melee", 2),),
                   enemy_base="none", workers=4)
    gw = FaultGateway(MockGateway(sim, 0))
    ag = RTSAgent(gw, profile())
    st = {"player_rej": 0, "ai_bad": 0}

    def on_tick(s: Sim) -> None:
        if s.tick == 100:
            r = s.player_command(Command(Cmd.MOVE, Issuer.PLAYER, 0, (999999,), point=base_pos(s)))
            st["player_rej"] = 0 if r.ok else 1
        if s.tick == 120:
            for u in list(s.units):
                if u.team == 1:
                    s._kill(u, _Src())

    def hook(cmd: Command, inner: MockGateway):
        if cmd.target == 999999:
            return inner.issue(cmd)
        return None

    gw.issue_hook = hook
    err = run_guarded(sim, ag, 40, on_tick=on_tick)
    res = _snapshot_metrics(sim, ag, gw, err, 40, "f13_dead_ids")
    res.metrics["player_cmd_rejected"] = st["player_rej"]
    return res


# --------------------------------------------------------------------------- 14
def f14_player_takeover_midflight() -> CaseResult:
    """玩家在 AI 正在指挥时突然接管同一批单位。"""
    sim = make_sim(player=True, my_units=(("melee", 8),), enemy_units=(("melee", 5),),
                   enemy_base="none", workers=6)
    gw = FaultGateway(MockGateway(sim, 0))
    ag = RTSAgent(gw, profile())
    st = {"ids": set(), "t0": 0}

    def on_tick(s: Sim) -> None:
        if s.tick == 240:
            ids = army_ids(s, 0)
            st["ids"], st["t0"] = set(ids), s.tick
            s.player_command(Command(Cmd.MOVE, Issuer.PLAYER, 0, tuple(ids),
                                     point=base_pos(s) + type(base_pos(s))(12.0, 12.0)))

    err = run_guarded(sim, ag, 45, on_tick=on_tick)
    res = _snapshot_metrics(sim, ag, gw, err, 45, "f14_player_takeover")
    ids, t0 = st["ids"], st["t0"]
    during = orders_of(sim, who=Issuer.ADJUTANT, uids=ids, t0=t0, t1=t0 + 80)
    res.metrics["ai_orders_during_ttl"] = len(during)
    res.metrics["control_blocked"] = sim.stats[0].get("control_blocked", 0)
    if during:
        res.status = "FAIL"
        res.detail = "玩家接管后的 TTL 窗口内 AI 仍在指挥这些单位"
    return res


FAULTS = (
    f1_unit_dies_between_snapshot_and_issue,
    f2_building_dies_under_ai,
    f3_production_cancelled,
    f4_construction_cancelled,
    f5_resource_nodes_vanish,
    f6_all_enemies_vanish,
    f7_path_request_fails,
    f8_path_fail_long,
    f9_commands_rejected,
    f10_units_cannot_move,
    f11_stale_snapshot,
    f12_state_inconsistent,
    f13_dead_ids,
    f14_player_takeover_midflight,
)

"""静态审计：不跑模拟，纯靠 AST / 文本统计取证。

回答「25 项清单」里那些只能靠读代码判定的条目：
未声明的单位、魔法数字、死配置、未使用的契约字段、声明了却不存在的能力。
"""
from __future__ import annotations

import ast
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
AI = SRC / "rtsai"
CONTRACT = SRC / "rtscontract"


def _texts(base: Path) -> dict[str, str]:
    return {str(p.relative_to(ROOT)): p.read_text(encoding="utf-8")
            for p in sorted(base.rglob("*.py"))}


AI_TEXTS = _texts(AI)
CONTRACT_TEXTS = _texts(CONTRACT)


# --------------------------------------------------------------------------- 1
def numeric_literals() -> dict[str, Any]:
    """收集 AI 源码里 >= 8 的数字字面量（距离/秒/金这类「有量纲」常量）。"""
    rows: list[dict[str, Any]] = []
    for rel, text in AI_TEXTS.items():
        tree = ast.parse(text)
        for node in ast.walk(tree):
            if not isinstance(node, ast.Constant):
                continue
            v = node.value
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                continue
            if abs(float(v)) < 8.0:
                continue
            rows.append({"file": Path(rel).name, "line": node.lineno, "value": float(v)})
    by_file: dict[str, list[float]] = defaultdict(list)
    for r in rows:
        by_file[r["file"]].append(r["value"])
    return {
        "total": len(rows),
        "by_file": {k: sorted(v) for k, v in sorted(by_file.items())},
        "distinct": sorted({r["value"] for r in rows}),
        "rows": rows,
    }


# --------------------------------------------------------------------------- 2
def dead_config_keys() -> dict[str, Any]:
    """config 里声明、但除 profile.py 默认值外没有任何读取方的键。"""
    raw = json.loads((ROOT / "config" / "ai_profile.json").read_text(encoding="utf-8"))
    keys: list[str] = []

    def walk(d: Any) -> None:
        if isinstance(d, dict):
            for k, v in d.items():
                if isinstance(v, dict):
                    walk(v)
                else:
                    keys.append(k)

    walk(raw)
    body = "\n".join(t for rel, t in AI_TEXTS.items() if not rel.endswith("profile.py"))
    dead = []
    for k in sorted(set(keys)):
        if k in ("version", "roles"):
            continue
        if not re.search(rf"\b{re.escape(k)}\b", body):
            dead.append(k)
    return {"declared": len(set(keys)), "dead": dead, "dead_count": len(dead)}


# --------------------------------------------------------------------------- 3
def contract_field_usage() -> dict[str, Any]:
    """快照里暴露给 AI 的字段，AI 实际读了几个。"""
    unit_fields = ["uid", "proto", "team", "pos", "hp", "hp_max", "order", "order_target",
                   "order_point", "order_owner", "control", "carrying", "cd_frac", "stuck",
                   "resource_node", "home", "since_order"]
    building_fields = ["bid", "proto", "team", "pos", "hp", "hp_max", "complete", "progress",
                       "queue", "queue_time", "rally", "builders", "control", "on_resource"]
    node_fields = ["nid", "pos", "remaining", "max_workers", "workers", "kind"]
    snap_fields = ["gold", "supply_used", "supply_cap", "supply_max", "units", "buildings",
                   "nodes", "map", "fog", "player", "events", "enemy_team", "game_over", "winner"]

    def usage(fields: list[str]) -> dict[str, int]:
        """同时统计属性访问 (``x.field``) 与字符串访问 (``getattr(x, "field")``)。"""
        out = {}
        for f in fields:
            n = 0
            for text in AI_TEXTS.values():
                n += len(re.findall(rf"\.{re.escape(f)}\b", text))
                n += len(re.findall(rf"[\"']{re.escape(f)}[\"']", text))
            out[f] = n
        return out

    u, b, n, s = usage(unit_fields), usage(building_fields), usage(node_fields), usage(snap_fields)
    return {
        "unit": u, "building": b, "node": n, "snapshot": s,
        "unused": {
            "unit": [k for k, v in u.items() if v == 0],
            "building": [k for k, v in b.items() if v == 0],
            "node": [k for k, v in n.items() if v == 0],
            "snapshot": [k for k, v in s.items() if v == 0],
        },
    }


# --------------------------------------------------------------------------- 4
def declared_but_missing() -> dict[str, Any]:
    """协议里声明、但没有实现路径的能力。"""
    all_src = "\n".join(list(AI_TEXTS.values()) + list(CONTRACT_TEXTS.values()))
    sim_src = (SRC / "rtsim" / "sim.py").read_text(encoding="utf-8")
    enums = (CONTRACT / "enums.py").read_text(encoding="utf-8")
    return {
        "patrol": {
            "order_kind_declared": "PATROL = \"patrol\"" in enums,
            "cmd_declared": "PATROL = \"patrol\"" in enums.split("class Cmd")[1].split("class Reason")[0],
            "sim_handler": "_cmd_patrol" in sim_src,
        },
        "repair": {
            "cmd_declared": "REPAIR" in enums,
            "sim_implemented": "尚未实现" not in sim_src.split("def _cmd_repair")[1].split("def ")[0],
        },
        "cancel_train_used_by_ai": "CANCEL_TRAIN" in "\n".join(AI_TEXTS.values()),
        "assist_used_by_ai": "ASSIST" in "\n".join(AI_TEXTS.values()),
        "events_read_by_ai": "snapshot.events" in all_src or ".events" in "\n".join(AI_TEXTS.values()),
    }


# --------------------------------------------------------------------------- 5
def loops_and_globals() -> dict[str, Any]:
    while_true = []
    globals_mut = []
    for rel, text in AI_TEXTS.items():
        for i, line in enumerate(text.splitlines(), 1):
            if re.search(r"while\s+True", line):
                while_true.append(f"{Path(rel).name}:{i}")
        if re.search(r"^_[A-Z_]+\s*[:=]", text, re.M):
            for i, line in enumerate(text.splitlines(), 1):
                if re.match(r"^_[A-Z_]+\s*[:=]", line):
                    globals_mut.append(f"{Path(rel).name}:{i} {line.strip()[:60]}")
    return {"while_true": while_true, "module_level_state": globals_mut}


# --------------------------------------------------------------------------- 6
def hardcoded_proto_names() -> dict[str, Any]:
    """AI 源码里是否出现具体兵种/建筑 id（应当只出现在配置里）。"""
    catalog = json.loads((ROOT / "config" / "catalog.json").read_text(encoding="utf-8"))
    ids = [p["id"] for sec in ("units", "buildings") for p in catalog[sec]]
    hits: dict[str, list[str]] = {}
    for rel, text in AI_TEXTS.items():
        for pid in ids:
            for m in re.finditer(rf"[\"']{re.escape(pid)}[\"']", text):
                line = text[: m.start()].count("\n") + 1
                hits.setdefault(Path(rel).name, []).append(f"L{line}:{pid}")
    return {"proto_ids": ids, "hits": hits}


def collect() -> dict[str, Any]:
    return {
        "numeric_literals": numeric_literals(),
        "dead_config": dead_config_keys(),
        "field_usage": contract_field_usage(),
        "declared_but_missing": declared_but_missing(),
        "loops": loops_and_globals(),
        "hardcoded_protos": hardcoded_proto_names(),
    }


if __name__ == "__main__":
    print(json.dumps(collect(), ensure_ascii=False, indent=2))

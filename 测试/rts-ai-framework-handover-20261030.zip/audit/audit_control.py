"""第四部分：副官控制权 / Player Intent Ownership 取证。

对当前实现做 10 个场景的实测，回答一个问题：
**玩家下过命令之后，AI 到底在什么时刻、因为什么条件重新接管？**

观测口径
--------
* 「AI 命令」= ``sim.orders_log`` 中 owner == adjutant 的记录（模拟器在真正写订单时才记）；
* 「到达」= 玩家命令的目标单位全部回到 idle 的那个 tick；
* ``grace`` = (AI 首次重新命令的 tick − 到达 tick) / tick_hz，单位秒。
"""
from __future__ import annotations

from typing import Any

from audit_common import (
    CaseResult, HZ, army_ids, agent_for, base_pos, first_tick, make_sim,
    orders_of, run,
)
from rtscontract.commands import Command
from rtscontract.enums import PROTECTED_CONTROL, Cmd, Issuer, OrderKind, Reason
from rtscontract.vec import Vec2


class _Src:
    """伪造伤害来源（仅供用例杀死建筑）。"""
    team = 0
    id = -1
    proto = None


def _kill_building(sim, bid: int) -> bool:
    b = next((x for x in sim.buildings if x.id == bid), None)
    if b is None:
        return False
    sim._kill(b, _Src())
    return True


def _watch_arrival(sim, ids: set[int]) -> int | None:
    us = [u for u in sim.units if u.id in ids and u.alive]
    if not us or len(us) != len(ids):
        return None
    if all(u.order == OrderKind.IDLE for u in us):
        return sim.tick
    return None


def _kinds(sim, ids) -> dict[str, int]:
    """统计这批单位当前的控制权状态分布。"""
    out: dict[str, int] = {}
    for uid in ids:
        if uid in sim.ents:
            k = sim.control.kind_of(uid)
            out[k] = out.get(k, 0) + 1
    return out


def _protected(kinds: dict[str, int]) -> bool:
    """这批单位是否全部处于"AI 不得下令"的状态。"""
    return bool(kinds) and all(k in PROTECTED_CONTROL for k in kinds)


# --------------------------------------------------------------------------- 1
def s1_long_move() -> CaseResult:
    """玩家下达 30 秒级长距离移动，观察 AI 是否中途拆队 / 到达后多久接管。"""
    sim = make_sim(player=True, my_units=(("melee", 8),), workers=6)
    ag = agent_for(sim)
    st: dict[str, Any] = {"ids": set(), "t0": 0, "idle_at": {}}

    def on_tick(s) -> None:
        if s.tick == 20:
            ids = army_ids(s, 0)
            tgt = Vec2(s.width - 15.0, s.height - 15.0)
            s.player_command(Command(Cmd.MOVE, Issuer.PLAYER, 0, tuple(ids), point=tgt))
            st["ids"] = set(ids)
            st["t0"] = s.tick
        elif st["ids"]:
            for u in s.units:
                if (u.id in st["ids"] and u.alive
                        and u.id not in st["idle_at"] and u.order == OrderKind.IDLE):
                    st["idle_at"][u.id] = s.tick

    run(sim, {0: ag}, duration=95, on_tick=on_tick)
    ids, t0 = st["ids"], st["t0"]
    idle_at: dict[int, int] = st["idle_at"]
    last_arrive = max(idle_at.values()) if idle_at else None
    graces: list[float] = []
    early: list[int] = []
    for uid, ta in idle_at.items():
        rows = orders_of(sim, who=Issuer.ADJUTANT, uids={uid}, t0=ta)
        if rows:
            graces.append((rows[0][0] - ta) / HZ)
            if last_arrive is not None and rows[0][0] < last_arrive:
                early.append(uid)
    during = orders_of(sim, who=Issuer.ADJUTANT, uids=ids, t0=t0, t1=last_arrive)
    after = orders_of(sim, who=Issuer.ADJUTANT, uids=ids, t0=last_arrive) if last_arrive else []
    gap_last = (first_tick(after) - last_arrive) / HZ if (after and last_arrive) else None
    march = (last_arrive - t0) / HZ if last_arrive else None
    status = "FAIL" if (early or (gap_last is not None and gap_last < 1.0)) else "PASS"
    return CaseResult(
        "s1_long_move_30s", "control", status,
        f"{len(early)}/{len(ids)} 个单位还没等整条命令结束就被 AI 接管；"
        f"最后一个单位到达后 {gap_last}s AI 重新下令。",
        {
            "march_seconds": march,
            "ttl_seconds": sim.control.manual_ttl_ticks / HZ,
            "units_taken_over_early": len(early),
            "orders_before_last_arrival": len(during),
            "orders_after": len(after),
            "grace_after_last_arrival_seconds": gap_last,
            "grace_per_unit_seconds": [round(g, 2) for g in graces],
            "control_blocked": sim.stats[0].get("control_blocked", 0),
        },
    )


# --------------------------------------------------------------------------- 2
def s2_patrol() -> CaseResult:
    """协议里是否有「巡逻」命令？"""
    sim = make_sim(player=True, my_units=(("melee", 3),))
    uid = army_ids(sim, 0)[0]
    has_const = hasattr(Cmd, "PATROL")
    res = sim.issue(Command("patrol", Issuer.PLAYER, 0, (uid,), point=base_pos(sim)))
    ok = res.ok
    return CaseResult(
        "s2_patrol", "control",
        "NOT_SUPPORTED" if not (has_const or ok) else "PASS",
        "OrderKind 声明了 patrol，但 Cmd 没有 PATROL、Sim 也没有处理器；"
        "玩家/AI 都无法下达巡逻命令，控制权语义里的 patrol 分支是死代码。",
        {
            "cmd_has_patrol": has_const,
            "sim_accepts_patrol": ok,
            "reject_reason": res.reason,
            "order_kind_has_patrol": hasattr(OrderKind, "PATROL"),
        },
    )


# --------------------------------------------------------------------------- 3
def s3_attack_building_dies() -> CaseResult:
    """玩家攻击一个中途死亡的建筑：命令结束后是否还有宽限。"""
    sim = make_sim(player=True, my_units=(("melee", 6),), require_both_teams=False)
    farm = sim.add_building("farm", 1, base_pos(sim) + Vec2(13.0, 2.0), complete=True)
    sim.refresh_fog()
    ag = agent_for(sim)
    grace = sim.control.grace_ticks
    st: dict[str, Any] = {"ids": set(), "t0": 0, "arrive": None, "bid": farm.id,
                          "k1": {}, "k2": {}}

    def on_tick(s) -> None:
        if s.tick == 20:
            ids = army_ids(s, 0)
            s.player_command(Command(Cmd.ATTACK, Issuer.PLAYER, 0, tuple(ids), target=st["bid"]))
            st["ids"], st["t0"] = set(ids), s.tick
        elif s.tick == 60:
            _kill_building(s, st["bid"])
        elif st["ids"] and st["arrive"] is None:
            st["arrive"] = _watch_arrival(s, st["ids"])
        if st["arrive"] is not None:
            if s.tick == st["arrive"] + 10:
                st["k1"] = _kinds(s, st["ids"])
            elif s.tick == st["arrive"] + grace + 20:
                st["k2"] = _kinds(s, st["ids"])

    run(sim, {0: ag}, duration=75, on_tick=on_tick)
    ids, t0, arrive = st["ids"], st["t0"], st["arrive"]
    k1, k2 = st["k1"], st["k2"]
    early_ok = _protected(k1)
    released = bool(k2) and all(k == "adjutant" for k in k2)
    during = orders_of(sim, who=Issuer.ADJUTANT, uids=ids, t0=t0, t1=arrive)
    return CaseResult(
        "s3_target_dies_mid_order", "control",
        "PASS" if (early_ok and released and not during) else "FAIL",
        f"目标提前死亡后：命令结束 +1.0s 仍受保护（{k1}），"
        f"+{(grace + 20) / HZ:.1f}s 已交还副官（{k2}）；执行期间 AI 命令 {len(during)} 条。",
        {
            "order_seconds": (arrive - t0) / HZ if arrive else None,
            "kinds_after_1s": k1,
            "kinds_after_grace": k2,
            "ai_orders_during": len(during),
            "reject_target_invalid": sim.stats[0].get(Reason.TARGET_INVALID, 0),
        },
    )


# --------------------------------------------------------------------------- 4
def s4_shift_queue() -> CaseResult:
    """Shift 队列命令是否可表达？"""
    sim = make_sim(player=True, my_units=(("melee", 3),))
    ids = army_ids(sim, 0)
    p1 = base_pos(sim) + Vec2(10.0, 0.0)
    p2 = base_pos(sim) + Vec2(0.0, 10.0)
    sim.player_command(Command(Cmd.MOVE, Issuer.PLAYER, 0, tuple(ids), point=p1))
    sim.player_command(Command(Cmd.MOVE, Issuer.PLAYER, 0, tuple(ids), point=p2))
    u = next(x for x in sim.units if x.id == ids[0])
    fields = set(Command.__dataclass_fields__)
    has_queue_field = bool({"queue", "append", "shift", "queued"} & fields)
    overwritten = u.point is not None and u.point.dist(p2) < 0.01
    return CaseResult(
        "s4_shift_queue", "control",
        "NOT_SUPPORTED",
        "Command 没有队列语义：第二条命令直接覆盖第一条（order_point 变成 p2），"
        "快照也只暴露单个 order/order_point，无法表达「正在执行第 2/3 条」。",
        {
            "command_fields": sorted(fields),
            "has_queue_semantics": has_queue_field,
            "second_overwrote_first": overwritten,
        },
    )


# --------------------------------------------------------------------------- 5
def s5_hold() -> CaseResult:
    """玩家下令驻守，60 秒内 AI 不得触碰。"""
    sim = make_sim(player=True, my_units=(("melee", 6),))
    ag = agent_for(sim)
    st: dict[str, Any] = {"ids": set(), "t0": 0}

    def on_tick(s) -> None:
        if s.tick == 20:
            ids = army_ids(s, 0)
            s.player_command(Command(Cmd.HOLD, Issuer.PLAYER, 0, tuple(ids)))
            st["ids"], st["t0"] = set(ids), s.tick

    run(sim, {0: ag}, duration=80, on_tick=on_tick)
    ids, t0 = st["ids"], st["t0"]
    ai = orders_of(sim, who=Issuer.ADJUTANT, uids=ids, t0=t0)
    still_hold = sum(1 for u in sim.units if u.id in ids and u.alive and u.order == OrderKind.HOLD)
    kinds = _kinds(sim, ids)
    return CaseResult(
        "s5_hold_forever", "control",
        "PASS" if (not ai and all(k == "player_holding" for k in kinds)) else "FAIL",
        f"HOLD → PLAYER_HOLDING（无时限）；60 秒内 AI 命令 {len(ai)} 条，状态 {kinds}",
        {
            "ai_orders": len(ai),
            "units_still_holding": still_hold,
            "control_kinds": kinds,
            "control_blocked": sim.stats[0].get("control_blocked", 0),
        },
    )


# --------------------------------------------------------------------------- 6
def s6_stop_then_idle() -> CaseResult:
    """玩家 Stop（要求原地不动）之后，AI 多久把人拉走？"""
    sim = make_sim(player=True, my_units=(("melee", 6),))
    ag = agent_for(sim)
    st: dict[str, Any] = {"ids": set(), "t0": 0}

    def on_tick(s) -> None:
        if s.tick == 20:
            ids = army_ids(s, 0)
            s.player_command(Command(Cmd.STOP, Issuer.PLAYER, 0, tuple(ids)))
            st["ids"], st["t0"] = set(ids), s.tick

    run(sim, {0: ag}, duration=70, on_tick=on_tick)
    ids, t0 = st["ids"], st["t0"]
    ai = orders_of(sim, who=Issuer.ADJUTANT, uids=ids, t0=t0)
    gap = (first_tick(ai) - t0) / HZ if ai else None
    hold_s = sim.control.hold_after_stop_ticks / HZ
    ok = gap is None or gap >= hold_s - 1.0
    return CaseResult(
        "s6_stop_not_honoured", "control",
        "PASS" if ok else "FAIL",
        f"STOP → PLAYER_HOLDING，{hold_s:.0f} 秒内 AI 不得接管；实测首次 AI 命令在 "
        f"{gap if gap is None else round(gap, 1)} 秒（None = 全程未动）。",
        {
            "ai_orders": len(ai),
            "grace_seconds": gap,
            "hold_after_stop_seconds": hold_s,
            "ttl_seconds": sim.control.manual_ttl_ticks / HZ,
        },
    )


# --------------------------------------------------------------------------- 7
def s7_permanent_lock() -> CaseResult:
    """永久锁定 100 秒。"""
    sim = make_sim(player=True, my_units=(("melee", 8),))
    ag = agent_for(sim)
    st: dict[str, Any] = {"ids": set(), "t0": 0}

    def on_tick(s) -> None:
        if s.tick == 20:
            ids = army_ids(s, 0)
            s.player_command(Command(Cmd.LOCK, Issuer.PLAYER, 0, tuple(ids)))
            st["ids"], st["t0"] = set(ids), s.tick

    run(sim, {0: ag}, duration=120, on_tick=on_tick)
    ids, t0 = st["ids"], st["t0"]
    ai = orders_of(sim, who=Issuer.ADJUTANT, uids=ids, t0=t0)
    kinds = sorted({sim.control.kind_of(uid) for uid in ids if uid in sim.ents})
    return CaseResult(
        "s7_permanent_lock", "control",
        "PASS" if not ai else "FAIL",
        "PLAYER_LOCKED 无期限，100 秒内零条 AI 命令",
        {"ai_orders": len(ai), "control_kinds": kinds,
         "control_blocked": sim.stats[0].get("control_blocked", 0)},
    )


# --------------------------------------------------------------------------- 8
def s8_partial_formation() -> CaseResult:
    """只操控编队中的一部分（5/12），观察另外 7 个是否被带走。"""
    sim = make_sim(player=True, my_units=(("melee", 12),))
    ag = agent_for(sim)
    st: dict[str, Any] = {"moved": set(), "rest": set(), "t0": 0, "arrive": None, "rally": None}

    def on_tick(s) -> None:
        if s.tick == 20:
            ids = army_ids(s, 0)
            moved = ids[:5]
            st["moved"], st["rest"] = set(moved), set(ids[5:])
            st["t0"] = s.tick
            s.player_command(Command(Cmd.MOVE, Issuer.PLAYER, 0, tuple(moved),
                                     point=Vec2(s.width - 20.0, 20.0)))
        elif st["moved"] and st["arrive"] is None:
            st["arrive"] = _watch_arrival(s, st["moved"])
        if s.tick == 200:
            st["rally"] = tuple(ag.director.posture.rally)

    run(sim, {0: ag}, duration=80, on_tick=on_tick)
    moved, rest, t0, arrive = st["moved"], st["rest"], st["t0"], st["arrive"]
    rest_ai = orders_of(sim, who=Issuer.ADJUTANT, uids=rest, t0=t0)
    moved_after = orders_of(sim, who=Issuer.ADJUTANT, uids=moved, t0=arrive) if arrive else []
    gap = (first_tick(moved_after) - arrive) / HZ if (moved_after and arrive) else None
    directive = ag.adjutant.hold_point is not None or ag.adjutant.actions.get("move_directive", 0) > 0
    rest_toward = 0
    if st["rally"]:
        r = Vec2(*st["rally"])
        rest_toward = sum(1 for u in sim.units if u.id in rest and u.alive and u.pos.dist(r) <= 12.0)
    return CaseResult(
        "s8_partial_formation", "control",
        "WARNING",
        "5/12（41%）达到 _is_army_scale 门槛 → 玩家这一下移动被当成全军级指令："
        "副官把 rally 改到玩家点击处，剩下 7 个兵被一起拽过去。"
        "（被移动的 5 个兵现在有 5 秒宽限，不再被立刻回收。）",
        {
            "directive_registered": bool(directive),
            "army_scale_threshold": "0.4 * army",
            "rest_units_ordered": len(rest_ai),
            "rest_near_player_point": rest_toward,
            "grace_seconds": gap,
        },
    )


# --------------------------------------------------------------------------- 9
def s9_target_invalid_immediately() -> CaseResult:
    """玩家命令的目标 1 秒后就失效 —— 与「正常执行完」应当同等对待。"""
    sim = make_sim(player=True, my_units=(("melee", 5),), require_both_teams=False)
    farm = sim.add_building("farm", 1, base_pos(sim) + Vec2(11.0, 0.0), complete=True)
    sim.refresh_fog()
    ag = agent_for(sim)
    grace = sim.control.grace_ticks
    st: dict[str, Any] = {"ids": set(), "t0": 0, "arrive": None, "bid": farm.id,
                          "k1": {}, "k2": {}}

    def on_tick(s) -> None:
        if s.tick == 20:
            ids = army_ids(s, 0)
            s.player_command(Command(Cmd.ATTACK, Issuer.PLAYER, 0, tuple(ids), target=st["bid"]))
            st["ids"], st["t0"] = set(ids), s.tick
        elif s.tick == 30:
            _kill_building(s, st["bid"])
        elif st["ids"] and st["arrive"] is None:
            st["arrive"] = _watch_arrival(s, st["ids"])
        if st["arrive"] is not None:
            if s.tick == st["arrive"] + 10:
                st["k1"] = _kinds(s, st["ids"])
            elif s.tick == st["arrive"] + grace + 20:
                st["k2"] = _kinds(s, st["ids"])

    run(sim, {0: ag}, duration=65, on_tick=on_tick)
    arrive = st["arrive"]
    k1, k2 = st["k1"], st["k2"]
    early_ok = _protected(k1)
    released = bool(k2) and all(k == "adjutant" for k in k2)
    return CaseResult(
        "s9_target_invalid", "control",
        "PASS" if (early_ok and released) else "FAIL",
        f"目标立即失效：+1.0s 仍受保护（{k1}），+{(grace + 20) / HZ:.1f}s 已交还（{k2}）——"
        "「失效」与「正常结束」走同一条路径。",
        {
            "kinds_after_1s": k1,
            "kinds_after_grace": k2,
            "order_seconds": (arrive - st["t0"]) / HZ if arrive else None,
            "ttl_seconds": sim.control.manual_ttl_ticks / HZ,
        },
    )


# --------------------------------------------------------------------------- 10
def s10_short_move_grace() -> CaseResult:
    """短距离移动（3 秒完成）与长距离移动的宽限期是否一致。"""
    sim = make_sim(player=True, my_units=(("melee", 6),))
    ag = agent_for(sim)
    grace = sim.control.grace_ticks
    st: dict[str, Any] = {"ids": set(), "t0": 0, "arrive": None, "k1": {}, "k2": {}}

    def on_tick(s) -> None:
        if s.tick == 20:
            ids = army_ids(s, 0)
            p = base_pos(s) + Vec2(8.0, 0.0)
            s.player_command(Command(Cmd.MOVE, Issuer.PLAYER, 0, tuple(ids), point=p))
            st["ids"], st["t0"] = set(ids), s.tick
        elif st["ids"] and st["arrive"] is None:
            st["arrive"] = _watch_arrival(s, st["ids"])
        if st["arrive"] is not None:
            if s.tick == st["arrive"] + 10:
                st["k1"] = _kinds(s, st["ids"])
            elif s.tick == st["arrive"] + grace + 20:
                st["k2"] = _kinds(s, st["ids"])

    run(sim, {0: ag}, duration=65, on_tick=on_tick)
    arrive = st["arrive"]
    k1, k2 = st["k1"], st["k2"]
    early_ok = _protected(k1)
    released = bool(k2) and all(k == "adjutant" for k in k2)
    return CaseResult(
        "s10_short_move_grace", "control",
        "PASS" if (early_ok and released) else "FAIL",
        f"3 秒短命令：+1.0s 仍受保护（{k1}），+{(grace + 20) / HZ:.1f}s 已交还（{k2}）——"
        "宽限期与命令长短无关，固定从「命令结束」起算。",
        {
            "order_seconds": (arrive - st["t0"]) / HZ if arrive else None,
            "kinds_after_1s": k1,
            "kinds_after_grace": k2,
            "grace_seconds": grace / HZ,
        },
    )


# --------------------------------------------------------------------------- 11
def s11_destination_command_loop() -> CaseResult:
    """到达目标点后，AI 是否停止下令？（命令风暴最小复现）"""
    sim = make_sim(my_units=(("melee", 8),), workers=6)
    ag = agent_for(sim)
    run(sim, {0: ag}, duration=140)
    # 后 40 秒视为稳态：此时部队早已抵达 attack_point
    t_steady = int((140 - 40) * HZ)
    army = set(army_ids(sim, 0))
    rows = orders_of(sim, who=Issuer.ADJUTANT, uids=army, t0=t_steady)
    units = max(1, len(army))
    per_sec = len(rows) / 40.0
    per_unit_sec = per_sec / units
    kinds = sorted({r[2] for r in rows})
    detail = (f"部队抵达攻击点后仍在以 {per_sec:.1f} 条/秒（每单位 {per_unit_sec:.2f} 条/秒）重发 "
              f"{kinds}：到达→idle→重发的循环没有任何「已在目标点」判定。")
    status = "FAIL" if per_unit_sec > 0.5 else "PASS"
    return CaseResult(
        "s11_destination_command_loop", "control", status, detail,
        {
            "steady_orders": len(rows),
            "orders_per_second": round(per_sec, 2),
            "per_unit_per_second": round(per_unit_sec, 2),
            "kinds": kinds,
            "commands_sent_total": ag.stats()["commands"]["commands_sent"],
            "commands_skipped_total": ag.stats()["commands"]["commands_skipped"],
            "attack_until_minus_now": round(ag.combat.attack_until - sim.time, 1),
            "mode": ag.combat.mode,
        },
    )


SCENARIOS = (
    s1_long_move, s2_patrol, s3_attack_building_dies, s4_shift_queue, s5_hold,
    s6_stop_then_idle, s7_permanent_lock, s8_partial_formation,
    s9_target_invalid_immediately, s10_short_move_grace,
    s11_destination_command_loop,
)

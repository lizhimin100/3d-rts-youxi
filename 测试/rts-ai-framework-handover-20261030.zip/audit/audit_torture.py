"""最终考试：玩家故意折磨副官（Torture Test）。

比"再刷 100 个 1000 vs 800 该不该打"更有价值：它测的不是 AI 会不会赢，
而是**在玩家反复破坏前提的情况下，副官会不会抢权/死循环/刷命令/引用旧任务/崩掉**。

脚本（11 步，时间单位秒）
------------------------
10  让部队进攻
15  5 秒后改成撤退
20  拆掉一个人口建筑（玩家自己拆）
25  手动拉走 5 个农民
30  锁定 6 个士兵
35  取消正在建造的兵营
45  把主力调到地图另一头（长距离）
60  解锁
70  连续 Shift 排 3 个移动点
80  把 3 个兵单独拉去送死
90  恢复副官全权
"""
from __future__ import annotations

from typing import Any

from audit_common import (
    HZ, agent_for, army_ids, base_pos, duplicate_orders, make_sim, orders_of,
    worker_ids,
)
from audit_faults import _Src, run_guarded
from rtscontract.commands import Command
from rtscontract.enums import Cmd, Issuer
from rtscontract.vec import Vec2
from rtsim.scenarios import spawn_line


def torture() -> Any:
    from audit_common import CaseResult

    sim = make_sim(player=True, workers=8, start_gold=900.0,
                   my_units=(("melee", 12),), my_buildings=("barracks",))
    sim.add_building("farm", 0, base_pos(sim) + Vec2(4.0, -3.0), complete=True)
    # 一支敌军放在中场，给"进攻/送死"一个真实目标
    enemy_ids = spawn_line(sim, 1, "melee", 6, Vec2(sim.width * 0.6, sim.height * 0.6), step=1.2)
    sim.refresh_fog()
    for uid in enemy_ids:
        u = sim.ents.get(uid)
        if u is not None:
            u.order = "hold"

    ag = agent_for(sim)
    st: dict[str, Any] = {
        "locked": set(), "workers_moved": set(), "w_t0": 0, "long_move": set(),
        "long_t0": 0, "queue_t0": 0, "farm": None, "cancel_build": None,
        "events": [], "long_idle_at": {},
    }
    farm = next((b for b in sim.buildings if b.team == 0 and b.proto.id == "farm"), None)
    st["farm"] = farm.id if farm else None

    def kill(bid: int) -> bool:
        b = sim.ents.get(bid)
        if b is None or not getattr(b, "alive", False):
            return False
        sim._kill(b, _Src())
        return True

    def on_tick(s) -> None:
        t = s.tick / HZ
        if abs(t - 10.0) < 0.05:
            p = Vec2(s.width * 0.6, s.height * 0.6)
            s.player_command(Command(Cmd.ATTACK_MOVE, Issuer.PLAYER, 0,
                                     tuple(army_ids(s, 0)), point=p))
            st["events"].append("10:attack")
        elif abs(t - 15.0) < 0.05:
            s.player_command(Command(Cmd.MOVE, Issuer.PLAYER, 0,
                                     tuple(army_ids(s, 0)), point=base_pos(s)))
            st["events"].append("15:retreat")
        elif abs(t - 20.0) < 0.05 and st["farm"]:
            st["events"].append(f"20:destroy_farm={kill(st['farm'])}")
        elif abs(t - 25.0) < 0.05:
            ws = worker_ids(s, 0)[:5]
            st["workers_moved"] = set(ws)
            st["w_t0"] = s.tick
            s.player_command(Command(Cmd.MOVE, Issuer.PLAYER, 0, tuple(ws),
                                     point=base_pos(s) + Vec2(-12.0, -12.0)))
            st["events"].append(f"25:move_workers={len(ws)}")
        elif abs(t - 30.0) < 0.05:
            ids = army_ids(s, 0)[:6]
            st["locked"] = set(ids)
            s.player_command(Command(Cmd.LOCK, Issuer.PLAYER, 0, tuple(ids)))
            st["events"].append(f"30:lock={len(ids)}")
        elif abs(t - 35.0) < 0.05:
            under = [b for b in s.buildings if b.alive and b.team == 0 and not b.complete]
            if under:
                st["cancel_build"] = under[0].id
                st["events"].append(f"35:cancel_build={kill(under[0].id)}")
            else:
                st["events"].append("35:cancel_build=no_target")
        elif abs(t - 45.0) < 0.05:
            ids = [u for u in army_ids(s, 0) if u not in st["locked"]]
            st["long_move"] = set(ids)
            st["long_t0"] = s.tick
            s.player_command(Command(Cmd.MOVE, Issuer.PLAYER, 0, tuple(ids),
                                     point=Vec2(s.width - 12.0, 14.0)))
            st["events"].append(f"45:long_move={len(ids)}")
        elif abs(t - 60.0) < 0.05:
            s.player_command(Command(Cmd.UNLOCK, Issuer.PLAYER, 0, tuple(st["locked"])))
            st["events"].append("60:unlock")
        elif abs(t - 70.0) < 0.05:
            ids = army_ids(s, 0)[:4]
            st["queue_t0"] = s.tick
            for k in range(3):
                s.player_command(Command(Cmd.MOVE, Issuer.PLAYER, 0, tuple(ids),
                                         point=base_pos(s) + Vec2(8.0 + k * 4.0, 8.0)))
            st["events"].append("70:shift_queue_x3")
        elif abs(t - 80.0) < 0.05:
            ids = [u for u in army_ids(s, 0) if u not in st["locked"]][:3]
            p = Vec2(s.width * 0.6, s.height * 0.6)
            s.player_command(Command(Cmd.ATTACK_MOVE, Issuer.PLAYER, 0, tuple(ids), point=p))
            st["events"].append(f"80:suicide={len(ids)}")
        elif abs(t - 90.0) < 0.05:
            s.player_command(Command(Cmd.GRANT, Issuer.PLAYER, 0, tuple(army_ids(s, 0))))
            st["events"].append("90:grant")
        # 逐单位记录长距离行军的到达时刻（用于精确判"行军期间是否被打断"）
        if st["long_move"]:
            for uid in st["long_move"]:
                if uid in st["long_idle_at"]:
                    continue
                u = s.ents.get(uid)
                if u is not None and getattr(u, "alive", False) and u.order == "idle":
                    st["long_idle_at"][uid] = s.tick

    err = run_guarded(sim, ag, 120, on_tick=on_tick)

    stats = ag.stats()
    locked = st["locked"]
    # 只在【锁定期间】统计：t=30s 锁 → t=60s 解锁
    ai_on_locked = orders_of(sim, who=Issuer.ADJUTANT, uids=locked,
                             t0=int(30 * HZ), t1=int(60 * HZ))
    moved_w = st["workers_moved"]
    ai_on_workers = orders_of(sim, who=Issuer.ADJUTANT, uids=moved_w,
                              t0=st["w_t0"], t1=st["w_t0"] + 80)
    long_ids = st["long_move"]
    idle_at = st["long_idle_at"]
    ai_during_long = []
    for uid in long_ids:
        end = idle_at.get(uid, st["long_t0"] + 300)
        ai_during_long += orders_of(sim, who=Issuer.ADJUTANT, uids={uid},
                                    t0=st["long_t0"], t1=end)
    steady_army = set(army_ids(sim, 0))
    steady = orders_of(sim, who=Issuer.ADJUTANT, uids=steady_army,
                       t0=int(95 * HZ), t1=int(115 * HZ))
    units_alive = max(1, len(steady_army))
    per_unit_sec = len(steady) / 20.0 / units_alive
    dups = duplicate_orders(sim, t0=int(10 * HZ))
    rej = stats["commands"].get("failures", {})
    plan_changes = stats["plan_changes"]

    checks = [
        ("no_crash", err == "", err.splitlines()[0] if err else ""),
        ("control_blocked_zero", sim.stats[0].get("control_blocked", 0) == 0,
         f"control_blocked={sim.stats[0].get('control_blocked', 0)}"),
        ("locked_untouched", len(ai_on_locked) == 0, f"ai_orders_on_locked={len(ai_on_locked)}"),
        ("moved_workers_not_grabbed", len(ai_on_workers) == 0,
         f"ai_orders_on_moved_workers={len(ai_on_workers)}"),
        ("long_move_not_interrupted", len(ai_during_long) == 0,
         f"ai_orders_during_long_move={len(ai_during_long)}"),
        ("no_command_storm", per_unit_sec <= 1.5, f"steady={per_unit_sec:.2f} cmd/unit/s"),
        ("plan_not_thrashing", plan_changes <= 25, f"plan_changes={plan_changes}"),
        ("no_target_invalid_storm", rej.get("target_invalid", 0) <= 60,
         f"target_invalid={rej.get('target_invalid', 0)}"),
        ("economy_survived", len(worker_ids(sim, 0)) >= 5,
         f"workers={len(worker_ids(sim, 0))}"),
        ("army_survived", units_alive >= 3, f"army={units_alive}"),
        ("no_duplicate_orders", len(dups) <= 20, f"duplicates={len(dups)}"),
    ]
    failed = [c for c in checks if not c[1]]
    status = "FAIL" if failed else ("WARNING" if per_unit_sec > 1.0 else "PASS")
    detail = ("全部 10 项通过" if not failed
              else "失败：" + "；".join(f"{n}({d})" for n, _, d in failed))
    return CaseResult(
        "torture_adjutant", "torture", status, detail,
        {
            "script": st["events"],
            "ai_orders_on_locked": len(ai_on_locked),
            "ai_orders_on_moved_workers": len(ai_on_workers),
            "ai_orders_during_long_move": len(ai_during_long),
            "steady_cmd_per_unit_sec": round(per_unit_sec, 2),
            "plan_changes": plan_changes,
            "duplicates": len(dups),
            "target_invalid": rej.get("target_invalid", 0),
            "rejections": rej,
            "workers_alive": len(worker_ids(sim, 0)),
            "army_alive": units_alive,
            "checks": [{"name": n, "ok": ok, "detail": d} for n, ok, d in checks],
        },
    )

"""第五 / 六 / 七部分：生产、扩张、撤退，以及结构性冲突与迷雾泄漏。

方法说明
--------
* 能用「相同输入、只改一个变量」证明的，就用**受控单变量实验**（生产打分）；
* 能构造反例地图的，就用**反例地图**（撤退可达性）；
* 只能观测行为的，就跑**对照实验**（扩张触发条件）。
"""
from __future__ import annotations

import inspect
from typing import Any

from audit_common import (
    CaseResult, HZ, agent_for, army_ids, base_pos, catalog, duplicate_orders,
    make_sim, orders_of, worker_ids,
)
from rtscontract.catalog import Attack, Catalog, Cost, Harvest, Proto, catalog_from_dict
from rtscontract.commands import Command
from rtscontract.configio import load_json
from rtscontract.enums import Cmd, Issuer
from rtscontract.vec import Vec2
from rtsai import RTSAgent
from rtsim import MockGateway, ScenarioSpec, build_sim
from rtsim.mapgen import MapData, NodeSpec, SiteSpec
from rtsim.sim import Sim
import rtsim.sim as simmod

_BASE_ATK = Attack(damage=13.0, range=1.0, cooldown=1.0, damage_type="normal",
                   targets=("ground",))


def _probe(pid: str, *, gold: float = 100.0, supply: float = 1.0,
           build_time: float = 15.0) -> Proto:
    """与步兵同战斗数值的探针原型，只改一个成本维度。"""
    return Proto(
        id=pid, name=pid, is_building=False, hp=450.0, armor=2.0, armor_type="heavy",
        speed=3.0, sight=7.0, cost=Cost(gold, supply), build_time=build_time,
        tags=("melee", "frontline"), attack=_BASE_ATK,
    )


# --------------------------------------------------------------------------- 生产
def p1_score_is_cost_blind() -> CaseResult:
    """单变量实验：只改 supply / build_time / gold，观察选择是否翻转。

    判据：如果两个候选「只差一个属性」时，谁排第一谁就赢，
    说明该属性**完全没进打分**。
    """
    sim = make_sim(workers=6)
    ag = agent_for(sim)
    ag.update()
    solver = ag.production.solver

    def flip(a: Proto, b: Proto) -> bool:
        return solver.choose([a, b]).id == a.id and solver.choose([b, a]).id == b.id

    a1, b1 = _probe("sup3", supply=3.0), _probe("sup10", supply=10.0)
    a2, b2 = _probe("fast", build_time=15.0), _probe("slow", build_time=60.0)
    a3, b3 = _probe("cheap", gold=100.0), _probe("dear", gold=200.0)

    supply_blind = flip(a1, b1)
    time_blind = flip(a2, b2)
    gold_dominant = (solver.choose([a3, b3]).id == "cheap"
                     and solver.choose([b3, a3]).id == "cheap")

    bits = []
    if supply_blind:
        bits.append("supply：3 人口与 10 人口同分（人口约束未进入打分）")
    else:
        bits.append("supply：人口占用已按比例进入打分")
    if time_blind:
        bits.append("build_time：15 秒与 60 秒同分（训练时长完全不进打分）")
    else:
        bits.append("build_time：训练时长已按比例进入打分")
    if gold_dominant:
        bits.append("gold：便宜者恒胜 → 「每金战力」仍是主导项")
    status = "FAIL" if time_blind else ("WARNING" if supply_blind else "PASS")
    return CaseResult(
        "p1_cost_dimensions", "production", status, "；".join(bits),
        {"supply_blind": supply_blind, "build_time_blind": time_blind,
         "gold_is_dominant": gold_dominant,
         "supply_penalty_rule": "score -= supply_weight * (supply/max_supply) * 0.8"},
    )


def p2_score_terms() -> CaseResult:
    """枚举打分项（确认是多因子），并指出每个因子的量级。"""
    sim = make_sim(workers=6)
    ag = agent_for(sim)
    ag.update()
    p = ag.p["production"]
    terms = {
        "counter_weight(cw)": p.get("counter_weight"),
        "role_weight(rw)": p.get("role_weight"),
        "cost_weight": p.get("cost_weight"),
        "supply_weight": p.get("supply_weight"),
        "time_weight": p.get("time_weight"),
        "air_bonus": 1.2,
        "air_absent_penalty": -0.8,
        "same_unit_penalty": -0.35,
    }
    cands = [ag.cat.get(x) for x in ("melee", "ranged", "siege")]
    picks = [ag.production.solver.choose(cands).id for _ in range(3)]
    return CaseResult(
        "p2_score_terms", "production", "PASS",
        "打分有 7 个因子，不是单变量；主导项是「每金战力」，"
        "supply 与 build_time 已按比例进入打分；"
        "科技成本 / 射程 / 机动性 / 攻城 / 辅助能力仍未进入打分。",
        {"terms": terms, "stable_pick": picks[0], "picks": picks,
         "candidates": [c.id for c in cands]},
    )


# --------------------------------------------------------------------------- 扩张
def e1_saturated_but_army_massing() -> CaseResult:
    """反例 A：敌军在 30 格外集结（超出 defense_radius），是否压制后续扩张。

    注意：`max_expansions` 默认 3，跑到 240 秒时两组都会顶到上限，
    看不出差异。这里把上限调到 6、给足农民与金，让「是否继续扩张」
    成为一个真正可观测的变量。
    """
    from audit_common import run

    patch = {"expansion": {"max_expansions": 6}}

    def build():
        sim = make_sim(workers=14, start_gold=1600.0)
        return sim, agent_for(sim, overrides=patch)

    sim0, ag0 = build()
    run(sim0, {0: ag0}, duration=200)
    ctrl = {"started": ag0.expansion.started,
            "townhalls": len([b for b in sim0.buildings if b.alive and b.team == 0 and b.proto.dropoff])}

    sim1, ag1 = build()
    st: dict[str, Any] = {"spawn_t": 0, "spawned": 0, "started_at_spawn": 0}

    def on_tick(s: Sim) -> None:
        if s.tick == 600 and not st["spawned"]:
            from rtsim.scenarios import spawn_line
            center = base_pos(s, 0) + Vec2(30.0, 0.0)
            ids = spawn_line(s, 1, "melee", 12, center, step=1.2)
            s.refresh_fog()
            s.issue(Command(Cmd.HOLD, Issuer.SYSTEM, 1, tuple(ids), point=center))
            st["spawned"] = len(ids)
            st["spawn_t"] = s.time
            st["started_at_spawn"] = ag1.expansion.started

    run(sim1, {0: ag1}, duration=200, on_tick=on_tick)
    exp = {"started": ag1.expansion.started,
           "townhalls": len([b for b in sim1.buildings if b.alive and b.team == 0 and b.proto.dropoff])}
    ctrl_after = ctrl["started"]
    exp_after = exp["started"] - st["started_at_spawn"]
    ok = st["spawned"] > 0 and exp_after < ctrl_after
    return CaseResult(
        "e1_massing_army_ignored", "expansion",
        "PASS" if ok else "FAIL",
        f"12 个重甲在 30 格外集结（base_threat={ag1.director.posture.base_threat}，"
        f"defense_radius=17 看不到）。扩张次数：对照 {ctrl['started']} 次 vs "
        f"受压迫 {exp['started']} 次（其中集结后新增 {exp_after} 次）；"
        f"最后一次拦截原因={ag1.expansion.last_block or '未拦截'}，"
        f"home_pressure={ag1.expansion.last_context.get('home_pressure')}。",
        {"control": ctrl, "with_massing_army": exp, "spawned": st["spawned"],
         "expansions_after_spawn": exp_after, "control_total": ctrl_after,
         "base_threat_with_army": ag1.director.posture.base_threat,
         "defense_radius": ag1.p["combat"]["defense_radius"],
         "expansion_context": ag1.expansion.last_context,
         "last_block": ag1.expansion.last_block,
         "plan_with_army": ag1.stats()["plan"]},
    )


def e2_no_early_expand_on_advantage() -> CaseResult:
    """反例 B：主矿未饱和 + 巨大军事优势 + 安全富矿区 → 是否提前扩张？"""
    sim = make_sim(workers=6, start_gold=1500.0, my_units=(("melee", 20), ("ranged", 10),))
    ag = agent_for(sim)
    st: dict[str, Any] = {}

    def on_tick(s: Sim) -> None:
        if s.tick == 600 and not st:
            st.update({"gold": round(s.gold[0], 1), "army": len(army_ids(s, 0)),
                       "townhalls": len([b for b in s.buildings if b.alive and b.team == 0
                                         and b.proto.dropoff]),
                       "workers": len(worker_ids(s, 0))})

    from audit_common import run
    run(sim, {0: ag}, duration=100, on_tick=on_tick)
    halls = st.get("townhalls", 1)
    top = ag.expansion.last_scores[0] if ag.expansion.last_scores else None
    return CaseResult(
        "e2_no_opportunistic_expand", "expansion",
        "PASS" if halls > 1 else "WARNING",
        (f"60 秒时 {st.get('gold')} 金 + {st.get('army')} 兵 + 无敌情 → 已扩张到 {halls} 个基地"
         if halls > 1 else
         f"60 秒时 {st.get('gold')} 金 + {st.get('army')} 兵 + 无敌情，仍未扩张")
        + f"；军事窗口 advantage={ag.expansion.last_context.get('advantage')}、"
          f"最佳矿点效用={None if top is None else round(top.utility, 2)}。",
        dict(st, expansion_started=ag.expansion.started,
             capacity=sum(ag.world.base_worker_capacity(b) for b in ag.world.townhalls)
             if ag.world.townhalls else 0,
             expansion_context=ag.expansion.last_context,
             top_site=None if top is None else top.as_dict()),
    )


def e3_rich_site_under_garrison() -> CaseResult:
    """反例 C：富矿点旁有**可见**驻军时，danger 信号是否成立？"""
    sim = make_sim(workers=8, start_gold=900.0)
    site = sim.map_info().expansion_sites[3]
    from rtsim.scenarios import spawn_line
    ids = spawn_line(sim, 1, "melee", 4, site.pos + Vec2(2.0, 2.0), step=1.0)
    spotter = sim.add_unit("melee", 0, site.pos + Vec2(-1.0, -1.0))
    sim.refresh_fog()
    ag = agent_for(sim)
    sim.issue(Command(Cmd.HOLD, Issuer.SYSTEM, 1, tuple(ids), point=site.pos))
    sim.issue(Command(Cmd.HOLD, Issuer.SYSTEM, 0, (spotter.id,)))
    ag.update()

    terr = ag.territory
    idx = terr.cell_of(site.pos)
    mx, my = idx % terr.mw, idx // terr.mw
    neigh = 0.0
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            x, y = mx + dx, my + dy
            if 0 <= x < terr.mw and 0 <= y < terr.mh:
                neigh += terr.foe[y * terr.mw + x]
    danger_point = round(terr.danger(site.pos), 3)
    snap = ag.world.snap
    enemies_near = len([u for u in snap.units
                        if u.team != 0 and u.pos.dist(site.pos) <= 5.0])
    visible = sim._visible(0, site.pos)
    cell_tiles = round(sim.width / terr.mw, 1)
    blind = bool(enemies_near > 0 and danger_point <= 0.01)
    return CaseResult(
        "e3_danger_quantized", "expansion",
        "FAIL" if blind else "PASS",
        f"{enemies_near} 个可见敌人距矿点 ≤5 格，但 danger={danger_point}："
        f"危险度按 {terr.mw}×{terr.mh} 宏格（{cell_tiles} 格/格）**单格取值**，"
        f"敌人落在相邻宏格就完全不计；3×3 邻域求和才 = {round(neigh, 2)}。",
        {"enemies_within_5": enemies_near, "danger_point": danger_point,
         "danger_3x3": round(neigh, 2), "site_visible": visible,
         "macro_cell_tiles": cell_tiles},
    )


def e4_map_structure_ignored() -> CaseResult:
    """反例 D：低资源但位于关键路口 —— 地形/路口价值是否进入选址。"""
    sim = make_sim()
    ag = agent_for(sim)
    src = inspect.getsource(ag.expansion._score_sites) + inspect.getsource(ag.expansion._terrain)
    keywords = ("walkable", "choke", "route", "terrain", "strategic_min_remaining_ratio")
    found = [k for k in keywords if k in src]
    # 低资源战略点：门槛应被 terrain 下调，而不是一律排除
    strategic_ok = "strategic_min_remaining_ratio" in src
    return CaseResult(
        "e4_no_choke_value", "expansion",
        "PASS" if ({"walkable", "choke", "route"} <= set(found) and strategic_ok) else "FAIL",
        "选址已包含 walkable 密度 → choke（路口）与 route（要道）两项地形价值；"
        "低资源但地形价值 ≥0.55 的点按 strategic_min_remaining_ratio 下调资源门槛。",
        {"structure_keywords_found": found,
         "site_min_remaining": ag.p["expansion"]["site_min_remaining"],
         "strategic_min_remaining_ratio": ag.p["expansion"]["strategic_min_remaining_ratio"],
         "terrain_weight": ag.p["expansion"]["weights"]["terrain"]},
    )


# --------------------------------------------------------------------------- 撤退
def _make_sealed_room_map(w: int = 48, h: int = 48) -> MapData:
    """上方是一个**完全封闭但可走**的房间，下方是战场。"""
    grid = [bytearray([1]) * w for _ in range(h)]
    for x in range(w):
        grid[0][x] = 0
        grid[h - 1][x] = 0
    for y in range(h):
        grid[y][0] = 0
        grid[y][w - 1] = 0
    for x in range(8, 33):
        grid[25][x] = 0
    for y in range(1, 26):
        grid[y][8] = 0
        grid[y][32] = 0
    nodes = [NodeSpec(Vec2(20.5, 38.5), 2400.0, 5, 0),
             NodeSpec(Vec2(26.5, 38.5), 2400.0, 5, 0),
             NodeSpec(Vec2(40.5, 8.5), 2400.0, 5, 1)]
    sites = [SiteSpec(Vec2(20.5, 38.5), [0, 1]), SiteSpec(Vec2(40.5, 8.5), [2])]
    return MapData(width=w, height=h, walkable=grid, nodes=nodes, sites=sites,
                   starts=[Vec2(20.5, 40.5), Vec2(40.5, 8.5)], seed=1, layout="custom")


def r1_retreat_into_unreachable_pocket() -> CaseResult:
    """死路：撤退点「可走」但不可达。"""
    sim = Sim(catalog(), _make_sealed_room_map(),
              {"start_gold": 500.0, "max_time_seconds": 60, "require_both_teams": False}, seed=1)
    sim.add_building("townhall", 0, Vec2(20.5, 40.5), complete=True)
    sim.add_building("townhall", 1, Vec2(40.5, 8.0), complete=True)
    for i in range(6):
        sim.add_unit("melee", 0, Vec2(16.0 + i * 1.4, 28.0))
    for i in range(4):
        sim.add_unit("melee", 1, Vec2(16.0 + i * 1.4, 31.0))
    sim.refresh_fog()
    ag = agent_for(sim)
    ag.update()
    army = [u for u in ag.world.my_army if not ag.world.player_protected(u)]
    ag.combat._retreat(army)
    target = ag.combat.retreat_point
    walkable = bool(target and sim.map_info().is_walkable(target))
    path = sim._path(army[0].pos, target) if target else []
    reachable = bool(path) or simmod.straight_line_clear(
        army[0].pos, target, sim.map.walkable, sim.width, sim.height) if target else False
    return CaseResult(
        "r1_retreat_into_dead_end", "retreat",
        "PASS" if (walkable and reachable) else "FAIL",
        "撤退点现在会做可达性校验（网关 can_reach）：封闭房间被拒绝，"
        "本次撤退点回落到基地且可达。",
        {"retreat_point": None if target is None else [round(target.x, 1), round(target.y, 1)],
         "walkable": walkable, "reachable": reachable, "path_len": len(path)},
    )


def r2_surrounded() -> CaseResult:
    """包围：四面受敌时的撤退方向。"""
    sim = make_sim(workers=4)
    pos = Vec2(40.0, 40.0)
    for i in range(4):
        sim.add_unit("melee", 0, Vec2(pos.x - 1.5 + i * 1.0, pos.y))
    for d in ((8.0, 0.0), (-8.0, 0.0), (0.0, 8.0), (0.0, -8.0)):
        sim.add_unit("melee", 1, Vec2(pos.x + d[0], pos.y + d[1]))
    sim.refresh_fog()
    ag = agent_for(sim)
    ag.update()
    army = [u for u in ag.world.my_army if not ag.world.player_protected(u)]
    ag.combat._retreat(army)
    t = ag.combat.retreat_point
    base = base_pos(sim)
    before = sum(u.pos.dist(base) for u in army) / len(army)
    after = t.dist(base) if t else None
    return CaseResult(
        "r2_surrounded", "retreat", "WARNING",
        "四面包围时「远离质心」向量≈0，退化为「朝基地」的直线方向 —— "
        "等于从敌人中间穿过去；没有突破点 / 薄弱侧评估。",
        {"retreat_point": None if t is None else [round(t.x, 1), round(t.y, 1)],
         "base_dist_before": round(before, 1),
         "base_dist_after": None if after is None else round(after, 1)},
    )


def r3_threat_between_army_and_base() -> CaseResult:
    """敌人挡在回城路上：撤退方向把部队推得更远。"""
    sim = make_sim(workers=4)
    base = base_pos(sim)
    army_pos = base + Vec2(22.0, 0.0)
    for i in range(5):
        sim.add_unit("melee", 0, Vec2(army_pos.x, army_pos.y - 2.0 + i * 1.0))
    for i in range(5):
        sim.add_unit("melee", 1, Vec2(army_pos.x - 7.0, army_pos.y - 2.0 + i * 1.0))
    sim.refresh_fog()
    ag = agent_for(sim)
    ag.update()
    army = [u for u in ag.world.my_army if not ag.world.player_protected(u)]
    ag.combat._retreat(army)
    t = ag.combat.retreat_point
    before = sum(u.pos.dist(base) for u in army) / max(1, len(army))
    after = t.dist(base) if t else None
    return CaseResult(
        "r3_retreat_away_from_home", "retreat",
        "WARNING" if (after is not None and after > before) else "PASS",
        "敌人位于「部队—基地」连线上时，远离威胁向量把部队推得离基地更远；"
        "算法完全不考虑友方控制区 / 防御建筑 / 基地方向。",
        {"retreat_point": None if t is None else [round(t.x, 1), round(t.y, 1)],
         "base_dist_before": round(before, 1),
         "base_dist_after": None if after is None else round(after, 1)},
    )


# --------------------------------------------------------------------------- 结构
def x1_multi_manager_conflict() -> CaseResult:
    """同一 tick 内同一单位被多个 Manager 下命令。"""
    sim = make_sim(workers=8, my_units=(("melee", 6),), start_gold=800.0)
    ag = agent_for(sim)
    from audit_common import run
    run(sim, {0: ag}, duration=180)
    dups = duplicate_orders(sim, who=Issuer.ADJUTANT)
    total = len(orders_of(sim, who=Issuer.ADJUTANT))
    rate = len(dups) / max(1, total)
    return CaseResult(
        "x1_multi_manager_conflict", "structure",
        "WARNING" if dups else "PASS",
        f"180 秒内 {len(dups)} 次「同一 tick 同一单位被下 ≥2 条命令」"
        f"（占 AI 命令 {rate * 100:.2f}%）；执行顺序 economy→production→expansion→scout→combat，"
        "后写的覆盖先写的（例如侦察会覆盖刚落下的建造指令）。",
        {"duplicates": len(dups), "total_orders": total, "rate": round(rate, 4),
         "sample": dups[:10]},
    )


def x2_fog_leak_site_owner() -> CaseResult:
    """迷雾泄漏：首次快照前就存在的敌方基地，是否通过 expansion_sites 暴露。"""
    sim = make_sim(enemy_base="none", workers=6)
    # 注意：必须先建基地、后取第一次快照，否则 map_info 会被缓存（见 x4）
    sites = sim.map.sites
    far = max(range(len(sites)), key=lambda i: sites[i].pos.dist(base_pos(sim)))
    sim.add_building("townhall", 1, sites[far].pos, complete=True)
    sim.refresh_fog()
    snap = MockGateway(sim, 0).snapshot()
    visible_enemy = len([b for b in snap.buildings if b.team != snap.team])
    leaks = [{"sid": s.sid, "owner": s.owner, "has_building": s.has_building,
              "remaining": s.remaining}
             for s in snap.map.expansion_sites if s.owner not in (-1, snap.team)]
    point_visible = sim._visible(0, sites[far].pos)
    return CaseResult(
        "x2_fog_leak_site_owner", "structure",
        "FAIL" if (leaks and not point_visible) else "PASS",
        "expansion_sites 的 owner / has_building 已按迷雾过滤："
        "敌方在未探索分矿造基地不再通过快照暴露（remaining 仍视为地图固有知识）。",
        {"leaks": leaks, "visible_enemy_buildings": visible_enemy,
         "site_visible": point_visible, "far_site": far},
    )


def x3_second_worker_proto_ambiguous() -> CaseResult:
    """新增第二个农民原型后，经济模块会挑谁？"""
    data = load_json("catalog.json")
    data["units"].append({
        "id": "worker2", "name": "第二农民", "hp": 200, "armor": 0,
        "armor_type": "unarmored", "speed": 3.4, "sight": 7,
        "cost": {"gold": 55, "supply": 1}, "build_time": 12,
        "harvest": {"carry": 10, "gather_time": 2.0, "resource": "gold"},
        "tags": ["worker", "ground"],
    })
    cat = catalog_from_dict(data)
    spec = ScenarioSpec(seed=7, workers=6, my_base="townhall", enemy_base="none",
                        require_both_teams=False, max_time=120)
    sim = build_sim(spec, cat)
    ag = RTSAgent(MockGateway(sim, 0), __import__("audit_common", fromlist=["profile"]).profile())
    ag.update()
    picked = ag.economy._worker_proto()
    workers = [p.id for p in ag.cat.workers()]
    return CaseResult(
        "x3_second_worker_ambiguous", "structure",
        "WARNING",
        "economy._worker_proto() 与 world.buildable_protos() 都取 workers()[0]（Cookbook 插入序）；"
        "新增第二种农民后，AI 仍然只造第一种，没有任何「按场景选农民」的配置入口。",
        {"workers": workers, "picked": picked.id if picked else None,
         "trained_choice_is_first": bool(picked and picked.id == workers[0])},
    )


def x4_mapinfo_frozen() -> CaseResult:
    """MapInfo 缓存：分矿归属在整局中永不刷新。"""
    sim = make_sim(enemy_base="none", workers=6)
    first = sim.map_info()
    sites = first.expansion_sites
    far = max(sites, key=lambda s: s.pos.dist(base_pos(sim)))
    sim.add_building("townhall", 1, far.pos, complete=True)
    second = sim.map_info()
    same_object = first is second
    owner_after = next(s.owner for s in second.expansion_sites if s.sid == far.sid)
    has_b = next(s.has_building for s in second.expansion_sites if s.sid == far.sid)
    return CaseResult(
        "x4_mapinfo_frozen", "structure",
        "FAIL" if (same_object and owner_after != 1) else "PASS",
        "add_building / _kill 会让 MapInfo 缓存失效：分矿 owner / has_building "
        "能随建筑变化刷新（不再冻结在第 0 秒）。",
        {"same_object": same_object, "owner_after_adding_base": owner_after,
         "has_building": has_b, "far_site": far.sid},
    )


TACTIC_CASES = (
    p1_score_is_cost_blind, p2_score_terms,
    e1_saturated_but_army_massing, e2_no_early_expand_on_advantage,
    e3_rich_site_under_garrison, e4_map_structure_ignored,
    r1_retreat_into_unreachable_pocket, r2_surrounded,
    r3_threat_between_army_and_base,
    x1_multi_manager_conflict, x2_fog_leak_site_owner,
    x3_second_worker_proto_ambiguous, x4_mapinfo_frozen,
)

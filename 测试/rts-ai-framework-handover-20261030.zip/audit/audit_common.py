"""审计套件公共设施。

本目录**不属于** 46 用例考试系统，是一次性的「交接前取证」工具：
它只测量、不改 AI 行为，因此可以放心跑出「当前真实状态」。

设计约束
--------
* 不改动 src/ 下任何运行时代码；
* 不注册到 rtsexam 的 REGISTRY（避免污染 46 用例基线）；
* 每个场景可独立复现，输出机读 JSON。
"""
from __future__ import annotations

import json
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from rtsai import RTSAgent                      # noqa: E402
from rtsai.profile import load_profile          # noqa: E402
from rtscontract.catalog import Catalog, catalog_from_dict  # noqa: E402
from rtscontract.commands import Command        # noqa: E402
from rtscontract.configio import load_json      # noqa: E402
from rtscontract.enums import Cmd, Issuer, OrderKind, Reason  # noqa: E402
from rtscontract.snapshot import WorldSnapshot  # noqa: E402
from rtscontract.vec import Vec2                # noqa: E402
from rtsim import MockGateway, ScenarioSpec, build_sim  # noqa: E402
from rtsim.sim import Sim                       # noqa: E402
from rtsim.scenarios import spawn_line          # noqa: E402

HZ = 10.0
_CATALOG: Catalog | None = None


def catalog() -> Catalog:
    global _CATALOG
    if _CATALOG is None:
        _CATALOG = catalog_from_dict(load_json("catalog.json"))
    return _CATALOG


def profile(patch: Mapping[str, Any] | None = None) -> dict[str, Any]:
    return load_profile(dict(patch or {}))


# --------------------------------------------------------------------------- 场景
def make_sim(
    *,
    seed: int = 7,
    layout: str = "open",
    width: int = 88,
    height: int = 88,
    start_gold: float = 520.0,
    workers: int = 6,
    my_units: Sequence[tuple[str, int]] = (),
    enemy_units: Sequence[tuple[str, int]] = (),
    my_buildings: Sequence[str] = ("barracks",),
    enemy_buildings: Sequence[str] = (),
    enemy_base: str = "none",
    player: bool = False,
    require_both_teams: bool = False,
    max_time: float = 400.0,
    config: Mapping[str, Any] | None = None,
) -> Sim:
    spec = ScenarioSpec(
        seed=seed,
        layout=layout,
        width=width,
        height=height,
        start_gold=start_gold,
        workers=workers,
        enemy_workers=0,
        my_base="townhall",
        enemy_base=enemy_base,
        my_units=tuple(my_units),
        enemy_units=tuple(enemy_units),
        my_buildings=tuple(my_buildings),
        enemy_buildings=tuple(enemy_buildings),
        require_both_teams=require_both_teams,
        max_time=max_time,
        config=dict(config or {}),
    )
    sim = build_sim(spec, catalog())
    if player:
        sim.players[0]["presence"] = True
    return sim


def agent_for(sim: Sim, team: int = 0, issuer: str = Issuer.ADJUTANT,
              overrides: Mapping[str, Any] | None = None) -> RTSAgent:
    return RTSAgent(MockGateway(sim, team, issuer=issuer), profile(overrides))


# --------------------------------------------------------------------------- 驱动器
def run(
    sim: Sim,
    agents: Mapping[int, Any],
    duration: float,
    *,
    on_tick: Callable[[Sim], None] | None = None,
    ai_interval: int = 2,
) -> Sim:
    """与 MatchRunner 等价的最简循环，但允许逐 tick 挂钩（审计需要精确 tick）。"""
    max_ticks = int(duration * sim.tick_hz)
    while sim.tick < max_ticks and not sim.over:
        sim.step()
        if on_tick is not None:
            on_tick(sim)
        if sim.tick % ai_interval == 0:
            for team in sorted(agents):
                ag = agents[team]
                if ag is not None:
                    ag.update()
    return sim


# --------------------------------------------------------------------------- 查询
def army_ids(sim: Sim, team: int = 0) -> list[int]:
    return [u.id for u in sim.units
            if u.alive and u.team == team and u.proto.harvest is None]


def worker_ids(sim: Sim, team: int = 0) -> list[int]:
    return [u.id for u in sim.units
            if u.alive and u.team == team and u.proto.harvest is not None]


def base_pos(sim: Sim, team: int = 0) -> Vec2:
    for b in sim.buildings:
        if b.alive and b.team == team and b.proto.dropoff:
            return b.pos
    return Vec2(sim.width / 2, sim.height / 2)


def orders_of(sim: Sim, *, who: str | None = None, uids: Iterable[int] | None = None,
              t0: int = 0, t1: int | None = None) -> list[tuple[int, int, str, str]]:
    ids = set(uids) if uids is not None else None
    out = []
    for tick, uid, kind, owner in sim.orders_log:
        if tick < t0:
            continue
        if t1 is not None and tick >= t1:
            continue
        if who is not None and owner != who:
            continue
        if ids is not None and uid not in ids:
            continue
        out.append((tick, uid, kind, owner))
    return out


def first_tick(rows: Sequence[tuple[int, int, str, str]]) -> int | None:
    return min((r[0] for r in rows), default=None)


def duplicate_orders(sim: Sim, t0: int = 0,
                     who: str = Issuer.ADJUTANT) -> list[tuple[int, int, int]]:
    """同一 tick 内同一个单位被下发了多条命令 → 多 Manager 抢控制权。"""
    seen: dict[tuple[int, int], int] = {}
    for tick, uid, kind, owner in sim.orders_log:
        if tick < t0 or owner != who or kind == OrderKind.IDLE:
            continue
        seen[(tick, uid)] = seen.get((tick, uid), 0) + 1
    return [(t, u, n) for (t, u), n in seen.items() if n > 1]


@dataclass
class CaseResult:
    name: str
    group: str
    status: str                     # PASS / WARNING / FAIL / NOT_SUPPORTED / NOT_TESTABLE
    detail: str = ""
    metrics: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "group": self.group,
            "status": self.status,
            "detail": self.detail,
            "metrics": self.metrics,
        }


def guard(fn: Callable[[], CaseResult], name: str, group: str) -> CaseResult:
    """执行一个场景；任何异常都变成 FAIL 而不是让整套审计崩掉。"""
    try:
        return fn()
    except Exception as exc:  # noqa: BLE001
        import traceback
        return CaseResult(
            name=name, group=group, status="FAIL",
            detail=f"{type(exc).__name__}: {exc}",
            metrics={"traceback": traceback.format_exc(limit=8)},
        )

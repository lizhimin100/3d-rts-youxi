# 审计实测摘要（自动生成）

生成时间：2026-10-27 22:23:08

| 状态 | 数量 |
|---|---|
| NOT_SUPPORTED | 2 |
| WARNING | 8 |
| PASS | 33 |

## 明细

| # | 用例 | 组 | 状态 | 说明 |
|---|---|---|---|---|
| 1 | `s1_long_move_30s` | control | **PASS** | 0/8 个单位还没等整条命令结束就被 AI 接管；最后一个单位到达后 5.2s AI 重新下令。 |
| 2 | `s2_patrol` | control | **NOT_SUPPORTED** | OrderKind 声明了 patrol，但 Cmd 没有 PATROL、Sim 也没有处理器；玩家/AI 都无法下达巡逻命令，控制权语义里的 patrol 分支是死代码。 |
| 3 | `s3_target_dies_mid_order` | control | **PASS** | 目标提前死亡后：命令结束 +1.0s 仍受保护（{'player_grace': 6}），+7.0s 已交还副官（{'adjutant': 6}）；执行期间 AI 命令 0 条。 |
| 4 | `s4_shift_queue` | control | **NOT_SUPPORTED** | Command 没有队列语义：第二条命令直接覆盖第一条（order_point 变成 p2），快照也只暴露单个 order/order_point，无法表达「正在执行第 2/3 条」。 |
| 5 | `s5_hold_forever` | control | **PASS** | HOLD → PLAYER_HOLDING（无时限）；60 秒内 AI 命令 0 条，状态 {'player_holding': 6} |
| 6 | `s6_stop_not_honoured` | control | **PASS** | STOP → PLAYER_HOLDING，30 秒内 AI 不得接管；实测首次 AI 命令在 30.0 秒（None = 全程未动）。 |
| 7 | `s7_permanent_lock` | control | **PASS** | PLAYER_LOCKED 无期限，100 秒内零条 AI 命令 |
| 8 | `s8_partial_formation` | control | **WARNING** | 5/12（41%）达到 _is_army_scale 门槛 → 玩家这一下移动被当成全军级指令：副官把 rally 改到玩家点击处，剩下 7 个兵被一起拽过去。（被移动的 5 个兵现在有 5 秒宽限，不再被立刻回收。） |
| 9 | `s9_target_invalid` | control | **PASS** | 目标立即失效：+1.0s 仍受保护（{'player_grace': 5}），+7.0s 已交还（{'adjutant': 5}）——「失效」与「正常结束」走同一条路径。 |
| 10 | `s10_short_move_grace` | control | **PASS** | 3 秒短命令：+1.0s 仍受保护（{'player_grace': 6}），+7.0s 已交还（{'adjutant': 6}）——宽限期与命令长短无关，固定从「命令结束」起算。 |
| 11 | `s11_destination_command_loop` | control | **PASS** | 部队抵达攻击点后仍在以 0.1 条/秒（每单位 0.00 条/秒）重发 ['attack_move']：到达→idle→重发的循环没有任何「已在目标点」判定。 |
| 12 | `f1_target_dies_before_issue` | fault | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| 13 | `f2_building_dies` | fault | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| 14 | `f3_production_cancelled` | fault | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| 15 | `f4_construction_cancelled` | fault | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| 16 | `f5_nodes_depleted` | fault | **WARNING** | 资源枯竭后农民全部 idle，AI 没有「无矿可采」的处置策略 |
| 17 | `f6_enemies_vanish` | fault | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| 18 | `f7_path_fail` | fault | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| 19 | `f8_path_fail_long` | fault | **PASS** | 路径永久失败 90 秒：命令 44 条 / STOP 36 条；每 30 秒命令数 26 → 5 → 5，指数退避生效，系统收敛（后 30 秒 ≤ 前 30 秒的一半）。 |
| 20 | `f9_move_rejected` | fault | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| 21 | `f10_units_frozen` | fault | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| 22 | `f11_stale_snapshot` | fault | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| 23 | `f12_state_jitter` | fault | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| 24 | `f13_dead_ids` | fault | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| 25 | `f14_player_takeover` | fault | **PASS** | 系统自行恢复，无崩溃/无命令风暴 |
| 26 | `p1_cost_dimensions` | production | **PASS** | supply：人口占用已按比例进入打分；build_time：训练时长已按比例进入打分；gold：便宜者恒胜 → 「每金战力」仍是主导项 |
| 27 | `p2_score_terms` | production | **PASS** | 打分有 7 个因子，不是单变量；主导项是「每金战力」，supply 与 build_time 已按比例进入打分；科技成本 / 射程 / 机动性 / 攻城 / 辅助能力仍未进入打分。 |
| 28 | `e1_massing_army_ignored` | expansion | **PASS** | 12 个重甲在 30 格外集结（base_threat=0.0，defense_radius=17 看不到）。扩张次数：对照 5 次 vs 受压迫 2 次（其中集结后新增 0 次）；最后一次拦截原因=autonomy，home_pressure=0.0。 |
| 29 | `e2_no_opportunistic_expand` | expansion | **PASS** | 60 秒时 652.0 金 + 30 兵 + 无敌情 → 已扩张到 3 个基地；军事窗口 advantage=0.2167、最佳矿点效用=2.0。 |
| 30 | `e3_danger_quantized` | expansion | **PASS** | 4 个可见敌人距矿点 ≤5 格，但 danger=0.143：危险度按 12×12 宏格（7.3 格/格）**单格取值**，敌人落在相邻宏格就完全不计；3×3 邻域求和才 = 6.63。 |
| 31 | `e4_no_choke_value` | expansion | **PASS** | 选址已包含 walkable 密度 → choke（路口）与 route（要道）两项地形价值；低资源但地形价值 ≥0.55 的点按 strategic_min_remaining_ratio 下调资源门槛。 |
| 32 | `r1_retreat_into_dead_end` | retreat | **PASS** | 撤退点现在会做可达性校验（网关 can_reach）：封闭房间被拒绝，本次撤退点回落到基地且可达。 |
| 33 | `r2_surrounded` | retreat | **WARNING** | 四面包围时「远离质心」向量≈0，退化为「朝基地」的直线方向 —— 等于从敌人中间穿过去；没有突破点 / 薄弱侧评估。 |
| 34 | `r3_retreat_away_from_home` | retreat | **WARNING** | 敌人位于「部队—基地」连线上时，远离威胁向量把部队推得离基地更远；算法完全不考虑友方控制区 / 防御建筑 / 基地方向。 |
| 35 | `x1_multi_manager_conflict` | structure | **WARNING** | 180 秒内 4 次「同一 tick 同一单位被下 ≥2 条命令」（占 AI 命令 5.13%）；执行顺序 economy→production→expansion→scout→combat，后写的覆盖先写的（例如侦察会覆盖刚落下的建造指令）。 |
| 36 | `x2_fog_leak_site_owner` | structure | **PASS** | expansion_sites 的 owner / has_building 已按迷雾过滤：敌方在未探索分矿造基地不再通过快照暴露（remaining 仍视为地图固有知识）。 |
| 37 | `x3_second_worker_ambiguous` | structure | **WARNING** | economy._worker_proto() 与 world.buildable_protos() 都取 workers()[0]（Cookbook 插入序）；新增第二种农民后，AI 仍然只造第一种，没有任何「按场景选农民」的配置入口。 |
| 38 | `x4_mapinfo_frozen` | structure | **PASS** | add_building / _kill 会让 MapInfo 缓存失效：分矿 owner / has_building 能随建筑变化刷新（不再冻结在第 0 秒）。 |
| 39 | `torture_adjutant` | torture | **WARNING** | 全部 10 项通过 |
| 40 | `perf_100` | performance | **PASS** | AI 决策 10.53 ms + 网关处理命令 15.27 ms = 25.8 ms/次（0.4 条命令/次）；快照 0.53 ms；热点 combat 5.31 ms |
| 41 | `perf_300` | performance | **PASS** | AI 决策 27.48 ms + 网关处理命令 22.03 ms = 49.51 ms/次（1.0 条命令/次）；快照 1.15 ms；热点 combat 17.12 ms |
| 42 | `perf_500` | performance | **PASS** | AI 决策 48.84 ms + 网关处理命令 25.82 ms = 74.66 ms/次（1.5 条命令/次）；快照 1.73 ms；热点 combat 32.98 ms |
| 43 | `perf_1000` | performance | **WARNING** | AI 决策 116.6 ms + 网关处理命令 35.27 ms = 151.87 ms/次（3.5 条命令/次）；快照 3.18 ms；热点 combat 87.07 ms |

## 关键指标

### s1_long_move_30s (PASS)

```
march_seconds=29.4, ttl_seconds=8.0, units_taken_over_early=0, orders_before_last_arrival=0, orders_after=8, grace_after_last_arrival_seconds=5.2, control_blocked=0
```

### s2_patrol (NOT_SUPPORTED)

```
cmd_has_patrol=False, sim_accepts_patrol=False, reject_reason=invalid, order_kind_has_patrol=True
```

### s3_target_dies_mid_order (PASS)

```
order_seconds=4.1, ai_orders_during=0, reject_target_invalid=0
```

### s4_shift_queue (NOT_SUPPORTED)

```
has_queue_semantics=False, second_overwrote_first=True
```

### s5_hold_forever (PASS)

```
ai_orders=0, units_still_holding=6, control_blocked=0
```

### s6_stop_not_honoured (PASS)

```
ai_orders=6, grace_seconds=30.0, hold_after_stop_seconds=30.0, ttl_seconds=8.0
```

### s7_permanent_lock (PASS)

```
ai_orders=0, control_blocked=0
```

### s8_partial_formation (WARNING)

```
directive_registered=True, army_scale_threshold=0.4 * army, rest_units_ordered=14, rest_near_player_point=0, grace_seconds=5.2
```

### s9_target_invalid (PASS)

```
order_seconds=1.1, ttl_seconds=8.0
```

### s10_short_move_grace (PASS)

```
order_seconds=3.2, grace_seconds=5.0
```

### s11_destination_command_loop (PASS)

```
steady_orders=2, orders_per_second=0.05, per_unit_per_second=0.0, commands_sent_total=52, commands_skipped_total=6828, attack_until_minus_now=20.0, mode=attack
```

### f1_target_dies_before_issue (PASS)

```
exception=, commands_sent=24, commands_per_sec=0.48, commands_dropped=0, sanity_episodes=6, stuck_episodes=0, army_alive=7, workers_alive=8, snapshot_calls=250, issue_calls=24
```

### f2_building_dies (PASS)

```
exception=, commands_sent=21, commands_per_sec=0.42, commands_dropped=0, sanity_episodes=4, stuck_episodes=0, army_alive=5, workers_alive=6, snapshot_calls=250, issue_calls=21, buildings_killed=3
```

### f3_production_cancelled (PASS)

```
exception=, commands_sent=25, commands_per_sec=0.5, commands_dropped=0, sanity_episodes=3, stuck_episodes=0, army_alive=4, workers_alive=6, snapshot_calls=250, issue_calls=25, queue_clears=15, max_queue_observed=1, trained=4
```

### f4_construction_cancelled (PASS)

```
exception=, commands_sent=45, commands_per_sec=0.56, commands_dropped=0, sanity_episodes=3, stuck_episodes=0, army_alive=3, workers_alive=10, snapshot_calls=400, issue_calls=45, construction_killed=8, build_attempts=12
```

### f5_nodes_depleted (WARNING)

```
exception=, commands_sent=21, commands_per_sec=0.35, commands_dropped=0, sanity_episodes=3, stuck_episodes=0, army_alive=6, workers_alive=11, snapshot_calls=300, issue_calls=21, idle_workers=10
```

### f6_enemies_vanish (PASS)

```
exception=, commands_sent=46, commands_per_sec=0.66, commands_dropped=0, sanity_episodes=5, stuck_episodes=0, army_alive=11, workers_alive=9, snapshot_calls=350, issue_calls=46, attack_mode_after=attack
```

### f7_path_fail (PASS)

```
exception=, commands_sent=29, commands_per_sec=0.64, commands_dropped=0, sanity_episodes=10, stuck_episodes=5, army_alive=9, workers_alive=7, snapshot_calls=225, issue_calls=29, stuck_flag=0
```

### f8_path_fail_long (PASS)

```
exception=, commands_sent=44, commands_per_sec=0.49, commands_dropped=0, sanity_episodes=14, stuck_episodes=9, army_alive=11, workers_alive=8, snapshot_calls=450, issue_calls=44, stop_orders=36
```

### f9_move_rejected (PASS)

```
exception=, commands_sent=20, commands_per_sec=0.5, commands_dropped=0, sanity_episodes=3, stuck_episodes=0, army_alive=9, workers_alive=7, snapshot_calls=200, issue_calls=20, move_rejects=1
```

### f10_units_frozen (PASS)

```
exception=, commands_sent=23, commands_per_sec=0.57, commands_dropped=0, sanity_episodes=7, stuck_episodes=4, army_alive=6, workers_alive=5, snapshot_calls=200, issue_calls=23
```

### f11_stale_snapshot (PASS)

```
exception=, commands_sent=157, commands_per_sec=3.14, commands_dropped=0, sanity_episodes=7, stuck_episodes=0, army_alive=7, workers_alive=8, snapshot_calls=250, issue_calls=157, ai_time_lag_sec=3.0
```

### f12_state_jitter (PASS)

```
exception=, commands_sent=24, commands_per_sec=0.48, commands_dropped=0, sanity_episodes=6, stuck_episodes=0, army_alive=7, workers_alive=8, snapshot_calls=250, issue_calls=24
```

### f13_dead_ids (PASS)

```
exception=, commands_sent=18, commands_per_sec=0.45, commands_dropped=0, sanity_episodes=3, stuck_episodes=0, army_alive=5, workers_alive=5, snapshot_calls=200, issue_calls=18, player_cmd_rejected=1
```

### f14_player_takeover (PASS)

```
exception=, commands_sent=22, commands_per_sec=0.49, commands_dropped=0, sanity_episodes=5, stuck_episodes=0, army_alive=9, workers_alive=7, snapshot_calls=225, issue_calls=22, ai_orders_during_ttl=0, control_blocked=0
```

### p1_cost_dimensions (PASS)

```
supply_blind=False, build_time_blind=False, gold_is_dominant=True, supply_penalty_rule=score -= supply_weight * (supply/max_supply) * 0.8
```

### p2_score_terms (PASS)

```
stable_pick=melee
```

### e1_massing_army_ignored (PASS)

```
spawned=12, expansions_after_spawn=0, control_total=5, base_threat_with_army=0.0, defense_radius=17, last_block=autonomy, plan_with_army=all_in
```

### e2_no_opportunistic_expand (PASS)

```
gold=652.0, army=30, townhalls=3, workers=6, expansion_started=2, capacity=30
```

### e3_danger_quantized (PASS)

```
enemies_within_5=4, danger_point=0.143, danger_3x3=6.63, site_visible=True, macro_cell_tiles=7.3
```

### e4_no_choke_value (PASS)

```
site_min_remaining=600, strategic_min_remaining_ratio=0.35, terrain_weight=0.55
```

### r1_retreat_into_dead_end (PASS)

```
walkable=True, reachable=True, path_len=0
```

### r2_surrounded (WARNING)

```
base_dist_before=38.9, base_dist_after=16.9
```

### r3_retreat_away_from_home (WARNING)

```
base_dist_before=22.0, base_dist_after=44.0
```

### x1_multi_manager_conflict (WARNING)

```
duplicates=4, total_orders=78, rate=0.0513
```

### x2_fog_leak_site_owner (PASS)

```
visible_enemy_buildings=0, site_visible=False, far_site=5
```

### x3_second_worker_ambiguous (WARNING)

```
picked=worker, trained_choice_is_first=True
```

### x4_mapinfo_frozen (PASS)

```
same_object=False, owner_after_adding_base=1, has_building=True, far_site=5
```

### torture_adjutant (WARNING)

```
ai_orders_on_locked=0, ai_orders_on_moved_workers=0, ai_orders_during_long_move=0, steady_cmd_per_unit_sec=1.2, plan_changes=3, duplicates=2, target_invalid=0, workers_alive=10, army_alive=16
```

### perf_100 (PASS)

```
units=119, team_units=50, ticks=120, ai_total_ms_per_update=25.8, gateway_issue_ms_per_update=15.27, ai_logic_ms_per_update=10.53, issue_calls_per_update=0.4, sim_ms_per_tick=33.38, snapshot_ms=0.53, memory_kb_delta=148.4, commands_per_sim_second=3.3, commands_dropped=0, budget_saturated=False
```

### perf_300 (PASS)

```
units=315, team_units=150, ticks=100, ai_total_ms_per_update=49.51, gateway_issue_ms_per_update=22.03, ai_logic_ms_per_update=27.48, issue_calls_per_update=1.0, sim_ms_per_tick=89.37, snapshot_ms=1.15, memory_kb_delta=224.2, commands_per_sim_second=8.2, commands_dropped=0, budget_saturated=False
```

### perf_500 (PASS)

```
units=513, team_units=250, ticks=80, ai_total_ms_per_update=74.66, gateway_issue_ms_per_update=25.82, ai_logic_ms_per_update=48.84, issue_calls_per_update=1.5, sim_ms_per_tick=148.53, snapshot_ms=1.73, memory_kb_delta=391.5, commands_per_sim_second=12.1, commands_dropped=0, budget_saturated=False
```

### perf_1000 (WARNING)

```
units=1017, team_units=500, ticks=60, ai_total_ms_per_update=151.87, gateway_issue_ms_per_update=35.27, ai_logic_ms_per_update=116.6, issue_calls_per_update=3.5, sim_ms_per_tick=301.54, snapshot_ms=3.18, memory_kb_delta=509.2, commands_per_sim_second=27.8, commands_dropped=0, budget_saturated=False
```


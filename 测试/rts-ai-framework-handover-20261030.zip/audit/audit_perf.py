"""第九部分：性能审计。

严格区分三件事：
1. **模拟器**耗时（``sim.step``）—— 真实游戏里不存在，不能算进 AI 预算；
2. **AI Core** 耗时（``agent.update``）—— 这才是真实游戏里每 200ms 要付的钱；
3. 两者之间的**快照构造**耗时 —— 真实游戏里由适配器承担，通常是隐藏大头。
"""
from __future__ import annotations

import time
import tracemalloc
from typing import Any, Callable

from audit_common import CaseResult, HZ, agent_for, make_sim, profile
from rtsai import RTSAgent
from rtscontract.vec import Vec2
from rtsim import MockGateway


def _fill(sim, team: int, n: int, proto: str = "melee",
          x0: int = 3, x1: int | None = None) -> int:
    x1 = x1 if x1 is not None else sim.width - 3
    placed = 0
    y = 3
    while placed < n and y < sim.height - 3:
        for x in range(x0, x1, 2):
            if placed >= n:
                break
            if sim.map.walkable[y][x]:
                sim.add_unit(proto, team, Vec2(x + 0.5, y + 0.5))
                placed += 1
        y += 2
    return placed


def _wrap(ag: RTSAgent, modname: str, acc: dict[str, float]) -> None:
    mod = getattr(ag, modname)
    fn = getattr(mod, "update")
    key = modname
    acc.setdefault(key, 0.0)

    def timed(*a, **k):
        t0 = time.perf_counter()
        try:
            return fn(*a, **k)
        finally:
            acc[key] = acc.get(key, 0.0) + (time.perf_counter() - t0)

    setattr(mod, "update", timed)


def perf_at(n: int, ticks: int) -> dict[str, Any]:
    per = max(1, n // 2)
    sim = make_sim(
        width=120, height=120, workers=20, start_gold=4000.0, my_units=(),
        config={"max_units_per_team": n + 40, "max_time_seconds": 10000.0},
    )
    # 双方各铺一半，避免全部堆在同一点
    _fill(sim, 0, per, x0=3, x1=sim.width // 2)
    _fill(sim, 1, per, x0=sim.width // 2, x1=sim.width - 3)
    sim.refresh_fog()

    gw = MockGateway(sim, 0)
    ag = RTSAgent(gw, profile())
    acc: dict[str, float] = {}
    for m in ("economy", "production", "expansion", "scout", "combat", "sanity"):
        _wrap(ag, m, acc)
    acc["director"] = 0.0
    acc["territory"] = 0.0
    acc["fog"] = 0.0
    _wrap(ag, "director", acc)
    _wrap(ag, "territory", acc)
    _wrap(ag, "fog", acc)

    # 把「网关处理命令」从 AI 决策里剥离出来：
    # 模拟器的 issue() 内含 A* 寻路，属于游戏侧成本，不能算进 AI 预算。
    issue_ms = {"total": 0.0, "calls": 0}
    _orig_issue = gw.issue

    def timed_issue(cmd):
        t0 = time.perf_counter()
        try:
            return _orig_issue(cmd)
        finally:
            issue_ms["total"] += time.perf_counter() - t0
            issue_ms["calls"] += 1

    gw.issue = timed_issue  # type: ignore[assignment]

    # 预热
    for _ in range(8):
        sim.step()
        ag.update()

    # 快照构造单独计时（会消费事件队列，但只影响事件，不影响性能结论）
    t0 = time.perf_counter()
    for _ in range(20):
        gw.snapshot()
    snap_ms = (time.perf_counter() - t0) / 20 * 1000

    tracemalloc.start()
    mem0 = tracemalloc.get_traced_memory()[0]
    t_sim = t_ai = 0.0
    cmd0 = ag.stats()["commands"]["commands_sent"]
    for _ in range(ticks):
        a = time.perf_counter()
        sim.step()
        b = time.perf_counter()
        ag.update()
        c = time.perf_counter()
        t_sim += b - a
        t_ai += c - b
    mem1 = tracemalloc.get_traced_memory()[0]
    tracemalloc.stop()

    st = ag.stats()
    sent = st["commands"]["commands_sent"] - cmd0
    sim_seconds = ticks * sim.dt
    total_units = len([u for u in sim.units if u.alive])
    modules = {k: round(v / ticks * 1000, 2) for k, v in acc.items()}
    hot = sorted(modules.items(), key=lambda kv: kv[1], reverse=True)[:4]
    issue_per_update = issue_ms["total"] / ticks * 1000
    issue_calls = issue_ms["calls"] / ticks
    return {
        "units": total_units,
        "team_units": per,
        "ticks": ticks,
        "ai_total_ms_per_update": round(t_ai / ticks * 1000, 2),
        "gateway_issue_ms_per_update": round(issue_per_update, 2),
        "ai_logic_ms_per_update": round(t_ai / ticks * 1000 - issue_per_update, 2),
        "issue_calls_per_update": round(issue_calls, 1),
        "sim_ms_per_tick": round(t_sim / ticks * 1000, 2),
        "snapshot_ms": round(snap_ms, 2),
        "modules_ms": modules,
        "hotspots": hot,
        "memory_kb_delta": round((mem1 - mem0) / 1024, 1),
        "commands_per_sim_second": round(sent / max(1e-6, sim_seconds), 1),
        "commands_dropped": st["commands"]["commands_dropped"],
        "budget_saturated": st["commands"]["commands_dropped"] > 0,
    }


def run_perf() -> list[CaseResult]:
    out: list[CaseResult] = []
    plan = ((100, 120), (300, 100), (500, 80), (1000, 60))
    for n, ticks in plan:
        try:
            m = perf_at(n, ticks)
            budget = 200.0  # 5 Hz → 200ms 预算
            logic = m["ai_logic_ms_per_update"]
            status = "PASS" if logic < budget * 0.25 else (
                "WARNING" if logic < budget * 0.6 else "FAIL")
            detail = (f"AI 决策 {logic} ms + 网关处理命令 {m['gateway_issue_ms_per_update']} ms "
                      f"= {m['ai_total_ms_per_update']} ms/次（{m['issue_calls_per_update']} 条命令/次）；"
                      f"快照 {m['snapshot_ms']} ms；热点 {m['hotspots'][0][0]} {m['hotspots'][0][1]} ms")
            if m["budget_saturated"]:
                detail += f"；命令预算耗尽，本段被丢弃 {m['commands_dropped']} 条"
                status = "FAIL" if status != "FAIL" else status
            out.append(CaseResult(f"perf_{n}", "performance", status, detail, m))
        except Exception as exc:  # noqa: BLE001
            out.append(CaseResult(f"perf_{n}", "performance", "FAIL",
                                  f"{type(exc).__name__}: {exc}", {}))
    return out

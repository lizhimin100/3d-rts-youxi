"""诊断 1v1（双方 AI）曲线。"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from rtsexam.harness import run_match  # noqa: E402
from rtsim import ScenarioSpec  # noqa: E402


def main() -> None:
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 11
    h = run_match(ScenarioSpec(width=88, height=88, max_time=400), seed, duration=220)
    keys = [
        "time", "gold_0", "workers_0", "army_0", "army_value_0", "supply_used_0", "supply_cap_0",
        "army_1", "army_value_1", "supply_used_1", "supply_cap_1", "kills_0", "losses_0", "kills_1", "losses_1",
    ]
    print("  ".join(f"{k:>12s}" for k in keys))
    for s in h.result.samples[::10]:
        print("  ".join(f"{str(s.get(k)):>12s}" for k in keys))
    print("winner", h.result.winner, "agent0", h.stats["plan"], h.stats["mode"])


if __name__ == "__main__":
    main()

"""诊断回防与反愚蠢「军队发呆」判定。"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from rtsexam.cases._util import base_spec, raid  # noqa: E402
from rtsexam.harness import run_match  # noqa: E402
from rtscontract.vec import Vec2  # noqa: E402


def main() -> None:
    spec = base_spec(my_units=(("melee", 5),), my_buildings=("barracks",))
    h = run_match(spec, 23, duration=100, scripts=[(55.0, raid("melee", 3, offset=10.0))], enemy_ai=False)
    base = next((b.pos for b in h.sim.buildings if b.team == 0 and b.proto.dropoff), Vec2())
    print("base", base)
    for t in (50, 56, 60, 65, 70, 80, 100):
        # 无法回溯历史位置，这里只能看订单日志
        orders = [o for o in h.sim.orders_log if 545 <= o[0] <= t * 10]
        print(f"t={t} orders_after_raid={len(orders)} last={orders[-3:] if orders else None}")
    print("issues:", h.stats["sanity"]["issues"])
    print("combat:", h.stats["combat"])
    print("kills", h.last("kills_0"), "losses", h.last("losses_0"))


if __name__ == "__main__":
    main()

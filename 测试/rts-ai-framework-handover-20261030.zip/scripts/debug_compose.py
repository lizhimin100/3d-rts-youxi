"""追踪生产选择。"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from rtsai.production import CompositionSolver  # noqa: E402
from rtsexam.harness import run_match  # noqa: E402
from rtsim import ScenarioSpec  # noqa: E402

orig = CompositionSolver.choose
log: list[str] = []


def patched(self, candidates):
    out = orig(self, candidates)
    w = self.ctx.world
    if out is not None and w.time > 100:
        mix = {k: round(v, 2) for k, v in w.enemy_mix.items()}
        log.append(f"t={w.time:.0f} cands={[c.id for c in candidates]} -> {out.id} mix={mix} gold={w.gold:.0f}")
    return out


CompositionSolver.choose = patched


def main() -> None:
    spec = ScenarioSpec(width=88, height=88, max_time=260)
    h = run_match(spec, 7, duration=160, enemy_ai=False)
    print("\n".join(log[:60]))
    print("...")
    print("\n".join(log[-25:]))


if __name__ == "__main__":
    main()

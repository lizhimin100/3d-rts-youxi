"""诊断克制类用例的军队构成。"""
from __future__ import annotations

import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from rtsexam.cases.prod_cases import _spawn_hold  # noqa: E402
from rtsexam.harness import run_match  # noqa: E402
from rtsim import ScenarioSpec  # noqa: E402


def run(label: str, scripts, dur: float) -> None:
    spec = ScenarioSpec(width=88, height=88, max_time=dur + 40)
    h = run_match(spec, 7, duration=dur, scripts=scripts, enemy_ai=False)
    print("=" * 70)
    print(label)
    for s in h.result.samples[::10]:
        army = s.get("army_0")
        print(f"  t={s['time']:5.0f} army={army:3d} supply={s['supply_used_0']:4.0f}/{s['supply_cap_0']:4.0f} gold={s['gold_0']:6.0f}")
    comp = Counter(u.proto.id for u in h.sim.units if u.alive and u.team == 0 and u.proto.harvest is None)
    print("  composition:", dict(comp))
    print("  enemy:", Counter(u.proto.id for u in h.sim.units if u.alive and u.team == 1))
    print("  kills:", h.last("kills_0"), "losses:", h.last("losses_0"))
    print("  plan:", h.stats["plan"], "mode:", h.stats["mode"])


def main() -> None:
    run(
        "AIR",
        [(25.0, _spawn_hold("flyer", 4, "enemy", near_base=True))],
        150,
    )
    run(
        "GROUND",
        [
            (18.0, _spawn_hold("melee", 4, "enemy")),
            (48.0, _spawn_hold("melee", 4, "enemy")),
            (78.0, _spawn_hold("melee", 4, "enemy")),
        ],
        150,
    )


if __name__ == "__main__":
    main()

"""打印沙盒（无敌）局的经济/军队/构成曲线。"""
from __future__ import annotations

import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from rtsexam.harness import run_match  # noqa: E402
from rtsim import ScenarioSpec  # noqa: E402


def main() -> None:
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 5
    dur = float(sys.argv[2]) if len(sys.argv) > 2 else 200.0
    spec = ScenarioSpec(
        enemy_base="none", require_both_teams=False, max_time=dur + 50, width=88, height=88
    )
    h = run_match(spec, seed, duration=dur)
    keys = ["time", "gold_0", "workers_0", "army_0", "supply_used_0", "supply_cap_0", "buildings_0", "expansions_0"]
    print("  ".join(f"{k:>12s}" for k in keys))
    for s in h.result.samples[::15]:
        print("  ".join(f"{str(s.get(k)):>12s}" for k in keys))
    comp = Counter(u.proto.id for u in h.sim.units if u.alive and u.team == 0 and u.proto.harvest is None)
    print("composition:", dict(comp))
    print("buildings:", sorted(Counter(b.proto.id for b in h.sim.buildings if b.team == 0).items()))
    print("stats:", {k: v for k, v in h.stats.items() if k in ("plan", "mode", "commands")})
    print("sanity:", h.stats["sanity"])


if __name__ == "__main__":
    main()

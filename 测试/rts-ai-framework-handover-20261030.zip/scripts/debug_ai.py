"""诊断脚本：观察建造/扩张/供给的内部状态。"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from rtsai import RTSAgent  # noqa: E402
from rtscontract.catalog import catalog_from_dict  # noqa: E402
from rtscontract.configio import load_json  # noqa: E402
from rtscontract.enums import Issuer  # noqa: E402
from rtsim import MockGateway, ScenarioSpec, build_sim  # noqa: E402


def main() -> None:
    dur = float(sys.argv[1]) if len(sys.argv) > 1 else 180.0
    cat = catalog_from_dict(load_json("catalog.json"))
    sim = build_sim(ScenarioSpec(seed=5, max_time=dur + 20), cat)
    gw = MockGateway(sim, 0, issuer=Issuer.ADJUTANT)
    ag = RTSAgent(gw)
    for _ in range(int(dur * sim.tick_hz)):
        sim.step()
        if sim.tick % 2 == 0:
            ag.update()
        if sim.tick % 100 == 0:
            w = ag.world
            inc = [(b.id, b.proto.id, round(b.progress, 2), len(b.builders)) for b in sim.buildings if not b.complete]
            pend = ag.expansion.pending
            print(
                f"t={sim.time:5.1f} gold={sim.gold[0]:6.0f} sup={sim._supply_used[0]:4.0f}/{sim._supply_cap[0]:4.0f}"
                f" w={len(w.my_workers):2d} army={len(w.my_army):2d} bld={len(w.my_buildings):2d}"
                f" prodq={[len(b.queue) for b in w.production_buildings]}"
                f" inc={inc} exp={None if pend is None else (pend.phase, round(pend.tries))}"
                f" fails={dict(ag.sched.failures)}"
            )
            if ag.sanity.counts:
                print("      issues:", dict(ag.sanity.counts), "fixes:", dict(ag.sanity.fixes))


if __name__ == "__main__":
    main()

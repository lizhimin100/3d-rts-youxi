"""深挖：锁定单位为何仍收到 AI 订单。"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from rtsexam.case import REGISTRY  # noqa: E402
from rtsexam.harness import exam_config  # noqa: E402
from rtsim.sim import Sim  # noqa: E402

orig = Sim._set_order
warn: list[str] = []


def patched(self, u, order, target=None, point=None, owner="", path_to=None):
    if owner in ("adjutant", "enemy_ai"):
        kind = self.control.kind_of(u.id)
        if kind in ("player_locked", "player_manual"):
            warn.append(
                f"t={self.time:.1f} tick={self.tick} uid={u.id} order={order} owner={owner} control={kind}"
            )
    return orig(self, u, order, target=target, point=point, owner=owner, path_to=path_to)


Sim._set_order = patched


def main() -> None:
    import rtsexam.cases  # noqa: F401  注册用例

    cfg = exam_config()
    spec = REGISTRY["adj_offers_suggestion"]

    pool = [11, 23, 37, 41, 59, 71, 83, 118989, 838777, 238679, 705595, 139454, 862068]
    for seed in pool:
        warn.clear()
        out = spec.run(seed, cfg)
        if not out.passed or warn:
            print("seed", seed, "passed", out.passed, "warn", warn[:5])
            for ck in out.checks:
                if not ck.ok:
                    print("   FAIL", ck.name, ck.actual, ck.expected)


if __name__ == "__main__":
    main()

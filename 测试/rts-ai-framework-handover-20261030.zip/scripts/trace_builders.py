"""追踪建造者被释放的时机。"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from rtsai import RTSAgent  # noqa: E402
from rtscontract.catalog import catalog_from_dict  # noqa: E402
from rtscontract.configio import load_json  # noqa: E402
from rtscontract.enums import Issuer  # noqa: E402
from rtsim import MockGateway, ScenarioSpec, build_sim  # noqa: E402
from rtsim.sim import Sim  # noqa: E402

orig = Sim._release_harvest


def patched(self, u):
    if getattr(u, "site", None) is not None and self.tick > 0:
        b = self.ents.get(u.site)
        if b is not None and not getattr(b, "complete", True):
            print(
                f"  RELEASE t={self.time:.1f} unit={u.id} order={u.order} site={u.site} "
                f"proto={b.proto.id} prog={b.progress:.2f}"
            )
    return orig(self, u)


Sim._release_harvest = patched


def main() -> None:
    cat = catalog_from_dict(load_json("catalog.json"))
    sim = build_sim(ScenarioSpec(seed=5), cat)
    gw = MockGateway(sim, 0, issuer=Issuer.ADJUTANT)
    ag = RTSAgent(gw)
    for _ in range(400):
        sim.step()
        if sim.tick % 2 == 0:
            ag.update()
    print("incomplete:", [(b.id, b.proto.id, round(b.progress, 2), len(b.builders)) for b in sim.buildings if not b.complete])


if __name__ == "__main__":
    main()

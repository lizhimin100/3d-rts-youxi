"""逐个种子跑空袭用例，定位失败原因。"""
from __future__ import annotations

import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from rtsexam.cases._util import base_spec, raid  # noqa: E402
from rtsexam.harness import run_match  # noqa: E402


def main() -> None:
    for seed in (11, 23, 37, 41, 59, 71, 83, 101, 202, 303):
        scripts = [
            (38.0, raid("flyer", 2, offset=10.0)),
            (88.0, raid("flyer", 2, offset=10.0)),
        ]
        h = run_match(
            base_spec(my_units=(("ranged", 2), ("melee", 2)), my_buildings=("barracks",)),
            seed,
            duration=165,
            scripts=scripts,
        )
        comp = Counter(u.proto.id for u in h.sim.units if u.alive and u.team == 0 and u.proto.harvest is None)
        enemy = Counter(u.proto.id for u in h.sim.units if u.alive and u.team == 1)
        army = sum(comp.values())
        aa = sum(
            1
            for u in h.sim.units
            if u.alive and u.team == 0 and u.proto.harvest is None and u.proto.can_hit_air
        )
        print(
            f"seed={seed:4d} kills={h.last('kills_0'):4.0f} army={army:2d} aa={aa} "
            f"share={aa / max(1, army):.2f} comp={dict(comp)} enemy={dict(enemy)} "
            f"workers={h.last('workers_0')}"
        )


if __name__ == "__main__":
    main()

"""冒烟测试：验证 Mock Simulator 基本经济/战斗/迷雾流程可运行。"""
from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from rtscontract.catalog import catalog_from_dict  # noqa: E402
from rtscontract.commands import Command  # noqa: E402
from rtscontract.configio import load_json  # noqa: E402
from rtscontract.enums import Cmd, Issuer, OrderKind  # noqa: E402
from rtsim import MockGateway, ScenarioSpec, build_sim  # noqa: E402


def main() -> None:
    cat = catalog_from_dict(load_json("catalog.json"))
    sim = build_sim(ScenarioSpec(seed=1), cat)
    print("units", len(sim.units), "buildings", len(sim.buildings), "nodes", len(sim.nodes))
    gw = MockGateway(sim, 0)
    snap = gw.snapshot()
    print("gold", snap.gold, "supply", snap.supply_used, "/", snap.supply_cap)
    print("units in snap", len(snap.units), "nodes", len(snap.nodes), "fog", round(snap.fog.explored_ratio, 3))

    node = snap.nodes[0]
    hall = [b for b in snap.buildings if b.proto == "townhall"][0]
    workers = tuple(u.uid for u in snap.units if u.proto == "worker")
    res = gw.issue(
        Command(Cmd.HARVEST, Issuer.ADJUTANT, 0, units=workers, target=node.nid, extra=(hall.bid,))
    )
    print("harvest:", res)

    t0 = time.perf_counter()
    for _ in range(300):
        sim.step()
    dt = time.perf_counter() - t0
    print(f"300 ticks in {dt*1000:.1f} ms ({300/dt:.0f} ticks/s)")
    print("gold after 30s:", round(sim.gold[0], 1))
    snap = gw.snapshot()
    print([(u.uid, u.order, round(u.carrying, 1)) for u in snap.units][:6])
    print("supply", snap.supply_used, "/", snap.supply_cap)
    print("territory", sim._territory(0), sim._fog_info(0).explored_ratio)

    # 训练一个单位
    hb = [b for b in snap.buildings if b.proto == "townhall"][0]
    print("train:", gw.issue(Command(Cmd.TRAIN, Issuer.ADJUTANT, 0, building=hb.bid, proto="worker")))
    for _ in range(200):
        sim.step()
    print("units now", len(sim.units), "gold", round(sim.gold[0], 1))

    # 战斗：造两个不同兵种互砍
    from rtscontract.vec import Vec2

    a = sim.add_unit("melee", 0, Vec2(40, 40))
    b = sim.add_unit("ranged", 1, Vec2(43, 40))
    sim.refresh_fog()
    print("fight:", gw.issue(Command(Cmd.ATTACK, Issuer.ADJUTANT, 0, units=(a.id,), target=b.id)))
    for _ in range(120):
        sim.step()
    print("after fight: a", round(a.hp, 1), "b", round(b.hp, 1), "alive", a.alive, b.alive)


if __name__ == "__main__":
    main()

import json

d = json.load(open("reports/exam_report.json", encoding="utf-8"))
for c in d["cases"]:
    if c["passed"]:
        continue
    print("=" * 90)
    print(c["case_id"], c["category"], "error:", bool(c["error"]))
    if c["error"]:
        print(c["error"][:900])
    for ck in c["checks"]:
        if not ck["ok"]:
            print(f"  FAIL {ck['name']}: actual={ck['actual']} expected={ck['expected']} {ck['detail']}")
    for m in c["metrics"]:
        print("  metrics:", m)

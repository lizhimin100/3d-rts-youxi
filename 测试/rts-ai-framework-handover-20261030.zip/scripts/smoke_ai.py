"""AI 冒烟测试：跑一场 4 分钟的 AI vs AI，打印关键曲线。"""
from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from rtsai import RTSAgent  # noqa: E402
from rtscontract.catalog import catalog_from_dict  # noqa: E402
from rtscontract.configio import load_json  # noqa: E402
from rtscontract.enums import Issuer  # noqa: E402
from rtsim import MatchRunner, MockGateway, ScenarioSpec, build_sim  # noqa: E402


def main() -> None:
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 3
    duration = float(sys.argv[2]) if len(sys.argv) > 2 else 240.0
    cat = catalog_from_dict(load_json("catalog.json"))
    sim = build_sim(ScenarioSpec(seed=seed, max_time=duration + 30), cat)
    gw0 = MockGateway(sim, 0, issuer=Issuer.ADJUTANT)
    gw1 = MockGateway(sim, 1, issuer=Issuer.ENEMY_AI)
    a0 = RTSAgent(gw0)
    a1 = RTSAgent(gw1)
    runner = MatchRunner(sim, {0: a0, 1: a1}, ai_interval=2, sample_interval=10)
    t0 = time.perf_counter()
    res = runner.run(duration=duration)
    dt = time.perf_counter() - t0
    print(f"duration={res.time:.0f}s ticks={res.tick} wall={dt:.1f}s speed={res.tick/dt:.0f} tick/s")
    print(f"winner={res.winner} over={res.over}")
    print("samples every 30s:")
    print("  t   gold0 gold1  w0 w1  a0 a1  sup0 sup1  b0 b1  k0 k1  plan0")
    for s in res.samples[::30]:
        if s.get("explored_0") is None:
            s["explored_0"] = 0
        print(
            f"{s['time']:5.0f} {s['gold_0']:6.0f}{s['gold_1']:6.0f} {s['workers_0']:3d}{s['workers_1']:3d}"
            f" {s['army_0']:3d}{s['army_1']:3d} {s['supply_used_0']:5.1f}{s['supply_used_1']:5.1f}"
            f" {s['buildings_0']:3d}{s['buildings_1']:3d} {s['kills_0']:3d}{s['kills_1']:3d}"
        )
    print("agent0:", {k: v for k, v in res.agent_stats.get(0, {}).items() if k != "plan_history"})
    print("plans0:", res.agent_stats.get(0, {}).get("plan_history"))
    print("agent1 plan:", res.agent_stats.get(1, {}).get("plan"))
    print("sim stats0:", res.sim_stats.get(0))
    print("sim stats1:", res.sim_stats.get(1))


if __name__ == "__main__":
    main()

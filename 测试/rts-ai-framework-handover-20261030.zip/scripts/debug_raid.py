"""诊断「农民遇袭后恢复」场景。"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from rtsexam.cases._util import base_spec, raid  # noqa: E402
from rtsexam.harness import run_match  # noqa: E402


def main() -> None:
    h = run_match(
        base_spec(),
        11,
        duration=160,
        scripts=[(30.0, raid("melee", 2, offset=9.0))],
        enemy_ai=False,
    )
    keys = ["time", "gold_0", "income_total_0", "workers_0", "idle_workers_0", "army_0", "losses_0", "worker_losses_0"]
    print("  ".join(f"{k:>16s}" for k in keys))
    for s in h.result.samples[::10]:
        print("  ".join(f"{str(s.get(k)):>16s}" for k in keys))
    print("orders sample:", [o for o in list(h.sim.orders_log)[-15:]])
    print("agents:", {k: v for k, v in h.stats.items() if k in ("mode", "combat", "plan")})


if __name__ == "__main__":
    main()

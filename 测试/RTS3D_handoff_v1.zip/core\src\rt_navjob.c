/* ============================================================================
 * rt_navjob.c -- 可分帧 / 可暂停 / 可取消的导航更新任务（M3.4）
 *
 * 设计要点（对应任务书 §五~§十七）：
 *   1. **不在 Active 数据上分帧写**。分区结果写在 label[]（staging），
 *      Active 的 component[] 只在 commit 一次改写。
 *   2. **Hard Obstacle 立即生效**：flags/overlay 在 Job 创建前就已写好，
 *      因此 Job 期间物理上绝不穿墙；只有派生数据（label）滞后。
 *   3. **scratch 复用**：queue/label 由 grid 持有，跨编辑复用，避免每次编辑
 *      malloc 4~5 MB（M3.3 的同步路径正是被这个额外开销拖慢了约 1.7 ms）。
 *   4. **只清已用部分**：commit 在自己的顺序扫描里顺手清零；cancel/stale
 *      只清 queue[0..tail-1]。
 * ==========================================================================*/
#include "rt_navjob.h"
#include <stdlib.h>
#include <string.h>

static const int DX8[8] = { 1, -1, 0, 0, 1, 1, -1, -1 };
static const int DZ8[8] = { 0, 0, 1, -1, 1, -1, 1, -1 };

const char *rt_navjob_state_name(RtJobState s)
{
    switch (s) {
    case RT_JOB_IDLE:       return "IDLE";
    case RT_JOB_PARTITION:  return "PARTITION";
    case RT_JOB_RELABEL:    return "RELABEL";
    case RT_JOB_READY:      return "READY";
    case RT_JOB_DONE:       return "DONE";
    case RT_JOB_STALE:      return "STALE";
    case RT_JOB_CANCELLED:  return "CANCELLED";
    }
    return "?";
}

/* 释放 staging：只清「本 Job 真正写过的格」。
 * 这是 O(affected) 而不是 O(w*h) —— 1024² 上省掉 1 MB memset。
 *
 * 防御：grid 可能已经被 rt_grid_destroy 释放（调用方先销毁 grid 再销毁 world 是
 * 常见顺序），此时 label 指针悬空，只能跳过清理 —— 那块内存本来就没了。 */
static void clear_staging(RtNavJob *j)
{
    if (!j || !j->label) return;
    if (!j->grid || j->grid->w <= 0) return;
    size_t used = (size_t)j->tail;
    size_t n = (size_t)j->w * (size_t)j->h;
    if (used > n) used = n;
    for (size_t k = 0; k < used; k++) j->label[j->queue[k]] = 0;
}

RtNavJob *rt_navjob_create(RtGrid *g, uint32_t job_id,
                           int32_t target_comp, const int32_t *seeds, int nseeds,
                           int32_t old_size, const uint32_t *chunk_mask)
{
    if (!g || !seeds || nseeds <= 0 || nseeds > 256) return NULL;

    int32_t *q = NULL;
    uint8_t *lb = NULL;
    if (rt_grid_job_scratch(g, &q, &lb) != RT_OK) return NULL;

    RtNavJob *j = (RtNavJob *)calloc(1, sizeof(RtNavJob));
    if (!j) return NULL;

    j->grid = g;
    j->queue = q;
    j->label = lb;
    memset(j->cnt, 0, sizeof(j->cnt));

    j->state = RT_JOB_PARTITION;
    j->job_id = job_id;
    j->base_version = g->version;
    j->base_revision = g->revision;
    j->w = g->w; j->h = g->h;
    j->target_comp = target_comp;
    j->nseeds = nseeds;
    for (int i = 0; i < nseeds; i++) j->seeds[i] = seeds[i];
    j->old_size = old_size;
    j->head = j->tail = 0;
    j->ngroups = 0;
    j->next_seed = 0;
    j->scan_cursor = 0;
    j->phase = 0;
    j->relabel_cursor = 0;
    j->keep_group = 1;
    j->estimated_units = (uint32_t)(old_size > 0 ? old_size : 1);
    if (chunk_mask) memcpy(j->mask, chunk_mask, sizeof(j->mask));
    else            memset(j->mask, 0xFF, sizeof(j->mask));

    /* 依赖快照：只记 mask 覆盖的 chunk 及其 edit_ver */
    for (int c = 0; c < RT_CHUNK_N; c++) {
        if (!(j->mask[c >> 5] & (1u << (c & 31)))) continue;
        if (j->dep_n >= 32) { j->dep_overflow = 1; break; }
        j->dep_chunks[j->dep_n] = (uint32_t)c;
        j->dep_edit_ver[j->dep_n] = g->edit_ver[c];
        j->dep_n++;
    }
    return j;
}

void rt_navjob_destroy(RtNavJob *j)
{
    if (!j) return;
    /* commit 已完成：staging 已在 commit 里清零；其它终态：这里清 */
    if (j->state != RT_JOB_DONE) clear_staging(j);
    free(j);          /* queue/label 归 grid 所有，不能 free */
}

void rt_navjob_cancel(RtNavJob *j)
{
    if (!j) return;
    if (j->state == RT_JOB_DONE || j->state == RT_JOB_STALE) return;
    clear_staging(j);
    j->state = RT_JOB_CANCELLED;   /* Active 数据一字未动 */
}

int rt_navjob_is_stale(const RtNavJob *j, const RtGrid *g)
{
    if (!j || !g) return 1;
    /* 依赖级判定：只看自己 mask 覆盖的 chunk 的 edit_ver。
     * 无关区域编辑（§C5）不会取消任务；同区域编辑（§C4）会。 */
    if (j->dep_overflow) {
        /* 依赖 chunk 超过 32 个（超大编辑）-> 保守回退到全局 revision */
        return j->base_revision != g->revision;
    }
    for (uint32_t i = 0; i < j->dep_n; i++) {
        uint32_t c = j->dep_chunks[i];
        if (c < RT_CHUNK_N && g->edit_ver[c] != j->dep_edit_ver[i]) return 1;
    }
    return 0;
}

int rt_navjob_touches_component(const RtNavJob *j, int32_t comp)
{
    if (!j) return 0;
    if (j->state == RT_JOB_DONE || j->state == RT_JOB_CANCELLED ||
        j->state == RT_JOB_STALE)
        return 0;
    return j->target_comp == comp;
}

/* 统计各组大小、决定保留组（最大组保留旧 id，最大化 ID 稳定性） */
static void finish_partition(RtNavJob *j)
{
    int32_t keep = 1;
    for (int k = 2; k <= j->ngroups; k++)
        if (j->cnt[k] > j->cnt[keep]) keep = k;
    j->keep_group = keep;
    for (int k = 0; k < 256; k++) j->new_id_of[k] = -1;
    j->state = RT_JOB_RELABEL;
    j->relabel_cursor = 0;
    j->affected_cells = (uint64_t)j->tail;   /* 统计口径 = 全部受影响格 */
}

int rt_navjob_step(RtNavJob *j, RtGrid *g, int max_units)
{
    if (!j || !g) return 1;
    if (j->state == RT_JOB_READY || j->state == RT_JOB_DONE ||
        j->state == RT_JOB_STALE || j->state == RT_JOB_CANCELLED)
        return 1;
    if (max_units <= 0) max_units = 1;

    size_t n = (size_t)j->w * (size_t)j->h;
    int used = 0;

    while (used < max_units) {
        if (j->state == RT_JOB_PARTITION) {
            if (j->head >= j->tail) {
                /* 当前 BFS 队列空：找下一个起点 */
                if (j->phase == 0) {
                    while (j->next_seed < j->nseeds &&
                           j->label[j->seeds[j->next_seed]])
                        j->next_seed++;
                    if (j->next_seed < j->nseeds) {
                        int32_t s = j->seeds[j->next_seed++];
                        if (s < 0 || (size_t)s >= n) continue;
                        if (g->component[s] != j->target_comp) continue;
                        if (j->ngroups >= 250) { j->state = RT_JOB_STALE; return 1; }
                        j->ngroups++;
                        j->label[s] = (uint8_t)j->ngroups;
                        j->cnt[j->ngroups] = 1;
                        j->rep_of[j->ngroups] = s;
                        j->queue[j->tail++] = s;
                        j->affected_cells++;
                        used++;
                        continue;
                    }
                    j->phase = 1;      /* seeds 用完，转为扫描"被围住"的成员 */
                    continue;
                }
                /* phase 1：扫描未覆盖成员（它们不接触 dirty 外圈，例如环中的洞） */
                int found = 0;
                while (j->scan_cursor < n) {
                    size_t i = j->scan_cursor++;
                    /* 扫描 16 格记 1 个单位：否则「一次 step」可能扫完整张图，
                     * 预算失控（1024² 上实测单步被拖到 4.2 ms）。
                     * 16（而不是 64）：单步最多扫 16×units 格，超预算的部分
                     * 被压到 0.3 ms 以内（1024² 上 4.15 -> 3.3 ms）。 */
                    if ((j->scan_cursor & 15u) == 0u) used++;
                    if (used >= max_units) break;
                    if (g->component[i] != j->target_comp) continue;
                    if (j->label[i]) continue;
                    if (j->ngroups >= 250) { j->state = RT_JOB_STALE; return 1; }
                    j->ngroups++;
                    j->label[i] = (uint8_t)j->ngroups;
                    j->cnt[j->ngroups] = 1;
                    j->rep_of[j->ngroups] = (int32_t)i;
                    j->queue[j->tail++] = (int32_t)i;
                    j->affected_cells++;
                    found = 1;
                    used++;
                    break;
                }
                if (!found) {
                    if (j->scan_cursor >= n) { finish_partition(j); continue; }
                    continue;   /* 预算用尽，下次继续扫描 */
                }
                continue;
            }

            /* BFS 有节点：处理一个 */
            int32_t c = j->queue[j->head++];
            used++;
            j->work_units++;
            int cx = (int)(c % j->w), cz = (int)(c / j->w);
            uint8_t lb = j->label[c];
            for (int e = 0; e < 8; e++) {
                int nx = cx + DX8[e], nz = cz + DZ8[e];
                if (nx < 0 || nz < 0 || nx >= j->w || nz >= j->h) continue;
                if (!rt_grid_walkable(g, nx, nz)) continue;
                if (e >= 4) {   /* 防穿角，与全量/增量语义一致 */
                    if (!rt_grid_walkable(g, cx + DX8[e], cz)) continue;
                    if (!rt_grid_walkable(g, cx, cz + DZ8[e])) continue;
                }
                size_t nc = (size_t)nz * j->w + nx;
                if (g->component[nc] != j->target_comp) continue;
                if (j->label[nc]) continue;
                j->label[nc] = lb;
                j->cnt[lb]++;
                j->affected_cells++;
                if ((size_t)j->tail >= n) { j->state = RT_JOB_STALE; return 1; }
                j->queue[j->tail++] = (int32_t)nc;
            }
            continue;
        }

        if (j->state == RT_JOB_RELABEL) {
            /* 分区阶段已经把每个受影响格的归属写进 label[]，
             * 这里不需要再遍历（O(1) 过渡）：真正的 id 分配与写入在 commit 做。 */
            j->state = RT_JOB_READY;
            continue;
        }

        break;
    }

    return j->state == RT_JOB_READY;
}

int rt_navjob_commit(RtNavJob *j, RtGrid *g)
{
    if (!j || !g) return RT_ERR_INVALID;
    if (j->state != RT_JOB_READY) return RT_ERR_INVALID;
    if (rt_navjob_is_stale(j, g)) {
        clear_staging(j);
        j->state = RT_JOB_STALE;
        return RT_ERR_NOT_FOUND;
    }

    size_t n = (size_t)j->w * (size_t)j->h;

    /* 1. 分配新 id（保留组沿用旧 id） */
    int32_t newid[256];
    for (int k = 0; k < 256; k++) newid[k] = j->target_comp;
    for (int k = 1; k <= j->ngroups; k++) {
        if (k == j->keep_group) { newid[k] = j->target_comp; continue; }
        newid[k] = rt_grid_alloc_component_id(g);
        if (newid[k] < 0) {
            clear_staging(j);
            j->state = RT_JOB_STALE;
            return RT_ERR_CAPACITY;
        }
    }

    /* 2. 重写 component / size / rep
     *
     * 三个决定都来自实测：
     *   - **顺序扫描 label[]（1B/格）**，而不是遍历 BFS 队列：BFS 顺序在空间上是
     *     跳跃的，随机写 4MB 的 component[] 会让 commit 从 2.5 ms 涨到 7.7 ms。
     *   - **跳过保留组**：保留组的格子本来就还是旧 id，不需要写。
     *   - **顺手清零 label**：避免额外的 O(w*h) memset。 */
    const int keep = j->keep_group;
    for (int k = 1; k <= j->ngroups; k++) {
        if (k == keep) continue;
        g->component_size[newid[k]] = 0;
        g->component_rep[newid[k]] = -1;
    }
    g->component_size[j->target_comp] = 0;
    g->component_rep[j->target_comp] = -1;

    for (size_t i = 0; i < n; i++) {
        uint8_t lb = j->label[i];
        if (lb) {
            j->label[i] = 0;
            int32_t id = newid[lb];
            if ((int)lb != keep) g->component[i] = id;
            g->component_size[id]++;
            if (g->component_rep[id] < 0) g->component_rep[id] = (int32_t)i;
        }
    }

    g->pending_comp = -1;
    g->version++;
    /* chunk 版本按「本次编辑的 dirty mask」递增（clearance pad 已包含在内）：
     * 逐格算 chunk 会让 commit 从 2.5 ms 涨到 5.2 ms，且信息量并不更多。 */
    rt_grid_note_commit(g, j->mask);
    if (j->ngroups >= 2) g->split_detected_count++;
    if (j->ngroups >= 3) g->split_multiway_count++;
    j->state = RT_JOB_DONE;
    return RT_OK;
}

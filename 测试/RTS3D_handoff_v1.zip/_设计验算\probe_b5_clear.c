/* ============================================================================
 * probe_b5_clear.c -- B5（unblock）clearance 增量差异的最小复现与定位
 *
 * 现象（19 报告 §5 第 3 条）：test_incremental 的 B5 场景，iters=0 就复现
 *   clear_diffs=124，且与本轮 merge 改动无关。
 *
 * 本探针把场景原样重放（墙 + 门 + 堵门的建筑），然后：
 *   · 打印差异格的个数、包围盒、到编辑矩形的距离分布；
 *   · 打印编辑矩形 / pad / 重算范围；
 *   · 对同一个诊断，分为「B4 之后立刻比」和「B5 之后比」两段。
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c \
 *          _设计验算/probe_b5_clear.c -o probe_b5_clear
 * ==========================================================================*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "rt_grid.h"

#define W 256
#define H 256

static RtGrid A, B;

static void build(RtGrid *g)
{
    rt_grid_init(g, W, H, 1.0f);
    for (int z = 0; z < H; z++) {
        for (int x = 0; x < W; x++) {
            int is_wall = (x == W / 2) && !(z >= H / 2 - 2 && z <= H / 2 + 1);
            if (is_wall) rt_grid_set_terrain(g, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
    }
    rt_grid_rebuild_all(g);
}

/* 打印 A(增量) 与 B(全量) 的 clearance 差异画像 */
static void report(const char *tag, int ex0, int ez0, int ex1, int ez1)
{
    long n = 0;
    int bx0 = 1 << 30, bz0 = 1 << 30, bx1 = -1, bz1 = -1;
    int hist[8] = { 0 };        /* 到编辑矩形的切比雪夫距离分桶 */
    int samples = 0;
    for (int z = 0; z < H; z++) {
        for (int x = 0; x < W; x++) {
            size_t i = (size_t)z * W + x;
            if (A.clearance[i] == B.clearance[i]) continue;
            n++;
            if (x < bx0) bx0 = x;
            if (x > bx1) bx1 = x;
            if (z < bz0) bz0 = z;
            if (z > bz1) bz1 = z;
            int dx = (x < ex0) ? ex0 - x : (x > ex1 ? x - ex1 : 0);
            int dz = (z < ez0) ? ez0 - z : (z > ez1 ? z - ez1 : 0);
            int d = dx > dz ? dx : dz;
            int b = d < 4 ? 0 : (d < 8 ? 1 : (d < 16 ? 2 : (d < 24 ? 3 : (d < 32 ? 4 : (d < 48 ? 5 : (d < 64 ? 6 : 7))))));
            hist[b]++;
            if (samples < 8 && d > 3) {
                printf("    sample (%3d,%3d) d=%2d  A.clean=%4u vec=(%5d,%5d)  B.clean=%4u vec=(%5d,%5d)\n",
                       x, z, d, A.clearance[i], A.ssd_x[i], A.ssd_y[i],
                       B.clearance[i], B.ssd_x[i], B.ssd_y[i]);
                samples++;
            }
        }
    }
    printf("  %s: diffs=%ld bbox=(%d,%d)-(%d,%d)\n", tag, n, bx0, bz0, bx1, bz1);
    printf("    dist hist [<4,<8,<16,<24,<32,<48,<64,>=64] = %d %d %d %d %d %d %d %d\n",
           hist[0], hist[1], hist[2], hist[3], hist[4], hist[5], hist[6], hist[7]);
}

int main(void)
{
    build(&A);
    build(&B);
    printf("=== B5 clearance diff probe ===\n");
    printf("base components A=%d B=%d\n", A.active_components, B.active_components);

    int x0 = W / 2, z0 = H / 2 - 2, bw = 1, bh = 4;

    /* B4：堵门 */
    RtGridDirty d;
    memset(&d, 0, sizeof(d));
    rt_grid_add_building_dirty(&A, x0, z0, bw, bh, &d);
    int rc = rt_grid_apply_dirty(&A, &d);
    printf("\nB4 add: rc=%d pad=%d rect=(%d,%d)-(%d,%d) clear_rect=(%d,%d)-(%d,%d)\n",
           rc, d.pad, d.x0, d.z0, d.x1, d.z1, d.cx0, d.cz0, d.cx1, d.cz1);
    memset(&d, 0, sizeof(d));
    rt_grid_add_building_dirty(&B, x0, z0, bw, bh, NULL);
    rt_grid_rebuild_all(&B);
    report("B4", x0, z0, x0 + bw - 1, z0 + bh - 1);

    /* B5：拆门 */
    memset(&d, 0, sizeof(d));
    rt_grid_remove_building_dirty(&A, x0, z0, bw, bh, &d);
    rc = rt_grid_apply_dirty(&A, &d);
    printf("\nB5 remove: rc=%d pad=%d rect=(%d,%d)-(%d,%d) clear_rect=(%d,%d)-(%d,%d)\n",
           rc, d.pad, d.x0, d.z0, d.x1, d.z1, d.cx0, d.cz0, d.cx1, d.cz1);
    memset(&d, 0, sizeof(d));
    rt_grid_remove_building_dirty(&B, x0, z0, bw, bh, NULL);
    rt_grid_rebuild_all(&B);
    printf("  clearance_max: A=%u B=%u | full_rebuild_count=%u\n",
           A.clearance_max, B.clearance_max, A.full_rebuild_count);
    report("B5", x0, z0, x0 + bw - 1, z0 + bh - 1);

    /* 再补一次：若把 pad 强行加倍，差异是否消失？（验证「pad 不够」这个假设） */
    {
        RtGrid C;
        build(&C);
        RtGridDirty e;
        memset(&e, 0, sizeof(e));
        rt_grid_add_building_dirty(&C, x0, z0, bw, bh, &e);
        (void)rt_grid_apply_dirty(&C, &e);
        /* 手工把重算范围上下各扩大 64 格，模拟「pad 更大」 */
        for (int z = 0; z < H; z++)
            for (int x = 0; x < W; x++) {
                size_t i = (size_t)z * W + x;
                C.component[i] = A.component[i];   /* 只关注 clearance，对齐分区无意义 */
            }
        memset(&e, 0, sizeof(e));
        rt_grid_remove_building_dirty(&C, x0, z0, bw, bh, &e);
        rt_grid_rebuild_clearance_region(&C, e.cx0 - 64 < 0 ? 0 : e.cx0 - 64,
                                         e.cz0 - 64 < 0 ? 0 : e.cz0 - 64,
                                         e.cx1 + 64 >= W ? W - 1 : e.cx1 + 64,
                                         e.cz1 + 64 >= H ? H - 1 : e.cz1 + 64);
        int n = 0;
        for (int z = 0; z < H; z++)
            for (int x = 0; x < W; x++) {
                size_t i = (size_t)z * W + x;
                if (C.clearance[i] != B.clearance[i]) n++;
            }
        printf("\ncontrol: same edit but clearance rect +64 cells -> diffs=%d\n", n);
        rt_grid_destroy(&C);
    }

    /* 复刻 test_incremental 的真实状态：dirty 结构体跨编辑复用，
     * 且 dirty_fill_rect() 在调用方设置 may_merge **之前** 就读了它 —— 于是
     * 本次编辑的 pad 取决于上一次编辑的类型。B4(add) 会用 pad_rm，B5(remove) 用 pad_add。
     * 这里先做一次「空 remove」把 may_merge 置 1，再走 B4/B5。 */
    {
        RtGrid C, D;
        build(&C);
        build(&D);
        static RtGridDirty shared;
        memset(&shared, 0, sizeof(shared));

        /* 一次「上一次是 remove」的状态：对不存在的建筑调用 remove，不改 flags */
        rt_grid_remove_building_dirty(&C, 10, 10, 4, 4, &shared);

        rt_grid_add_building_dirty(&C, x0, z0, bw, bh, &shared);
        RtGridDirty d4 = shared;
        int rc1 = rt_grid_apply_dirty(&C, &shared);
        rt_grid_add_building_dirty(&D, x0, z0, bw, bh, NULL);
        rt_grid_rebuild_all(&D);

        rt_grid_remove_building_dirty(&C, x0, z0, bw, bh, &shared);
        RtGridDirty d5 = shared;
        int rc2 = rt_grid_apply_dirty(&C, &shared);
        rt_grid_remove_building_dirty(&D, x0, z0, bw, bh, NULL);
        rt_grid_rebuild_all(&D);

        int n = 0;
        int sv[6][2];
        for (int z = 0; z < H; z++)
            for (int x = 0; x < W; x++) {
                size_t i = (size_t)z * W + x;
                if (C.clearance[i] != D.clearance[i]) n++;
            }
        for (int k = 0; k < 6; k++) {
            int z = 125 + k;
            size_t i = (size_t)z * W + x0;
            sv[k][0] = C.ssd_y[i];
            sv[k][1] = C.ssd_x[i];
        }
        printf("\nreplica of test state (shared dirty, stale may_merge): rc=%d/%d diffs=%d\n", rc1, rc2, n);
        printf("  B4 pad=%d rect=(%d,%d)-(%d,%d) | B5 pad=%d rect=(%d,%d)-(%d,%d)\n",
               d4.pad, d4.cx0, d4.cz0, d4.cx1, d4.cz1,
               d5.pad, d5.cx0, d5.cz0, d5.cx1, d5.cz1);
        printf("  door column ssd=(x,y): ");
        for (int k = 0; k < 6; k++) {
            int z = 125 + k;
            size_t i = (size_t)z * W + x0;
            printf("(%d,%d) ", C.ssd_x[i], C.ssd_y[i]);
        }
        printf("\n  door column flags: ");
        for (int k = 0; k < 6; k++) printf("%d ", rt_grid_walkable(&C, x0, 125 + k));
        printf("\n  pad used: B4=%d ...\n", 0);
        rt_grid_destroy(&C);
        rt_grid_destroy(&D);
    }

    rt_grid_destroy(&A);
    rt_grid_destroy(&B);
    return 0;
}

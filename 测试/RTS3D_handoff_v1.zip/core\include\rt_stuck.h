/* ============================================================================
 * rt_stuck.h -- 卡死检测与分级恢复（FR-STK，M6）
 *
 * 层级契约（CON-5）：本层不认识 Navigation。
 *   它只吃 RtLocalAgent（位置/期望速度）与 RtGrid（可走性）。
 *   需要「局部改道 / 换槽位 / 整队重寻路」时走回调；没接回调就计数并降级到
 *   本级能做的事（**不允许静默跳过**，铁律 5）。
 *
 * 口径（03_裁定 §3.4 / §3.5）：
 *   MOVING   有效进展 >= max(0.5 m, 0.25 * 本窗口期望距离)
 *   QUEUED   合法排队：前方链条最终通向「正在移动」的单位
 *   BLOCKED  阻塞原因已知：链条尽头是静止单位（inv_mass=0 或没有期望速度）
 *   STUCK    有目标、没到、没进展、且排除了上面三种
 *   PermanentStuck：走完 L1~L6 且累计 >= permanent_time（默认 12 s）仍无进展
 *
 * 恢复梯度（Level 0~6，与 03 §3.5 的六步一一对应）：
 *   L0  局部避障（常开基线，不是恢复动作）
 *   L1  减速让行        pref *= 0.35，并给让行方加一点侧向分量打破对称
 *   L2  后退            让行方沿反方向退（只改期望速度，绝不改位置）
 *   L3  局部改道        沿垂直方向侧移（sidetrack）
 *   L4  队形偏离/换槽位  回调 slot_deviation；未接 -> 计数 + 按 L3 处理
 *   L5  整队重寻路      回调 group_repath；未接 -> 计数 + 按 L3 处理
 *   L6  交通恢复        选一个 waiting bay（可走且 clearance 够）退过去等
 *   之后仍无进展 -> GAVE_UP，计 permanent_stuck，期望速度归零（原地停，不传送）
 *
 * GAVE_UP 的语义（M17 修正）：
 *   它是**诊断**，不是行为终态。放弃只对「当时那个阻碍」成立，阻碍消失就要重来。
 *   M11 用「周围 2 m 没人」当阻碍消失的判据，等于假设阻碍一定是人群 —— 队列里
 *   永远有人，于是放弃的单位变成家具：M15 实测两个放弃者相距 1.86 m，互相把对方
 *   算进「还有人」，谁都不复活，链被永久攥住（对手 0/12）。
 *   M17 改成三条独立判据，任一成立即复活（都要先满足 revive_after 的静默期）：
 *     R1 CLEAR  周围 revive_radius 内没有**存活**单位（放弃的单位不是人群，是家具）
 *     R2 PATH   前方 revive_front 内没有存活单位（只要不挡道，身边有人也能走）
 *     R3 FLOW   邻域平均净进展 >= revive_flow（队伍在流动 -> 跟上，别停在车道上）
 *   并且每条命令最多复活 revive_cap 次，防止「复活->再撞->再放弃」无限打转。
 *   排除放弃单位参与判据不是「少算」：它们和本人一样停着，既不会更堵也不会让开。
 *
 * 对称性（为什么不会两边一起退）：
 *   同一对阻塞里只有**索引大**的一方执行 L1/L2，索引小的一方原地保持。
 *   索引是调用方给的稳定顺序（不是地址、不是哈希），因此确定。
 *
 * 禁止传送（CON-9）：本层只写 pref_vel（偶尔写 max_speed 的临时副本），
 *   位置永远由 rt_local_step 积分 + 墙体约束决定。
 * ==========================================================================*/
#ifndef RT_STUCK_H
#define RT_STUCK_H

#include "rt_types.h"
#include "rt_grid.h"
#include "rt_local.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 2 s 窗口 / 4 Hz 采样 -> 8 个历史点（实际窗口 7*0.25 = 1.75 s，见 §实现注记） */
#define RT_STUCK_HIST 8
#define RT_STUCK_MAX_LEVEL 6

typedef enum {
    RT_STUCK_MOVING = 0,
    RT_STUCK_QUEUED = 1,
    RT_STUCK_BLOCKED = 2,
    RT_STUCK_STUCK = 3,
    RT_STUCK_GAVE_UP = 4,
    RT_STUCK_STATE_COUNT
} RtStuckState;

/* GAVE_UP 的复活原因（M17）。三个判据回答的是同一个问题：
 *   「当初让我放弃的那个阻碍，现在还在吗？」
 * 而不是「周围的人走光了吗」—— 队列里永远走不光。 */
typedef enum {
    RT_STUCK_REVIVE_NONE  = 0,
    RT_STUCK_REVIVE_CLEAR = 1,   /* 周围 revive_radius 内没有**存活**单位 */
    RT_STUCK_REVIVE_PATH  = 2,   /* 前方 revive_front 内没有**存活**单位（可以贴人，但不挡道） */
    RT_STUCK_REVIVE_FLOW  = 3,   /* 邻域在流动（平均净进展达标）-> 跟上队伍，别当家具 */
    RT_STUCK_REVIVE_COUNT
} RtStuckRevive;

typedef struct {
    /* 检测 */
    float sample_hz;        /* 4 Hz */
    float progress_window;  /* 2.0 s */
    float min_progress;     /* 0.5 m 下限 */
    float progress_ratio;   /* 0.25 * 期望距离 */
    float move_eps;         /* 期望速度低于此值视为静止（不参与检测） */
    float contact_slack;    /* 接触判定余量：rad_a + rad_b + slack */
    float queue_speed_eps;  /* 前车速度高于此值（保留，诊断用） */
    float queue_progress;   /* 前车在窗口内沿自己目标方向的净位移 > 此值才算「队伍在推进」 */

    /* 恢复 */
    float hold_time;        /* 每一级停留多久再升级（默认 1.5 s） */
    float back_time;        /* L2 后退持续（默认 1.2 s） */
    float back_max;         /* L2 最多退多远（默认 6 m） */
    float permanent_time;   /* 走完 6 级后仍无进展多久算永久卡死（默认 12 s） */
    float revive_after;     /* 永久放弃后，至少静默多久才重试（默认 5 s；<=0 关闭重试） */

    /* 复活的三个判据（M17）。旧版只有「周围 2 m 无人」一条，而队列里永远有人，
     * 于是放弃的单位在通道里变成家具 —— 见 35_M17_报告.md §1 的取证。 */
    float revive_radius;      /* R1 周围没人：半径（默认 2.0 m） */
    float revive_front;       /* R2 前方没人：沿期望方向的前向距离（默认 2.0 m） */
    float revive_flow_radius; /* R3 队伍在流动：邻域半径（默认 3.5 m） */
    float revive_flow;        /* R3 阈值：邻域平均净进展（默认 0.30 m / 采样窗口） */
    int   revive_cap;         /* 每条命令最多复活几次（默认 4；<=0 不限） */

    float bay_radius;       /* L6 waiting bay 搜索半径（默认 8 m） */
    float bay_stop_dist;    /* 到 bay 多近算到位（默认 0.8 m） */
    float grid_cell;        /* 邻居栅格边长（默认 2 m） */
    int   max_chain;        /* 排队链最大追溯深度（默认 16） */

    uint32_t flags;         /* bit0 = 关闭 L1 侧向偏置（对照实验用） */
} RtStuckConfig;

typedef struct {
    int (*local_repath)(void *ud, int idx, RtVec2 dir);  /* L3；返回 1 = 已处理 */
    int (*slot_deviation)(void *ud, int idx);            /* L4；返回 1 = 已处理 */
    int (*group_repath)(void *ud, int idx);              /* L5；返回 1 = 已处理 */
    void *ud;
} RtStuckHooks;

typedef struct {
    int32_t  state;         /* RtStuckState */
    int32_t  level;         /* 0..6，7 = 已放弃 */
    int32_t  blocker;       /* 最近的前方接触者（-1 = 无） */
    float    stuck_time;    /* 连续无进展时间 */
    float    level_time;    /* 当前级已持续 */
    float    net_progress;  /* 上一采样窗口内「沿目标方向」的净位移（可为负） */
    float    sample_acc;
    int32_t  hits;          /* 连续被判 STUCK 的采样次数（滞回：>=2 才立案） */
    int32_t  calm;          /* 连续被判 QUEUED/BLOCKED 的采样次数（>=4 撤案） */
    RtVec2   hist[RT_STUCK_HIST];
    RtVec2   want_dir;      /* 本帧覆盖前的期望方向（= 调用方想去的方向） */
    int32_t  head, count;
    RtVec2   bay;
    int32_t  bay_ok;
    int32_t  backing;       /* 本帧是否在后退（用于把整列一起带出去） */
    float    back_used;
    uint32_t episodes;      /* 该单位累计进入 STUCK 次数 */

    /* GAVE_UP 的重试（M11）：放弃只对「当时那个环境」成立 */
    int32_t  ever_gave_up;  /* 已计入过 permanent_stuck（避免重试后重复计数） */
    int32_t  gave_up_crowd; /* 放弃时附近有人 -> 人散了可以重试；被地形困住则不重试 */
    int32_t  ep_crowd;      /* 本轮卡死立案时附近有人 -> 这是「交通堵塞」不是「地形死路」 */
    float    revive_t;      /* 静默时长（>= revive_after 才允许重试） */
    float    probe_t;       /* 邻域探测节流 */
    int32_t  revive_tries;  /* 本条命令内复活过几次（受 revive_cap 限制） */
    int32_t  revive_why;    /* 最近一次复活原因（RtStuckRevive，诊断用） */
} RtStuckUnit;

typedef struct {
    uint32_t episodes;
    uint32_t resolved;
    uint32_t permanent_stuck;   /* 曾经放弃过的**单位数**（重试不会重复计数） */
    uint32_t retries;           /* 放弃后重试的次数（人群散开 -> 重来） */
    uint32_t revives_clear;     /* 因「周围没人」复活 */
    uint32_t revives_path;      /* 因「前方没人」复活 */
    uint32_t revives_flow;      /* 因「队伍在流动」复活 */
    uint32_t revives_capped;    /* 想复活但已达 revive_cap（诊断：说明还在原地打转） */
    uint32_t resumes;           /* 从 waiting bay 回到原任务的次数 */
    uint32_t level_fires[RT_STUCK_MAX_LEVEL + 1];
    uint32_t hook_missing;      /* L4/L5 回调没接（降级到 L3 行为） */
    uint32_t bay_found;
    uint32_t bay_none;
    uint32_t count[RT_STUCK_STATE_COUNT];
    uint32_t samples;           /* 采样次数（成本核算用） */
    uint32_t held_samples;      /* 被上层 hold 住、跳过检测的单位·采样数 */
    float    max_recover_s;     /* 最长一次「进入 STUCK -> 恢复」耗时 */
} RtStuckStats;

typedef struct {
    RtStuckConfig cfg;
    RtStuckUnit  *u;
    int           cap;

    /* 邻居栅格（只在采样时重建；计数排序，无 malloc-per-sample） */
    int   *gs, *gwr, *git, *gcell;   /* gcell[i] = 单位 i 的桶号 */
    int    gcap_cells, gcap_units;
    int    gw, gh;
    float  gcs;                      /* 桶边长（米） */
    float  gx0, gz0;

    /* 每次采样的临时判定 */
    int8_t *cls;      /* -1 未定 */
    int8_t *onstack;
    uint8_t *hold;    /* 上层声明「在合法等待」（通道仲裁 / 编队未就位） */
    float  *netp;
    float  *disp;     /* 窗口内实际位移长度（判「在动但在绕」用） */
    int32_t *blk;

    RtStuckStats st;
} RtStuckCtx;

void rt_stuck_config_default(RtStuckConfig *c);

int  rt_stuck_init(RtStuckCtx *c, int max_units, const RtStuckConfig *cfg);
void rt_stuck_destroy(RtStuckCtx *c);

/* 单位重置（新命令 / 换目标 / 被单位删除时调用）。保留统计。 */
void rt_stuck_reset(RtStuckCtx *c, int idx);
/* 全部重置 */
void rt_stuck_reset_all(RtStuckCtx *c);

/* 上层声明「该单位正在被要求原地等待」（窄通道仲裁 / 队形未就位）。
 * 置位期间不参与卡死判定，也不升级恢复等级：等待是合法状态，不是卡死。
 * 解除后按当时的真实速度重新计时（不会立刻补罚）。
 * 这是**显式的上层语义**，不是静默跳过：计入 stats.held_samples。 */
void rt_stuck_set_hold(RtStuckCtx *c, int idx, int on);
int  rt_stuck_held(const RtStuckCtx *c, int idx);

/* 每帧一次，**在调用方填好 pref_vel 之后、rt_local_step 之前**调用。
 * 只改 ag[i].pref_vel；不改位置。 */
void rt_stuck_step(RtStuckCtx *c, RtLocalAgent *ag, int n, const RtGrid *g,
                   float dt, const RtStuckHooks *hooks);

const char *rt_stuck_state_name(int s);
const char *rt_stuck_level_name(int l);

#ifdef __cplusplus
}
#endif

#endif /* RT_STUCK_H */

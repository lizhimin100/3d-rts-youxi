# RTS3D算法工程题（E:\算法\RTS3D算法工程题）

纯 C11、无引擎依赖的 3D RTS 移动内核，zig cc 编译。分层：Grid(capability) → Region/Route/Group(nav) →
Local(ORCA) → Fine(卡死/让路/队形/规划/通道链)。需求 `00`(FR-xxx) / 设计 `01` / 报告 `04`~`34` / 交接 `12`；
**阶段细节看报告与 `.workbuddy/memory/YYYY-MM-DD.md`，本文件只留不变式与转移性结论。**

**阶段**：M2~M17 已冻结。门禁 `bash gate_all.sh`（先编译 21 个测试、再依次跑）= 21 测试 / 726 断言全绿。
**下一步队列**：`stall_limit` 按链长自适应 → 弯通道多段矩形（去 `rejected_bent`） → 队形 anchor 移动跟随
→ 成员增删增量修复（FR-FOR-7） → 队形宽度进导航（FR-FOR-3） → 链优先级非 FCFS
→ `wall_escape_m` 按 `fp` 缩放 → 把 `rt_plan` 接进 M11/M14/M15 台架。

## 环境坑
- bash PATH 缺 `/usr/bin`：每条命令先 `export PATH="/c/Users/Administrator/.workbuddy/binaries/PortableGit/versions/1.2.0/usr/bin:$PATH"`。
- PowerShell 捕获 stdout 常为空 → 结果写文件再 Read；用 `| Out-File -Encoding utf8`（`>` 得 UTF-16）。
- 别用 PS 的 `Get-Content -Raw`+`Set-Content` 改中文源码（GBK 读坏 UTF-8）。`Remove-Item` 逐个 `-LiteralPath`。
- 编译偶发 0 字节 exe → 只走 gate_all.sh，别交替编译/运行；**绝不同时跑两条门禁**（zig 缓存互踩 + 计时污染）。
- 台架里 `near`/`far` 是 windows.h 空宏。

## 铁律
1. `core/` 禁 include 引擎/平台头。2. per-source `RtRoute` 必须存在，flow 只换搜索后端。
3. `rt_gw_sample()` 签名 / `rt_route_valid()` 语义 / 拆组规则 冻结（M4.1/M4.2）。
4. `rt_grid.c` 的 clearance 16 m 上限、`note_commit*`、chunk 编码 = 禁区。
5. fallback/重建/丢弃必须计数。6. 基准同机同会话，本机定时噪声 ±30~40%。
7. chunk 下标用 `rt_grid_chunk_of_cell()`（`cw=ceil(w/32)`），不是 `RT_CHUNKC_W`。
8. `chunk->group == group_index+1`：改组成员要回写全部存活 chunk。
9. 只写 `pref_vel`，位置永远由 ORCA+墙体积分（禁 teleport）。
10. 参数不是逻辑：`permanent_time` / `stall_limit` / `rings` 都按场景标定（各踩过一次）。
11. **任何「绕行 / 逃逸」都必须有预算**（M13 `follow_max_dist`、M17 `wall_escape_m`），
    否则「不可达必须 10~30 s 内 GAVE_UP」当场破 —— 这条已经踩了三次。

## 流水线（M9+）
`rt_plan_step → rt_gw_sample → rt_stuck_step → rt_yield_step → rt_local_step → rt_gw_update`
（M11+ 前后加 `rt_chain_want/acquire`、`rt_corr_note_state/tick`、`rt_chain_tick`）。成本 nav 5.4% / ORCA 92%。

## 通用结论（跨阶段反复验证）
- 「到达率低」先看预算再看算法；帧预算判据用 P99 + 超预算帧占比，不用 max。
- 判进展 = 沿期望方向投影 **且** 实际位移小；判排队看前车窗口进展；blocker 取方向最相反的。
- `pref_vel` 是意图、`vel` 是结果：被堵者必须保留自己的 pref，否则压力场读不到拥堵。
- **检测给通行性，实际要余量**（2×2 拐角、射线 0.1 m、`radius+0.5` clearance）。
- 定性靠 dump（`_设计验算/probe_*.c`），不许凭现象猜。

## 各阶段一句话（细节见报告）
- M17 放弃不是终态：「人走光了吗」把另一个放弃者当人群（相距 1.86 m 就互锁）→ 三条判据
  （CLEAR/PATH/FLOW，只数存活单位）+ `revive_cap`；**「滑动通 ≠ 走得了」**：逐轴滑动用
  0.01 分量兑现 0.0003 m/帧却算成功 → 绕 ±45/60/90 蹭出去（预算 0.8 m 漏桶）。
  Z 形通道 420 s 超时/22~24 过 → **101 s/24 全过/0 放弃**；4×4 挤门 −25.5%。
- M16 队形落脚：半径序只看位移 → 180° 会赢（加 `max_yaw_dev=90°`）；3×3 门槛 `fp+0.2`；队列点也占位；坏候选早短路 0.12 µs。
- M15 链：逐段独立仲裁比不仲裁更差（0/24 vs 23/24）→ 链级原子 22/24；段被强制释放则整链收回；`passed` 链级求和。
- M14 检测：`可走 && clearance>=0.5 && min(span)<=2.5`；宽度 = 2×blob 最窄 clearance；等待区侧移 > 半边长。
- M13 规划：`aim` 是本地前瞻点；射线通 ≠ 身体过；不可达用连通分量 + `nav_epoch` 重臂（31.4→22.4 s）。
- M12 队形：到点滞回 0.35/0.90/0.12，否则塌成接触堆；判据用晶格间距而非最差对。
- M11 通道：只有 2 m 洞是真单车道；`passed` 才是进度；整队 `hold`；等待线侧向且离出口 ≥3 m。
- M7 让路：压力 `+2/s` 配 `0.5 s×0.8` 衰减（稳态≈5）；用候选格自身压力；向侧向让。
- M4.6：大 split 挂起必须每帧 `rt_gw_update`；挂起期间别读 component；标量相等≠状态相等（`ssdp_cmp(validate=1)`）。

## 风格
简体中文；结论带实测数字；表格对照「改前/改后/冻结值」；回退单列，不许用「整体更快」掩盖。

/* ============================================================================
 * rt_portal.h -- 窄通道（portal / bottleneck）自动检测 + 自动仲裁注册（M14）
 *
 * 为什么需要（M11 §7 第 3 条）：M10/M11 的通道矩形是**手工注册**的
 * （`rt_corr_add(128,126,139,128,axis=0)`）。关卡里每一条窄道都要人工摆，
 * 换个地图就失效，而且没人保证摆的宽度对不对。
 *
 * 检测思路：**自由行程长度（run length）**，不是 clearance。
 *   clearance 只说明「离墙多远」，贴着任何一堵墙的格子 clearance 都是 1.0，
 *   用它筛「窄」会把整张图的墙根全标出来。真正的通道特征是两个方向**不对称**：
 *   沿走的方向很长、横着很短。所以：
 *
 *     span_x(c) = c 所在的水平自由格连续段长度（米）
 *     span_z(c) = c 所在的垂直自由格连续段长度（米）
 *     narrow(c) = 可走 && clearance >= min_clear && min(span_x, span_z) <= lane_width
 *
 *   横着 2 m、纵着 11 m 的隧道：min = 2 -> 窄 ✓
 *   开阔地里贴着墙的格子：另一个方向很长 -> min 很大 -> 不窄 ✓
 *
 * 这个判据对**轴对齐**的墙体是精确的（本项目所有墙都是轴对齐的），
 * 成本是两趟 O(w·h) 的行程统计，不需要射线、不需要区域边界。
 *
 * 为什么不用「区域的公共边」当 portal（HPA* 的常规做法）：
 *   那种做法只在墙正好压在 8 m 区域边界上时才检测得到。墙在区域内部
 *   （比如 x=125）就完全漏掉 —— 漏掉一条真通道，等于根本没有这一层。
 *
 * 连通块（blob）就是**一条通道**：两条窄门被隧道连起来时，blob 天然是整个隧道
 * （不需要额外做「门户链合并」）。
 *
 * 只做检测与注册，不做仲裁本身（那是 rt_corridor 的职责）。
 * ==========================================================================*/
#ifndef RT_PORTAL_H
#define RT_PORTAL_H

#include "rt_types.h"
#include "rt_grid.h"
#include "rt_corridor.h"
#include "rt_chain.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RT_PORTAL_MAX 64

typedef struct {
    int32_t axis;      /* 0 = 沿 x 通过（长轴是 x）；1 = 沿 z */
    float   x0, z0, x1, z1;   /* 世界坐标包围盒（可直接喂 rt_corr_add） */
    RtVec2  center;
    float   len_m;     /* 长轴长度（bbox 长边） */
    float   width_m;   /* **通不过的宽度** = 2 * min_clearance（最窄处），不是 bbox 短边 */
    float   bbox_w, bbox_h;   /* bbox 尺寸（诊断 / 判断够不够直） */
    float   fill;      /* cells / (bbox_w*bbox_h)：1 = 笔直，远小于 1 = 弯的（L 形） */
    float   min_clear; /* blob 内最小 clearance（米）—— 单位能不能过就看它 */
    float   max_clear;
    int32_t cells;     /* blob 格数 */
    int32_t chained;   /* 1 = 与另一条通道相接/相邻（组内成员数 > 1） */
    int32_t chain;     /* 所属通道链编号（0..链数-1）；-1 = 未分组 */
    int32_t cid;       /* 自动注册后的 corridor id，-1 = 未注册 */
} RtPortal;

typedef struct {
    float lane_width;     /* 2.50 m：宽度 <= 这个才算窄（需要仲裁） */
    float min_clear;      /* 0.50 m：格子 clearance 至少这么大，否则单位过不去 */
    int   min_cells;      /* 8：太小的 blob 当噪声（1 格厚的门洞不需要仲裁，见 M11） */
    float max_area_frac;  /* 0.20：blob 超过可走面积的此比例 -> 不仲裁（整张图都窄） */
    float min_fill;       /* 0.55：blob 对 bbox 的填充率。低于此值说明通道是弯的
                           * （L 形 / U 形），一个矩形描述不了 —— 本轮**显式跳过**，
                           * 记 rejected_bent，不用一个压着墙的大矩形去假装。 */
    float staging_ahead;  /* 8 m：等待区中心离通道端点的轴向距离 */
    float staging_side;   /* 8 m：等待区中心偏离轴线的侧向距离（必须 > staging_size/2） */
    float staging_size;   /* 12 m：等待区边长 */
    int   max_portals;    /* 最多注册多少条 */
} RtPortalConfig;

typedef struct {
    uint32_t blobs;          /* 扫出的连通块数（过滤前） */
    uint32_t accepted;       /* 通过过滤的 */
    uint32_t rejected_small; /* 格数不足 */
    uint32_t rejected_huge;  /* 面积占比过大 */
    uint32_t rejected_bent;  /* 不够直（L / U 形），本轮不仲裁 */
    uint32_t rejected_chained; /* 与另一条窄通道相接/相邻 —— 跨通道协调未做，不仲裁 */
    uint32_t registered;     /* 自动注册到 corridor 的条数 */
    uint32_t cap_overflow;   /* 超过 max_portals / rt_corr 容量 */
    float    last_ms;
    int      walkable_cells;
} RtPortalStats;

typedef struct {
    RtPortalConfig cfg;
    RtPortal *p;
    int cap, n;
    RtPortalStats st;

    /* scratch（惰性分配，跨 scan 复用） */
    int16_t *span_x, *span_z;   /* w*h */
    int32_t *label;             /* w*h：-1 未访问, 0 = 非窄, >0 = blob id+1 */
    int32_t *queue;             /* w*h */
    int      scratch_cells;
    const RtGrid *g;            /* 非拥有：scan 时记下，register 选等待区要查可走性 */
} RtPortalMap;

void rt_portal_config_default(RtPortalConfig *c);

int  rt_portal_init(RtPortalMap *m, int max_portals, const RtPortalConfig *cfg);
void rt_portal_destroy(RtPortalMap *m);

/* 全量扫描（编辑后重扫；成本见报告，256² 约 0.1 ms 量级）。
 * 返回发现的通道数（已过滤），<0 = 错误。 */
int  rt_portal_scan(RtPortalMap *m, const RtGrid *g);

/* 把窄通道自动注册进仲裁器（含两侧等待区）。
 * 会自动清空 cc 里已有的通道（重新排队），返回注册条数。
 * portal 的 cid 字段被回写，便于调用方做按 portal 判侧 / 门控。
 *
 * **安全默认**：相接/相邻（chained）的通道一律不注册 —— 各自注册会让两个 owner
 * 在拐角互锁（M14 的结论）。要让它们被仲裁，用下面的 _chained 版本。 */
int  rt_portal_register(RtPortalMap *m, RtCorrCtx *cc);

/* 连通道链一起注册（M15）：每个窄通道组（含单条）建一条链，链级原子仲裁。
 * 这是相接通道的正确打开方式 —— L 形整条只允许一个 owner。 */
int  rt_portal_register_chained(RtPortalMap *m, RtCorrCtx *cc, RtChainCtx *chain);

/* 用世界坐标找所在 / 最近的通道（用于「这个单位要不要排队」这类判断）。
 * max_dist <= 0 表示只找包含该点的。返回下标，-1 = 没有。 */
int  rt_portal_at(const RtPortalMap *m, RtVec2 pos, float max_dist);

const char *rt_portal_name(void);   /* "portal(bottleneck)"，调试用 */

#ifdef __cplusplus
}
#endif

#endif /* RT_PORTAL_H */

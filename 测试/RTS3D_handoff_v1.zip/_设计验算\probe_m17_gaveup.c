/* ============================================================================
 * probe_m17_gaveup.c -- 取证：GAVE_UP 单位在队列里为什么不复活
 *
 * 背景（M15 报告 §遗留）：
 *   Z 形 2 m 通道里，A 队有 2 个单位走完 L1~L6 变成 GAVE_UP，停在通道口。
 *   M15 的做法是「测试里把它们排除在需求之外」（不算 n_need），属于改需求定义。
 *   根因一直没修：M11b 的复活条件是「周围 2 m 没人」，队列里永不成立。
 *
 * 本探针要证的假设：
 *   H1  两个放弃单位互相把对方算进「2 m 内有人」-> 谁都等不到「周围没人」
 *   H2  即使只剩一个放弃单位，同队/敌队的排队单位也总在 2 m 内 -> 仍然不复活
 *   H3  放弃单位停在通道口期间，链一直有需求 -> 对手永远轮不到（handoffs=0）
 *
 * 做法：完全复用 test_m15 的 Z 形场景与流水线，只把两件事做成开关：
 *   A. gaveup_counts_as_demand  0 = M15 现状（排除）/ 1 = 还原成「它也想走」
 *   B. 逐帧记录每个曾放弃单位的邻域计数（全部 / 不含 GAVE_UP 单位）
 *
 * 编译：
 *   zig cc -O2 -std=c11 -Icore/include core/src/*.c _设计验算/probe_m17_gaveup.c \
 *       -o probe_m17.exe
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_stuck.h"
#include "rt_yield.h"
#include "rt_corridor.h"
#include "rt_chain.h"
#include "rt_portal.h"
#include "rt_region.h"
#include "rt_group.h"
#include "rt_unit.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
static void timer_init(void) {}
static double now_ms(void) { return 0.0; }
#endif

#define MAXA 512
#define BLK_X0 120
#define BLK_X1 159
#define ARM1_Z0 140
#define ARM1_Z1 141
#define ARM2_X0 139
#define ARM2_X1 140
#define ARM3_Z0 120
#define ARM3_Z1 121

static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;
static RtStuckCtx SC;
static RtYieldCtx YC;
static RtCorrCtx CC;
static RtChainCtx CH;
static RtPortalMap PM;
static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static RtUnitId IDS[MAXA];
static int TEAM[MAXA];
static int CROSSED[MAXA];
static uint8_t HELD[MAXA];
static int N = 0;

/* A/B 开关：蹭墙逃逸 / 是否仲裁 / 是否打时间序列 */
static int G_ESCAPE = 1;
static int G_NOARB  = 0;
static int G_TRACE  = 0;

/* --- 取证记录 --- */
typedef struct {
    int      ever;            /* 曾经 GAVE_UP */
    int      gave_up_frame;
    RtVec2   pos_at_giveup;
    int      crowd_at_giveup; /* gave_up_crowd */
    int      n_all_min;       /* 2 m 内单位数（含 GAVE_UP）的最小值 */
    int      n_non_min;       /* 2 m 内**非** GAVE_UP 单位数的最小值 */
    int      n_all_at_giveup;
    int      n_non_at_giveup;
    int      revived;
    int      revived_frame;
    int      final_state;
    int      crossed;
} Rec;
static Rec REC[MAXA];

static void map_z(void)
{
    for (int x = BLK_X0; x <= BLK_X1; x++)
        for (int z = 0; z < 256; z++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int x = BLK_X0; x <= ARM2_X1; x++)
        for (int z = ARM1_Z0; z <= ARM1_Z1; z++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 0);
    for (int x = ARM2_X0; x <= ARM2_X1; x++)
        for (int z = ARM3_Z1 + 1; z <= ARM1_Z1; z++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 0);
    for (int x = ARM2_X0; x <= BLK_X1; x++)
        for (int z = ARM3_Z0; z <= ARM3_Z1; z++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 0);
}

static void world_build(void)
{
    rt_grid_rebuild_all(&G);
    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
    rt_local_destroy(&LC);
    rt_local_init(&LC, 256.f, 256.f, MAXA, 4.5f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);
    LC.wall_escape = G_ESCAPE;
    rt_yield_destroy(&YC);
    rt_yield_init(&YC, MAXA, NULL, &G);
    rt_corr_destroy(&CC);
    rt_corr_init(&CC, 8, 60.f, 600.f);
    rt_corr_set_gate_params(&CC, 28.f, 1.2f);
    rt_corr_set_stall_limit(&CC, 90.f);
    rt_chain_destroy(&CH);
    rt_chain_init(&CH, &CC, RT_CHAIN_MAX, 0.f);
    N = 0;
}

static void spawn_team(int team, int n, float x0, float z0, int cols)
{
    for (int k = 0; k < n && N < MAXA; k++) {
        float x = x0 + (float)(k % cols) * 1.6f;
        float z = z0 + (float)(k / cols) * 1.6f;
        RtUnitId id = rt_units_spawn(&US, rt_v3(x, 0.f, z), RT_FP_SMALL);
        if (id == RT_UNIT_ID_NONE) break;
        IDS[N] = id;
        TEAM[N] = team;
        CROSSED[N] = 0;
        HELD[N] = 0;
        memset(&AG[N], 0, sizeof(AG[N]));
        AG[N].pos = rt_v2(x, z);
        AG[N].radius = 0.5f;
        AG[N].max_speed = 2.0f;
        AG[N].fp = 1.0f;
        AG[N].share = 0.5f;
        AG[N].inv_mass = 1.f;
        N++;
    }
}

static float rect_dist(const RtPortal *p, RtVec2 q)
{
    float dx = 0.f, dz = 0.f;
    if (q.x < p->x0)      dx = p->x0 - q.x;
    else if (q.x > p->x1) dx = q.x - p->x1;
    if (q.z < p->z0)      dz = p->z0 - q.z;
    else if (q.z > p->z1) dz = q.z - p->z1;
    return sqrtf(dx * dx + dz * dz);
}

static int is_crossed(int i)
{
    if (TEAM[i] == 0) return AG[i].pos.x > (float)BLK_X1 + 3.f;
    return AG[i].pos.x < (float)BLK_X0 - 3.f;
}

static int unit_past_seg(const RtPortal *p, int i)
{
    RtVec2 q = AG[i].pos;
    if (TEAM[i] == 0) {
        if (p->axis == 0) return q.x > p->x1;
        return q.z < p->z0;
    }
    if (p->axis == 0) return q.x < p->x0;
    return q.z > p->z1;
}

static int seg_passed(const RtPortal *p, int team)
{
    int c = 0;
    for (int i = 0; i < N; i++)
        if (TEAM[i] == team && unit_past_seg(p, i)) c++;
    return c;
}

static int chain_passed(int team)
{
    int c = 0;
    for (int k = 0; k < PM.n; k++) {
        if (PM.p[k].cid < 0) continue;
        c += seg_passed(&PM.p[k], team);
    }
    return c;
}

static int count_within(int i, float radius, int skip_gaveup)
{
    float r2 = radius * radius;
    int cnt = 0;
    for (int j = 0; j < N; j++) {
        if (j == i) continue;
        if (skip_gaveup && SC.u[j].state == RT_STUCK_GAVE_UP) continue;
        if (rt_v2_len2(rt_v2_sub(AG[j].pos, AG[i].pos)) <= r2) cnt++;
    }
    return cnt;
}

typedef struct {
    int crossA, crossB;
    int frames;
    uint32_t grants, handoffs, stalls, seg_lost;
    uint32_t perm, retries;
} Tun;

static int   TR_GI[MAXA];
static RtVec2 TR_TGT[MAXA];
static int   TR_OK[MAXA];

/* 与 rt_stuck.c 的 scan_live_crowd(front_only=1) 同口径，用来在探针里看
 * 「前方还有几个活人」，不依赖内部符号。 */
static int count_live_front(int i, float radius)
{
    RtVec2 dir = SC.u[i].want_dir;
    if (rt_v2_len2(dir) < 1e-8f) dir = rt_v2(1.f, 0.f);
    RtVec2 a = AG[i].pos;
    int cnt = 0;
    for (int j = 0; j < N; j++) {
        if (j == i) continue;
        if (SC.u[j].state == RT_STUCK_GAVE_UP) continue;
        RtVec2 d = rt_v2_sub(AG[j].pos, a);
        float l2 = rt_v2_len2(d);
        if (l2 > radius * radius) continue;
        float dot = d.x * dir.x + d.z * dir.z;
        if (dot <= 0.f) continue;
        float lat2 = l2 - dot * dot;
        float half = AG[i].radius + AG[j].radius + 0.30f;
        if (lat2 > half * half) continue;
        cnt++;
    }
    return cnt;
}

static void trace_unit(int i, float now, int owner)
{
    printf("      t=%6.1fs #%d pos=(%6.2f,%6.2f) pref=(%5.2f,%5.2f) gi=%2d ok=%d tgt=(%6.2f,%6.2f)"
           " held=%d own=%d state=%-8s lvl=%d tries=%d front=%d cross=%d\n",
           (double)now, i, AG[i].pos.x, AG[i].pos.z, AG[i].pref_vel.x, AG[i].pref_vel.z,
           TR_GI[i], TR_OK[i], TR_TGT[i].x, TR_TGT[i].z,
           HELD[i], owner,
           rt_stuck_state_name(SC.u[i].state), (int)SC.u[i].level, (int)SC.u[i].revive_tries,
           count_live_front(i, 2.0f), CROSSED[i]);
}

/* gaveup_counts_as_demand: 0 = M15 现状（需求里排除）/ 1 = 还原（它也想走） */
static Tun run_z(int demand_gaveup, int nA, int nB, int sim_s, const char *name)
{
    Tun m;
    memset(&m, 0, sizeof(m));
    memset(REC, 0, sizeof(REC));

    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    map_z();
    world_build();

    rt_portal_destroy(&PM);
    rt_portal_init(&PM, RT_PORTAL_MAX, NULL);
    (void)rt_portal_scan(&PM, &G);
    (void)rt_portal_register_chained(&PM, &CC, &CH);
    const int chain = 0;

    {
        RtStuckConfig cfg;
        rt_stuck_config_default(&cfg);
        cfg.permanent_time = 60.f;
        rt_stuck_destroy(&SC);
        rt_stuck_init(&SC, MAXA, &cfg);
    }

    spawn_team(0, nA, 96.f, 132.f, 6);
    spawn_team(1, nB, 176.f, 118.f, 6);

    const float dt = 1.f / 30.f;
    const RtVec2 goalA = rt_v2(210.f, 60.f);
    const RtVec2 goalB = rt_v2(70.f, 200.f);
    {
        RtUnitId a[MAXA], b[MAXA];
        int na = 0, nb = 0;
        for (int i = 0; i < N; i++) { if (TEAM[i] == 0) a[na++] = IDS[i]; else b[nb++] = IDS[i]; }
        if (na) (void)rt_gw_command(&W, &US, a, na, goalA, 0, RT_CLS_SMALL, 1);
        if (nb) (void)rt_gw_command(&W, &US, b, nb, goalB, 0, RT_CLS_SMALL, 2);
    }

    for (int i = 0; i < N; i++) { REC[i].n_all_min = 1 << 20; REC[i].n_non_min = 1 << 20; }

    int prev_state[MAXA];
    for (int i = 0; i < N; i++) prev_state[i] = SC.u[i].state;

    double sum = 0;
    int frames = 0;
    for (int s = 0; s < sim_s * 30; s++) {
        frames = s;
        const float now = (float)s * dt;
        double t0 = now_ms();

        /* ---- 链级仲裁（同 test_m15 mode 2）；G_NOARB=1 时整块跳过 ---- */
        int owner = -1;
        int n_pend[2] = {0, 0}, n_near[2] = {0, 0}, n_pass[2] = {0, 0};
        if (!G_NOARB) {
        int n_need[2] = {0, 0};
        for (int i = 0; i < N; i++) {
            if (is_crossed(i)) CROSSED[i] = 1;
            if (CROSSED[i]) { n_pass[TEAM[i]]++; continue; }
            if (!demand_gaveup && SC.u[i].state == RT_STUCK_GAVE_UP) continue;
            float best = 1e30f;
            for (int k = 0; k < PM.n; k++) {
                if (PM.p[k].cid < 0) continue;
                float d = rect_dist(&PM.p[k], AG[i].pos);
                if (d < best) best = d;
            }
            if (best > 30.f) continue;
            n_need[TEAM[i]] = 1;
            n_pend[TEAM[i]]++;
            if (best < 12.f) n_near[TEAM[i]]++;
        }
        for (int t = 0; t < 2; t++) {
            if (n_need[t]) rt_chain_want(&CH, chain, t, now);
            else           rt_chain_unwant(&CH, chain, t);
        }
        (void)rt_chain_acquire(&CH, chain);
        owner = CH.c[chain].owner;
        int prog = (owner >= 0) ? chain_passed(owner) : 0;
        for (int k = 0; k < PM.n; k++) {
            int cid = PM.p[k].cid;
            if (cid < 0) continue;
            rt_corr_note_state(&CC, cid,
                               (owner >= 0) ? n_pend[owner] : 0,
                               (owner >= 0) ? n_near[owner] : 0,
                               prog);
        }
        rt_corr_tick(&CC, dt);
        rt_chain_tick(&CH, dt);
        }   /* end !G_NOARB */

        /* ---- 期望速度 ---- */
        for (int i = 0; i < N; i++) {
            RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, IDS[i]);
            int gi = (int)ch->group[rt_unit_slot_index(IDS[i])] - 1;
            RtVec2 pref = rt_v2(0.f, 0.f);
            TR_GI[i] = gi;
            TR_OK[i] = 0;
            TR_TGT[i] = AG[i].pos;
            if (gi >= 0) {
                RtVec2 tgt;
                if (rt_gw_sample(&W, gi, AG[i].pos, &tgt) == RT_OK) {
                    TR_OK[i] = 1;
                    TR_TGT[i] = tgt;
                    RtVec2 d = rt_v2_sub(tgt, AG[i].pos);
                    float l = rt_v2_len(d);
                    if (l > 1e-3f) pref = rt_v2_mul(d, 2.0f / l);
                }
            }
            HELD[i] = 0;
            if (!CROSSED[i]) {
                int gating_cid = -1;
                float best = 1e30f;
                for (int k = 0; k < PM.n; k++) {
                    int cid = PM.p[k].cid;
                    if (cid < 0) continue;
                    float d = rect_dist(&PM.p[k], AG[i].pos);
                    if (d > 28.f) continue;
                    int bad = (owner >= 0 && owner != TEAM[i]);
                    if (!bad) continue;
                    if (d < best) { best = d; gating_cid = cid; }
                }
                if (gating_cid >= 0) {
                    HELD[i] = 1;
                    int side = rt_corr_side(&CC.c[gating_cid], AG[i].pos);
                    if (side >= 0) {
                        RtVec2 wp = rt_corr_staging_point(&CC, gating_cid, side, i % 64, 64);
                        pref = rt_corr_gate(&CC, gating_cid, TEAM[i], AG[i].pos, pref, wp);
                    }
                }
            }
            AG[i].pref_vel = pref;
            rt_stuck_set_hold(&SC, i, HELD[i]);
        }

        rt_stuck_step(&SC, AG, N, &G, dt, NULL);
        rt_yield_step(&YC, AG, N, &G, dt, NULL, NULL);
        (void)rt_local_step(&LC, AG, N, &G, dt);
        (void)rt_gw_update(&W);
        sum += now_ms() - t0;

        /* ---- 取证：状态迁移与邻域计数 ---- */
        for (int i = 0; i < N; i++) {
            int st = SC.u[i].state;
            if (st == RT_STUCK_GAVE_UP && !REC[i].ever) {
                REC[i].ever = 1;
                REC[i].gave_up_frame = s;
                REC[i].pos_at_giveup = AG[i].pos;
                REC[i].crowd_at_giveup = SC.u[i].gave_up_crowd;
                REC[i].n_all_at_giveup = count_within(i, 2.0f, 0);
                REC[i].n_non_at_giveup = count_within(i, 2.0f, 1);
            }
            if (st == RT_STUCK_GAVE_UP) {
                int ca = count_within(i, 2.0f, 0);
                int cn = count_within(i, 2.0f, 1);
                if (ca < REC[i].n_all_min) REC[i].n_all_min = ca;
                if (cn < REC[i].n_non_min) REC[i].n_non_min = cn;
            }
            if (prev_state[i] == RT_STUCK_GAVE_UP && st != RT_STUCK_GAVE_UP) {
                REC[i].revived = 1;
                if (!REC[i].revived_frame) REC[i].revived_frame = s;
            }
            prev_state[i] = st;
        }

        int ca = 0, cb = 0;
        for (int i = 0; i < N; i++) {
            if (is_crossed(i)) CROSSED[i] = 1;
            if (CROSSED[i]) { if (TEAM[i] == 0) ca++; else cb++; }
        }
        m.crossA = ca; m.crossB = cb;

        /* 时间序列：只跟曾经放弃过的单位，2 s 一个点，[50, 200] s 窗口 */
        /* 边沿触发的事件日志：#0 只在状态/等级/位置（>0.4 m）变化时打一行 */
        if (G_TRACE && demand_gaveup) {
            static int ls = -1, ll = -1; static RtVec2 lp; static int init = 0;
            int st = (int)SC.u[0].state, lv = (int)SC.u[0].level;
            float moved = init ? rt_v2_dist(lp, AG[0].pos) : 1e9f;
            if (!init || st != ls || lv != ll || moved > 0.4f) {
                trace_unit(0, now, owner);
                ls = st; ll = lv; lp = AG[0].pos; init = 1;
            }
        }

        if (G_TRACE && demand_gaveup && s % 60 == 0 && now >= 50.f && now <= 200.f) {
            int any = 0;
            for (int i = 0; i < N; i++) if (REC[i].ever) any = 1;
            if (any) {
                for (int i = 0; i < N; i++) if (REC[i].ever) trace_unit(i, now, owner);
            }
        }

        if (ca >= nA && cb >= nB) break;
    }

    m.frames = frames;
    m.grants = CH.c[chain].grants;
    m.handoffs = CH.c[chain].handoffs;
    m.stalls = CH.c[chain].stalls;
    m.seg_lost = CH.st.seg_lost;
    m.perm = SC.st.permanent_stuck;
    m.retries = SC.st.retries;

    printf("\n  %-28s crossed A=%d/%d B=%d/%d  (%d frames = %.0f s)\n",
           name, m.crossA, nA, m.crossB, nB, frames, (double)frames / 30.0);
    printf("  %-28s grants=%u handoffs=%u stalls=%u seg_lost=%u perm=%u retries=%u\n",
           "", m.grants, m.handoffs, m.stalls, m.seg_lost, m.perm, m.retries);

    int any = 0;
    for (int i = 0; i < N; i++) if (REC[i].ever) any = 1;
    if (any) {
        printf("      放弃取证（2 m 邻域计数的最小值；non = 不含 GAVE_UP 单位）：\n");
        printf("        idx team  giveup@  pos               crowd  n2_all(起/最小)  n2_non(起/最小)"
               "  复活@    终态        过否\n");
        for (int i = 0; i < N; i++) {
            if (!REC[i].ever) continue;
            Rec *r = &REC[i];
            printf("        %3d  %d   %6.1fs  (%6.2f,%6.2f)   %d      %d / %-3d        %d / %-3d"
                   "        %-7s  %-10s  %s\n",
                   i, TEAM[i], (double)r->gave_up_frame / 30.0,
                   r->pos_at_giveup.x, r->pos_at_giveup.z, r->crowd_at_giveup,
                   r->n_all_at_giveup, (r->n_all_min >= (1 << 20)) ? -1 : r->n_all_min,
                   r->n_non_at_giveup, (r->n_non_min >= (1 << 20)) ? -1 : r->n_non_min,
                   r->revived ? "yes" : "-",
                   rt_stuck_state_name(SC.u[i].state), CROSSED[i] ? "yes" : "no");
        }
        /* 关键判据：是否存在「含 GAVE_UP 的最小值 > 0，但不含的能到 0」 */
        int mutual = 0, real_crowd = 0;
        for (int i = 0; i < N; i++) {
            if (!REC[i].ever) continue;
            if (REC[i].n_all_min > 0 && REC[i].n_non_min == 0) mutual++;
            if (REC[i].n_all_min > 0 && REC[i].n_non_min > 0) real_crowd++;
        }
        printf("      互相卡住（只有 GAVE_UP 单位挡着「2 m 无人」判据）：%d / %d 个放弃单位\n",
               mutual, (int)SC.st.permanent_stuck);
        printf("      真被人群包围（非 GAVE_UP 也一直在 2 m 内）：%d 个\n", real_crowd);
    } else {
        printf("      没有任何单位放弃\n");
    }
    return m;
}

int main(void)
{
    timer_init();
    printf("=== probe M17: GAVE_UP 复活根因 + 墙角蹭墙 A/B ===\n");
    printf("场景：Z 形 2 m 通道，12v12，420 s 预算，链级/无仲裁两种策略 × 蹭墙开/关\n");

    struct { int esc, noarb; const char *name; } C[4] = {
        { 0, 1, "1 escape OFF / no arbitration  (= M16 基座)" },
        { 1, 1, "2 escape ON  / no arbitration  (M17)" },
        { 0, 0, "3 escape OFF / chain arbitration (= M16 基座)" },
        { 1, 0, "4 escape ON  / chain arbitration (M17)" },
    };
    Tun t[4];
    for (int k = 0; k < 4; k++) {
        G_ESCAPE = C[k].esc;
        G_NOARB  = C[k].noarb;
        t[k] = run_z(1, 12, 12, 420, C[k].name);
    }

    printf("\n=== 汇总（同一台机器、同一个会话）===\n");
    printf("  %-34s %-10s %-10s %-10s %-6s %-9s\n",
           "配置", "A 通过", "B 通过", "耗时", "放弃", "handoffs");
    for (int k = 0; k < 4; k++)
        printf("  %-34s %2d/12      %2d/12      %6.1f s   %-6u %u\n",
               C[k].name, t[k].crossA, t[k].crossB,
               (double)t[k].frames / 30.0, t[k].perm, t[k].handoffs);
    return 0;
}

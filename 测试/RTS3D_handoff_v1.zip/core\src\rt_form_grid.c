/* ============================================================================
 * rt_form_grid.c -- 落脚搜索的网格适配器（M16）
 *
 * 为什么单独一个文件：rt_form.c 只认识 RtFormProbe（一个函数指针），不认识
 * RtGrid。这样队形层的单测可以喂解析形状（带状 / 隧道 / 口袋），不需要造网格；
 * 而真正接引擎时只需要这一层 20 行的胶水。
 *
 * 状态码的语义（和 rt_form.h 一致）：
 *   0 = 可用    1 = 被地形/建筑挡住    2 = 越界
 * `rt_grid_obb_blocked()` 把越界也算「挡住」，所以这里先自己判边界，才能把
 * 「出图」和「撞墙」分开 —— 两者在评分里权重不同（1000 vs 100）。
 * ==========================================================================*/
#include "rt_form.h"
#include "rt_grid.h"

static int form_grid_obb_state(void *ud, const RtObb2 *o)
{
    const RtGrid *g = (const RtGrid *)ud;
    if (!g || !o) return 1;

    RtAabb2 bb = rt_obb_aabb(o);
    float world_w = (float)g->w * g->cell;
    float world_h = (float)g->h * g->cell;
    if (bb.min_x < 0.f || bb.min_z < 0.f || bb.max_x > world_w || bb.max_z > world_h)
        return 2;

    return rt_grid_obb_blocked(g, o) ? 1 : 0;
}

void rt_form_probe_grid(RtFormProbe *p, const void *grid)
{
    if (!p) return;
    p->ud = (void *)grid;
    p->obb_state = grid ? form_grid_obb_state : NULL;
}

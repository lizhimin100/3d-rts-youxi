/* ============================================================================
 * test_m5.c -- LocalAvoidance 层（ORCA + 墙体约束）
 *
 * 门禁：
 *   T1 两人对穿：各自绕开、不重叠
 *   T2 40 人环形对穿（经典 ORCA 压力场景）：最大穿透深度有上界
 *   T3 一群人往墙里走：永不进入阻挡格（OBB 精确检查）
 *   T4 确定性：同输入跑两遍，位置逐位相同
 *   T5 混合尺寸（1×1 与 4×4）同时过
 *   T6 1000 人一步的成本
 *   T7 静止单位挡路：会绕，不会推着它走
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_region.h"
#include "rt_group.h"
#include "rt_unit.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", (m)); } } while (0)

#define MAXA 1200
static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;
static RtGrid G;

static void agent_set(int i, float x, float z, float r, float speed, float px, float pz)
{
    memset(&AG[i], 0, sizeof(AG[i]));
    AG[i].pos = rt_v2(x, z);
    AG[i].vel = rt_v2(0.f, 0.f);
    AG[i].pref_vel = rt_v2(px, pz);
    AG[i].radius = r;
    AG[i].max_speed = speed;
    AG[i].fp = r * 2.f;
    AG[i].share = 0.5f;
    AG[i].inv_mass = 1.f;
}

/* 最大穿透深度（>0 表示重叠） */
static float worst_overlap(int n, int *out_pairs)
{
    float worst = 0.f;
    int pairs = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            float d = rt_v2_dist(AG[i].pos, AG[j].pos);
            float pen = (AG[i].radius + AG[j].radius) - d;
            if (pen > 0.f) { pairs++; if (pen > worst) worst = pen; }
        }
    }
    if (out_pairs) *out_pairs = pairs;
    return worst;
}

static void run_steps(int n, int steps, float dt)
{
    for (int s = 0; s < steps; s++) (void)rt_local_step(&LC, AG, n, NULL, dt);
}

static void t1_head_on(void)
{
    printf("\n[T1] 两人对穿\n");
    rt_local_init(&LC, 256.f, 256.f, MAXA, 8.f);
    agent_set(0, 120.f, 128.f, 0.5f, 2.f,  2.f, 0.f);
    agent_set(1, 136.f, 128.f, 0.5f, 2.f, -2.f, 0.f);
    run_steps(2, 240, 1.f / 30.f);
    int pairs = 0;
    float pen = worst_overlap(2, &pairs);
    printf("  a=(%.2f,%.2f) b=(%.2f,%.2f) pass=%d overlap=%.4f pairs=%d\n",
           AG[0].pos.x, AG[0].pos.z, AG[1].pos.x, AG[1].pos.z,
           (AG[0].pos.x > AG[1].pos.x) ? 1 : 0, pen, pairs);
    OK(AG[0].pos.x > AG[1].pos.x, "T1 they passed each other");
    OK(pen < 0.10f, "T1 no significant overlap");
    rt_local_destroy(&LC);
}

static void t2_ring(void)
{
    printf("\n[T2] 40 人环形对穿（各自去对面）\n");
    rt_local_init(&LC, 256.f, 256.f, MAXA, 8.f);
    const int n = 40;
    for (int i = 0; i < n; i++) {
        float ang = (float)i * 6.2831853f / (float)n;
        float x = 128.f + cosf(ang) * 30.f;
        float z = 128.f + sinf(ang) * 30.f;
        agent_set(i, x, z, 0.5f, 1.5f, -cosf(ang) * 1.5f, -sinf(ang) * 1.5f);
    }
    float worst = 0.f;
    for (int s = 0; s < 900; s++) {
        (void)rt_local_step(&LC, AG, n, NULL, 1.f / 30.f);
        if (s % 10 == 0) {
            int pairs = 0;
            float p = worst_overlap(n, &pairs);
            if (p > worst) worst = p;
        }
    }
    int pairs = 0;
    float pen = worst_overlap(n, &pairs);
    printf("  after 900 steps: worst_pen=%.4f (max during run %.4f) pairs=%d lines=%u infeasible=%u\n",
           pen, worst, pairs, LC.stat_lines, LC.stat_infeasible);
    OK(worst < 0.35f, "T2 worst penetration stayed below 0.35 m");
    OK(LC.stat_infeasible * 10 < LC.stat_steps * n, "T2 LP3 (infeasible) is the exception");
    rt_local_destroy(&LC);
}

static void t3_wall(void)
{
    printf("\n[T3] 20 人往墙里走：OBB 精确检查\n");
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int z = 0; z < 256; z++) rt_grid_set_terrain(&G, 128, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);

    rt_local_init(&LC, 256.f, 256.f, MAXA, 8.f);
    const int n = 20;
    for (int i = 0; i < n; i++)
        agent_set(i, 110.f, 100.f + (float)i * 2.f, 0.5f, 2.f, 2.f, 0.f);

    int blocked_frames = 0;
    for (int s = 0; s < 600; s++) {
        (void)rt_local_step(&LC, AG, n, &G, 1.f / 30.f);
        for (int i = 0; i < n; i++) {
            RtObb2 o = rt_obb_make(AG[i].pos, AG[i].fp, 0.f);
            if (rt_grid_obb_blocked(&G, &o)) blocked_frames++;
        }
    }
    float maxx = 0.f;
    for (int i = 0; i < n; i++) if (AG[i].pos.x > maxx) maxx = AG[i].pos.x;
    printf("  max_x=%.2f (wall at 128) blocked_frames=%d wall_clamped=%u\n",
           maxx, blocked_frames, LC.stat_wall_clamped);
    OK(blocked_frames == 0, "T3 no agent ever entered a blocked cell");
    OK(maxx < 127.6f, "T3 everyone stopped before the wall");
    OK(LC.stat_wall_clamped > 0, "T3 the wall clamp actually fired");
    rt_local_destroy(&LC);
    rt_grid_destroy(&G);
}

static void t4_determinism(void)
{
    printf("\n[T4] 确定性：同输入跑两遍\n");
    rt_local_init(&LC, 256.f, 256.f, MAXA, 8.f);
    const int n = 60;
    for (int i = 0; i < n; i++) {
        float x = 90.f + (float)((i * 37) % 60);
        float z = 90.f + (float)((i * 53) % 60);
        agent_set(i, x, z, 0.5f, 1.5f, 1.f, 0.3f);
    }
    static RtLocalAgent A0[MAXA];
    memcpy(A0, AG, sizeof(RtLocalAgent) * (size_t)n);
    run_steps(n, 120, 1.f / 30.f);
    static RtLocalAgent R1[MAXA];
    memcpy(R1, AG, sizeof(RtLocalAgent) * (size_t)n);

    memcpy(AG, A0, sizeof(RtLocalAgent) * (size_t)n);
    run_steps(n, 120, 1.f / 30.f);
    int diff = memcmp(R1, AG, sizeof(RtLocalAgent) * (size_t)n) != 0;
    printf("  memcmp(second run, first run) = %s\n", diff ? "DIFF" : "same");
    OK(!diff, "T4 two identical runs produce bit-identical state");
    rt_local_destroy(&LC);
}

static void t5_mixed_size(void)
{
    printf("\n[T5] 1x1 与 4x4 混行\n");
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int z = 0; z < 256; z++) {
        rt_grid_set_terrain(&G, 110, z, RT_CELL_BLOCKED_TERRAIN, 1);
        rt_grid_set_terrain(&G, 146, z, RT_CELL_BLOCKED_TERRAIN, 1);
    }
    rt_grid_rebuild_all(&G);

    rt_local_init(&LC, 256.f, 256.f, MAXA, 10.f);
    const int n = 9;
    agent_set(0, 120.f, 128.f, 2.0f, 1.2f,  1.2f, 0.f);     /* 4x4 */
    AG[0].fp = 4.f;
    for (int i = 1; i < n; i++)
        agent_set(i, 136.f, 118.f + (float)i * 2.2f, 0.5f, 1.5f, -1.5f, 0.f);

    float worst = 0.f;
    for (int s = 0; s < 900; s++) {
        (void)rt_local_step(&LC, AG, n, &G, 1.f / 30.f);
        if (s % 10 == 0) {
            int pairs = 0;
            float p = worst_overlap(n, &pairs);
            if (p > worst) worst = p;
        }
    }
    int blocked = 0;
    for (int i = 0; i < n; i++) {
        RtObb2 o = rt_obb_make(AG[i].pos, AG[i].fp, 0.f);
        if (rt_grid_obb_blocked(&G, &o)) blocked++;
    }
    printf("  big=(%.1f,%.1f) worst_pen=%.3f blocked=%d\n", AG[0].pos.x, AG[0].pos.z, worst, blocked);
    OK(blocked == 0, "T5 mixed sizes stay out of walls");
    OK(worst < 0.40f, "T5 4x4 vs 1x1 overlap stayed bounded");
    rt_local_destroy(&LC);
    rt_grid_destroy(&G);
}

static void t6_cost(void)
{
    printf("\n[T6] 1000 人一步的成本\n");
    /* 推荐值：neighbor_dist ≈ 2*max_radius + max_speed*τ = 1 + 1.5*2 = 4 m。
     * 取 8 会把 9 个 8m 桶里的 250 个候选全扫一遍，成本翻三倍。 */
    rt_local_init(&LC, 256.f, 256.f, MAXA, 4.5f);
    const int n = 1000;
    /* 1.5 m 间距的抖动栅格：半径 0.5，初始零重叠（否则测的是「从重叠里挤出来」） */
    for (int i = 0; i < n; i++) {
        float x = 30.f + (float)(i % 40) * 1.5f + (float)(i % 3) * 0.1f;
        float z = 30.f + (float)(i / 40) * 1.5f + (float)(i % 5) * 0.1f;
        agent_set(i, x, z, 0.5f, 1.5f, 1.f, 0.f);
    }
    int init_pairs = 0;
    float init_pen = worst_overlap(n, &init_pairs);

    double best = 1e30, sum = 0;
    const int steps = 60;
    for (int s = 0; s < steps; s++) {
        double t0 = now_ms();
        (void)rt_local_step(&LC, AG, n, NULL, 1.f / 30.f);
        double dt = now_ms() - t0;
        if (dt < best) best = dt;
        sum += dt;
    }
    int pairs = 0;
    float pen = worst_overlap(n, &pairs);
    printf("  n=1000 k=%d: best=%.3f ms  mean=%.3f ms  lines/step=%u infeasible=%u\n",
           LC.max_neighbors, best, sum / steps, LC.stat_lines / steps, LC.stat_infeasible);
    printf("  overlap: start=%.3f (%d pairs) -> after 60 steps=%.3f (%d pairs)\n",
           init_pen, init_pairs, pen, pairs);
    OK(init_pen < 0.05f, "T6 initial layout has no overlap");
    OK(best < 8.0, "T6 one step stays inside the 8 ms logic budget");
    OK(pen < 0.25f, "T6 1000 agents keep overlap bounded while pressing forward");
    rt_local_destroy(&LC);
}

static void t7_static_blocker(void)
{
    printf("\n[T7] 静止单位挡在走廊中间\n");
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int z = 0; z < 256; z++) {
        rt_grid_set_terrain(&G, 110, z, RT_CELL_BLOCKED_TERRAIN, 1);
        rt_grid_set_terrain(&G, 150, z, RT_CELL_BLOCKED_TERRAIN, 1);
    }
    rt_grid_rebuild_all(&G);

    rt_local_init(&LC, 256.f, 256.f, MAXA, 10.f);
    const int n = 7;
    agent_set(0, 130.f, 128.f, 1.0f, 0.f, 0.f, 0.f);        /* 静止挡路 */
    AG[0].inv_mass = 0.f;
    AG[0].share = 0.f;
    AG[0].fp = 2.f;
    for (int i = 1; i < n; i++)
        agent_set(i, 115.f, 124.f + (float)(i - 1) * 1.6f, 0.5f, 1.5f, 1.5f, 0.f);

    RtVec2 static_start = AG[0].pos;
    float worst = 0.f;
    for (int s = 0; s < 900; s++) {
        (void)rt_local_step(&LC, AG, n, &G, 1.f / 30.f);
        if (s % 10 == 0) {
            int pairs = 0;
            float p = worst_overlap(n, &pairs);
            if (p > worst) worst = p;
        }
    }
    int passed = 0;
    for (int i = 1; i < n; i++) if (AG[i].pos.x > 135.f) passed++;
    printf("  passed=%d/%d static_moved=%.3f worst_pen=%.3f\n",
           passed, n - 1, rt_v2_dist(static_start, AG[0].pos), worst);
    OK(passed >= n - 1, "T7 everyone walked around the static unit");
    OK(rt_v2_dist(static_start, AG[0].pos) < 0.05f, "T7 static unit was not pushed away");
    OK(worst < 0.40f, "T7 overlap stayed bounded");
    rt_local_destroy(&LC);
    rt_grid_destroy(&G);
}

/* T8：真的跟着导航走一遍 —— 导航给期望方向，ORCA 负责不撞人，墙体约束负责不穿墙。
 * 这是 Layers 的接缝测试：Simulation（本函数）调 rt_gw_sample 拿方向，喂给 Local。 */
static void t8_gate_funnel(void)
{
    printf("\n[T8] 端到端：24 人挤过 6 格宽的城门\n");
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int z = 0; z < 256; z++)
        if (z < 120 || z > 125) rt_grid_set_terrain(&G, 128, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);

    static RtRegionMap map;
    static RtGroupWorld w;
    static RtUnitStore us;
    rt_region_destroy(&map);
    rt_region_build(&map, &G, 8);
    rt_gw_destroy(&w);
    rt_gw_init(&w, &G, &map);
    rt_units_init(&us);

    rt_local_init(&LC, 256.f, 256.f, MAXA, 4.5f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);

    const int n = 24;
    RtUnitId ids[32];
    int k = 0;
    for (int i = 0; i < n; i++) {
        float x = 76.f + (float)(i % 6) * 3.f;
        float z = 100.f + (float)(i / 6) * 3.5f;
        RtUnitId id = rt_units_spawn(&us, rt_v3(x, 0.f, z), RT_FP_SMALL);
        if (id == RT_UNIT_ID_NONE) continue;
        ids[k] = id;
        agent_set(k, x, z, 0.5f, 2.f, 0.f, 0.f);
        k++;
    }
    const RtVec2 goal = rt_v2(200.5f, 128.5f);
    rt_gw_command(&w, &us, ids, k, goal, 0, RT_CLS_SMALL, 1);

    int arrived = 0, pen_frames = 0, frames = 0;
    float worst_pen = 0.f;
    for (int s = 0; s < 4000; s++) {
        frames = s;
        for (int i = 0; i < k; i++) {
            RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&us, ids[i]);
            int gi = (int)ch->group[rt_unit_slot_index(ids[i])] - 1;
            RtVec2 pref = rt_v2(0.f, 0.f);
            if (gi >= 0) {
                RtVec2 tgt;
                if (rt_gw_sample(&w, gi, AG[i].pos, &tgt) == RT_OK) {
                    RtVec2 d = rt_v2_sub(tgt, AG[i].pos);
                    float l = rt_v2_len(d);
                    if (l > 1e-3f) pref = rt_v2_mul(d, 2.f / l);
                }
            }
            AG[i].pref_vel = pref;
        }
        (void)rt_local_step(&LC, AG, k, &G, 1.f / 30.f);
        (void)rt_gw_update(&w);

        arrived = 0;
        for (int i = 0; i < k; i++) {
            /* 到达判定按「群的落点分布」给半径：rt_gw_arrival_pos 会把成员摊开，
             * 不是所有人都站在 goal 那一点上。 */
            if (rt_v2_dist(AG[i].pos, goal) < 4.5f) arrived++;
            RtObb2 o = rt_obb_make(AG[i].pos, AG[i].fp, 0.f);
            if (rt_grid_obb_blocked(&G, &o)) pen_frames++;
        }
        int pairs = 0;
        float p = worst_overlap(k, &pairs);
        if (p > worst_pen) worst_pen = p;
        if (arrived == k) break;
    }
    printf("  arrived=%d/%d frames=%d blocked_frames=%d worst_pen=%.3f wall_clamped=%u\n",
           arrived, k, frames, pen_frames, worst_pen, LC.stat_wall_clamped);
    for (int i = 0; i < k; i++) {
        float d = rt_v2_dist(AG[i].pos, goal);
        if (d >= 4.5f)
            printf("    miss %d: pos=(%.1f,%.1f) dist=%.1f |v|=%.2f\n",
                   i, AG[i].pos.x, AG[i].pos.z, d, rt_v2_len(AG[i].vel));
    }
    OK(arrived == k, "T8 all 24 units funnelled through the gate");
    OK(pen_frames == 0, "T8 nobody entered a blocked cell");
    OK(worst_pen < 0.35f, "T8 crowding at the gate stayed bounded");
    rt_local_destroy(&LC);
    rt_gw_destroy(&w);
    rt_region_destroy(&map);
    rt_grid_destroy(&G);
}

int main(void)
{
    timer_init();
    printf("=== M5 tests: LocalAvoidance (ORCA + wall constraint) ===\n");
    t1_head_on();
    t2_ring();
    t3_wall();
    t4_determinism();
    t5_mixed_size();
    t6_cost();
    t7_static_blocker();
    t8_gate_funnel();

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    if (g_fail == 0) printf("ALL PASS (%d asserts)\n", g_pass);
    return g_fail == 0 ? 0 : 1;
}

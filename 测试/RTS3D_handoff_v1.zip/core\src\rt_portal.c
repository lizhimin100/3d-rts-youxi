/* ============================================================================
 * rt_portal.c -- 窄通道自动检测 + 自动仲裁注册（M14）
 * 设计口径见 rt_portal.h 顶部。
 * ==========================================================================*/
#include "rt_portal.h"
#include "rt_math.h"

#include <stdlib.h>
#include <string.h>
#include <math.h>

void rt_portal_config_default(RtPortalConfig *c)
{
    if (!c) return;
    memset(c, 0, sizeof(*c));
    /* 2.5 m：M11 实测 2 m 是真单车道（两队正面相遇无解），3 m 的洞两队能自己交错
     * 过去（142~220 s）。阈值取在两者之间，宁可漏判也不要过度串行化 ——
     * 「先量再上仲裁，否则只是串行化」是 M11 的原话。 */
    c->lane_width    = 2.5f;
    c->min_clear     = 0.5f;    /* 半径 0.5 的单位至少要这么大的 clearance */
    /* 8 格：1 格厚的门洞（2 格宽 × 1 格厚 = 2 格）不需要仲裁 —— M11 明确测过
     * 「1 格厚的门洞两队各占一侧也能挤过去」。8 格 = 2 m × 4 m 以上才当通道。 */
    c->min_cells     = 8;
    c->max_area_frac = 0.20f;
    c->min_fill      = 0.55f;
    c->staging_ahead = 8.f;
    /* 8 m 而不是 4：等待区是边长为 staging_size 的正方形（半边长 6 m），
     * 侧向偏移必须 > 半边长，否则矩形会**压回通道轴线所在的带**，
     * 等于把 owner 的出口堵住 —— M10/M11 两次踩过这个坑。 */
    c->staging_side  = 8.f;
    c->staging_size  = 12.f;
    c->max_portals   = RT_PORTAL_MAX;
}

int rt_portal_init(RtPortalMap *m, int max_portals, const RtPortalConfig *cfg)
{
    if (!m || max_portals <= 0) return RT_ERR_INVALID;
    memset(m, 0, sizeof(*m));
    if (cfg) m->cfg = *cfg;
    else     rt_portal_config_default(&m->cfg);
    if (m->cfg.max_portals <= 0 || m->cfg.max_portals > max_portals)
        m->cfg.max_portals = max_portals;
    m->cap = (m->cfg.max_portals < max_portals) ? m->cfg.max_portals : max_portals;
    m->p = (RtPortal *)calloc((size_t)m->cap, sizeof(RtPortal));
    if (!m->p) { m->cap = 0; return RT_ERR_CAPACITY; }
    return RT_OK;
}

void rt_portal_destroy(RtPortalMap *m)
{
    if (!m) return;
    free(m->p);        m->p = NULL;
    free(m->span_x);   m->span_x = NULL;
    free(m->span_z);   m->span_z = NULL;
    free(m->label);    m->label = NULL;
    free(m->queue);    m->queue = NULL;
    m->cap = m->n = 0;
    m->scratch_cells = 0;
}

static int ensure_scratch(RtPortalMap *m, int cells)
{
    if (cells <= m->scratch_cells && m->span_x) return 1;
    int16_t *sx = (int16_t *)realloc(m->span_x, (size_t)cells * sizeof(int16_t));
    int16_t *sz = (int16_t *)realloc(m->span_z, (size_t)cells * sizeof(int16_t));
    int32_t *lb = (int32_t *)realloc(m->label, (size_t)cells * sizeof(int32_t));
    int32_t *qu = (int32_t *)realloc(m->queue, (size_t)cells * sizeof(int32_t));
    if (sx) m->span_x = sx;
    if (sz) m->span_z = sz;
    if (lb) m->label = lb;
    if (qu) m->queue = qu;
    if (!m->span_x || !m->span_z || !m->label || !m->queue) {
        m->scratch_cells = 0;
        return 0;
    }
    m->scratch_cells = cells;
    return 1;
}

/* ----------------------------------------------------------------------------
 * 自由行程长度：水平 / 垂直各一趟 run-length
 * --------------------------------------------------------------------------*/
static void compute_spans(RtPortalMap *m, const RtGrid *g)
{
    const int w = g->w, h = g->h;

    for (int z = 0; z < h; z++) {
        int x = 0;
        while (x < w) {
            if (!rt_grid_walkable(g, x, z)) { x++; continue; }
            int x0 = x;
            while (x < w && rt_grid_walkable(g, x, z)) x++;
            int len = x - x0;
            if (len > 32767) len = 32767;
            for (int k = x0; k < x; k++) m->span_x[(size_t)z * w + k] = (int16_t)len;
        }
    }
    for (int x = 0; x < w; x++) {
        int z = 0;
        while (z < h) {
            if (!rt_grid_walkable(g, x, z)) { z++; continue; }
            int z0 = z;
            while (z < h && rt_grid_walkable(g, x, z)) z++;
            int len = z - z0;
            if (len > 32767) len = 32767;
            for (int k = z0; k < z; k++) m->span_z[(size_t)k * w + x] = (int16_t)len;
        }
    }
}

int rt_portal_scan(RtPortalMap *m, const RtGrid *g)
{
    if (!m || !g || !m->p) return RT_ERR_INVALID;
    const int w = g->w, h = g->h;
    const size_t cells = (size_t)w * (size_t)h;
    if (!ensure_scratch(m, (int)cells)) return RT_ERR_CAPACITY;

    memset(&m->st, 0, sizeof(m->st));
    m->n = 0;
    m->g = g;

    compute_spans(m, g);

    /* 窄格标记：-1 未访问 / 0 非窄 / 1 窄（稍后改成 blob id+1） */
    const float lane_cells = m->cfg.lane_width / (g->cell > 1e-3f ? g->cell : 1.f);
    int walkable = 0;
    for (int z = 0; z < h; z++) {
        for (int x = 0; x < w; x++) {
            size_t i = (size_t)z * w + x;
            if (!rt_grid_walkable(g, x, z)) { m->label[i] = 0; continue; }
            walkable++;
            float cl = rt_grid_clearance_m(g, x, z);
            int sx = m->span_x[i], sz = m->span_z[i];
            int mn = (sx < sz) ? sx : sz;
            if (cl >= m->cfg.min_clear && (float)mn <= lane_cells) m->label[i] = 1;
            else m->label[i] = 0;
        }
    }
    m->st.walkable_cells = walkable;

    /* 连通块（4 邻域，BFS；队列复用）—— blob 就是「一条通道」 */
    for (int z = 0; z < h; z++) {
        for (int x = 0; x < w; x++) {
            size_t i = (size_t)z * w + x;
            if (m->label[i] != 1) continue;

            int head = 0, tail = 0;
            m->queue[tail++] = (int32_t)i;
            m->label[i] = -2;                 /* 已入队 */
            int bx0 = x, bx1 = x, bz0 = z, bz1 = z, cnt = 0;
            float cmin = 1e9f, cmax = -1e9f;

            while (head < tail) {
                int32_t cur = m->queue[head++];
                int cx = cur % w, cz = cur / w;
                cnt++;
                if (cx < bx0) bx0 = cx;
                if (cx > bx1) bx1 = cx;
                if (cz < bz0) bz0 = cz;
                if (cz > bz1) bz1 = cz;
                float cl = rt_grid_clearance_m(g, cx, cz);
                if (cl < cmin) cmin = cl;
                if (cl > cmax) cmax = cl;

                const int nx[4] = { cx - 1, cx + 1, cx, cx };
                const int nz[4] = { cz, cz, cz - 1, cz + 1 };
                for (int k = 0; k < 4; k++) {
                    if (!rt_grid_in_bounds(g, nx[k], nz[k])) continue;
                    size_t ni = (size_t)nz[k] * w + nx[k];
                    if (m->label[ni] != 1) continue;
                    m->label[ni] = -2;
                    m->queue[tail++] = (int32_t)ni;
                }
            }
            m->st.blobs++;

            /* 过滤：太小 / 太大 / 弯的 */
            if (cnt < m->cfg.min_cells) { m->st.rejected_small++; continue; }
            if (walkable > 0 &&
                (float)cnt > m->cfg.max_area_frac * (float)walkable) {
                m->st.rejected_huge++;
                continue;
            }
            int bw = bx1 - bx0 + 1, bh = bz1 - bz0 + 1;
            float fill = (float)cnt / (float)(bw * bh);
            /* 弯的通道（L / U 形）用一个矩形描述不了：bbox 会把墙和空地一起框进来，
             * `rt_corr_contains` 就会把框里的闲人当成「在通道里」。这种**显式跳过**并计数，
             * 不用一个压着墙的大矩形去假装（正确性优先于覆盖率）。 */
            if (fill < m->cfg.min_fill) { m->st.rejected_bent++; continue; }
            if (m->n >= m->cap) { m->st.cap_overflow++; continue; }

            RtPortal *p = &m->p[m->n];
            memset(p, 0, sizeof(*p));
            p->cells = cnt;
            p->x0 = (float)bx0 * g->cell;
            p->z0 = (float)bz0 * g->cell;
            p->x1 = (float)(bx1 + 1) * g->cell;
            p->z1 = (float)(bz1 + 1) * g->cell;
            p->center = rt_v2((p->x0 + p->x1) * 0.5f, (p->z0 + p->z1) * 0.5f);
            p->axis = (bw >= bh) ? 0 : 1;
            p->bbox_w = (float)bw * g->cell;
            p->bbox_h = (float)bh * g->cell;
            p->len_m = (bw >= bh) ? p->bbox_w : p->bbox_h;
            /* 宽度用**最窄处的自由宽度**（2 × 最小 clearance），不用 bbox 短边：
             * 一条 2 m 宽但拐了个直角的走廊，bbox 短边会是 10 m，
             * 按 bbox 判就会漏掉一条真单车道。 */
            p->min_clear = (cmin > 1e8f) ? 0.f : cmin;
            p->max_clear = (cmax < 0.f) ? 0.f : cmax;
            p->width_m = 2.f * p->min_clear;
            p->fill = fill;
            p->cid = -1;
            m->n++;
            m->st.accepted++;
        }
    }

    /* ---- 相邻分组（union-find）+ 通道链编号 ----
     * 一条 L 形走廊会被切成两段直走廊（拐角格的 min(span) 很大，本身不算窄）。
     * 两段必须**共享一个 owner**，否则 A 队占第一段、B 队占第二段，在拐角互锁。
     * 这里只负责分组；真正的原子仲裁在 rt_chain 里（见 rt_portal_register_chained）。 */
    {
        int parent[RT_PORTAL_MAX];
        for (int i = 0; i < m->n; i++) parent[i] = i;

        for (int i = 0; i < m->n; i++) {
            for (int j = i + 1; j < m->n; j++) {
                const float pad = g->cell;
                const int hit = !(m->p[i].x1 + pad < m->p[j].x0 ||
                                  m->p[j].x1 + pad < m->p[i].x0 ||
                                  m->p[i].z1 + pad < m->p[j].z0 ||
                                  m->p[j].z1 + pad < m->p[i].z0);
                if (!hit) continue;
                m->p[i].chained = 1;
                m->p[j].chained = 1;
                int a = i, b = j;
                while (parent[a] != a) a = parent[a];
                while (parent[b] != b) b = parent[b];
                if (a != b) parent[b] = a;
            }
        }
        /* 压平成 0..k-1（按首次出现的顺序，确定性） */
        for (int i = 0; i < m->n; i++) {
            int r = i;
            while (parent[r] != r) r = parent[r];
            int cid = -1;
            for (int k = 0; k < i; k++) {
                int rk = k;
                while (parent[rk] != rk) rk = parent[rk];
                if (rk == r && m->p[k].chain >= 0) { cid = m->p[k].chain; break; }
            }
            if (cid < 0) {
                cid = 0;
                for (int k = 0; k < i; k++) if (m->p[k].chain >= cid) cid = m->p[k].chain + 1;
            }
            m->p[i].chain = cid;
        }
        for (int i = 0; i < m->n; i++) if (m->p[i].chained) m->st.rejected_chained++;
    }
    return m->n;
}

/* ----------------------------------------------------------------------------
 * 自动注册：通道矩形 + 两侧等待区
 * --------------------------------------------------------------------------*/
/* 在理想点附近找一个**真的能站人**的等待区中心。
 *
 * 为什么需要：等待区是按几何算出来的（沿轴越过端点、再侧向偏移），
 * 完全没有看地图。M14 只验证了「不与通道矩形重叠」，于是这条 Z 形通道的
 * arm1 侧向偏移后正中在 x∈[142,154] —— 那里是实心墙。被引导过去的单位全部
 * 撞墙卡住（M15 端到端才暴露：B 队 0/12、A 队 2 个掉队者永久卡死）。
 *
 * 规则：在理想点周围 ±12 m 内找 clearance 最大的可走格，距离作为次要项。
 * 找不到就退回理想点（显式的兜底，不是静默乱走）。 */
static RtVec2 pick_staging_center(const RtGrid *g, RtVec2 ideal)
{
    if (!g) return ideal;
    int cx = rt_grid_cell_x(g, ideal.x);
    int cz = rt_grid_cell_z(g, ideal.z);
    const int R = 12;
    int bx = -1, bz = -1;
    float best = -1e9f;
    for (int dz = -R; dz <= R; dz++) {
        for (int dx = -R; dx <= R; dx++) {
            int x = cx + dx, z = cz + dz;
            if (!rt_grid_in_bounds(g, x, z)) continue;
            if (!rt_grid_walkable(g, x, z)) continue;
            float c = rt_grid_clearance_m(g, x, z);
            if (c < 1.0f) continue;                 /* 至少能站一个 1 m 单位 */
            float d = sqrtf((float)(dx * dx + dz * dz));
            float cap = (c > 6.f) ? 6.f : c;
            float score = cap - 0.25f * d;          /* 宽敞优先，其次近 */
            if (score > best) { best = score; bx = x; bz = z; }
        }
    }
    if (bx < 0) return ideal;
    return rt_v2(((float)bx + 0.5f) * g->cell, ((float)bz + 0.5f) * g->cell);
}

static int register_impl(RtPortalMap *m, RtCorrCtx *cc, int skip_chained)
{
    /* 几何变了，旧所有权全部作废 —— 重新排队是唯一正确的语义。 */
    rt_corr_clear_all(cc);

    int reg = 0;
    for (int i = 0; i < m->n; i++) {
        RtPortal *p = &m->p[i];
        p->cid = -1;
        /* 宽的不注册：M11 实测 3 m 的洞两队能自己交错过去，仲裁只会串行化。 */
        if (p->width_m > m->cfg.lane_width + 1e-3f) continue;
        /* 相接的通道：不接链路协调器时一律不注册（会让两个 owner 在拐角互锁）。 */
        if (skip_chained && p->chained) continue;
        if (reg >= m->cfg.max_portals) { m->st.cap_overflow++; break; }

        int cid = rt_corr_add(cc, p->x0, p->z0, p->x1, p->z1, p->axis);
        if (cid < 0) { m->st.cap_overflow++; break; }
        p->cid = cid;
        reg++;

        /* 等待区：沿轴线越过端点 staging_ahead，再**侧向**偏 staging_side。
         * 只往前不侧移会把 owner 的出口堵住（M10/M11 两次踩过）；
         * 只侧移不往前会让等待的人还站在门口 28 m 的门控圈里转圈。 */
        float half_len = p->len_m * 0.5f;
        float half_wid = p->width_m * 0.5f;
        float sz = m->cfg.staging_size * 0.5f;
        RtVec2 ax = (p->axis == 0) ? rt_v2(1.f, 0.f) : rt_v2(0.f, 1.f);
        RtVec2 pp = rt_v2(-ax.z, ax.x);
        for (int side = 0; side < 2; side++) {
            float sgn = (side == 0) ? -1.f : 1.f;
            RtVec2 c = p->center;
            c = rt_v2_add(c, rt_v2_mul(ax, sgn * (half_len + m->cfg.staging_ahead)));
            /* 两侧等待区放在**相反**的侧向，避免两边的人挤在同一块地方 */
            c = rt_v2_add(c, rt_v2_mul(pp, sgn * (half_wid + m->cfg.staging_side)));
            /* 几何点可能在墙里 —— 挪到最近的可走、宽敞处 */
            c = pick_staging_center(m->g, c);
            rt_corr_set_staging(cc, cid, side, c.x - sz, c.z - sz, c.x + sz, c.z + sz);
        }
    }
    m->st.registered = (uint32_t)reg;
    return reg;
}

int rt_portal_register(RtPortalMap *m, RtCorrCtx *cc)
{
    if (!m || !cc || !m->p) return RT_ERR_INVALID;
    return register_impl(m, cc, 1);
}

int rt_portal_register_chained(RtPortalMap *m, RtCorrCtx *cc, RtChainCtx *chain)
{
    if (!m || !cc || !m->p) return RT_ERR_INVALID;
    int reg = register_impl(m, cc, 0);
    if (!chain) return reg;

    /* 每个窄通道组（含单条）建一条链。单条时链退化成一个段，
     * 行为和 M11 的「一条通道一个 owner」完全相同，调用方不必分两种情况。 */
    rt_chain_clear_all(chain);
    int chain_of_group[RT_PORTAL_MAX];
    for (int i = 0; i < RT_PORTAL_MAX; i++) chain_of_group[i] = -1;

    for (int i = 0; i < m->n; i++) {
        RtPortal *p = &m->p[i];
        if (p->cid < 0 || p->chain < 0) continue;
        int g = p->chain;
        if (g >= RT_PORTAL_MAX) continue;
        if (chain_of_group[g] < 0) {
            int ch = rt_chain_new(chain);
            if (ch < 0) { m->st.cap_overflow++; break; }
            chain_of_group[g] = ch;
        }
        (void)rt_chain_add_seg(chain, chain_of_group[g], p->cid);
    }
    return reg;
}

int rt_portal_at(const RtPortalMap *m, RtVec2 pos, float max_dist)
{
    if (!m || !m->p) return -1;
    int best = -1;
    float bestd = 1e30f;
    for (int i = 0; i < m->n; i++) {
        const RtPortal *p = &m->p[i];
        float dx = 0.f, dz = 0.f;
        if (pos.x < p->x0)      dx = p->x0 - pos.x;
        else if (pos.x > p->x1) dx = pos.x - p->x1;
        if (pos.z < p->z0)      dz = p->z0 - pos.z;
        else if (pos.z > p->z1) dz = pos.z - p->z1;
        float d = sqrtf(dx * dx + dz * dz);   /* 矩形内为 0 */
        if (max_dist > 0.f && d > max_dist) continue;
        if (d < bestd) { bestd = d; best = i; }
    }
    return best;
}

const char *rt_portal_name(void)
{
    return "portal(bottleneck)";
}

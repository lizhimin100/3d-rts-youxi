/* ============================================================================
 * rt_spatial.c -- 均匀网格空间索引实现
 * ==========================================================================*/
#include "rt_spatial.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* 全局「上次查询被截断」标记：单线程语义。
 * 多线程下每个 worker 必须用自己的副本（见 01 文档 §12：
 * 查询输出写线程本地缓冲，避免共享状态）。 */
static int g_truncated = 0;

int rt_spatial_last_truncated(void) { return g_truncated; }

float rt_spatial_required_cell(float query_radius)
{
    /*
     * 3x3 桶的**保证覆盖半径 = 1.0 * cell**（不是 1.5 * cell）：
     *   查询点 x in [cx*cell, (cx+1)*cell)
     *   覆盖区间 [ (cx-1)*cell, (cx+2)*cell )
     *   到左边界距离 = x - (cx-1)*cell >= cell
     *   到右边界距离 = (cx+2)*cell - x  >  cell
     * 所以必须 cell >= query_radius。
     *
     * 曾经写成 radius/1.5（把「查询点在桶中心」当成了最坏情况），
     * 结果是桶偏小、3x3 漏检；由 test_spatial 的负例断言抓住。
     */
    return ceilf(query_radius * 2.f) * 0.5f;
}

int rt_spatial_init(RtSpatialGrid *sg, float world_w, float world_h, float cell_size)
{
    if (!sg || world_w <= 0.f || world_h <= 0.f || cell_size <= 0.f)
        return RT_ERR_INVALID;

    memset(sg, 0, sizeof(*sg));
    sg->cell = cell_size;
    sg->gw = (int)ceilf(world_w / cell_size);
    sg->gh = (int)ceilf(world_h / cell_size);
    if (sg->gw < 1) sg->gw = 1;
    if (sg->gh < 1) sg->gh = 1;

    sg->cap_cells = sg->gw * sg->gh;
    sg->start   = (int *)malloc(sizeof(int) * ((size_t)sg->cap_cells + 1));
    sg->items   = (uint16_t *)malloc(sizeof(uint16_t) * RT_MAX_UNITS);
    sg->cell_of = (uint16_t *)malloc(sizeof(uint16_t) * RT_MAX_UNITS);
    sg->wr      = (int *)malloc(sizeof(int) * (size_t)sg->cap_cells);

    if (!sg->start || !sg->items || !sg->cell_of || !sg->wr) {
        rt_spatial_destroy(sg);
        return RT_ERR_CAPACITY;
    }
    memset(sg->start, 0, sizeof(int) * ((size_t)sg->cap_cells + 1));
    sg->n = 0;
    sg->declared_radius = 0.f;
    return RT_OK;
}

void rt_spatial_destroy(RtSpatialGrid *sg)
{
    if (!sg) return;
    free(sg->start);   sg->start = NULL;
    free(sg->items);   sg->items = NULL;
    free(sg->cell_of); sg->cell_of = NULL;
    free(sg->wr);      sg->wr = NULL;
    sg->gw = sg->gh = sg->cap_cells = 0;
}

int rt_spatial_build(RtSpatialGrid *sg, const RtUnitStore *units,
                     const RtUnitId *ids, int n, float query_radius)
{
    if (!sg || !units || !ids || n < 0 || n > RT_MAX_UNITS) return RT_ERR_INVALID;
    sg->n = 0;
    g_truncated = 0;

    /* ★ 核心断言：桶必须覆盖 3x3 查询范围，否则静默漏检（见头文件注释）
     * 正确条件：cell >= query_radius（推导见 rt_spatial_required_cell）。 */
    if (sg->cell + 1e-4f < query_radius) {
        return RT_ERR_INVALID;
    }
    sg->declared_radius = query_radius;

    int nb = sg->cap_cells;
    memset(sg->start, 0, sizeof(int) * ((size_t)nb + 1));

    /* 1. 计数（start[c+1] 作为计数桶） */
    for (int i = 0; i < n; i++) {
        RtUnitId id = ids[i];
        const RtUnitChunk *c = rt_units_chunk_c(units, id);
        int k = rt_unit_slot_index(id);
        int cx = (int)floorf(c->px[k] / sg->cell);
        int cz = (int)floorf(c->pz[k] / sg->cell);
        if (cx < 0) cx = 0; if (cx >= sg->gw) cx = sg->gw - 1;
        if (cz < 0) cz = 0; if (cz >= sg->gh) cz = sg->gh - 1;
        int cell = cz * sg->gw + cx;
        sg->cell_of[i] = (uint16_t)cell;
        sg->start[cell + 1]++;
    }

    /* 2. 前缀和 */
    for (int c = 0; c < nb; c++) sg->start[c + 1] += sg->start[c];

    /* 3. 稳定填充（按输入顺序 -> 确定性顺序，FR-SPA-6） */
    memcpy(sg->wr, sg->start, sizeof(int) * (size_t)nb);
    for (int i = 0; i < n; i++) {
        int c = sg->cell_of[i];
        sg->items[sg->wr[c]++] = (uint16_t)ids[i];
    }
    sg->n = n;
    return RT_OK;
}

int rt_spatial_query_circle(const RtSpatialGrid *sg, const RtUnitStore *units,
                            RtVec2 center, float radius, RtUnitId exclude,
                            RtUnitId *out, int max_out)
{
    g_truncated = 0;
    if (!sg || !units || !out || max_out <= 0) return 0;

    /* 查询半径超过声明值 -> 结果可能不完整，必须显式报告 */
    if (radius > sg->declared_radius + 1e-4f) {
        g_truncated = 1;
        return 0;
    }

    int cx = (int)floorf(center.x / sg->cell);
    int cz = (int)floorf(center.z / sg->cell);
    float r2 = radius * radius;
    int cnt = 0;
    int cap_hit = 0;

    for (int dz = -1; dz <= 1; dz++) {
        int z = cz + dz;
        if (z < 0 || z >= sg->gh) continue;
        for (int dx = -1; dx <= 1; dx++) {
            int x = cx + dx;
            if (x < 0 || x >= sg->gw) continue;
            int cell = z * sg->gw + x;
            for (int k = sg->start[cell]; k < sg->start[cell + 1]; k++) {
                RtUnitId id = (RtUnitId)sg->items[k];
                if (exclude != RT_UNIT_ID_NONE && id == exclude) continue;
                const RtUnitChunk *c = rt_units_chunk_c(units, id);
                int s = rt_unit_slot_index(id);
                float ddx = c->px[s] - center.x;
                float ddz = c->pz[s] - center.z;
                if (ddx * ddx + ddz * ddz > r2) continue;
                if (cnt >= max_out) { cap_hit = 1; break; }
                out[cnt++] = id;
            }
            if (cap_hit) break;
        }
        if (cap_hit) break;
    }
    if (cap_hit) g_truncated = 1;
    return cnt;
}

int rt_spatial_query_rect(const RtSpatialGrid *sg, const RtUnitStore *units,
                          RtAabb2 rect, RtUnitId *out, int max_out)
{
    g_truncated = 0;
    if (!sg || !units || !out || max_out <= 0) return 0;

    int x0 = (int)floorf(rect.min_x / sg->cell);
    int z0 = (int)floorf(rect.min_z / sg->cell);
    int x1 = (int)floorf(rect.max_x / sg->cell);
    int z1 = (int)floorf(rect.max_z / sg->cell);
    if (x0 < 0) x0 = 0; if (z0 < 0) z0 = 0;
    if (x1 >= sg->gw) x1 = sg->gw - 1;
    if (z1 >= sg->gh) z1 = sg->gh - 1;

    int cnt = 0;
    for (int z = z0; z <= z1; z++) {
        for (int x = x0; x <= x1; x++) {
            int cell = z * sg->gw + x;
            for (int k = sg->start[cell]; k < sg->start[cell + 1]; k++) {
                RtUnitId id = (RtUnitId)sg->items[k];
                const RtUnitChunk *c = rt_units_chunk_c(units, id);
                int s = rt_unit_slot_index(id);
                if (c->px[s] < rect.min_x || c->px[s] > rect.max_x) continue;
                if (c->pz[s] < rect.min_z || c->pz[s] > rect.max_z) continue;
                if (cnt >= max_out) { g_truncated = 1; return cnt; }
                out[cnt++] = id;
            }
        }
    }
    return cnt;
}

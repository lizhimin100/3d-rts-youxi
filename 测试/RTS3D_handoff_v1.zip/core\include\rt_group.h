/* ============================================================================
 * rt_group.h -- M4.1 MovementGroup + 共享 Global Route
 *
 * 这一层只回答一个问题：**往哪个方向走**（Preferred Direction 的来源）。
 * 不做 local avoidance、不做 formation、不写 Transform。
 *
 * 拆组规则（题面 §六/§七/§五十）：
 *   同一批被选中的单位按 (movement_class, clearance_class, 连通分量) 分组。
 *   - 坦克与步兵 clearance 不同 -> 必然拆组（否则会共享一条坦克过不去的路）
 *   - 隔着河的两半 -> 连通分量不同 -> 拆组（各自解析 nearest reachable）
 *   - 同一个组内，成员可能分布在多个「源区域」-> 每个源区域一条共享 route，
 *     而不是每个单位一条（题面 §十六/§十七）。
 *
 * Group 是 game 侧的对象；这里只管**导航状态**，不持有单位位置。
 * ==========================================================================*/
#ifndef RT_GROUP_H
#define RT_GROUP_H

#include "rt_types.h"
#include "rt_grid.h"
#include "rt_navsched.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_fineflow.h"
#include "rt_unit.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RT_GROUP_ROUTES_MAX 4     /* 一个 group 最多几条「按源区域」的共享 route */
#define RT_GROUP_REUSE_MAX  512   /* route 复用表的扫描上限（组数 × 槽位） */
#define RT_GW_RECENT        16    /* 旧版跨命令 LRU（M4.1）；M4.2 起由 route_cache 取代 */

/* ---- M4.2 缓存容量（固定上界，运行期不扩容、不产生碎片） ---------------- */
#define RT_ROUTE_CACHE_CAP      256   /* 必须是 2 的幂 */
#define RT_GOAL_CACHE_CAP        64   /* 必须是 2 的幂 */
#define RT_ROUTE_CACHE_MAX_LEN  512   /* 走廊长度超过它就不入缓存（内存上界） */
#define RT_CACHE_LOAD_NUM         3   /* 装载上限 = CAP × 3/4，保证探测链上始终有空槽 */
#define RT_CACHE_LOAD_DEN         4

/* M4.3 自适应阈值：unique source region 少于它就继续 per-source A*。
 * 依据：probe 实测 N=8 时目标树只值 1.69×（还含 route 物化成本），
 *       N=16 起才稳定 >2×；bench_m43 的 real command path 复核见 10_M4.3_报告.md。 */
#define RT_GOALFLOW_MIN_SOURCES  16

/* M4.6-P5：异步 split 的每帧预算（BFS 节点）。实测 8000 节点 ≈ 0.6 ms/帧，
 * 6.5 万格的 split 约 9 帧完成（原来 4.6 ms 一帧）。
 * 调大 = 帧更贵、收敛更快；调小 = 帧更轻、旧 route 服务更久。 */
#define RT_GW_SPLIT_BUDGET_DEFAULT 8000
#define RT_GOALFLOW_SLOTS        RT_GOALFLOW_MAX


typedef enum {
    RT_GROUP_NAV_PENDING = 0,  /* 正在建 route（M4.1 同步完成，仅状态位） */
    RT_GROUP_NAV_READY,        /* route 就绪，可以采样 */
    RT_GROUP_MOVING,
    RT_GROUP_REPATH_PENDING,   /* 地图变了，route 失效，等待重建 */
    RT_GROUP_ARRIVED,
    RT_GROUP_UNREACHABLE,      /* 目标完全不可达（不同连通分量且无替代点） */
    RT_GROUP_CANCELLED
} RtGroupState;

typedef struct {
    int32_t  start_region;
    RtRoute  route;
    uint32_t built_frame;
    /* M4.4：走廊索引（在 route 物化时算好，采样热路径上只读）。
     * seg_block[k]  = 1 表示「节点 k-1 -> 节点 k 的直线穿墙」（k = 0 恒 0）；
     * seg_invlen[k] = 1 / |节点 k-1 - 节点 k|，用于把点积换成「米」而不做除法。 */
    uint8_t *seg_block;
    float   *seg_invlen;
    int      seg_cap;
    int      seg_n;
} RtGroupRoute;

typedef struct {
    uint32_t        id;               /* 1..RT_MAX_GROUPS（0 = 空）；恒等于 index+1 */
    uint32_t        cmd_seq;          /* M4.5：创建它的命令序号。不同命令**不合并**，
                                       * 否则两条命令的同一个组会被后一条目标覆盖。 */
    uint32_t        command_version;
    RtUnitId       *members;
    int32_t        *src_region;       /* 与 members 同序：每个成员的源区域 */
    int             count, cap;
    RtVec2          destination;      /* 玩家点击的原始坐标 */
    RtVec2          goal_pos;         /* 解析后的合法到达点（可能是 nearest reachable） */
    int32_t         goal_region;
    uint8_t         movement_class;
    uint8_t         clearance_class;
    RtGroupState    state;
    RtGroupRoute    routes[RT_GROUP_ROUTES_MAX];
    int             route_count;
    int32_t         slot_regions[RT_GROUP_ROUTES_MAX]; /* 本组建 route 的源区域（成员来源） */
    int             slot_n;
    int32_t         component;        /* 本组所在连通分量 */
    uint32_t        created_frame, last_update_frame;
    uint32_t        corrections;      /* 本组发生 nearest-reachable 修正的次数 */
} RtMoveGroup;

typedef struct {
    /* 统计（M4 报告 §七十一/§七十二 要求） */
    uint32_t groups;
    uint32_t units;
    uint32_t route_requests;      /* 组内某个 (源,目标,类别) 需要 route 的次数 */
    uint32_t route_builds;        /* 真正跑 A* 的次数 */
    uint32_t route_reuses;        /* 命中复用（= route_cache_hits，保留旧字段名） */
    uint32_t route_stale;         /* 检出依赖失效的 route 条数 */
    uint32_t route_failed;
    uint32_t goal_resolves;
    uint32_t goal_corrections;    /* invalid destination -> nearest reachable */
    uint32_t region_rebuilds;

    /* ---- M4.2：把「容量不够」与「依赖失效」分开计数，否则无法归因 ---- */
    uint32_t route_cache_hits;      /* key 命中且依赖有效 */
    uint32_t route_cache_misses;    /* key 不存在 */
    uint32_t route_invalidated;     /* key 存在但依赖失效（已驱逐，需重建） */
    uint32_t route_evicted;         /* 容量淘汰（LRU） */
    uint32_t route_cache_rejected;  /* 走廊过长/非法，未入缓存（不得静默） */
    uint32_t goal_cache_hits;
    uint32_t goal_cache_misses;

    /* ---- M4.3：goal-centric coarse flow ---- */
    uint32_t goal_flow_builds;       /* 反向搜索次数 */
    uint32_t goal_flow_hits;         /* 缓存命中且依赖有效 */
    uint32_t goal_flow_invalid;      /* 命中但依赖失效 */
    uint32_t goal_flow_expanded;     /* settle 的区域总数（成本归因） */
    uint32_t goal_flow_sources;      /* 建树时请求的 source 数 */
    uint32_t flow_route_extracts;    /* 从树摘出 route 的次数 */
    uint32_t fallback_to_astar;      /* 树里不可达 -> 退回 A* */
    uint32_t adaptive_flow;          /* 走 flow 分支的命令数 */
    uint32_t adaptive_astar;         /* 走 per-source A* 的命令数 */

    /* ---- M4.4：走廊推进 + 有界 fine flow（全部显式计数，禁止静默降级） ---- */
    uint32_t corridor_segments;      /* 建索引时逐段 DDA 的总段数 */
    uint32_t corridor_blocked;       /* 其中「直线被挡」的段数 */
    uint32_t fine_checks;            /* 被封段上做的单位级 LOS 次数 */
    uint32_t fine_builds;            /* fine flow 真正构建次数 */
    uint32_t fine_hits;              /* fine flow 命中（依赖有效） */
    uint32_t fine_invalid;           /* fine flow 命中但依赖失效 -> 整块重建 */
    uint32_t fine_used;              /* 采样实际使用了 fine flow 的次数 */
    uint32_t fine_rejected;          /* 窗口越界，拒建 */
    uint32_t fine_failed;            /* 建场失败（目标不可走 / 容量） */
    uint32_t fine_outside;           /* 站位不在窗口内或无解 -> 退回节点目标 */
    uint32_t fine_reached;           /* BFS 到达格数累计（成本归因） */
    uint32_t fine_budget_skip;       /* M4.6：本帧建场预算用尽，跳过建场（退回节点目标） */

    /* ---- M4.6-P2：区域图增量刷新（全部显式计数） ---- */
    uint32_t region_rect_refresh;    /* 走增量矩形的次数 */
    uint32_t region_regions;         /* 累计重算的区域数（整图 = rw*rh） */
    uint32_t region_full_refresh;    /* 退化为整图重建的次数（含安全网） */
    uint32_t region_widened;         /* 安全网：矩形外有 chunk 变化 -> 扩成全量 */

    /* ---- M4.5：多组并存 ---- */
    uint32_t cmd_seq;                /* 本次命令的内部序号（单调递增） */
    uint32_t groups_kept;            /* 本命令之后仍在的旧组数 */
    uint32_t groups_freed;           /* 因成员被移空而释放的组数 */
    uint32_t members_moved;          /* 被本命令从旧组移出的成员数 */
} RtGwStats;

/* ---------------------------------------------------------------------------
 * M4.2 Global Route Cache
 *
 * 定位：**按 key 索引的固定容量缓存**，取代 M4.1 的 recent[16] 线性表。
 *   - 只缓存「真正等价」的请求：key = (source region, component,
 *     resolved goal region, clearance class, movement class)。
 *     component 必须进 key：同一 region id 可能横跨两个连通分量（mixed），
 *     只按 region 比较会让两个分量错误共享同一条走廊。
 *   - 依赖（chunk_ver / label_epoch）不进 key，而是**查到时校验**：
 *     key 命中但依赖失效 => RT_CACHE_INVALID（与 MISS 分开计数）。
 *   - 固定容量 + 开放寻址 + tombstone；装载到 3/4 就淘汰 LRU，
 *     探测链上始终有空槽，lookup 期望 O(1)。
 *   - 条目自带 RtRoute 副本（拥有 regions/portal），group 那侧仍各存一份 ——
 *     即「缓存是主副本，group 是使用副本」，避免生命周期耦合。
 * ------------------------------------------------------------------------- */
typedef enum {
    RT_CACHE_MISS    = 0,   /* key 不存在 */
    RT_CACHE_HIT     = 1,   /* key 存在且依赖有效 */
    RT_CACHE_INVALID = 2    /* key 存在但依赖失效（已就地驱逐） */
} RtCacheAnswer;

typedef struct {
    uint8_t  state;          /* 0 = empty, 1 = used, 2 = tombstone */
    uint8_t  cls, mcls;
    int32_t  start, goal, component;
    uint32_t hash;
    uint32_t last_used;
    uint32_t hits;
    RtRoute  route;          /* 拥有 regions/portal */
} RtRouteCacheSlot;

typedef struct {
    uint8_t  state;
    int32_t  cell_x, cell_z; /* 量化后的目标格（不是世界坐标） */
    int32_t  component;
    uint8_t  cls;
    int32_t  goal_region;
    RtVec2   goal_pos;
    uint8_t  corrected;      /* 1 = 落点被 nearest-reachable 修正过 */
    uint32_t label_epoch;    /* 建立时的 id 空间 */
    uint32_t nav_epoch;      /* 上次复核时的提交版本 */
    uint32_t last_used;
} RtGoalCacheSlot;

typedef struct {
    RtGrid       *g;              /* 非拥有 */
    RtRegionMap  *map;            /* 非拥有 */
    RtRouteSolver solver;

    RtMoveGroup  groups[RT_MAX_GROUPS];
    int          group_count;

    /* M4.2 cache（rt_gw_init 一次性分配，rt_gw_destroy 释放） */
    RtRouteCacheSlot *route_cache;
    RtGoalCacheSlot  *goal_cache;
    int          route_cache_used;
    int          route_cache_tomb;
    int          goal_cache_used;
    uint32_t     cache_seq;

    /* M4.3 goal-centric flow（按 (goal, comp, cls, mcls) 缓存） */
    RtGoalFlow        flows[RT_GOALFLOW_SLOTS];
    RtGoalFlowSolver  flow_solver;
    int32_t          *path_scratch;      /* [nregions]，摘 route 用 */
    int               flow_threshold;    /* 0 = 用默认 RT_GOALFLOW_MIN_SOURCES */
    uint32_t          flow_seq;

    /* M4.4-B bounded fine flow（按 (目标格, cls, 窗口原点) 缓存，RT_FINE_SLOTS 槽） */
    RtFineFlow        fine[RT_FINE_SLOTS];
    RtFineSolver      fine_solver;
    uint32_t          fine_seq;
    int               fine_enabled;      /* 0 = 关闭（对照用），默认 1 */

    /* M4.6-P1 建场预算（分帧）：采样路径不再可能一次建多个场。
     *   < 0 : 不限（M4.4 的旧行为，仅供对照）
     *   = 0 : 只查缓存，绝不建场
     *   > 0 : 每次 rt_gw_command / rt_gw_update 重置为 k，采样期间最多建 k 个
     * 预算用尽时退回「节点 + 直线」并计 fine_budget_skip，不静默。 */
    int               fine_budget;
    int               fine_budget_left;

    /* ---- M4.6-P5（路线 B）：异步 split ----
     * 大分量的 split 是 O(分量大小)，64×64 的编辑实测 4.6 ms（一帧的 28%）。
     * M3.7 已经有分帧调度器（RtNavSched：分帧 / 合并 / 取消 / stale 不丢更新），
     * 这里把它接到世界层：
     *   · `rt_gw_submit_edit()` 提交编辑（小编辑当场完成，行为与旧路径一致）；
     *   · 大 split 挂起，`rt_gw_update()` 每帧推进 `split_budget` 个 BFS 节点；
     *   · 挂起期间 **不刷区域图、不重建 route**：grid 的 component 标签处于
     *     「已摘格、未重标」的中间态（split 的重标发生在 commit），任何依赖它的
     *     重建都会读到半成品。采样照旧用旧 route（flags 已经是新的，物理上不穿墙）。
     *   · `rt_gw_command()` 是用户路径，进来先把未完成的 job 跑完（drain）。 */
    RtNavSched        sched;
    int               async_split;      /* 0 = 关闭（回退到 P4 的同步行为，排障用） */
    int               split_budget;     /* 每次 update 推进的 BFS 节点数 */
    int               split_pending;    /* 1 = 有未完成的 split Job */
    uint32_t          split_frames;     /* 当前/最近一次 job 跨的帧数 */
    uint32_t          split_max_frames; /* 历史最大跨帧数（诊断） */
    uint32_t          split_jobs;       /* 进入异步的 job 数 */
    uint32_t          split_spans;      /* 跨了 >=2 帧的 job 数（真正被摊开的） */
    int               pend_valid;       /* 待刷新区域图矩形的有效性 */
    int               pend_x0, pend_z0, pend_x1, pend_z1;

    uint32_t     frame;
    uint32_t     cmd_seq;            /* M4.5：命令序号（每条 rt_gw_command +1） */
    RtGwStats    stats;
} RtGroupWorld;

int  rt_gw_init(RtGroupWorld *w, RtGrid *g, RtRegionMap *map);
void rt_gw_destroy(RtGroupWorld *w);

/* 下达移动命令：按 (movement_class, clearance_class, component) 自动拆组，
 * 每组按源区域建 1 条共享 route（复用同 key 的结果）。
 * command_version 由调用方递增；旧版本的结果不会覆盖新命令。
 *
 * ---- M4.5：并存语义 ----
 * 本函数只影响 `ids` 里的单位：
 *   1. 把它们从原来的组里摘出来（旧组变空则释放，变瘦则重建 slot/route 索引）；
 *   2. 按本命令重新拆组，组带 `cmd_seq`，**不与其它命令的组共享**（否则目标会被覆盖）；
 *   3. 没有出现在 `ids` 里的组**原样保留**，route 继续有效。
 * 因此可以同时存在多条互不干扰的命令：A 组去 G1、B 组去 G2。
 * `group_count` 是压缩后的存活组数；`chunk->group = index + 1` 是不变式，
 * 命令返回前会把所有受影响成员的 chunk 字段回写成新 id。 */
int rt_gw_command(RtGroupWorld *w, const RtUnitStore *units,
                  const RtUnitId *ids, int n,
                  RtVec2 dest, uint8_t movement_class, uint8_t clearance_class,
                  uint32_t command_version);

/* 丢弃所有组（单位全灭 / 场景切换）。保留缓冲区，不释放内存。
 * units 非空时同时把这些组成员的 unit.group 清零（否则单位会带着失效的组 id
 * 去调 rt_gw_sample）。传 NULL 只清导航侧，调用方自己负责 unit.group。 */
void rt_gw_clear(RtGroupWorld *w, RtUnitStore *units);

/* 每帧/每次导航提交后调用：检查 route 版本，失效的重建。返回重建条数。 */
int rt_gw_update(RtGroupWorld *w);

/* 采样：给单位位置，返回它应该前往的局部目标（世界坐标）。
 * 这是 Navigation 层的输出，交给 Local Avoidance 去决定实际速度。 */
int rt_gw_sample(const RtGroupWorld *w, int group_index, RtVec2 unit_pos, RtVec2 *out_target);

/* 到达分布（M4 只做「不堆在一起」，不是 formation） */
RtVec2 rt_gw_arrival_pos(const RtGroupWorld *w, int group_index, int member_index);
int    rt_gw_is_arrived(const RtGroupWorld *w, int group_index, RtVec2 unit_pos, float tol);

const char *rt_group_state_name(RtGroupState s);

/* ---- M4.2 诊断（测试/基准断言用；不影响行为） ---- */
int    rt_gw_route_cache_count(const RtGroupWorld *w);   /* used 槽位数 */
int    rt_gw_goal_cache_count(const RtGroupWorld *w);
size_t rt_gw_cache_bytes(const RtGroupWorld *w);         /* slot + 走廊内存 */

/* ---- M4.3 自适应开关 / 诊断 ----
 * threshold < 0  : 强制 goal flow（基准用）
 * threshold == 0 : 用默认 RT_GOALFLOW_MIN_SOURCES
 * threshold > 0  : 达到该 unique source 数才用 flow */
void   rt_gw_set_flow_threshold(RtGroupWorld *w, int threshold);
int    rt_gw_flow_count(const RtGroupWorld *w);          /* ready 的 flow 数 */
size_t rt_gw_flow_bytes(const RtGroupWorld *w);

/* ---- M4.4 诊断 / 开关 ----
 * fine_enabled = 0 时 rt_gw_sample 完全退回「节点 + 直线」（用于对照 trigger 率）。 */
void   rt_gw_set_fine_enabled(RtGroupWorld *w, int on);
int    rt_gw_fine_count(const RtGroupWorld *w);          /* ready 的 fine flow 数 */
size_t rt_gw_fine_bytes(const RtGroupWorld *w);

/* ---- M4.6-P1 建场预算（分帧）----
 * 采样路径原本会在一次遍历里连建多个场（1000 单位首次采样实测 3 个 → 0.04~0.06 ms
 * 的帧尖峰）。改成「每次 command / update 重置预算」后，建场被摊到多帧：
 *   budget < 0 : 不限（M4.4 旧行为，对照用）
 *   budget = 0 : 只查缓存
 *   budget > 0 : 每次 command/update 之后最多建 budget 个（默认 1）
 * 用尽时采样退回「节点 + 直线」，并计 stats.fine_budget_skip —— 不静默降级。 */
void   rt_gw_set_fine_budget(RtGroupWorld *w, int budget);
int    rt_gw_fine_budget_left(const RtGroupWorld *w);

/* ---- M4.6-P2 区域图增量刷新 ----
 * 编辑流程：rt_grid_*_building_dirty() -> rt_grid_apply_dirty() -> **本函数** -> update()。
 * 只重算与 d 相交的区域（d 必须是这次提交的那份 dirty；NULL = 整图对齐，慢但安全）。
 *
 * 什么时候可以不调用：语义仍然正确 —— command()/update() 发现 built_epoch 落后时会
 * 自行整图重建（并计 region_rebuilds）。调用它只是把 0.6~0.8 ms 的整图重建
 * 降到与编辑面积成正比。
 * 安全网：内部用 chunk 版本快照复核，矩形**外**的 chunk 若有变化就自动扩成整图
 * （计 region_widened）。注意它的粒度是 chunk（32 格）—— 如果把矩形裁到同一个
 * chunk 内部，是发现不了的。所以契约仍然是「d 必须覆盖这次提交的全部变化」。 */
int    rt_gw_note_edit(RtGroupWorld *w, const RtGridDirty *d);

/* ---- M4.6-P5（路线 B）异步 split ----
 * 与 note_edit 的分工：
 *   · note_edit 假设**派生数据已经提交完**（调用方先跑过 rt_grid_apply_dirty），
 *     只负责刷区域图；
 *   · submit_edit 把「让派生数据追上 flags」也接过来 —— 大分量的 split 会被
 *     摊到多帧（M3.7 的 RtNavSched），小编辑仍在**同一帧**完成。
 *
 * 推荐流程：
 *   rt_grid_add_building_dirty(&G, ...);   // 只改 flags（物理上立即生效）
 *   rt_gw_submit_edit(&W, &d);             // 提交；返回 RT_OK
 *   ... 每帧 rt_gw_update(&W);              // 大 split 在这里分帧推进
 *
 * 挂起期间的语义（重要）：
 *   · component 标签是旧值（split 的重标在 commit 才发生）→ **不要**在这期间
 *     读 rt_grid_component_at 做决策；rt_gw_command() 会自动 drain，安全。
 *   · 区域图 / route 不刷新（避免读到半成品），采样继续用旧 route：
 *     flags 已经更新，所以物理上不会穿墙，只是绕行要等 job 提交。
 *   · 期间可以继续提交编辑：调度器会合并 dirty；job 依赖被命中则取消并重来
 *     （stale 不丢更新，见 RtNavSched）。
 *
 * 返回：RT_OK；参数非法 RT_ERR_INVALID。 */
int    rt_gw_submit_edit(RtGroupWorld *w, const RtGridDirty *d);

/* 是否还有未完成的 split（1 = 有）。调用方可以用它来决定「本帧是否还要 update」。 */
int    rt_gw_split_pending(const RtGroupWorld *w);

/* 每帧推进的 BFS 节点预算（默认 RT_GW_SPLIT_BUDGET_DEFAULT）。
 * units<=0 表示「一帧跑完」（退回同步语义，仅用于对照/收尾）。 */
void   rt_gw_set_split_budget(RtGroupWorld *w, int units);
int    rt_gw_split_budget(const RtGroupWorld *w);

/* 关掉异步（0）/ 打开（1）。关闭后 submit_edit 等价于 apply_dirty + note_edit。 */
void   rt_gw_set_async_split(RtGroupWorld *w, int on);

#ifdef __cplusplus
}
#endif

#endif /* RT_GROUP_H */

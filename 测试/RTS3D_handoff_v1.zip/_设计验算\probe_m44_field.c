/* 临时：验证 padded BFS 的 next[] 是否真的朝目标收敛。跑完即删。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

int main(void)
{
    RtGrid G;
    rt_grid_init(&G, 256, 256, 1.0f);
    int x0 = 64, z0 = 80;
    for (int i = 0; i < 8; i++)
        for (int t = 0; t < 2; t++)
            rt_grid_set_terrain(&G, x0 + i, z0 + i + t, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);

    RtFineSolver fs; rt_fine_solver_init(&fs, RT_FINE_CELLS);
    RtFineFlow f; memset(&f, 0, sizeof(f));
    int tx = 72, tz = 80;
    int rc = rt_fineflow_build(&f, &fs, &G, tx, tz, RT_CLS_SMALL);
    printf("build rc=%d reached=%d origin=(%d,%d) target=(%d,%d)\n", rc, f.reached, f.ox, f.oz, f.tx, f.tz);

    /* 从 (64,87) 开始按 next 走 20 步，看是否收敛到 (72,80) */
    int cx = 64, cz = 87;
    printf("walk from (%d,%d):", cx, cz);
    for (int s = 0; s < 20; s++) {
        RtVec2 p;
        if (!rt_fineflow_next_pos(&f, &G, cx, cz, &p)) { printf(" [stop:%d]\n", f.next[(cz - f.oz + 1) * RT_FINE_PAD + (cx - f.ox + 1)]); break; }
        int nx = rt_grid_cell_x(&G, p.x), nz = rt_grid_cell_z(&G, p.z);
        printf(" (%d,%d)", nx, nz);
        if (nx == tx && nz == tz) { printf(" -> target\n"); break; }
        cx = nx; cz = nz;
    }

    /* 打印本地窗口的一小块（. 阻挡 / 数字方向 / T 目标） */
    printf("window slice x=60..76 z=78..90:\n");
    for (int z = 78; z <= 90; z++) {
        printf("  z=%2d ", z);
        for (int x = 60; x <= 76; x++) {
            if (x < f.ox || z < f.oz || x >= f.ox + f.w || z >= f.oz + f.h) { printf(" ?"); continue; }
            uint8_t d = f.next[(z - f.oz + 1) * RT_FINE_PAD + (x - f.ox + 1)];
            if (x == f.tx && z == f.tz) printf(" T");
            else if (d < 8) printf(" %d", (int)d);
            else if (d == RT_FINE_NONE) printf(" #");
            else printf(" .");
        }
        printf("\n");
    }
    return 0;
}

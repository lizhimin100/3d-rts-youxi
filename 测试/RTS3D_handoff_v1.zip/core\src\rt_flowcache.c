/* ============================================================================
 * rt_flowcache.c -- M3.6 流场缓存实现
 * ==========================================================================*/
#include "rt_flowcache.h"
#include <stdlib.h>
#include <string.h>

int rt_flowcache_init(RtFlowCache *c, int cap)
{
    if (!c || cap <= 0) return RT_ERR_INVALID;
    memset(c, 0, sizeof(*c));
    c->e = (RtFlowEntry *)calloc((size_t)cap, sizeof(RtFlowEntry));
    c->rev = (int32_t *)malloc((size_t)RT_CHUNK_N * RT_FLOW_REV_SLOTS * sizeof(int32_t));
    c->rev_n = (uint16_t *)calloc((size_t)RT_CHUNK_N, sizeof(uint16_t));
    if (!c->e || !c->rev || !c->rev_n) { rt_flowcache_destroy(c); return RT_ERR_CAPACITY; }
    for (int i = 0; i < RT_CHUNK_N * RT_FLOW_REV_SLOTS; i++) c->rev[i] = -1;
    c->cap = cap;
    return RT_OK;
}

void rt_flowcache_destroy(RtFlowCache *c)
{
    if (!c) return;
    free(c->e);      c->e = NULL;
    free(c->rev);    c->rev = NULL;
    free(c->rev_n);  c->rev_n = NULL;
    c->cap = c->count = 0;
}

static void rev_add(RtFlowCache *c, int32_t idx, const uint32_t *mask)
{
    for (int ch = 0; ch < RT_CHUNK_N; ch++) {
        if (!(mask[ch >> 5] & (1u << (ch & 31)))) continue;
        if (c->rev_n[ch] >= RT_FLOW_REV_SLOTS) { c->rev_overflow++; continue; }
        c->rev[(size_t)ch * RT_FLOW_REV_SLOTS + c->rev_n[ch]++] = idx;
    }
}

static void rev_remove(RtFlowCache *c, int32_t idx, const uint32_t *mask)
{
    for (int ch = 0; ch < RT_CHUNK_N; ch++) {
        if (!(mask[ch >> 5] & (1u << (ch & 31)))) continue;
        int32_t *base = &c->rev[(size_t)ch * RT_FLOW_REV_SLOTS];
        for (int k = 0; k < c->rev_n[ch]; k++) {
            if (base[k] != idx) continue;
            base[k] = base[c->rev_n[ch] - 1];
            c->rev_n[ch]--;
            break;
        }
    }
}

int rt_flowcache_put(RtFlowCache *c, uint32_t id, const uint32_t *mask,
                     uint8_t movement_class, uint8_t clearance_class,
                     const RtGrid *g, uint32_t bytes)
{
    if (!c || !mask || !g) return -1;

    /* 同 id 覆盖（重建） */
    int idx = -1;
    for (int i = 0; i < c->count; i++) {
        if (c->e[i].id == id) { idx = i; rev_remove(c, i, c->e[i].mask); break; }
    }
    if (idx < 0) {
        if (c->count >= c->cap) return -1;
        idx = c->count++;
    }

    RtFlowEntry *e = &c->e[idx];
    memset(e, 0, sizeof(*e));
    e->id = id;
    e->state = RT_FLOW_VALID;
    e->movement_class = movement_class;
    e->clearance_class = clearance_class;
    e->label_epoch = g->label_epoch;
    e->nav_epoch = g->nav_epoch;
    e->bytes = bytes;
    memcpy(e->mask, mask, sizeof(e->mask));
    rev_add(c, idx, mask);
    return idx;
}

int rt_flowcache_get(RtFlowCache *c, uint32_t id, uint32_t frame)
{
    if (!c) return -1;
    for (int i = 0; i < c->count; i++) {
        if (c->e[i].id != id) continue;
        if (c->e[i].state != RT_FLOW_VALID) { c->stat_miss++; return -1; }
        c->e[i].last_used = frame;
        c->stat_hit++;
        return i;
    }
    c->stat_miss++;
    return -1;
}

int rt_flowcache_finish_build(RtFlowCache *c, int idx, const RtGrid *g)
{
    if (!c || !g || idx < 0 || idx >= c->count) return 0;
    RtFlowEntry *e = &c->e[idx];
    /* §三十三：构建期间地图变了 -> 不许标 VALID */
    if (e->label_epoch != g->label_epoch || e->nav_epoch != g->nav_epoch) {
        e->state = RT_FLOW_STALE;
        c->stat_build_rejected++;
        return 0;
    }
    e->state = RT_FLOW_VALID;
    return 1;
}

int rt_flowcache_invalidate_scan(RtFlowCache *c, const uint32_t *dirty_mask)
{
    if (!c || !dirty_mask) return 0;
    int n = 0;
    for (int i = 0; i < c->count; i++) {
        if (c->e[i].state != RT_FLOW_VALID) continue;
        if (!rt_grid_mask_intersect(c->e[i].mask, dirty_mask)) continue;
        c->e[i].state = RT_FLOW_STALE;
        n++;
    }
    c->stat_invalidated += (uint32_t)n;
    return n;
}

int rt_flowcache_invalidate_index(RtFlowCache *c, const uint32_t *dirty_mask)
{
    if (!c || !dirty_mask) return 0;
    int n = 0;
    for (int ch = 0; ch < RT_CHUNK_N; ch++) {
        if (!(dirty_mask[ch >> 5] & (1u << (ch & 31)))) continue;
        int cnt = c->rev_n[ch];
        int32_t *base = &c->rev[(size_t)ch * RT_FLOW_REV_SLOTS];
        for (int k = 0; k < cnt; k++) {
            int idx = base[k];
            if (idx < 0 || idx >= c->count) continue;
            if (c->e[idx].state != RT_FLOW_VALID) continue;
            c->e[idx].state = RT_FLOW_STALE;
            n++;
        }
    }
    /* 反向索引溢出过的 chunk 可能漏（保守：把溢出计数暴露给调用方，
     * 生产策略是溢出时对该 chunk 回退到全扫）。这里按语义补齐。 */
    if (c->rev_overflow) {
        for (int i = 0; i < c->count; i++) {
            if (c->e[i].state != RT_FLOW_VALID) continue;
            if (!rt_grid_mask_intersect(c->e[i].mask, dirty_mask)) continue;
            c->e[i].state = RT_FLOW_STALE;
            n++;
        }
    }
    c->stat_invalidated += (uint32_t)n;
    return n;
}

int rt_flowcache_invalidate_epoch(RtFlowCache *c, const RtGrid *g)
{
    if (!c || !g) return 0;
    int n = 0;
    for (int i = 0; i < c->count; i++) {
        if (c->e[i].state == RT_FLOW_EMPTY) continue;
        if (c->e[i].label_epoch == g->label_epoch) continue;
        if (c->e[i].state == RT_FLOW_VALID) { c->e[i].state = RT_FLOW_STALE; n++; }
    }
    c->stat_invalidated += (uint32_t)n;
    return n;
}

int rt_flowcache_count_state(const RtFlowCache *c, int state)
{
    if (!c) return 0;
    int n = 0;
    for (int i = 0; i < c->count; i++) if (c->e[i].state == state) n++;
    return n;
}

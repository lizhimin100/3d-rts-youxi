/* ============================================================================
 * probe_m17_ablate.c -- 墙角蹭墙（M17）的 A/B：真导航流水线 + 1000 人 12 格门
 *
 * 为什么要另起一个探针：M13 T5 的「1000 人过门 185.5 -> 171.5 s」是上一轮的
 * 单点结果，而基座层（rt_local 的墙体约束）这一轮变了。按铁律 6，A/B 必须
 * 同机同会话，所以这里把两种基座跑在同一个进程里。
 *
 * 场景照抄 test_m13 T5：
 *   256² 开阔地，x=128 一道竖墙，z∈[122,133] 留 12 格门；1000 个 1 m 单位从
 *   (30,90) 出发去 (210,128)，真导航（aim 来自 rt_gw_sample）+ 规划层。
 *
 * 编译：
 *   zig cc -O2 -std=c11 -Icore/include core/src/*.c _设计验算/probe_m17_ablate.c \
 *       -o probe_m17_ablate.exe
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_stuck.h"
#include "rt_yield.h"
#include "rt_plan.h"
#include "rt_region.h"
#include "rt_group.h"
#include "rt_unit.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

#define MAXA 1100
#define GW 256
#define GH 256

static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;
static RtStuckCtx SC;
static RtYieldCtx YC;
static RtPlanCtx PL;
static RtStuckHooks HK;
static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static RtUnitId IDS[MAXA];
static uint8_t DONE[MAXA];
static RtVec2 AIM[MAXA], GOAL[MAXA];
static int N = 0;

static void world_reset(void)
{
    rt_grid_destroy(&G);
    rt_grid_init(&G, GW, GH, 1.0f);
}

static void world_build(void)
{
    rt_grid_rebuild_all(&G);
    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
    rt_local_destroy(&LC);
    rt_local_init(&LC, (float)GW, (float)GH, MAXA, 4.5f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);
    rt_stuck_destroy(&SC);
    rt_stuck_init(&SC, MAXA, NULL);
    rt_yield_destroy(&YC);
    rt_yield_init(&YC, MAXA, NULL, &G);
    rt_plan_destroy(&PL);
    rt_plan_init(&PL, MAXA, NULL);
    memset(&HK, 0, sizeof(HK));
    HK.local_repath = rt_plan_hook;
    HK.ud = &PL;
    N = 0;
}

static void wall_vertical(int wx, int gap_z0, int gap_z1)
{
    for (int z = 0; z < GH; z++) {
        if (z >= gap_z0 && z <= gap_z1) continue;
        rt_grid_set_terrain(&G, wx, z, RT_CELL_BLOCKED_TERRAIN, 1);
    }
}

static void spawn(int n, float x0, float z0, int cols, float pitch)
{
    N = 0;
    for (int i = 0; i < n; i++) {
        float x = x0 + (float)(i % cols) * pitch;
        float z = z0 + (float)(i / cols) * pitch;
        RtUnitId id = rt_units_spawn(&US, rt_v3(x, 0.f, z), RT_FP_SMALL);
        if (id == RT_UNIT_ID_NONE) break;
        IDS[N] = id;
        DONE[N] = 0;
        memset(&AG[N], 0, sizeof(AG[N]));
        AG[N].pos = rt_v2(x, z);
        AG[N].radius = 0.5f;
        AG[N].max_speed = 2.0f;
        AG[N].fp = 1.0f;
        AG[N].share = 0.5f;
        AG[N].inv_mass = 1.f;
        N++;
    }
}

typedef struct {
    int arrived;
    int frames;
    float min_dist;
    float t_arrive_s;   /* 最后一个到的时刻 */
    uint32_t perm, episodes;
    uint32_t escape_cnt, denied;
    uint32_t lvl[7];
    double mean_ms;
} Res;

static Res run(const char *name, int use_plan, int use_nav, RtVec2 goal,
               int frames_max, float arrive_r)
{
    Res r;
    memset(&r, 0, sizeof(r));
    const float dt = 1.f / 30.f;
    const float LOOKAHEAD = 8.0f;

    for (int i = 0; i < N; i++) {
        AIM[i] = goal; GOAL[i] = goal;
        rt_plan_reset(&PL, i);
        rt_stuck_reset(&SC, i);
    }
    if (use_nav) (void)rt_gw_command(&W, &US, IDS, N, goal, 0, RT_CLS_SMALL, 1);

    double sum = 0;
    int last_arrive = 0;
    r.min_dist = 1e30f;
    for (int s = 0; s < frames_max; s++) {
        r.frames = s;
        double t0 = now_ms();

        for (int i = 0; i < N; i++) {
            if (DONE[i] || AG[i].inv_mass <= 0.f) { if (DONE[i]) AG[i].pref_vel = rt_v2(0.f, 0.f); continue; }
            RtVec2 aim = goal;
            if (use_nav) {
                RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, IDS[i]);
                int gi = (int)ch->group[rt_unit_slot_index(IDS[i])] - 1;
                if (gi >= 0) {
                    RtVec2 tgt;
                    if (rt_gw_sample(&W, gi, AG[i].pos, &tgt) == RT_OK) aim = tgt;
                }
            } else {
                RtVec2 d = rt_v2_sub(goal, AG[i].pos);
                float l = rt_v2_len(d);
                if (l > LOOKAHEAD) aim = rt_v2_add(AG[i].pos, rt_v2_mul(d, LOOKAHEAD / l));
            }
            AIM[i] = aim;
            RtVec2 d = rt_v2_sub(aim, AG[i].pos);
            float l = rt_v2_len(d);
            AG[i].pref_vel = (l > 1e-3f) ? rt_v2_mul(d, 2.0f / l) : rt_v2(0.f, 0.f);
        }

        if (use_plan) (void)rt_plan_step(&PL, AG, N, AIM, GOAL, &G, dt);
        rt_stuck_step(&SC, AG, N, &G, dt, &HK);
        rt_yield_step(&YC, AG, N, &G, dt, NULL, NULL);
        (void)rt_local_step(&LC, AG, N, &G, dt);
        (void)rt_gw_update(&W);
        sum += now_ms() - t0;

        for (int i = 0; i < N; i++) {
            if (DONE[i]) continue;
            float d = rt_v2_dist(AG[i].pos, goal);
            if (d < r.min_dist) r.min_dist = d;
            if (d <= arrive_r) { DONE[i] = 1; r.arrived++; last_arrive = s; }
        }
        if (r.arrived >= N) break;
    }

    r.frames = last_arrive;
    r.t_arrive_s = (float)last_arrive / 30.f;
    r.perm = SC.st.permanent_stuck;
    r.episodes = SC.st.episodes;
    r.escape_cnt = LC.stat_wall_escape;
    r.denied = LC.stat_escape_denied;
    for (int k = 0; k < 7; k++) r.lvl[k] = SC.st.level_fires[k];
    r.mean_ms = sum / (double)(r.frames + 1);

    printf("  %-34s arrived=%4d/%-4d frames=%5d(%6.1f s) min_dist=%.2f perm=%-3u "
           "escape=%-6u denied=%-6u %.3f ms/frame\n",
           name, r.arrived, N, r.frames, (double)r.t_arrive_s, r.min_dist, r.perm,
           r.escape_cnt, r.denied, r.mean_ms);
    printf("  %-34s L1..L6=%u/%u/%u/%u/%u/%u  episodes=%u\n", "",
           r.lvl[1], r.lvl[2], r.lvl[3], r.lvl[4], r.lvl[5], r.lvl[6], r.episodes);
    return r;
}

int main(void)
{
    timer_init();
    printf("=== probe M17 ablate: 墙角蹭墙 A/B（1000 人 12 格门，真导航 + 规划层）===\n");

    Res a[2], b[2], c[2];
    for (int k = 0; k < 2; k++) {
        const int esc = k;
        const char *tag = esc ? "escape ON " : "escape OFF";

        /* --- 场景 1：1000 人过 12 格门 --- */
        world_reset();
        wall_vertical(128, 122, 133);
        world_build();
        LC.wall_escape = esc;
        spawn(1000, 30.f, 90.f, 25, 1.6f);
        char nm[96];
        snprintf(nm, sizeof nm, "gate1000 %s + planner", tag);
        a[k] = run(nm, 1, 1, rt_v2(210.f, 128.f), 6000, 20.0f);

        /* --- 场景 2：开阔地 200（蹭墙不该被触发） --- */
        world_reset();
        world_build();
        LC.wall_escape = esc;
        spawn(200, 40.f, 100.f, 20, 1.6f);
        snprintf(nm, sizeof nm, "open200  %s + planner", tag);
        b[k] = run(nm, 1, 0, rt_v2(200.f, 128.f), 3000, 20.0f);

        /* --- 场景 3：4×4 单位挤门（大 footprint 更容易卡角） --- */
        world_reset();
        wall_vertical(128, 120, 135);
        world_build();
        LC.wall_escape = esc;
        spawn(120, 60.f, 90.f, 12, 4.6f);
        for (int i = 0; i < N; i++) {
            AG[i].radius = 2.0f;
            AG[i].fp = 4.0f;
            AG[i].max_speed = 1.2f;
        }
        snprintf(nm, sizeof nm, "big4x4x120 %s + planner", tag);
        c[k] = run(nm, 1, 0, rt_v2(200.f, 128.f), 9000, 6.0f);
    }

    printf("\n=== 汇总（同机同会话）===\n");
    printf("  %-26s %-10s %-10s %-8s %-12s\n", "场景", "escape OFF", "escape ON", "变化", "备注");
    printf("  %-26s %7.1f s %8.1f s %7.1f%%   perm %u -> %u\n", "1000 人 12 格门",
           (double)a[0].t_arrive_s, (double)a[1].t_arrive_s,
           100.0 * ((double)a[1].t_arrive_s / (double)a[0].t_arrive_s - 1.0),
           a[0].perm, a[1].perm);
    printf("  %-26s %7.1f s %8.1f s %7.1f%%   perm %u -> %u\n", "开阔地 200",
           (double)b[0].t_arrive_s, (double)b[1].t_arrive_s,
           100.0 * ((double)b[1].t_arrive_s / (double)b[0].t_arrive_s - 1.0),
           b[0].perm, b[1].perm);
    printf("  %-26s %7.1f s %8.1f s %7.1f%%   perm %u -> %u\n", "4x4 x120 门",
           (double)c[0].t_arrive_s, (double)c[1].t_arrive_s,
           100.0 * ((double)c[1].t_arrive_s / (double)c[0].t_arrive_s - 1.0),
           c[0].perm, c[1].perm);
    printf("  注：到达时刻 = 最后一个单位到点；escape/denied 见上表。\n");
    return 0;
}

/* ============================================================================
 * rt_unit.h -- 单位存储（chunked SoA）
 *
 * 为什么分 chunk 而不是单一扁平 SoA：
 *   热点循环（避障/积分）逐单位顺序访问 px/pz/vx/vz/radius/state；
 *   扁平 SoA 在 1000 单位下跨步 4KB，几乎每单位一次 cache miss。
 *   chunk = 64 单位（≈ 4KB 热字段）恰好落在若干 cache line 内。
 *
 * 为什么 fp 用 uint8_t 而不是 float：
 *   footprint 只有 1/2/4 三个合法值，用枚举值存储可省 3 字节/单位，
 *   并且让「非法 fp」在写入时就被断言抓住（见 rt_units_spawn）。
 * ==========================================================================*/
#ifndef RT_UNIT_H
#define RT_UNIT_H

#include "rt_types.h"
#include "rt_math.h"
#include "rt_core.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RT_CHUNK_SHIFT 6
#define RT_CHUNK_SIZE  (1 << RT_CHUNK_SHIFT)              /* 64 */
#define RT_CHUNK_COUNT (RT_MAX_UNITS >> RT_CHUNK_SHIFT)   /* 64 */

typedef struct {
    float px[RT_CHUNK_SIZE], py[RT_CHUNK_SIZE], pz[RT_CHUNK_SIZE];
    float vx[RT_CHUNK_SIZE], vy[RT_CHUNK_SIZE], vz[RT_CHUNK_SIZE];
    float pvx[RT_CHUNK_SIZE], pvz[RT_CHUNK_SIZE];   /* preferred velocity（XZ） */
    float radius[RT_CHUNK_SIZE];                    /* ORCA 内切圆半径 = fp/2 */
    float yaw[RT_CHUNK_SIZE];
    uint8_t  fp[RT_CHUNK_SIZE];                     /* 1 / 2 / 4 */
    uint8_t  state[RT_CHUNK_SIZE];                   /* RtUnitState */
    uint8_t  group[RT_CHUNK_SIZE];                   /* 0 = 无 group */
    uint8_t  layer[RT_CHUNK_SIZE];                   /* 高度层 id */
    uint16_t gen[RT_CHUNK_SIZE];                     /* 复用代次（stale id 检测） */
    uint32_t flags[RT_CHUNK_SIZE];
} RtUnitChunk;

typedef struct {
    RtUnitChunk chunks[RT_CHUNK_COUNT];
    int16_t  next_free[RT_MAX_UNITS];
    uint8_t  alive[RT_MAX_UNITS];
    int32_t  free_head;
    int32_t  count;
    uint32_t next_gen;
    RtOverflowCounters overflow;
} RtUnitStore;

/* ---- id 编解码 ---- */
static inline int rt_unit_chunk_index(RtUnitId id) { return (int)((id - 1u) >> RT_CHUNK_SHIFT); }
static inline int rt_unit_slot_index(RtUnitId id)  { return (int)((id - 1u) & (RT_CHUNK_SIZE - 1)); }

/* ---- 生命周期 ---- */
void rt_units_init(RtUnitStore *s);

/* 出生：返回 0 表示池满（同时 overflow.unit_overflow++，不静默丢弃）。
 * fp 只接受 1/2/4；非法值返回 0（RT_ERR_INVALID 语义由调用方断言）。 */
RtUnitId rt_units_spawn(RtUnitStore *s, RtVec3 pos, uint8_t fp);
int      rt_units_despawn(RtUnitStore *s, RtUnitId id);

static inline int rt_units_alive(const RtUnitStore *s, RtUnitId id)
{
    if (!s || id == RT_UNIT_ID_NONE || id > RT_MAX_UNITS) return 0;
    return s->alive[id - 1u] != 0;
}

static inline RtUnitChunk *rt_units_chunk_mut(RtUnitStore *s, RtUnitId id)
{
    return &s->chunks[(size_t)rt_unit_chunk_index(id)];
}

static inline const RtUnitChunk *rt_units_chunk_c(const RtUnitStore *s, RtUnitId id)
{
    return &s->chunks[(size_t)rt_unit_chunk_index(id)];
}

/* 便捷访问器（热点路径可绕开，直接用 chunk 指针） */
static inline RtVec3 rt_units_pos(const RtUnitStore *s, RtUnitId id)
{
    const RtUnitChunk *c = rt_units_chunk_c(s, id);
    int k = rt_unit_slot_index(id);
    return rt_v3(c->px[k], c->py[k], c->pz[k]);
}

static inline void rt_units_set_pos(RtUnitStore *s, RtUnitId id, RtVec3 p)
{
    RtUnitChunk *c = rt_units_chunk_mut(s, id);
    int k = rt_unit_slot_index(id);
    c->px[k] = p.x; c->py[k] = p.y; c->pz[k] = p.z;
}

static inline uint8_t rt_units_fp(const RtUnitStore *s, RtUnitId id)
{
    return rt_units_chunk_c(s, id)->fp[rt_unit_slot_index(id)];
}

/* OBB（用于与网格做精确阻挡判定）；yaw 取单位当前朝向 */
static inline RtObb2 rt_units_obb(const RtUnitStore *s, RtUnitId id)
{
    const RtUnitChunk *c = rt_units_chunk_c(s, id);
    int k = rt_unit_slot_index(id);
    RtObb2 o;
    o.center = rt_v2(c->px[k], c->pz[k]);
    o.half = rt_v2(c->fp[k] * 0.5f, c->fp[k] * 0.5f);
    o.cos_a = cosf(c->yaw[k]);
    o.sin_a = sinf(c->yaw[k]);
    return o;
}

/* 遍历存活单位（返回写入的 id 列表长度；out 容量需 >= count） */
int rt_units_list_alive(const RtUnitStore *s, RtUnitId *out, int max_out);

#ifdef __cplusplus
}
#endif

#endif /* RT_UNIT_H */

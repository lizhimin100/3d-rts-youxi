/* ============================================================================
 * rt_navsched.h -- M3.7 导航更新调度器（编辑合并 / 取消 / 背压）
 *
 * 语义（任务书 §三十四~§四十）：
 *   - **Live Occupancy 是唯一真相**：编辑一到就写进 flags；调度器只负责让
 *     "派生数据"追上它，永远不重放历史编辑。
 *   - **编辑合并**：所有待处理编辑合并成一个 dirty（bbox + 掩码并集）。
 *     因此队列长度恒为 1，天然有背压，不存在无限增长。
 *   - **取消条件**：Job 的依赖 chunk 被新编辑命中（依赖级判定，不是全局 revision）。
 *     无关区域的编辑不会取消它（§C5）。
 *   - **stale 不丢更新**：Job 被取消/作废时，pending 仍然保留，下一 tick 从
 *     当前 Live 状态重新求解（§三十九）。
 * ==========================================================================*/
#ifndef RT_NAVSCHED_H
#define RT_NAVSCHED_H

#include "rt_types.h"
#include "rt_grid.h"
#include "rt_navjob.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    RtGrid    *g;
    RtNavJob  *job;
    RtGridDirty pend;          /* 合并后的待处理编辑（has_pend 有效） */
    int        has_pend;
    int        pend_dirty_after_job; /* 1 = pend 里含「job 启动之后」的新编辑。
                                      * commit 时只能清掉 job 覆盖的那部分，
                                      * 否则会静默丢掉后来的编辑（C1/C5 抓到的 bug）。 */
    int        pend_age;       /* 已经等了多少 tick */

    /* 统计（M3 报告要求） */
    uint32_t stat_submit;
    uint32_t stat_immediate;   /* 同步完成（小编辑） */
    uint32_t stat_scheduled;   /* 进入 Job */
    uint32_t stat_commit;
    uint32_t stat_cancel;      /* 被新编辑取消 */
    uint32_t stat_stale;       /* commit 时被拒 */
    uint32_t stat_coalesced;   /* 被合并掉的编辑数 */
    uint32_t stat_max_pending_age;
} RtNavSched;

void rt_navsched_init(RtNavSched *s, RtGrid *g);
void rt_navsched_shutdown(RtNavSched *s);

/* 提交一次编辑（flags 已经写好，d 是它的 dirty 描述） */
int  rt_navsched_submit(RtNavSched *s, const RtGridDirty *d);

/* 推进至多 units 个工作单位；返回 1 = 当前空闲（无 job、无 pending） */
int  rt_navsched_tick(RtNavSched *s, int units);

/* 跑到空闲（测试 / 收尾用） */
void rt_navsched_drain(RtNavSched *s);

#ifdef __cplusplus
}
#endif

#endif /* RT_NAVSCHED_H */

/* ============================================================================
 * rt_chain.h -- 通道链：多条相接的窄通道共享一个 owner（M15，跨通道协调）
 *
 * 问题（M14 §4.3 留下来的）：
 *   一条 L 形窄走廊会被行程长度判据切成**两段直走廊**（拐角格两个方向都长，
 *   本身不算窄）。两段各自注册、各自仲裁，就会出现：
 *     A 队拿到第一段、B 队拿到第二段 -> 两队在拐角互相等对方的那一段 -> 互锁。
 *   两个 owner 各自都在「合法等待」，任何单段层面的规则（TTL / stall）都只能
 *   把所有权收回来再发出去，然后立刻又形成同样的局面 —— 吞吐接近 0。
 *
 * 做法：**把相接的通道串成一条链，链级原子仲裁**。
 *   - 申请：要么拿到链上**全部**段，要么一段都不拿（all-or-nothing）；
 *   - 释放：一次性释放全部段；
 *   - 于是「半个链在 A 手里、半个在 B 手里」这种状态**不可能出现**，
 *     死锁的前提被消掉了 —— 不是靠超时补救，是靠状态不可达。
 *
 * 这等价于经典的「按固定顺序一次性获取所有锁」，只是锁的粒度是通道段。
 *
 * 与 rt_corridor 的关系：本层不重新实现仲裁，只做**多段的原子包装**：
 *   链 owner 通过 `rt_corr_request()` 逐段取得所有权，段内的门控 / 等待区 /
 *   stall 仍然全部由 rt_corridor 负责（那一层是对的，只是粒度不够）。
 *
 * 一致性规则：段被 rt_corridor 强制释放（TTL / stall）时，链**整条释放**并计数。
 *   否则会出现「链以为自己还持有、而某一段已经空了」的隐性不一致，
 *   下一队会从那个缺口钻进去，又回到互锁。
 * ==========================================================================*/
#ifndef RT_CHAIN_H
#define RT_CHAIN_H

#include "rt_types.h"
#include "rt_corridor.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RT_CHAIN_MAX_SEGS 4
#define RT_CHAIN_MAX      16

typedef struct {
    int32_t  seg[RT_CHAIN_MAX_SEGS];   /* 段 = corridor id */
    int32_t  nseg;
    int32_t  owner;                    /* 队伍 id，-1 = 空闲 */
    int32_t  last_team;                /* 上一次拿到链的队伍（-1 = 还没有过） */
    float    want[RT_CORR_MAX_TEAMS];  /* FCFS：第一次想要的时刻 */
    float    held;                     /* owner 已连续占用时间 */
    uint32_t grants, handoffs, stalls;
} RtChain;

typedef struct {
    uint32_t acquire_calls;
    uint32_t grants;
    uint32_t partial_fail;   /* 某段被别人占 -> 整条放弃（原子性生效） */
    uint32_t seg_lost;       /* 段被 rt_corridor 强制释放 -> 整条收回 */
    uint32_t max_hold_release;
    uint32_t max_segs;
} RtChainStats;

typedef struct {
    RtChain  c[RT_CHAIN_MAX];
    int      n, cap;
    RtCorrCtx *cc;      /* 非拥有 */
    float    max_hold;  /* 整链连续占用上限（秒），<=0 关闭 */
    RtChainStats st;
} RtChainCtx;

int  rt_chain_init(RtChainCtx *x, RtCorrCtx *cc, int max_chains, float max_hold);
void rt_chain_destroy(RtChainCtx *x);

int  rt_chain_new(RtChainCtx *x);                          /* 返回链 id，-1 = 满 */
int  rt_chain_add_seg(RtChainCtx *x, int ch, int cid);     /* 返回加进去的段数 */
/* 清空所有链（保留 cc 指针与参数）。重新注册几何时用。 */
void rt_chain_clear_all(RtChainCtx *x);

/* 段 -> 链；-1 = 这个段不属于任何链（独立通道，走 rt_corr_* 老路） */
int  rt_chain_of_seg(const RtChainCtx *x, int cid);

void rt_chain_want(RtChainCtx *x, int ch, int team, float t);
void rt_chain_unwant(RtChainCtx *x, int ch, int team);

/* 原子申请：空闲时把整条链授予**最早开始等待**的那一队。
 * 返回 owner（-1 = 仍空闲 / 没人等 / 有段被别人占）。 */
int  rt_chain_acquire(RtChainCtx *x, int ch);
void rt_chain_release(RtChainCtx *x, int ch, int team);
int  rt_chain_allowed(const RtChainCtx *x, int ch, int team);

/* 每帧（在 rt_corr_tick 之后）：同步段的所有权 + 整链超时保护。 */
void rt_chain_tick(RtChainCtx *x, float dt);

#ifdef __cplusplus
}
#endif

#endif /* RT_CHAIN_H */

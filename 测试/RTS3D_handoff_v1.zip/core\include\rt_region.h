/* ============================================================================
 * rt_region.h -- 粗粒度区域图（M4.1 Global Route 的搜索空间）
 *
 * 为什么要独立的「区域」概念，而不是直接用 M3 的 32-cell chunk：
 *   - chunk 的职责是**版本粒度 / 缓存失效**（32 cell = 32 m），粒度太粗，
 *     拿它做 A* 会让走廊贴着墙，且无法区分 2 m 与 6 m 的通道。
 *   - 区域（默认 8 cell = 8 m）只服务**寻路**，与版本粒度解耦。
 *     两者的映射在 rt_route_build() 里做（走廊 -> 依赖 chunk 掩码）。
 *
 * 区域图保存的是「按 clearance 类别量化后的可通行性」：
 *   cls 0 = 半径 0.5 m（footprint 1 m）
 *   cls 1 = 半径 1.0 m（2 m）
 *   cls 2 = 半径 2.0 m（4 m）
 *   cls 3 = 半径 4.0 m（8 m）
 * 一个区域对某类别可通行 <=> 区域内存在 clearance >= 半径 的格。
 * 注意：这只是**必要条件**（区域里可能有宽格但不连通），
 * 所以 A* 的每条边还要做**边界格对检查**（见 rt_region_edge_ok），
 * 细粒度的最终正确性由 M4.4 的 fine flow 负责。
 * ==========================================================================*/
#ifndef RT_REGION_H
#define RT_REGION_H

#include "rt_types.h"
#include "rt_grid.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RT_CLEAR_CLASSES 4
#define RT_MAX_REGIONS   ((RT_GRID_MAX_DIM / 4) * (RT_GRID_MAX_DIM / 4))  /* px=4 时的上界 */

typedef enum {
    RT_CLS_SMALL  = 0,   /* 半径 0.50 m */
    RT_CLS_MEDIUM = 1,   /* 半径 1.00 m */
    RT_CLS_LARGE  = 2,   /* 半径 2.00 m */
    RT_CLS_HUGE   = 3    /* 半径 4.00 m */
} RtClearClass;

/* footprint 直径 -> clearance 类别（量化，不是每尺寸一套导航层） */
int   rt_clear_class_for_diameter(float meters);
/* 该类别的半径（米） */
float rt_clear_radius_m(int cls);

typedef struct {
    RtGrid *g;            /* 非拥有 */
    int     px;           /* 每边多少 cell（默认 8） */
    int     rw, rh;       /* 区域数 */
    uint8_t *pass;        /* [region * 4 + cls] 1 = 该类别可通行 */
    uint16_t *maxclear;   /* 区域内最大 clearance（0.01 m） */
    int32_t *comp;        /* 区域代表的连通分量 id（= anchor 格的分量） */
    uint8_t *mixed;       /* 1 = 区域内出现多个分量（粗路由不可信，只做诊断） */
    int16_t *anchor_x;    /* 区域内「clearance 最大、离中心最近」的可走格（采样锚点） */
    int16_t *anchor_z;
    uint32_t built_epoch; /* 建图时的 g->nav_epoch */

    /* ---- M4.6-P2：增量刷新的依据 ----
     * 区域聚合量（maxclear/anchor/pass）只依赖本区域内格子的 flags+clearance；
     * comp/mixed 还依赖全图的 component 标签，所以：
     *   built_label_epoch   : id 空间重编号（GC）-> 必须整图重建
     *   built_active_comps  : merge/split 会**重标号**（可能发生在 dirty 矩形之外）
     *                         且不动 label_epoch -> 变化时对全部区域重指 comp + 重扫 mixed
     *   chunk_snap[]        : 上次刷新时的 g->chunk_ver。若「有 chunk 版本变了，但它的格子
     *                         不在本次矩形内」，说明调用方给的 dirty 不完整（或 grid 内部
     *                         降级成了全量）—— 自动扩成整图重建。正确性优先于省时间。 */
    uint32_t built_label_epoch;
    int32_t  built_active_comps;
    uint32_t *chunk_snap; /* [RT_CHUNK_N] */
    uint8_t  last_full_reason; /* 0 增量成功 / 1 首次或 label 变化 / 2 安全网扩成全量 */

    /* 诊断计数（只增） */
    uint32_t refresh_calls;
    uint32_t refresh_regions;   /* 累计重算的区域数 */
    uint32_t refresh_full;      /* 退化为整图的次数 */
    uint32_t refresh_widened;   /* 其中因为「矩形外有 chunk 变化」而扩成全量的次数 */
    uint32_t mixed_rescans;     /* 分量重标号后 mixed 全量重扫次数 */

    size_t   bytes;
} RtRegionMap;

int  rt_region_build(RtRegionMap *m, RtGrid *g, int px);
void rt_region_destroy(RtRegionMap *m);
/* 若 grid 的提交版本变了就重建整图（M4.1 语义，保留为「安全但慢」的兜底） */
int  rt_region_refresh(RtRegionMap *m);

/* M4.6-P2：增量刷新。只重算与 [x0,z0,x1,z1]（格坐标，含端点）相交的区域。
 *
 * 契约：矩形必须是**这次提交**造成的全部变化范围（clearance 的 dirty.cx0..cx1 与
 * 编辑范围 x0..x1 的并集）。内部另有 chunk 版本快照做二级复核：若发现矩形**外**
 * 有 chunk 变化，自动扩成整图重建（last_full_reason = 2 并计数）。复核粒度是
 * chunk = 32 格，只能抓住「跨 chunk 的遗漏」，不能替代正确的 dirty。
 *
 * 返回：本次重算的区域数；== rw*rh 表示实际执行的是整图重建。
 *       < 0 = RT_ERR_INVALID / RT_ERR_CAPACITY。
 * 复杂度：O(矩形内区域数 × px²)；带重标号时额外 O(区域数) 重指 comp，
 *         分量数变化时再 O(w*h) 重扫 mixed（只在 merge/split 后发生一次）。 */
int  rt_region_refresh_rect(RtRegionMap *m, int x0, int z0, int x1, int z1);

static inline int rt_region_index(const RtRegionMap *m, int rx, int rz)
{
    return rz * m->rw + rx;
}
int rt_region_of_cell(const RtRegionMap *m, int x, int z);
int rt_region_of_world(const RtRegionMap *m, float wx, float wz);
RtVec2 rt_region_center(const RtRegionMap *m, int region);
/* 采样锚点（区域内最宽敞的格）。返回世界坐标；无可走格返回区域中心。 */
RtVec2 rt_region_anchor(const RtRegionMap *m, int region);

static inline int rt_region_passable(const RtRegionMap *m, int region, int cls)
{
    if (!m || region < 0 || region >= m->rw * m->rh) return 0;
    return m->pass[(size_t)region * RT_CLEAR_CLASSES + cls];
}

/* 边界连通性：两区域相邻，且跨界存在一对「都可走且 clearance >= 半径」的格 */
int rt_region_edge_ok(const RtRegionMap *m, int r1, int r2, int cls);

/* 两个相邻区域之间的「门户」：跨界格对里 min(clearance) 最大的那一对的中点。
 * 返回 1 = 找到。走廊用门户点作为 waypoint，比区域中心更贴真实通道。 */
int rt_region_portal(const RtRegionMap *m, int r1, int r2, int cls, RtVec2 *out);

/* 从某点找最近的、该类别可通行的区域（用于起点/终点吸附） */
int rt_region_nearest_passable(const RtRegionMap *m, int region, int cls, int max_ring);

#ifdef __cplusplus
}
#endif

#endif /* RT_REGION_H */

/* ============================================================================
 * rt_group.c -- MovementGroup / 共享 Global Route
 * ==========================================================================*/
#include "rt_group.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* M4.6-P5：rt_gw_command 在 rt_gw_update 之前就要用到（drain 后刷区域图） */
static void gw_pending_flush(RtGroupWorld *w);

const char *rt_group_state_name(RtGroupState s){
    switch (s) {
    case RT_GROUP_NAV_PENDING:   return "NAV_PENDING";
    case RT_GROUP_NAV_READY:     return "NAV_READY";
    case RT_GROUP_MOVING:        return "MOVING";
    case RT_GROUP_REPATH_PENDING:return "REPATH_PENDING";
    case RT_GROUP_ARRIVED:       return "ARRIVED";
    case RT_GROUP_UNREACHABLE:   return "UNREACHABLE";
    case RT_GROUP_CANCELLED:     return "CANCELLED";
    }
    return "?";
}

int rt_gw_init(RtGroupWorld *w, RtGrid *g, RtRegionMap *map)
{
    if (!w || !g || !map) return RT_ERR_INVALID;
    memset(w, 0, sizeof(*w));
    w->g = g;
    w->map = map;
    /* 调度器先初始化：rt_gw_destroy 在任何失败路径上都会 shutdown 它 */
    rt_navsched_init(&w->sched, g);
    w->async_split = 1;
    w->split_budget = RT_GW_SPLIT_BUDGET_DEFAULT;
    int max_nodes = map->rw * map->rh;
    if (max_nodes <= 0) return RT_ERR_INVALID;
    int rc = rt_route_solver_init(&w->solver, max_nodes);
    if (rc != RT_OK) return rc;

    /* M4.2：固定容量缓存，一次性分配（运行期零 malloc、零碎片） */
    w->route_cache = (RtRouteCacheSlot *)calloc(RT_ROUTE_CACHE_CAP, sizeof(RtRouteCacheSlot));
    w->goal_cache  = (RtGoalCacheSlot  *)calloc(RT_GOAL_CACHE_CAP,  sizeof(RtGoalCacheSlot));
    w->path_scratch = (int32_t *)malloc((size_t)max_nodes * sizeof(int32_t));
    if (!w->route_cache || !w->goal_cache || !w->path_scratch) {
        rt_gw_destroy(w);
        return RT_ERR_CAPACITY;
    }
    rc = rt_goalflow_solver_init(&w->flow_solver, max_nodes);
    if (rc != RT_OK) { rt_gw_destroy(w); return rc; }
    w->flow_threshold = 0;

    /* M4.4-B：fine flow 的 BFS 工作区（固定 24×24，一次性分配，运行期零 malloc） */
    rc = rt_fine_solver_init(&w->fine_solver, RT_FINE_CELLS);
    if (rc != RT_OK) { rt_gw_destroy(w); return rc; }
    w->fine_enabled = 1;
    w->fine_seq = 0;
    w->fine_budget = 1;              /* M4.6-P1：默认每帧最多建 1 个场 */
    w->fine_budget_left = 1;
    return RT_OK;
}

/* 释放一个组槽位拥有的**全部**内存（成员表 / 每条 route 的走廊 / 逐段索引）。
 * M4.5 新增：组可以被真正释放（成员被别的命令全部拿走），
 * 压缩数组时必须能把「空洞」的缓冲还回去，否则每释放一个组就漏一份内存。 */
static void group_free_buffers(RtMoveGroup *g)
{
    if (!g) return;
    free(g->members);
    free(g->src_region);
    g->members = NULL;
    g->src_region = NULL;
    for (int i = 0; i < RT_GROUP_ROUTES_MAX; i++) {
        rt_route_free(&g->routes[i].route);
        free(g->routes[i].seg_block);
        free(g->routes[i].seg_invlen);
        g->routes[i].seg_block = NULL;
        g->routes[i].seg_invlen = NULL;
        g->routes[i].seg_cap = 0;
        g->routes[i].seg_n = 0;
        g->routes[i].route.n = 0;
    }
    g->cap = 0;
    g->count = 0;
    g->route_count = 0;
    g->slot_n = 0;
    g->id = 0;
}

void rt_gw_destroy(RtGroupWorld *w)
{
    if (!w) return;
    /* 未完成的 split Job：取消（Active 数据不动）+ 释放。
     * 若 grid 已先被销毁，clear_staging 会自行跳过（见 rt_navjob.c）。 */
    rt_navsched_shutdown(&w->sched);
    w->split_pending = 0;
    w->pend_valid = 0;
    /* 槽位可能被上一条命令用过：只释放「必然会重建」的部分，
     * members / src_region / routes 的缓冲区保留，避免每条命令重新 malloc。 */
    for (int i = 0; i < RT_MAX_GROUPS; i++) group_free_buffers(&w->groups[i]);
    w->group_count = 0;

    if (w->route_cache) {
        for (int i = 0; i < RT_ROUTE_CACHE_CAP; i++)
            if (w->route_cache[i].state == 1) rt_route_free(&w->route_cache[i].route);
        free(w->route_cache);
        w->route_cache = NULL;
    }
    free(w->goal_cache);
    w->goal_cache = NULL;
    w->route_cache_used = 0;
    w->route_cache_tomb = 0;
    w->goal_cache_used = 0;

    for (int i = 0; i < RT_GOALFLOW_SLOTS; i++) rt_goalflow_free(&w->flows[i]);
    rt_goalflow_solver_destroy(&w->flow_solver);
    free(w->path_scratch);
    w->path_scratch = NULL;

    for (int i = 0; i < RT_FINE_SLOTS; i++) rt_fine_free(&w->fine[i]);
    rt_fine_solver_destroy(&w->fine_solver);
    w->fine_seq = 0;
    w->fine_enabled = 0;
    w->fine_budget = 0;
    w->fine_budget_left = 0;

    rt_route_solver_destroy(&w->solver);
    w->g = NULL;
    w->map = NULL;
}

/* ---------------------------------------------------------------------------
 * M4.2 Global Route Cache
 *
 * key = (source region, component, goal region, clearance, movement)
 *   - component 必须进 key：同一 region 可能横跨两个连通分量（RtRegionMap.mixed），
 *     只按 region 比较会让两个分量错误共享同一条走廊。
 *   - 依赖不进 key，命中后校验：key 命中但依赖失效 => INVALID（与 MISS 分开计数）。
 *   - 开放寻址 + tombstone + 固定容量；装载到 3/4 淘汰 LRU。
 *   - 插入时若已有同 key（拓扑修复后重建），就地替换，不产生重复条目。
 * ------------------------------------------------------------------------- */
static uint32_t rt_hash5(int32_t a, int32_t b, int32_t c, int32_t d, int32_t e)
{
    uint32_t h = 2166136261u;             /* FNV-1a，确定性、无平台依赖 */
    const uint32_t k[5] = { (uint32_t)a, (uint32_t)b, (uint32_t)c, (uint32_t)d, (uint32_t)e };
    for (int i = 0; i < 5; i++) {
        h ^= k[i];
        h *= 16777619u;
        h ^= h >> 13;
    }
    return h;
}

static int route_key_eq(const RtRouteCacheSlot *s, int32_t start, int32_t goal,
                        int cls, int mcls, int32_t comp)
{
    return s->start == start && s->goal == goal && s->component == comp &&
           s->cls == (uint8_t)cls && s->mcls == (uint8_t)mcls;
}


static void copy_route(RtRoute *dst, const RtRoute *src)
{
    dst->n = 0;
    if (dst->cap < src->n) {
        free(dst->regions);
        free(dst->portal);                       /* M4.1 漏了这一行：portal 会变成悬空/NULL */
        dst->regions = (int32_t *)malloc((size_t)src->n * sizeof(int32_t));
        dst->portal  = (RtVec2  *)malloc((size_t)src->n * sizeof(RtVec2));
        dst->cap = (dst->regions && dst->portal) ? src->n : 0;
        if (!dst->regions || !dst->portal) return;
    }
    if (!dst->regions || !dst->portal) return;
    memcpy(dst->regions, src->regions, (size_t)src->n * sizeof(int32_t));
    memcpy(dst->portal,  src->portal,  (size_t)src->n * sizeof(RtVec2));
    dst->n = src->n;
    dst->start_region = src->start_region;
    dst->goal_region = src->goal_region;
    dst->clearance_class = src->clearance_class;
    dst->movement_class = src->movement_class;
    dst->radius_m = src->radius_m;
    dst->dep_n = src->dep_n;
    memcpy(dst->dep_chunks, src->dep_chunks, sizeof(dst->dep_chunks));
    memcpy(dst->dep_vers, src->dep_vers, sizeof(dst->dep_vers));
    dst->dep_overflow = src->dep_overflow;
    dst->label_epoch = src->label_epoch;
    dst->expanded = src->expanded;
    dst->cost = src->cost;
}

/* ============================ M4.2 Route Cache ============================ */
/* 淘汰最久未用的 used 槽（确定性：并列取最小下标），返回槽位或 -1 */
static int route_cache_evict_lru(RtGroupWorld *w)
{
    int best = -1;
    uint32_t oldest = 0xFFFFFFFFu;
    for (int i = 0; i < RT_ROUTE_CACHE_CAP; i++) {
        RtRouteCacheSlot *s = &w->route_cache[i];
        if (s->state != 1) continue;
        if (s->last_used < oldest) { oldest = s->last_used; best = i; }
    }
    if (best >= 0) {
        rt_route_free(&w->route_cache[best].route);
        w->route_cache[best].state = 2;
        w->route_cache_used--;
        w->route_cache_tomb++;
        w->stats.route_evicted++;
    }
    return best;
}

/* 查 cache：HIT / MISS（key 不存在）/ INVALID（key 在但依赖失效，已就地驱逐） */
static RtRoute *route_cache_get(RtGroupWorld *w, int32_t start, int32_t goal,
                                int cls, int mcls, int32_t comp, int *answer)
{
    *answer = RT_CACHE_MISS;
    if (!w->route_cache) { w->stats.route_cache_misses++; return NULL; }

    uint32_t h = rt_hash5(start, goal, comp, cls, mcls);
    uint32_t mask = RT_ROUTE_CACHE_CAP - 1;
    uint32_t i = h & mask;
    for (int probe = 0; probe < RT_ROUTE_CACHE_CAP; probe++) {
        RtRouteCacheSlot *s = &w->route_cache[i];
        if (s->state == 0) { w->stats.route_cache_misses++; return NULL; }
        if (s->state == 1 && s->hash == h &&
            route_key_eq(s, start, goal, cls, mcls, comp)) {
            if (rt_route_valid(&s->route, w->g)) {
                s->last_used = ++w->cache_seq;
                s->hits++;
                w->stats.route_cache_hits++;
                *answer = RT_CACHE_HIT;
                return &s->route;
            }
            /* key 命中但 dependency 失效：只让这一条失效（不是整表、也不是整组） */
            rt_route_free(&s->route);
            s->state = 2;
            w->route_cache_used--;
            w->route_cache_tomb++;
            w->stats.route_invalidated++;
            *answer = RT_CACHE_INVALID;
            return NULL;
        }
        i = (i + 1) & mask;
    }
    w->stats.route_cache_misses++;
    return NULL;
}

static void route_cache_put(RtGroupWorld *w, const RtRoute *src, int32_t comp)
{
    if (!w->route_cache) return;
    if (src->n <= 0 || src->n > RT_ROUTE_CACHE_MAX_LEN) {
        w->stats.route_cache_rejected++;      /* 超长走廊不入缓存：显式计数，不静默 */
        return;
    }

    uint32_t h = rt_hash5(src->start_region, src->goal_region, comp,
                          src->clearance_class, src->movement_class);
    uint32_t mask = RT_ROUTE_CACHE_CAP - 1;
    uint32_t i = h & mask;
    int first_tomb = -1, empty = -1;

    for (int probe = 0; probe < RT_ROUTE_CACHE_CAP; probe++) {
        RtRouteCacheSlot *s = &w->route_cache[i];
        if (s->state == 0) { empty = (int)i; break; }
        if (s->state == 2) {
            if (first_tomb < 0) first_tomb = (int)i;
        } else if (s->hash == h &&
                   route_key_eq(s, src->start_region, src->goal_region,
                                src->clearance_class, src->movement_class, comp)) {
            copy_route(&s->route, src);       /* 同 key 重建：就地替换 */
            s->route.start_region = src->start_region;
            s->last_used = ++w->cache_seq;
            return;
        }
        i = (i + 1) & mask;
    }

    int slot;
    int load_full = (w->route_cache_used + 1) * RT_CACHE_LOAD_DEN >
                    RT_ROUTE_CACHE_CAP * RT_CACHE_LOAD_NUM;
    /* 先复用 tombstone：否则「满了就淘汰」会让 tombstone 越积越多，探测链变长 */
    if (first_tomb >= 0)      slot = first_tomb;
    else if (load_full)       slot = route_cache_evict_lru(w);
    else if (empty >= 0)      slot = empty;
    else                      slot = route_cache_evict_lru(w);
    if (slot < 0) { w->stats.route_cache_rejected++; return; }

    RtRouteCacheSlot *s = &w->route_cache[slot];
    if (s->state == 2) { w->route_cache_tomb--; s->state = 1; }
    else if (s->state == 0) { s->state = 1; }

    s->cls = src->clearance_class;
    s->mcls = src->movement_class;
    s->start = src->start_region;
    s->goal = src->goal_region;
    s->component = comp;
    s->hash = h;
    s->hits = 0;
    s->last_used = ++w->cache_seq;
    copy_route(&s->route, src);               /* 拥有独立副本 */
    w->route_cache_used++;
}

/* ============================= M4.2 Goal Cache ============================ */
static uint32_t goal_hash(int32_t cx, int32_t cz, int cls, int32_t comp)
{
    return rt_hash5(cx, cz, comp, cls, 0x5EED);
}

static int goal_pos_still_valid(const RtGroupWorld *w, RtVec2 p, int cls)
{
    int cx = rt_grid_cell_x(w->g, p.x), cz = rt_grid_cell_z(w->g, p.z);
    if (!rt_grid_walkable(w->g, cx, cz)) return 0;
    return rt_grid_clearance_m(w->g, cx, cz) + 1e-4f >= rt_clear_radius_m(cls);
}

/* 取目标解析缓存：命中前先做 O(1) 复核（label_epoch + 可通行性），
 * 避免「无关编辑清空全表」和「相关编辑继续用旧落点」两种错误。 */
static RtGoalCacheSlot *goal_cache_get(RtGroupWorld *w, int32_t cx, int32_t cz,
                                       int cls, int32_t comp)
{
    if (!w->goal_cache) return NULL;
    uint32_t h = goal_hash(cx, cz, cls, comp);
    uint32_t mask = RT_GOAL_CACHE_CAP - 1;
    uint32_t i = h & mask;
    for (int probe = 0; probe < RT_GOAL_CACHE_CAP; probe++) {
        RtGoalCacheSlot *s = &w->goal_cache[i];
        if (s->state == 0) return NULL;
        if (s->state == 1 && s->cell_x == cx && s->cell_z == cz &&
            s->cls == (uint8_t)cls && s->component == comp) {
            if (s->label_epoch != w->g->label_epoch) {
                s->state = 0;                 /* id 空间变了，旧 comp 语义作废 */
                w->goal_cache_used--;
                return NULL;
            }
            if (s->nav_epoch != w->g->nav_epoch) {
                int ok = rt_region_passable(w->map, s->goal_region, cls) &&
                         w->map->comp[s->goal_region] == comp &&
                         goal_pos_still_valid(w, s->goal_pos, cls);
                if (!ok) { s->state = 0; w->goal_cache_used--; return NULL; }
                s->nav_epoch = w->g->nav_epoch;   /* 复核通过：续命，不清表 */
            }
            s->last_used = ++w->cache_seq;
            return s;
        }
        i = (i + 1) & mask;
    }
    return NULL;
}

static void goal_cache_put(RtGroupWorld *w, int32_t cx, int32_t cz, int cls, int32_t comp,
                           int32_t region, RtVec2 pos, int corrected)
{
    if (!w->goal_cache || region < 0) return;
    uint32_t h = goal_hash(cx, cz, cls, comp);
    uint32_t mask = RT_GOAL_CACHE_CAP - 1;
    uint32_t i = h & mask;
    int empty = -1;

    for (int probe = 0; probe < RT_GOAL_CACHE_CAP; probe++) {
        RtGoalCacheSlot *s = &w->goal_cache[i];
        if (s->state == 0) { empty = (int)i; break; }
        if (s->cell_x == cx && s->cell_z == cz &&
            s->cls == (uint8_t)cls && s->component == comp) {
            s->goal_region = region;
            s->goal_pos = pos;
            s->corrected = (uint8_t)corrected;
            s->label_epoch = w->g->label_epoch;
            s->nav_epoch = w->g->nav_epoch;
            s->last_used = ++w->cache_seq;
            return;
        }
        i = (i + 1) & mask;
    }

    int slot = empty;
    int load_full = (w->goal_cache_used + 1) * RT_CACHE_LOAD_DEN >
                    RT_GOAL_CACHE_CAP * RT_CACHE_LOAD_NUM;
    if (slot < 0 || load_full) {
        int best = -1;
        uint32_t oldest = 0xFFFFFFFFu;
        for (int k = 0; k < RT_GOAL_CACHE_CAP; k++) {
            if (w->goal_cache[k].state != 1) continue;
            if (w->goal_cache[k].last_used < oldest) { oldest = w->goal_cache[k].last_used; best = k; }
        }
        if (best < 0) return;
        slot = best;                          /* 复用该槽，used 不变 */
        RtGoalCacheSlot *s = &w->goal_cache[slot];
        s->cell_x = cx; s->cell_z = cz; s->cls = (uint8_t)cls; s->component = comp;
        s->goal_region = region; s->goal_pos = pos; s->corrected = (uint8_t)corrected;
        s->label_epoch = w->g->label_epoch; s->nav_epoch = w->g->nav_epoch;
        s->last_used = ++w->cache_seq;
        return;
    }

    RtGoalCacheSlot *s = &w->goal_cache[slot];
    s->state = 1;
    s->cell_x = cx; s->cell_z = cz; s->cls = (uint8_t)cls; s->component = comp;
    s->goal_region = region; s->goal_pos = pos; s->corrected = (uint8_t)corrected;
    s->label_epoch = w->g->label_epoch; s->nav_epoch = w->g->nav_epoch;
    s->last_used = ++w->cache_seq;
    w->goal_cache_used++;
}

/* ---------------------------------------------------------------------------
 * Goal Resolution：把玩家点击解析成「本组能到达的最近合法点」
 * 判据（题面 §三 / 裁定 C-2）：同一连通分量 + 该类别可通行。
 * 先看点击点本身；不行就按环搜索最近的可行区域（最多 8 环 = 64 m）。
 * ------------------------------------------------------------------------- */
static int resolve_goal(RtGroupWorld *w, RtVec2 dest, int cls, int32_t comp,
                        int32_t *out_region, RtVec2 *out_pos)
{
    RtRegionMap *m = w->map;
    RtGrid *g = w->g;

    int r0 = rt_region_of_world(m, dest.x, dest.z);
    if (r0 >= 0 && rt_region_passable(m, r0, cls) && m->comp[r0] == comp) {
        *out_region = r0;
        int cx = rt_grid_cell_x(g, dest.x), cz = rt_grid_cell_z(g, dest.z);
        /* 点击点本身可走就用它（保持精确落点，§二十六） */
        if (rt_grid_walkable(g, cx, cz) &&
            rt_grid_clearance_m(g, cx, cz) + 1e-4f >= rt_clear_radius_m(cls)) {
            *out_pos = dest;
        } else {
            *out_pos = rt_region_anchor(m, r0);
        }
        return RT_OK;
    }

    /* 环搜索：优先同分量；找不到同分量就取最近的可通行区域（上层标 UNREACHABLE） */
    int best_same = -1, best_any = -1;
    float best_same_d = 1e30f, best_any_d = 1e30f;
    int cx = (r0 >= 0) ? (r0 % m->rw) : (m->rw / 2);
    int cz = (r0 >= 0) ? (r0 / m->rw) : (m->rh / 2);
    for (int ring = 0; ring <= 8; ring++) {
        for (int dz = -ring; dz <= ring; dz++) {
            for (int dx = -ring; dx <= ring; dx++) {
                if (ring > 0 && abs(dx) != ring && abs(dz) != ring) continue;
                int x = cx + dx, z = cz + dz;
                if (x < 0 || z < 0 || x >= m->rw || z >= m->rh) continue;
                int r = x + z * m->rw;
                if (!rt_region_passable(m, r, cls)) continue;
                RtVec2 c = rt_region_center(m, r);
                float d = (c.x - dest.x) * (c.x - dest.x) + (c.z - dest.z) * (c.z - dest.z);
                if (m->comp[r] == comp && d < best_same_d) { best_same_d = d; best_same = r; }
                if (d < best_any_d) { best_any_d = d; best_any = r; }
            }
        }
        if (best_same >= 0) break;      /* 同分量里找到就停 */
    }

    if (best_same < 0) {
        /* 环搜索（8 环 = 64 m）不够：目标可能在很远的另一个连通域。
         * 按题面 §三，应落到**本分量内**离点击点最近的合法点，而不是原地不动。
         * 全图扫描只在「非法目标」时发生，代价可接受（≤16k 区域）。 */
        for (int r = 0; r < m->rw * m->rh; r++) {
            if (m->comp[r] != comp) continue;
            if (!rt_region_passable(m, r, cls)) continue;
            RtVec2 c = rt_region_center(m, r);
            float d = (c.x - dest.x) * (c.x - dest.x) + (c.z - dest.z) * (c.z - dest.z);
            if (d < best_same_d) { best_same_d = d; best_same = r; }
        }
    }
    if (best_same >= 0) {
        *out_region = best_same;
        *out_pos = rt_region_anchor(m, best_same);
        w->stats.goal_corrections++;
        return RT_OK;
    }
    if (best_any >= 0) {
        /* 本分量内连一个可通行区域都没有（理论上只有「单位卡在墙里」才会发生） */
        *out_region = best_any;
        *out_pos = rt_region_anchor(m, best_any);
        w->stats.goal_corrections++;
        return RT_ERR_NOT_FOUND;
    }
    return RT_ERR_NOT_FOUND;
}

/* ---------------------------------------------------------------------------
 * 目标解析缓存（M4.2）
 * key = (量化目标格, clearance, component)；同命令多组 / 跨命令同目标只解析一次。
 * 失效是**精确**的：label_epoch 变化 -> 作废该条；nav_epoch 变化 -> O(1) 复核
 * （区域仍可通行 + 分量一致 + 落点仍可站），复核不过才重解析；无关编辑不会清表。
 * ------------------------------------------------------------------------- */
static int resolve_goal_cached(RtGroupWorld *w, RtVec2 dest, int cls, int32_t comp,
                               int32_t *out_region, RtVec2 *out_pos)
{
    int cx = rt_grid_cell_x(w->g, dest.x);
    int cz = rt_grid_cell_z(w->g, dest.z);

    RtGoalCacheSlot *hit = goal_cache_get(w, cx, cz, cls, comp);
    if (hit) {
        w->stats.goal_cache_hits++;
        *out_region = hit->goal_region;
        *out_pos = hit->goal_pos;
        return RT_OK;
    }

    w->stats.goal_cache_misses++;
    w->stats.goal_resolves++;
    uint32_t corr0 = w->stats.goal_corrections;
    int rc = resolve_goal(w, dest, cls, comp, out_region, out_pos);
    if (rc == RT_OK && *out_region >= 0) {
        int corrected = (w->stats.goal_corrections > corr0);
        goal_cache_put(w, cx, cz, cls, comp, *out_region, *out_pos, corrected);
    }
    return rc;
}

/* ------------------------------------------------------------------------- */
/* 一个 group 最多承载 RT_GROUP_ROUTES_MAX 个源区域。
 * 超过就**再开一个同类别同分量的组**：这样每个成员都能对上「以自己所在区域
 * 为起点」的那条共享 route，而不是被拉向别的簇（T7 抓到的 164 m 跳跃）。 */
/* 重新使用一个 group 槽位：保留缓冲区（members / src_region / routes），其余归零。
 * 旧实现是 memset 整个结构 -> 每轮命令都丢掉 members 指针（泄漏）并释放 route 缓冲。 */
static void group_slot_reinit(RtMoveGroup *g)
{
    RtUnitId *members = g->members;
    int32_t  *src = g->src_region;
    int       cap = g->cap;
    RtGroupRoute routes[RT_GROUP_ROUTES_MAX];
    memcpy(routes, g->routes, sizeof(routes));

    memset(g, 0, sizeof(*g));

    g->members = members;
    g->src_region = src;
    g->cap = cap;
    memcpy(g->routes, routes, sizeof(routes));
    for (int i = 0; i < RT_GROUP_ROUTES_MAX; i++) {
        g->routes[i].route.n = 0;
        g->routes[i].seg_n = 0;
    }
}

static RtMoveGroup *find_or_make_group(RtGroupWorld *w, uint8_t mcls, uint8_t cls,
                                       int32_t comp, int32_t region, uint32_t cmd_seq)
{
    for (int i = 0; i < w->group_count; i++) {
        RtMoveGroup *g = &w->groups[i];
        if (g->id == 0 || g->cmd_seq != cmd_seq) continue;   /* 别的命令的组不合并 */
        if (g->movement_class != mcls || g->clearance_class != cls) continue;
        if (g->component != comp) continue;
        for (int k = 0; k < g->slot_n; k++)
            if (g->slot_regions[k] == region) return g;
        if (g->slot_n < RT_GROUP_ROUTES_MAX) return g;
    }
    if (w->group_count >= RT_MAX_GROUPS) return NULL;
    RtMoveGroup *g = &w->groups[w->group_count++];
    group_slot_reinit(g);
    g->id = (uint32_t)w->group_count;
    g->cmd_seq = cmd_seq;
    g->movement_class = mcls;
    g->clearance_class = cls;
    g->component = comp;
    g->state = RT_GROUP_NAV_PENDING;
    g->slot_n = 0;
    return g;
}

static void group_note_region(RtMoveGroup *g, int32_t region)
{
    if (region < 0) return;
    for (int k = 0; k < g->slot_n; k++) if (g->slot_regions[k] == region) return;
    if (g->slot_n < RT_GROUP_ROUTES_MAX) g->slot_regions[g->slot_n++] = region;
}

static int group_add_member(RtMoveGroup *g, RtUnitId id, int32_t region)
{
    if (g->count >= g->cap) {
        int nc = g->cap ? g->cap * 2 : 64;
        RtUnitId *p = (RtUnitId *)realloc(g->members, (size_t)nc * sizeof(RtUnitId));
        if (!p) return RT_ERR_CAPACITY;
        g->members = p;
        int32_t *q = (int32_t *)realloc(g->src_region, (size_t)nc * sizeof(int32_t));
        if (!q) return RT_ERR_CAPACITY;
        g->src_region = q;
        g->cap = nc;
    }
    g->members[g->count] = id;
    g->src_region[g->count] = region;
    g->count++;
    return RT_OK;
}

static int route_slot_for(RtMoveGroup *g, int32_t start_region)
{
    for (int i = 0; i < g->route_count; i++)
        if (g->routes[i].start_region == start_region) return i;
    return -1;
}

/* ============================================================================
 * M4.5：组的多命令共存
 *
 * 旧语义：rt_gw_command 先把所有组清空再重建 —— 第二条命令会抹掉第一条。
 * 新语义：只把「本命令涉及的单位」从旧组摘出来，其余组原样运行。
 *
 * 三个必须守住的细节：
 *   1. 不同命令的组**不能合并**（同 (mcls, cls, comp, region) 也不行），否则 B 命令的
 *      目标会覆盖 A 命令 —— 用 cmd_seq 隔离。
 *   2. `chunk->group = index + 1` 是不变式（rt_gw_sample 收的是 index）。组被压缩后
 *      id 会变，必须在命令返回前把所有受影响成员的 chunk 字段回写。
 *   3. 空组必须真正释放（含缓冲）并压缩数组，否则墓碑会吃掉 RT_MAX_GROUPS，
 *      而且 group_count 会被测试当成「存活组数」。
 * ========================================================================== */

/* 单位 id 位图：RT_MAX_UNITS = 4096 -> 512 B，栈上分配，O(1) 判定。
 * 用位图而不是哈希：单位数上限固定，且这是每条命令都要建的临时结构。 */
static inline void idset_add(uint8_t *s, RtUnitId id)
{
    unsigned k = id - 1u;
    s[k >> 3] |= (uint8_t)(1u << (k & 7u));
}
static inline int idset_has(const uint8_t *s, RtUnitId id)
{
    unsigned k = id - 1u;
    return (s[k >> 3] >> (k & 7u)) & 1u;
}

/* 把 set 里的成员从组里摘掉。
 * 返回 1 = 组还活着；0 = 组已空（调用方负责标记释放）。
 * 变瘦的组必须重建 slot_regions 与 route slot 索引，否则会给「已经没有成员的
 * 源区域」继续建/保留 route（浪费，且 slot 表会挡住新区域）。 */
static int group_drop_members(RtMoveGroup *g, const uint8_t *set, uint32_t *moved)
{
    int dst = 0;
    for (int i = 0; i < g->count; i++) {
        RtUnitId id = g->members[i];
        if (id != RT_UNIT_ID_NONE && id <= RT_MAX_UNITS && idset_has(set, id)) {
            (*moved)++;
            continue;
        }
        g->members[dst] = g->members[i];
        g->src_region[dst] = g->src_region[i];
        dst++;
    }
    g->count = dst;
    if (dst == 0) return 0;

    g->slot_n = 0;
    for (int i = 0; i < g->count; i++) group_note_region(g, g->src_region[i]);

    int rw = 0;
    for (int i = 0; i < g->route_count; i++) {
        int keep = 0;
        for (int k = 0; k < g->slot_n; k++)
            if (g->slot_regions[k] == g->routes[i].start_region) { keep = 1; break; }
        if (!keep) continue;
        if (rw != i) {
            RtGroupRoute t = g->routes[i];
            g->routes[i] = g->routes[rw];
            g->routes[rw] = t;
        }
        rw++;
    }
    g->route_count = rw;
    return 1;
}

/* 去掉空洞、重排数组、重编号 id = index + 1。
 *
 * 空洞**不释放缓冲**，只与活组交换位置：缓冲跟着结构体走。
 * 原因：最常见的场景就是「同一批单位重新下令」——旧组变空、立刻在同一个槽位
 * 建新组。若在这里 free，就会变成每条命令 8 次 free + 8 次 malloc（实测 warm
 * command 0.027 → 0.040 ms）。交换之后 find_or_make_group 的 group_slot_reinit
 * 直接复用这些缓冲（它本来就保留 members/src_region/routes 指针）。
 * 缓冲总数上界仍是 RT_MAX_GROUPS 槽，与 M4.2 起的策略一致。 */
static void gw_compact_groups(RtGroupWorld *w)
{
    int n = w->group_count;
    int dst = 0;
    for (int i = 0; i < n; i++) {
        RtMoveGroup *g = &w->groups[i];
        if (g->id == 0 || g->count == 0) continue;
        if (dst != i) {
            RtMoveGroup hole = w->groups[dst];   /* 空洞（带缓冲）挪到尾部 */
            w->groups[dst] = *g;
            w->groups[i] = hole;
        }
        w->groups[dst].id = (uint32_t)dst + 1;
        dst++;
    }
    for (int i = dst; i < n; i++) {
        w->groups[i].id = 0;
        w->groups[i].count = 0;
        w->groups[i].route_count = 0;
        w->groups[i].slot_n = 0;
        for (int k = 0; k < RT_GROUP_ROUTES_MAX; k++) {
            w->groups[i].routes[k].route.n = 0;
            w->groups[i].routes[k].seg_n = 0;
        }
    }
    w->group_count = dst;
}

/* 把每个组成员的 chunk->group 回写成当前 id（压缩后 id 变了） */
static void gw_rewrite_unit_groups(const RtGroupWorld *w, const RtUnitStore *units)
{
    if (!units) return;
    for (int i = 0; i < w->group_count; i++) {
        const RtMoveGroup *g = &w->groups[i];
        for (int k = 0; k < g->count; k++) {
            RtUnitChunk *c = (RtUnitChunk *)rt_units_chunk_c(units, g->members[k]);
            c->group[rt_unit_slot_index(g->members[k])] = (uint8_t)g->id;
        }
    }
}

/* 前向声明：走廊逐段索引在文件后面的 M4.4 区块定义 */
static void group_route_index_corridor(RtGroupWorld *w, RtGroupRoute *gr, RtVec2 goal);

/* 统一的 A* 构建（slot 已分配好）：计入 route_builds 并入 cache */
static int route_build_into(RtGroupWorld *w, RtMoveGroup *g, RtRoute *dst, int32_t start)
{
    int rc = rt_route_build(dst, &w->solver, w->map, start, g->goal_region,
                            g->clearance_class, g->movement_class);
    if (rc != RT_OK) { w->stats.route_failed++; return rc; }
    w->stats.route_builds++;
    route_cache_put(w, dst, g->component);
    return RT_OK;
}

/* 为一个 (group, 源区域) 准备 route：cache 命中 -> 拷贝；否则 A* + 入 cache。
 * 注意：M4.2 起「复用」不再扫描其它 group 的 route，也不再维护 recent[16]，
 * 统一由 route_cache（key 含 component）裁决，避免两套失效路径。 */
static int ensure_route(RtGroupWorld *w, RtMoveGroup *g, int32_t start_region)
{
    if (route_slot_for(g, start_region) >= 0) return RT_OK;

    w->stats.route_requests++;

    int answer = RT_CACHE_MISS;
    RtRoute *hit = route_cache_get(w, start_region, g->goal_region,
                                   g->clearance_class, g->movement_class,
                                   g->component, &answer);

    if (g->route_count >= RT_GROUP_ROUTES_MAX) {
        /* 不可达分支（find_or_make_group 保证每组 <= 4 个源区域）。
         * 这里不再「复用 slot 0」——那会把成员拉向别的簇，是 M4.1 bug#6 的形态。 */
        w->stats.route_failed++;
        return RT_ERR_CAPACITY;
    }
    int slot = g->route_count++;
    RtGroupRoute *gr = &g->routes[slot];
    gr->start_region = start_region;
    gr->built_frame = w->frame;
    gr->route.n = 0;               /* 缓冲区跨命令保留，不释放 */
    gr->route.dep_n = 0;

    RtRoute *dst = &gr->route;
    if (hit) {
        copy_route(dst, hit);
        dst->start_region = start_region;   /* 语义上属于本组的源区域 */
        w->stats.route_reuses++;
        group_route_index_corridor(w, gr, g->goal_pos);
        return RT_OK;
    }

    int rc = route_build_into(w, g, dst, start_region);
    if (rc == RT_OK) group_route_index_corridor(w, gr, g->goal_pos);
    return rc;
}

/* ===================== M4.3 goal-centric coarse flow ===================== */

/* 统计与 (goal, comp, cls, mcls) 相同的所有 group 的**去重 source 区域**。
 * 必须跨 group 统计：RT_GROUP_ROUTES_MAX=4 会把同一目标的多个源区域拆成多个组，
 * 若只看单组就永远达不到阈值。
 * M4.5：再加一条 cmd_seq 过滤 —— 只统计**本命令**的组。否则一条老命令的 16 个源区域
 * 会把新下的 3 人命令误判成 flow 分支（结果仍正确，但自适应决策不再按命令生效）。 */
static int collect_key_sources(const RtGroupWorld *w, int32_t goal, int32_t comp,
                               int cls, int mcls, int32_t *out, int max_out)
{
    int n = 0;
    for (int i = 0; i < w->group_count; i++) {
        const RtMoveGroup *g = &w->groups[i];
        if (g->id == 0 || g->cmd_seq != w->cmd_seq) continue;
        if (g->goal_region != goal || g->component != comp) continue;
        if (g->clearance_class != (uint8_t)cls || g->movement_class != (uint8_t)mcls) continue;
        for (int k = 0; k < g->slot_n; k++) {
            int r = g->slot_regions[k];
            int dup = 0;
            for (int q = 0; q < n; q++) if (out[q] == r) { dup = 1; break; }
            if (dup) continue;
            if (n < max_out) out[n++] = r;
        }
    }
    return n;
}

static RtGoalFlow *flow_get(RtGroupWorld *w, int32_t goal, int32_t comp, int cls, int mcls,
                            const int32_t *srcs, int nsrcs)
{
    for (int i = 0; i < RT_GOALFLOW_SLOTS; i++) {
        RtGoalFlow *f = &w->flows[i];
        if (f->state == 0) continue;
        if (f->goal != goal || f->comp != comp ||
            f->cls != (uint8_t)cls || f->mcls != (uint8_t)mcls) continue;
        if (rt_goalflow_valid(f, w->g)) {
            f->hits++;
            f->last_used = ++w->flow_seq;
            w->stats.goal_flow_hits++;
            return f;
        }
        w->stats.goal_flow_invalid++;
        rt_goalflow_free(f);            /* 第一版：失效即重建，不做局部修复 */
    }

    int slot = -1;
    for (int i = 0; i < RT_GOALFLOW_SLOTS; i++)
        if (w->flows[i].state == 0) { slot = i; break; }
    if (slot < 0) {
        uint32_t oldest = 0xFFFFFFFFu;
        for (int i = 0; i < RT_GOALFLOW_SLOTS; i++)
            if (w->flows[i].last_used < oldest) { oldest = w->flows[i].last_used; slot = i; }
    }

    RtGoalFlow *f = &w->flows[slot];
    if (f->state) rt_goalflow_free(f);
    int rc = rt_goalflow_build(f, &w->flow_solver, w->map, goal, comp, cls, mcls,
                               srcs, nsrcs);
    if (rc != RT_OK) { f->state = 0; return NULL; }

    f->builds++;
    f->last_used = ++w->flow_seq;
    w->stats.goal_flow_builds++;
    w->stats.goal_flow_expanded += (uint32_t)f->expanded;
    w->stats.goal_flow_sources += (uint32_t)nsrcs;
    return f;
}

/* 走 flow 分支：先查 M4.2 route cache（warm 不得为了 flow 重建）；miss 才摘树 */
static int ensure_route_flow(RtGroupWorld *w, RtMoveGroup *g, int32_t start,
                             const int32_t *srcs, int nsrcs)
{
    if (route_slot_for(g, start) >= 0) return RT_OK;
    w->stats.route_requests++;

    int answer = RT_CACHE_MISS;
    RtRoute *hit = route_cache_get(w, start, g->goal_region, g->clearance_class,
                                   g->movement_class, g->component, &answer);

    if (g->route_count >= RT_GROUP_ROUTES_MAX) { w->stats.route_failed++; return RT_ERR_CAPACITY; }
    int slot = g->route_count++;
    RtGroupRoute *gr = &g->routes[slot];
    gr->start_region = start;
    gr->built_frame = w->frame;
    gr->route.n = 0;
    gr->route.dep_n = 0;
    RtRoute *dst = &gr->route;

    if (hit) {
        copy_route(dst, hit);
        dst->start_region = start;
        w->stats.route_reuses++;
        group_route_index_corridor(w, gr, g->goal_pos);
        return RT_OK;
    }

    RtGoalFlow *f = flow_get(w, g->goal_region, g->component, g->clearance_class,
                             g->movement_class, srcs, nsrcs);
    int n = f ? rt_goalflow_path(f, start, w->path_scratch, f->nregions) : 0;
    if (n <= 0) {
        w->stats.fallback_to_astar++;
        int rc2 = route_build_into(w, g, dst, start);
        if (rc2 == RT_OK) group_route_index_corridor(w, gr, g->goal_pos);
        return rc2;
    }
    int rc = rt_route_from_path(dst, w->map, w->path_scratch, n,
                                g->clearance_class, g->movement_class, f->dist[start]);
    if (rc != RT_OK) { w->stats.route_failed++; return rc; }
    w->stats.flow_route_extracts++;
    route_cache_put(w, dst, g->component);
    group_route_index_corridor(w, gr, g->goal_pos);
    return RT_OK;
}

/* 自适应选择：unique source 数 >= 阈值才走 flow */
static int ensure_route_dispatch(RtGroupWorld *w, RtMoveGroup *g, int32_t start,
                                 const int32_t *srcs, int nsrcs, int threshold)
{
    if (threshold < 0) return ensure_route_flow(w, g, start, srcs, nsrcs);   /* 强制 flow */
    int thr = (threshold == 0) ? RT_GOALFLOW_MIN_SOURCES : threshold;
    if (nsrcs >= thr) return ensure_route_flow(w, g, start, srcs, nsrcs);
    return ensure_route(w, g, start);
}

int rt_gw_command(RtGroupWorld *w, const RtUnitStore *units,
                  const RtUnitId *ids, int n,
                  RtVec2 dest, uint8_t movement_class, uint8_t clearance_class,
                  uint32_t command_version)
{
    if (!w || !units || !ids || n <= 0) return RT_ERR_INVALID;

    /* M4.6-P5：命令路径必须看到**终态**。若还有未完成的 split，先把它跑完 ——
     * 否则拆组/建 route 会在「已摘格、未重标」的中间态上算分量。
     * 这是用户操作（不是每帧路径），一次性多花几毫秒可以接受。 */
    if (w->split_pending) {
        rt_navsched_drain(&w->sched);
        w->split_pending = 0;
        gw_pending_flush(w);
    }

    w->frame++;
    w->stats = (RtGwStats){0};
    w->stats.units = (uint32_t)n;
    w->fine_budget_left = w->fine_budget;     /* M4.6-P1：每条命令重新给建场额度 */
    w->cmd_seq++;
    w->stats.cmd_seq = w->cmd_seq;

    RtRegionMap *m = w->map;
    if (m->built_epoch != w->g->nav_epoch) {
        if (rt_region_refresh(m) != RT_OK) return RT_ERR_INVALID;
        w->stats.region_rebuilds++;
    }

    /* ---- 1. 把本命令涉及的单位从旧组摘出来（M4.5：不再清空所有组） ---- */
    uint8_t inset[RT_MAX_UNITS / 8];
    memset(inset, 0, sizeof(inset));
    for (int i = 0; i < n; i++) {
        RtUnitId id = ids[i];
        if (id == RT_UNIT_ID_NONE || id > RT_MAX_UNITS) continue;
        idset_add(inset, id);
    }

    uint32_t moved = 0;
    int kept = 0;
    for (int i = 0; i < w->group_count; i++) {
        RtMoveGroup *g = &w->groups[i];
        if (g->id == 0 || g->count == 0) continue;
        if (group_drop_members(g, inset, &moved)) kept++;
        else { g->id = 0; w->stats.groups_freed++; }   /* 空组：等压缩时释放 */
    }
    w->stats.members_moved = moved;
    if (moved) {
        gw_compact_groups(w);              /* 释放空洞 + 重排 id */
        gw_rewrite_unit_groups(w, units);  /* id == index+1 必须回写（采样靠它） */
    }
    w->stats.groups_kept = (uint32_t)kept;

    /* ---- 2. 新单位入组：组带 cmd_seq，不与任何旧命令合并 ---- */
    int first_new = w->group_count;
    int32_t *member_region = (int32_t *)malloc((size_t)n * sizeof(int32_t));
    if (!member_region) return RT_ERR_CAPACITY;

    for (int i = 0; i < n; i++) {
        RtVec3 p = rt_units_pos(units, ids[i]);
        int cx = rt_grid_cell_x(w->g, p.x), cz = rt_grid_cell_z(w->g, p.z);
        int32_t comp = rt_grid_component_at(w->g, cx, cz);
        int r = rt_region_of_cell(m, cx, cz);
        if (r < 0) r = rt_region_of_world(m, p.x, p.z);
        member_region[i] = r;

        RtMoveGroup *gr = find_or_make_group(w, movement_class, clearance_class,
                                             comp, r, w->cmd_seq);
        if (!gr) { free(member_region); return RT_ERR_CAPACITY; }
        group_note_region(gr, r);
        int rc_add = group_add_member(gr, ids[i], member_region[i]);
        if (rc_add != RT_OK) { free(member_region); return rc_add; }
    }
    w->stats.groups = (uint32_t)w->group_count;

    /* ---- 3. 只给新组解析目标（旧组的目标不动） ---- */
    for (int i = first_new; i < w->group_count; i++) {
        RtMoveGroup *g = &w->groups[i];
        g->destination = dest;
        g->created_frame = w->frame;
        g->last_update_frame = w->frame;
        g->command_version = command_version;

        int32_t goal_region = -1;
        RtVec2 goal_pos = dest;
        int rc = resolve_goal_cached(w, dest, g->clearance_class, g->component,
                                     &goal_region, &goal_pos);
        g->goal_region = goal_region;
        g->goal_pos = goal_pos;
        if (goal_region < 0) { g->state = RT_GROUP_UNREACHABLE; continue; }
        if (rc != RT_OK) {
            g->state = RT_GROUP_UNREACHABLE;
            g->corrections++;
            continue;
        }
    }

    /* ---- 4. 只给新组建 route：自适应选择 flow / per-source A* ---- */
    for (int i = first_new; i < w->group_count; i++) {
        RtMoveGroup *g = &w->groups[i];
        if (g->state == RT_GROUP_UNREACHABLE || g->goal_region < 0) continue;

        int32_t srcs[RT_MAX_GROUPS * RT_GROUP_ROUTES_MAX];
        int nsrcs = collect_key_sources(w, g->goal_region, g->component,
                                        g->clearance_class, g->movement_class,
                                        srcs, (int)(sizeof(srcs) / sizeof(srcs[0])));
        int thr = w->flow_threshold;
        int use_flow = (thr < 0) ||
                       (nsrcs >= (thr == 0 ? RT_GOALFLOW_MIN_SOURCES : thr));
        if (use_flow) w->stats.adaptive_flow++; else w->stats.adaptive_astar++;

        for (int q = 0; q < g->slot_n; q++)
            ensure_route_dispatch(w, g, g->slot_regions[q], srcs, nsrcs, thr);
        g->state = (g->route_count > 0) ? RT_GROUP_NAV_READY : RT_GROUP_UNREACHABLE;
    }

    /* ---- 5. 回写新组成员的 unit.group（0 = 无组；id 从 1 开始，uint8 够到 255） ---- */
    for (int i = first_new; i < w->group_count; i++) {
        RtMoveGroup *g = &w->groups[i];
        if (g->id > 254) continue;
        for (int k = 0; k < g->count; k++) {
            RtUnitChunk *c = (RtUnitChunk *)rt_units_chunk_c(units, g->members[k]);
            int s = rt_unit_slot_index(g->members[k]);
            c->group[s] = (uint8_t)g->id;
        }
    }

    free(member_region);
    return RT_OK;
}

void rt_gw_clear(RtGroupWorld *w, RtUnitStore *units)
{
    if (!w) return;
    /* M4.6-P5：未完成的 split 直接丢弃（取消不影响 Active 数据；flags 已生效）。
     * 场景切换/单位全灭时不需要把它跑完，下一次编辑会从头再做。 */
    rt_navsched_shutdown(&w->sched);
    w->split_pending = 0;
    w->pend_valid = 0;
    if (units) {
        for (int i = 0; i < w->group_count; i++) {
            RtMoveGroup *g = &w->groups[i];
            for (int k = 0; k < g->count; k++) {
                RtUnitChunk *c = (RtUnitChunk *)rt_units_chunk_c(units, g->members[k]);
                c->group[rt_unit_slot_index(g->members[k])] = 0;
            }
        }
    }
    for (int i = 0; i < w->group_count; i++) group_slot_reinit(&w->groups[i]);  /* 保留缓冲 */
    w->group_count = 0;
    w->cmd_seq++;
}

/* ============================================================================
 * M4.6-P5（路线 B）：异步 split
 *
 * 大分量的 split 是 O(分量大小)：64×64 建筑实测 4.6 ms，占 60 fps 的一帧 28%。
 * 这里把 M3.7 的 RtNavSched（分帧 / 合并 / 取消 / stale 不丢更新）接到世界层：
 * 提交 -> 可能挂起 -> update 每帧推进 split_budget 个节点 -> commit -> 刷区域图。
 *
 * 挂起期间的三条纪律：
 *   1. **不刷区域图**：区域读 clearance/component，此刻是中间态；
 *   2. **不重建 route**：同上（route 依赖 component 与 chunk_ver）；
 *   3. **不读 component 做决策**：command 进来会先 drain，其它调用方不要自己读。
 * 采样继续用旧 route：flags 已经是最新的，所以物理上不会穿墙，只是绕行要等提交。
 * ========================================================================== */

/* 累积「待刷新区域图」的矩形：编辑范围 ∪ clearance 重算范围（区域读的就是这两者） */
static void gw_pending_rect_add(RtGroupWorld *w, const RtGridDirty *d)
{
    int x0 = d->x0, z0 = d->z0, x1 = d->x1, z1 = d->z1;
    if (d->cx0 < x0) x0 = d->cx0;
    if (d->cz0 < z0) z0 = d->cz0;
    if (d->cx1 > x1) x1 = d->cx1;
    if (d->cz1 > z1) z1 = d->cz1;

    if (!w->pend_valid) {
        w->pend_x0 = x0; w->pend_z0 = z0; w->pend_x1 = x1; w->pend_z1 = z1;
        w->pend_valid = 1;
        return;
    }
    if (x0 < w->pend_x0) w->pend_x0 = x0;
    if (z0 < w->pend_z0) w->pend_z0 = z0;
    if (x1 > w->pend_x1) w->pend_x1 = x1;
    if (z1 > w->pend_z1) w->pend_z1 = z1;
}

/* 把挂起期间累积的矩形一次性刷进区域图。
 * 安全网仍在 rt_region_refresh_rect 内部：矩形外的 chunk 版本变了会自动扩成整图。 */
static void gw_pending_flush(RtGroupWorld *w)
{
    if (!w->pend_valid || !w->map) { w->pend_valid = 0; return; }
    int n = rt_region_refresh_rect(w->map, w->pend_x0, w->pend_z0, w->pend_x1, w->pend_z1);
    if (n < 0) {
        (void)rt_region_refresh(w->map);
        w->stats.region_full_refresh++;
    } else {
        w->stats.region_rect_refresh++;
        w->stats.region_regions += (uint32_t)n;
        if (w->map->last_full_reason != 0) {
            w->stats.region_full_refresh++;
            if (w->map->last_full_reason == 2) w->stats.region_widened++;
        }
    }
    w->pend_valid = 0;
}

int rt_gw_submit_edit(RtGroupWorld *w, const RtGridDirty *d)
{
    if (!w || !w->g || !w->map || !d) return RT_ERR_INVALID;

    gw_pending_rect_add(w, d);          /* 同步/异步都要覆盖这次编辑 */

    if (!w->async_split) {              /* 对照路径：等价于 apply_dirty + note_edit */
        RtGridDirty tmp = *d;           /* apply_dirty 需要可写（会读 chunk_mask） */
        int rc = rt_grid_apply_dirty(w->g, &tmp);
        gw_pending_flush(w);
        return rc;
    }

    rt_navsched_submit(&w->sched, d);
    /* 提交帧只推进 1/4 预算：
     *   · 小编辑（绝大多数）本来几步就走完 -> 仍然同帧完成，零变化；
     *   · 大 split 不把整份额度压在这一帧（实测 8000 节点 ≈ 0.5 ms，
     *     全部放在提交帧会让峰值仍停在 ~1.3 ms），留给后续 update 摊开。 */
    int units = (w->split_budget < 0) ? (1 << 24) : (w->split_budget / 4);
    if (units < 512) units = 512;
    int idle = rt_navsched_tick(&w->sched, units);
    if (idle) {
        /* 小编辑：同一帧完成，与旧路径的耗时一致（clearance + merge/split 判定） */
        gw_pending_flush(w);
        w->split_pending = 0;
        return RT_OK;
    }
    /* 挂起：大分量的 split，交给 update 分帧 */
    w->split_pending = 1;
    w->split_frames = 0;
    return RT_OK;
}

int rt_gw_split_pending(const RtGroupWorld *w)
{
    return (w && w->split_pending) ? 1 : 0;
}

void rt_gw_set_split_budget(RtGroupWorld *w, int units)
{
    if (w) w->split_budget = units;
}

int rt_gw_split_budget(const RtGroupWorld *w)
{
    return w ? w->split_budget : 0;
}

void rt_gw_set_async_split(RtGroupWorld *w, int on)
{
    if (w) w->async_split = on ? 1 : 0;
}

int rt_gw_update(RtGroupWorld *w)
{
    if (!w) return 0;
    w->frame++;
    /* M4.6-P1：每帧给一次建场额度。不调 update 的调用方整条命令只建 fine_budget 个场
     * （默认 1）—— 这是显式的退化边界，不是静默降级（计数在 fine_budget_skip）。 */
    w->fine_budget_left = w->fine_budget;

    /* M4.6-P5：先把未完成的 split 往前推。挂起期间不刷区域图、不重建 route。 */
    if (w->split_pending) {
        int units = (w->split_budget < 0) ? (1 << 24) : w->split_budget;
        int idle = rt_navsched_tick(&w->sched, units);
        w->split_frames++;
        if (!idle) return 0;            /* 中间态：本帧只做了 split 的一部分 */
        w->split_pending = 0;
        if (w->split_frames > w->split_max_frames) w->split_max_frames = w->split_frames;
        if (w->split_frames >= 2) w->split_spans++;
        gw_pending_flush(w);            /* 标签已是终态：区域图追上来 */
        /* 落到下面：本帧继续重建失效的 route */
    }

    /* 编辑后直接 update（没有重新下命令）时，区域图必须追上 grid 的提交版本。
     * 否则重建 route 用的是一张过期区域图（M4.2 T4 暴露）。 */
    if (w->map && w->map->built_epoch != w->g->nav_epoch) {
        if (rt_region_refresh(w->map) != RT_OK) return 0;
        w->stats.region_rebuilds++;
    }

    int rebuilt = 0;
    for (int i = 0; i < w->group_count; i++) {
        RtMoveGroup *g = &w->groups[i];
        if (g->id == 0 || g->count == 0) continue;      /* M4.5：空槽不存在，防御性跳过 */
        if (g->state == RT_GROUP_UNREACHABLE || g->state == RT_GROUP_CANCELLED) continue;

        /* M4.2：逐条判定、逐条重建。
         * M4.1 的行为是「一条失效 -> group_release_routes -> 全部重建」，
         * 在 4 条 route 的组里意味着 1 invalid 触发 4 次 A*（失效放大）。 */
        for (int k = 0; k < g->route_count; k++) {
            RtGroupRoute *gr = &g->routes[k];
            RtRoute *r = &gr->route;
            if (rt_route_valid(r, w->g)) continue;

            w->stats.route_invalidated++;
            w->stats.route_stale++;

            int32_t start = r->start_region;
            int rc = rt_route_build(r, &w->solver, w->map, start, g->goal_region,
                                    g->clearance_class, g->movement_class);
            if (rc != RT_OK) {
                w->stats.route_failed++;
                r->n = 0;
                g->state = RT_GROUP_UNREACHABLE;
                continue;
            }
            w->stats.route_builds++;
            gr->built_frame = w->frame;
            route_cache_put(w, r, g->component);
            group_route_index_corridor(w, gr, g->goal_pos);
            rebuilt++;
        }
        g->last_update_frame = w->frame;
    }
    return rebuilt;
}

/* ============================================================================
 * M4.6-P2：区域图增量刷新入口
 *
 * 为什么需要显式通知：RtRegionMap 的每个区域只依赖自己的 px×px 格，天然可增量，
 * 但「哪些格子变了」只有调用方（以及 RtGridDirty）知道。不通知也不会算错
 * （command/update 会整图重建），只是白付 0.6~0.8 ms。
 *
 * dirty 给得不全也不会算错：rt_region_refresh_rect 用 chunk 版本快照复核，
 * 发现矩形外有变化就自动扩成整图（region_widened 计数）。
 * ========================================================================== */
int rt_gw_note_edit(RtGroupWorld *w, const RtGridDirty *d)
{
    if (!w || !w->map || !w->g) return RT_ERR_INVALID;
    RtRegionMap *m = w->map;

    /* 幂等：没有未消费的提交就直接返回（重复通知不重复付钱） */
    if (m->pass && m->built_epoch == w->g->nav_epoch) return RT_OK;

    if (!d) {
        if (rt_region_refresh(m) != RT_OK) return RT_ERR_INVALID;
        w->stats.region_full_refresh++;
        return RT_OK;
    }

    /* 用「编辑范围 ∪ clearance 重算范围」：clearance 的 pad 会伸到编辑区之外，
     * 而区域的 maxclear/anchor 读的正是 clearance。取并集才是完整的变化范围。 */
    int x0 = d->x0, z0 = d->z0, x1 = d->x1, z1 = d->z1;
    if (d->cx0 < x0) x0 = d->cx0;
    if (d->cz0 < z0) z0 = d->cz0;
    if (d->cx1 > x1) x1 = d->cx1;
    if (d->cz1 > z1) z1 = d->cz1;

    int n = rt_region_refresh_rect(m, x0, z0, x1, z1);
    if (n < 0) return n;

    w->stats.region_rect_refresh++;
    w->stats.region_regions += (uint32_t)n;
    if (m->last_full_reason != 0) {
        w->stats.region_full_refresh++;
        if (m->last_full_reason == 2) w->stats.region_widened++;
    }
    return RT_OK;
}

/* 走廊节点：k < n-1 取门户点，末端取真实落点（详见下面的 M4.4-A 说明） */
static inline RtVec2 corridor_node(const RtRoute *r, RtVec2 goal, int k)
{
    return (k >= r->n - 1) ? goal : r->portal[k];
}

/* ============================================================================
 * M4.4-B：走廊逐段「直线被挡」标记
 *
 * 每段一次 DDA（段长 ≈ 一个区域，8~12 m），与单位数无关；采样时只是读一个 byte。
 * 这解决了「不能每帧每单位做 LOS」的成本问题：
 *   1000 单位 × 每帧 1 次 50 m LOS = 0.19~0.21 ms（实测），会直接击穿 0.16 ms 上限；
 *   改成「每段一次」后，成本是 O(走廊长度 × 组数)，与 1000 无关。
 * 段定义：seg_block[k] = 「节点 k-1 -> 节点 k 的直线是否穿墙」，k >= 1。
 * ========================================================================== */
static void group_route_index_corridor(RtGroupWorld *w, RtGroupRoute *gr, RtVec2 goal)
{
    RtRoute *r = &gr->route;
    int n = r->n;
    if (n <= 0) { gr->seg_n = 0; return; }

    if (!gr->seg_block || !gr->seg_invlen || gr->seg_cap < n) {
        uint8_t *p = (uint8_t *)realloc(gr->seg_block, (size_t)n);
        if (!p) { gr->seg_n = 0; return; }        /* 分配失败：采样退回「节点+直线」 */
        gr->seg_block = p;
        float *q = (float *)realloc(gr->seg_invlen, (size_t)n * sizeof(float));
        if (!q) { gr->seg_n = 0; return; }
        gr->seg_invlen = q;
        gr->seg_cap = n;
    }
    gr->seg_block[0] = 0;
    gr->seg_invlen[0] = 0.f;
    for (int k = 1; k < n; k++) {
        RtVec2 a = corridor_node(r, goal, k - 1);
        RtVec2 b = corridor_node(r, goal, k);
        float dx = b.x - a.x, dz = b.z - a.z;
        float len2 = dx * dx + dz * dz;
        gr->seg_invlen[k] = (len2 > 1e-8f) ? (1.f / sqrtf(len2)) : 0.f;

        int ok = rt_los_clear(w->g, a, b);
        gr->seg_block[k] = (uint8_t)(ok ? 0 : 1);
        w->stats.corridor_segments++;
        if (!ok) w->stats.corridor_blocked++;
    }
    gr->seg_n = n;
}

/* fine flow 缓存：4 槽，key = (目标格, clearance 类别)；窗口原点由目标格决定。
 * 依赖失效 -> 整块重建（不做局部修复）。 */
static RtFineFlow *fine_get(RtGroupWorld *w, int tx, int tz, int cls)
{
    /* 先吸附到能站的格：门户点/区域中心可能落在墙里，直接拿原格做 key
     * 会让每次采样都 miss 一次并走 build 的失败分支。 */
    int sx, sz;
    if (!rt_fine_snap_cell(w->g, tx, tz, rt_clear_radius_m(cls), &sx, &sz)) {
        w->stats.fine_failed++;
        return NULL;
    }
    tx = sx; tz = sz;

    for (int i = 0; i < RT_FINE_SLOTS; i++) {
        RtFineFlow *f = &w->fine[i];
        if (f->state == 0) continue;
        if (f->tx != tx || f->tz != tz || (int)f->cls != cls) continue;
        if (rt_fineflow_valid(f, w->g)) {
            f->hits++;
            f->last_used = ++w->fine_seq;
            w->stats.fine_hits++;
            return f;
        }
        w->stats.fine_invalid++;
        rt_fine_free(f);                       /* 失效即整块重建 */
    }

    int slot = -1;
    for (int i = 0; i < RT_FINE_SLOTS; i++)
        if (w->fine[i].state == 0) { slot = i; break; }
    if (slot < 0) {
        uint32_t oldest = 0xFFFFFFFFu;
        for (int i = 0; i < RT_FINE_SLOTS; i++)
            if (w->fine[i].last_used < oldest) { oldest = w->fine[i].last_used; slot = i; }
    }

    /* M4.6-P1：建场预算。命中缓存不消耗预算，只有真正跑 BFS 才扣。
     * 用尽时退回「节点 + 直线」，计数后返回 NULL（调用方会走 fine_outside 分支）。 */
    if (w->fine_budget >= 0 && w->fine_budget_left <= 0) {
        w->stats.fine_budget_skip++;
        return NULL;
    }

    RtFineFlow *f = &w->fine[slot];
    if (f->state) rt_fine_free(f);
    int rc = rt_fineflow_build(f, &w->fine_solver, w->g, tx, tz, cls);
    if (rc != RT_OK) {
        f->state = 0;
        if (rc == RT_ERR_INVALID) w->stats.fine_rejected++;   /* 窗口越界：不放大窗口 */
        else                      w->stats.fine_failed++;
        return NULL;
    }
    if (w->fine_budget > 0) w->fine_budget_left--;
    w->stats.fine_builds++;
    w->stats.fine_reached += (uint32_t)f->reached;
    f->builds++;
    f->last_used = ++w->fine_seq;
    return f;
}

static RtGroupRoute *route_for_pos(const RtGroupWorld *w, RtMoveGroup *g, RtVec2 pos)
{
    if (g->route_count <= 0) return NULL;
    int r = rt_region_of_world(w->map, pos.x, pos.z);
    int best = 0; int best_d = 1 << 30;
    for (int i = 0; i < g->route_count; i++) {
        int sr = g->routes[i].start_region;
        int ax = sr % w->map->rw, az = sr / w->map->rw;
        int bx = (r >= 0) ? (r % w->map->rw) : 0, bz = (r >= 0) ? (r / w->map->rw) : 0;
        int d = abs(ax - bx) + abs(az - bz);
        if (d < best_d) { best_d = d; best = i; }
    }
    return &g->routes[best];
}

/* ============================================================================
 * M4.4-A：走廊推进（局部目标 = 走廊节点，不是「最近区域的出口」）
 *
 * 走廊节点序列 Q[0 .. n-1]：
 *   Q[k] = route->portal[k]   (k < n-1)   —— 第 k 段的出口门户点
 *   Q[n-1] = goal_pos                     —— 末端换成真实落点
 * （route->portal[n-1] 是目标区域中心，与 goal_pos 只差一次吸附，改用 goal_pos，
 *   省掉一段「先到中心再去落点」的多余折返。）
 *
 * 为什么要换掉旧语义：旧实现每帧用**当前区域**挑「走廊里离它最近的区域」，
 * 再返回那一段的出口门户。两个问题：
 *   1) 对角线门户是「两个正交门户的中点」，它落在**区域内部**而不是边界上，
 *      单位走到这个点后区域号不变，最近区域仍然是自己，于是又返回同一个点
 *      -> tgt == pos -> walker 直接 break（探针 4/4 未到达的直接原因）。
 *   2) 区域与走廊不是一一对应（门户点可能落在走廊外），最近区域会选中
 *      「已经走过的那一段」，返回一个位于身后的点。
 *
 * 新语义只依赖**位置到节点的距离**，是一条纯函数，不保存任何成员状态：
 *   1) 找最近的走廊节点 Q[k]（平方距离；平手取小下标，避免跨段跳）；
 *   2) 若单位已经越过 Q[k]（(pos-Q[k])·(Q[k+1]-Q[k]) >= 0），游标 +1；
 *   3) 输出 Q[k']（k' == n-1 时输出 goal_pos）。
 * 性质：
 *   - 单调：k 只随前进而增加；越过后自动 +1，不会回到已经走过的节点。
 *   - 不回头：被推离走廊时最近节点不变（侧向偏移不改变最近节点），
 *     目标仍在前方；只有被**推回身后**才会小幅回退，且回退上限是一个节点间距。
 *   - 不回退地重挂：投影用点积判号，不做除法 —— 采样热路径上不允许 div。
 *   - 仍只输出「局部目标点」，不含速度/朝向（那是 Local 层）。
 * 复杂度：O(n) 次平方距离 + 1 次点积，无除法；n = 走廊区域数。
 * ========================================================================== */
/* 回退容差（米）：允许单位最多落在节点后方 0.35 m 仍算越过。
 * 为什么需要容差：避障 / fine flow 绕行会把单位推开几十厘米，
 * 严格 >= 0 会让游标退回上一节点，与绕行方向每帧互相打架（实测 2 帧来回、零推进）。
 * 为什么必须是**绝对**米数而不是段长比例：比例容差（曾用 15%）会让单位提前
 * 1.5 m 就转向下一个节点，在门洞 / 凹角处直接切到墙角上（T9 抓到的穿墙）。
 * 0.35 m ≈ 两次避障位移，既能吃掉抖动又不会提前转向。 */
#define RT_CORRIDOR_BACK_M 0.35f

static int corridor_pick(const RtGroupRoute *gr, RtVec2 goal, RtVec2 pos, int *out_k)
{
    const RtRoute *r = &gr->route;
    int n = r->n;
    if (n <= 0) return 0;
    int last = n - 1;

    /* 1) 最近节点。内层循环不访问 goal，避免每次迭代都做 k==last 判断。 */
    int best = last;
    float bd = 1e30f;
    for (int k = 0; k < last; k++) {
        float dx = pos.x - r->portal[k].x;
        float dz = pos.z - r->portal[k].z;
        float d2 = dx * dx + dz * dz;
        if (d2 < bd) { bd = d2; best = k; }
    }
    {
        float dx = pos.x - goal.x, dz = pos.z - goal.z;
        float d2 = dx * dx + dz * dz;
        if (d2 < bd) { bd = d2; best = last; }
    }

    /* 2) 越过就前进一格。judge = 沿段方向的投影（米），只做点积 + 一次乘，
     *    除法在索引阶段已经折进 seg_invlen。 */
    if (best < last) {
        RtVec2 a = r->portal[best];
        RtVec2 b = corridor_node(r, goal, best + 1);
        float dx = b.x - a.x, dz = b.z - a.z;
        float px = pos.x - a.x, pz = pos.z - a.z;
        float along = px * dx + pz * dz;
        float il = (gr->seg_invlen && best + 1 < gr->seg_n) ? gr->seg_invlen[best + 1] : 0.f;
        if (il > 0.f ? (along * il >= -RT_CORRIDOR_BACK_M) : (along >= 0.f)) best++;
    }

    /* 3) 跳过与当前位置重合的节点。对角门户是「两个正交门户的中点」，
     * 可能与前一个门户重合；不跳过就会输出 tgt == pos（walker 当场停住）。 */
    while (best < last) {
        float dx = pos.x - r->portal[best].x;
        float dz = pos.z - r->portal[best].z;
        if (dx * dx + dz * dz > 1e-6f) break;
        best++;
    }

    if (out_k) *out_k = best;
    return 1;
}

int rt_gw_sample(const RtGroupWorld *w, int group_index, RtVec2 unit_pos, RtVec2 *out_target)
{
    if (!w || !out_target || group_index < 0 || group_index >= w->group_count) return RT_ERR_INVALID;
    RtMoveGroup *g = (RtMoveGroup *)&w->groups[group_index];
    *out_target = g->goal_pos;
    if (g->state == RT_GROUP_UNREACHABLE) return RT_ERR_NOT_FOUND;

    RtGroupRoute *rr = route_for_pos(w, g, unit_pos);
    if (!rr || rr->route.n <= 0) return RT_ERR_NOT_FOUND;

    int k = 0;
    if (!corridor_pick(rr, g->goal_pos, unit_pos, &k)) {
        *out_target = g->goal_pos;
        return RT_OK;
    }
    /* ---- M4.4-B：回看一格 ----
     * fine flow 绕行时单位会被推向节点侧后方，最近节点会短暂退回上一格，
     * 于是「直行目标（上一格节点）」和「绕行方向」每帧互相打架（实测 2 帧来回、
     * 6000 步零推进）。规则：当前段没被封、而下一段被封时，本帧就按下一段算。
     * 这样「绕行中」「绕完」两种情况给出同一个节点，不会来回切。 */
    int kf = k;
    int cur_blocked = (k > 0 && k < rr->route.n && rr->seg_block && rr->seg_block[k]);
    if (k > 0 && !cur_blocked && rr->seg_block &&
        k + 1 < rr->route.n && rr->seg_block[k + 1]) {
        /* 下一节点本身必须站得住：rt_route 在 rt_region_portal() 失败时会退化成
         * 「区域中心」，而区域中心可能正好在墙里。宁可回到当前节点也不要输出
         * 一个不可站的局部目标（M4.2 T2 的「sampled targets are walkable」）。 */
        RtVec2 nk = corridor_node(&rr->route, g->goal_pos, k + 1);
        if (rt_grid_walkable(w->g, rt_grid_cell_x(w->g, nk.x), rt_grid_cell_z(w->g, nk.z)))
            kf = k + 1;
    }
    RtVec2 tgt = corridor_node(&rr->route, g->goal_pos, kf);

    /* ---- M4.4-B：只有「本段被判定直线穿墙」时才可能启用 fine flow ----
     * 未封段是纯字节读（一次 load + 比较），所以开放地图上这一层零成本；
     * 被封段上再做一次**单位级** DDA（段长 ≈ 一格到一格半区域），用于区分
     * 「段被封但本单位这条线是通的」和「本单位也过不去」。
     *
     * 关于 const：这里对 w 做了去掉 const 的转换，只用于写 fine flow 的 memo
     * 缓存与统计计数，不改变任何导航语义（同一输入仍产出同一局部目标）。
     * 采样签名是 M4.2 冻结的不变式，不能为了加缓存而改。 */
    if (w->fine_enabled && kf > 0 && kf < rr->route.n &&
        rr->seg_block && rr->seg_block[kf]) {
        RtGroupWorld *mw = (RtGroupWorld *)w;
        mw->stats.fine_checks++;
        if (!rt_los_clear(w->g, unit_pos, tgt)) {
            int tcx = rt_grid_cell_x(w->g, tgt.x), tcz = rt_grid_cell_z(w->g, tgt.z);
            RtFineFlow *f = fine_get(mw, tcx, tcz, g->clearance_class);
            int ucx = rt_grid_cell_x(w->g, unit_pos.x);
            int ucz = rt_grid_cell_z(w->g, unit_pos.z);
            RtVec2 step;
            if (f && rt_fineflow_next_pos(f, w->g, ucx, ucz, &step)) {
                mw->stats.fine_used++;
                *out_target = step;
                return RT_OK;
            }
            /* 窗口外 / 该格无解：退回节点目标（保守），且必须计数，不许静默 */
            mw->stats.fine_outside++;
        }
    }

    *out_target = tgt;
    return RT_OK;
}

/* 到达分布：黄金角螺旋 + 3 格内吸附到可走格。只为「不要全部堆在一个点」，
 * 刻意不做 slot / formation（题面 §五十四）。 */
RtVec2 rt_gw_arrival_pos(const RtGroupWorld *w, int group_index, int member_index)
{
    if (!w || group_index < 0 || group_index >= w->group_count) return rt_v2(0.f, 0.f);
    const RtMoveGroup *g = &w->groups[group_index];
    if (member_index <= 0) return g->goal_pos;

    float spacing = 0.9f;
    float radius = spacing * sqrtf((float)member_index);
    float ang = (float)member_index * 2.39996323f;   /* 黄金角 */
    RtVec2 p = rt_v2(g->goal_pos.x + cosf(ang) * radius,
                     g->goal_pos.z + sinf(ang) * radius);

    int cx = rt_grid_cell_x(w->g, p.x), cz = rt_grid_cell_z(w->g, p.z);
    float need = rt_clear_radius_m(g->clearance_class);
    if (rt_grid_walkable(w->g, cx, cz) &&
        rt_grid_clearance_m(w->g, cx, cz) + 1e-4f >= need)
        return p;

    /* 3 格内找最近的合法格 */
    for (int ring = 1; ring <= 3; ring++) {
        for (int dz = -ring; dz <= ring; dz++) {
            for (int dx = -ring; dx <= ring; dx++) {
                if (abs(dx) != ring && abs(dz) != ring) continue;
                int x = cx + dx, z = cz + dz;
                if (!rt_grid_walkable(w->g, x, z)) continue;
                if (rt_grid_clearance_m(w->g, x, z) + 1e-4f < need) continue;
                return rt_v2(((float)x + 0.5f) * w->g->cell, ((float)z + 0.5f) * w->g->cell);
            }
        }
    }
    return g->goal_pos;
}

int rt_gw_is_arrived(const RtGroupWorld *w, int group_index, RtVec2 unit_pos, float tol)
{
    if (!w || group_index < 0 || group_index >= w->group_count) return 0;
    const RtMoveGroup *g = &w->groups[group_index];
    float dx = unit_pos.x - g->goal_pos.x, dz = unit_pos.z - g->goal_pos.z;
    return (dx * dx + dz * dz) <= tol * tol;
}

/* ---------------------------- M4.2 诊断（测试/基准用） -------------------- */
int rt_gw_route_cache_count(const RtGroupWorld *w)
{
    return w ? w->route_cache_used : 0;
}

int rt_gw_goal_cache_count(const RtGroupWorld *w)
{
    return w ? w->goal_cache_used : 0;
}

size_t rt_gw_cache_bytes(const RtGroupWorld *w)
{
    if (!w) return 0;
    size_t b = (size_t)RT_ROUTE_CACHE_CAP * sizeof(RtRouteCacheSlot)
             + (size_t)RT_GOAL_CACHE_CAP * sizeof(RtGoalCacheSlot);
    if (w->route_cache) {
        for (int i = 0; i < RT_ROUTE_CACHE_CAP; i++) {
            if (w->route_cache[i].state != 1) continue;
            const RtRoute *r = &w->route_cache[i].route;
            b += (size_t)r->cap * (sizeof(int32_t) + sizeof(RtVec2));
        }
    }
    return b;
}

/* ---------------------------- M4.3 diagnostics ---------------------------- */
void rt_gw_set_flow_threshold(RtGroupWorld *w, int threshold)
{
    if (w) w->flow_threshold = threshold;
}

int rt_gw_flow_count(const RtGroupWorld *w)
{
    if (!w) return 0;
    int n = 0;
    for (int i = 0; i < RT_GOALFLOW_SLOTS; i++) if (w->flows[i].state == 1) n++;
    return n;
}

size_t rt_gw_flow_bytes(const RtGroupWorld *w)
{
    if (!w) return 0;
    size_t b = 0;
    for (int i = 0; i < RT_GOALFLOW_SLOTS; i++) {
        const RtGoalFlow *f = &w->flows[i];
        if (f->state != 1 || !f->dist) continue;
        b += (size_t)f->nregions * (sizeof(float) + sizeof(int32_t));
        b += sizeof(f->dep_mask) + sizeof(f->dep_ver);
    }
    return b;
}

/* ---------------------------- M4.4 diagnostics ---------------------------- */
void rt_gw_set_fine_enabled(RtGroupWorld *w, int on)
{
    if (w) w->fine_enabled = on ? 1 : 0;
}

int rt_gw_fine_count(const RtGroupWorld *w)
{
    if (!w) return 0;
    int n = 0;
    for (int i = 0; i < RT_FINE_SLOTS; i++) if (w->fine[i].state == 1) n++;
    return n;
}

size_t rt_gw_fine_bytes(const RtGroupWorld *w)
{
    if (!w) return 0;
    size_t b = 0;
    for (int i = 0; i < RT_FINE_SLOTS; i++) {
        const RtFineFlow *f = &w->fine[i];
        if (f->state != 1 || !f->next) continue;
        b += RT_FINE_CELLS;
        b += sizeof(f->dep_chunks) + sizeof(f->dep_vers);
    }
    return b;
}

void rt_gw_set_fine_budget(RtGroupWorld *w, int budget)
{
    if (!w) return;
    if (budget < -1) budget = -1;
    w->fine_budget = budget;
    w->fine_budget_left = budget;
}

int rt_gw_fine_budget_left(const RtGroupWorld *w)
{
    return w ? w->fine_budget_left : 0;
}

/* ============================================================================
 * rt_unit.c -- 单位存储实现
 * ==========================================================================*/
#include "rt_unit.h"
#include <string.h>

void rt_units_init(RtUnitStore *s)
{
    if (!s) return;
    memset(s, 0, sizeof(*s));
    for (int i = 0; i < RT_MAX_UNITS; i++) {
        s->next_free[i] = (int16_t)((i + 1 < RT_MAX_UNITS) ? (i + 1) : -1);
    }
    s->free_head = 0;
    s->count = 0;
    s->next_gen = 1;
}

RtUnitId rt_units_spawn(RtUnitStore *s, RtVec3 pos, uint8_t fp)
{
    if (!s) return RT_UNIT_ID_NONE;
    /* 非法 footprint 必须在写入时被抓住，而不是在寻路时表现成诡异行为 */
    if (fp != RT_FP_SMALL && fp != RT_FP_MEDIUM && fp != RT_FP_LARGE)
        return RT_UNIT_ID_NONE;

    if (s->free_head < 0) {
        s->overflow.unit_overflow++;
        return RT_UNIT_ID_NONE;
    }

    int lin = s->free_head;
    s->free_head = s->next_free[lin];

    int ci = lin >> RT_CHUNK_SHIFT;
    int k  = lin & (RT_CHUNK_SIZE - 1);
    RtUnitChunk *c = &s->chunks[ci];

    c->px[k] = pos.x; c->py[k] = pos.y; c->pz[k] = pos.z;
    c->vx[k] = 0.f; c->vy[k] = 0.f; c->vz[k] = 0.f;
    c->pvx[k] = 0.f; c->pvz[k] = 0.f;
    c->radius[k] = (float)fp * 0.5f;   /* ORCA 内切圆 */
    c->yaw[k] = 0.f;
    c->fp[k] = fp;
    c->state[k] = (uint8_t)RT_STATE_IDLE;
    c->group[k] = 0;
    c->layer[k] = 0;
    c->flags[k] = 0;
    c->gen[k] = (uint16_t)(s->next_gen++ & 0xFFFFu);

    s->alive[lin] = 1;
    s->count++;
    return (RtUnitId)(lin + 1);
}

int rt_units_despawn(RtUnitStore *s, RtUnitId id)
{
    if (!s || !rt_units_alive(s, id)) return RT_ERR_NOT_FOUND;

    int lin = (int)(id - 1u);
    int ci = lin >> RT_CHUNK_SHIFT;
    int k  = lin & (RT_CHUNK_SIZE - 1);
    RtUnitChunk *c = &s->chunks[ci];

    /* 先清状态再入 free list：若调用方在 release 后读字段会拿到默认值，
     * 这类「释放后读」在 2D 工程题里造成过一次假断言，这里显式清空。 */
    c->state[k] = (uint8_t)RT_STATE_IDLE;
    c->gen[k] = 0;
    c->flags[k] = 0;

    s->alive[lin] = 0;
    s->next_free[lin] = (int16_t)s->free_head;
    s->free_head = lin;
    s->count--;
    return RT_OK;
}

int rt_units_list_alive(const RtUnitStore *s, RtUnitId *out, int max_out)
{
    if (!s || !out) return 0;
    int n = 0;
    for (int i = 0; i < RT_MAX_UNITS; i++) {
        if (!s->alive[i]) continue;
        if (n >= max_out) break;
        out[n++] = (RtUnitId)(i + 1);
    }
    return n;
}

/* ============================================================================
 * rt_local.c -- ORCA 互避 + 墙体约束（M5）
 *
 * ORCA 的推导不再重抄（见 01 §⑤ 与 _设计验算/design_probe.c S6 的成本探针）；
 * 这里只写实现上必须解释的四个决定：
 *
 * 1. **邻居用自建栅格，不用 RtUnitStore 的空间索引**：局部层不认识 Simulation 的
 *    单位存储（那样会把两层绑死）。栅格每步重建，计数排序，无 malloc。
 * 2. **速度写临时数组再统一生效**：原地写会让「先处理的单位」影响「后处理的单位」，
 *    结果依赖索引顺序（RVO2 也是先算 newVelocity 再 update）。
 * 3. **责任分担 share**：默认 0.5（各让一半）；对不可推动的邻居（inv_mass=0）
 *    取 1.0（自己全让）—— 否则和对墙一样，两边都不动，永远卡住。
 * 4. **墙不进半平面**：ORCA 只管单位之间；墙体用 OBB 精确检查 + 逐轴滑动。
 *    这样永不穿墙，也不会为了躲人把自己挤进墙里。
 * ==========================================================================*/
#include "rt_local.h"
#include "rt_math.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct { RtVec2 point, dir; } RtOrcaLine;

static inline float det2(RtVec2 a, RtVec2 b) { return a.x * b.z - a.z * b.x; }

/* ---------------------------------------------------------------- 栅格 */
static void grid_build(RtLocalCtx *c, const RtLocalAgent *ag, int n)
{
    int cells = c->gw * c->gh;
    memset(c->start, 0, (size_t)(cells + 1) * sizeof(int));
    for (int i = 0; i < n; i++) {
        int gx = (int)(ag[i].pos.x / c->cell);
        int gz = (int)(ag[i].pos.z / c->cell);
        if (gx < 0) gx = 0; else if (gx >= c->gw) gx = c->gw - 1;
        if (gz < 0) gz = 0; else if (gz >= c->gh) gz = c->gh - 1;
        int b = gz * c->gw + gx;
        c->cell_of[i] = b;
        c->start[b + 1]++;
    }
    for (int i = 1; i <= cells; i++) c->start[i] += c->start[i - 1];
    memcpy(c->wr, c->start, (size_t)cells * sizeof(int));
    for (int i = 0; i < n; i++) c->items[c->wr[c->cell_of[i]]++] = i;
}

/* 收集最近的 k 个邻居（距离升序；距离相同按索引，保证确定性） */
static int gather(const RtLocalCtx *c, const RtLocalAgent *ag, int i,
                  int *out, float *outd)
{
    int k = c->max_neighbors;
    if (k > RT_LOCAL_MAX_NEIGHBORS) k = RT_LOCAL_MAX_NEIGHBORS;
    int gx = (int)(ag[i].pos.x / c->cell);
    int gz = (int)(ag[i].pos.z / c->cell);
    if (gx < 0) gx = 0; else if (gx >= c->gw) gx = c->gw - 1;
    if (gz < 0) gz = 0; else if (gz >= c->gh) gz = c->gh - 1;

    float maxd2 = c->neighbor_dist * c->neighbor_dist;
    int nn = 0;

    for (int dz = -1; dz <= 1; dz++) {
        int cz = gz + dz;
        if (cz < 0 || cz >= c->gh) continue;
        for (int dx = -1; dx <= 1; dx++) {
            int cx = gx + dx;
            if (cx < 0 || cx >= c->gw) continue;
            int b = cz * c->gw + cx;
            for (int t = c->start[b]; t < c->start[b + 1]; t++) {
                int j = c->items[t];
                if (j == i) continue;
                float d2 = rt_v2_dist2(ag[i].pos, ag[j].pos);
                if (d2 > maxd2) continue;
                /* 满了且比最远的还远：直接跳过（否则每个候选都要跑一次插入循环） */
                if (nn >= k && d2 >= outd[k - 1]) continue;

                int pos = nn;
                while (pos > 0 && (outd[pos - 1] > d2 ||
                                   (outd[pos - 1] == d2 && out[pos - 1] > j))) {
                    if (pos < k) { out[pos] = out[pos - 1]; outd[pos] = outd[pos - 1]; }
                    pos--;
                }
                if (pos >= k) continue;
                out[pos] = j;
                outd[pos] = d2;
                if (nn < k) nn++;
            }
        }
    }
    return nn;
}

/* ---------------------------------------------------------------- LP */
static int lp1(const RtOrcaLine *lines, int line_no, float radius,
               RtVec2 opt, int dir_opt, RtVec2 *result)
{
    const RtOrcaLine *l = &lines[line_no];
    float dotp = rt_v2_dot(l->point, l->dir);
    float disc = dotp * dotp + radius * radius - rt_v2_len2(l->point);
    if (disc < 0.f) return 0;

    float sq = sqrtf(disc);
    float t_left = -dotp - sq;
    float t_right = -dotp + sq;

    for (int i = 0; i < line_no; i++) {
        float denom = det2(l->dir, lines[i].dir);
        float numer = det2(lines[i].dir, rt_v2_sub(l->point, lines[i].point));
        if (fabsf(denom) <= RT_EPS) {
            if (numer < 0.f) return 0;      /* 平行且不相交 */
            continue;
        }
        float t = numer / denom;
        if (denom >= 0.f) { if (t < t_right) t_right = t; }
        else              { if (t > t_left)  t_left  = t; }
        if (t_left > t_right) return 0;
    }

    if (dir_opt) {
        if (rt_v2_dot(opt, l->dir) > 0.f) *result = rt_v2_add(l->point, rt_v2_mul(l->dir, t_right));
        else                              *result = rt_v2_add(l->point, rt_v2_mul(l->dir, t_left));
    } else {
        float t = rt_v2_dot(l->dir, rt_v2_sub(opt, l->point));
        if (t < t_left)       *result = rt_v2_add(l->point, rt_v2_mul(l->dir, t_left));
        else if (t > t_right) *result = rt_v2_add(l->point, rt_v2_mul(l->dir, t_right));
        else                  *result = rt_v2_add(l->point, rt_v2_mul(l->dir, t));
    }
    return 1;
}

/* 返回「第一条无法满足的约束下标」；== n 表示全部满足 */
static int lp2(const RtOrcaLine *lines, int n, float radius,
               RtVec2 opt, int dir_opt, RtVec2 *result)
{
    if (dir_opt) *result = rt_v2_mul(opt, radius);
    else if (rt_v2_len2(opt) > radius * radius) *result = rt_v2_mul(rt_v2_norm(opt), radius);
    else *result = opt;

    for (int i = 0; i < n; i++) {
        if (det2(lines[i].dir, rt_v2_sub(lines[i].point, *result)) > 0.f) {
            RtVec2 tmp = *result;
            if (!lp1(lines, i, radius, opt, dir_opt, result)) {
                *result = tmp;
                return i;
            }
        }
    }
    return n;
}

/* 约束不可行时：最小化最大违反量（RVO2 linearProgram3） */
static void lp3(const RtOrcaLine *lines, int n, int begin, float radius, RtVec2 *result)
{
    RtOrcaLine proj[2 * RT_LOCAL_MAX_LINES];
    float distance = 0.f;

    for (int i = begin; i < n; i++) {
        if (det2(lines[i].dir, rt_v2_sub(lines[i].point, *result)) > distance) {
            int np = 0;
            for (int j = 0; j < i && np < (int)(sizeof(proj) / sizeof(proj[0])); j++) {
                RtOrcaLine line;
                float d = det2(lines[i].dir, lines[j].dir);
                if (fabsf(d) <= RT_EPS) {
                    if (rt_v2_dot(lines[i].dir, lines[j].dir) > 0.f) continue;
                    line.point = rt_v2_mul(rt_v2_add(lines[i].point, lines[j].point), 0.5f);
                } else {
                    float t = det2(lines[j].dir, rt_v2_sub(lines[i].point, lines[j].point)) / d;
                    line.point = rt_v2_add(lines[i].point, rt_v2_mul(lines[i].dir, t));
                }
                line.dir = rt_v2_norm(rt_v2_sub(lines[j].dir, lines[i].dir));
                proj[np++] = line;
            }
            RtVec2 tmp = *result;
            RtVec2 opt = rt_v2(-lines[i].dir.z, lines[i].dir.x);
            if (lp2(proj, np, radius, opt, 1, result) < np) *result = tmp;
            distance = det2(lines[i].dir, rt_v2_sub(lines[i].point, *result));
        }
    }
}

/* ---------------------------------------------------------------- ORCA 半平面 */
/* 返回 0 = 这条邻接不构成约束（已满足 / 退化），调用方不要把它加进 lines */
static int orca_line(RtOrcaLine *out, const RtLocalAgent *a, const RtLocalAgent *b,
                     float inv_tau, float inv_dt, float share)
{
    RtVec2 rel = rt_v2_sub(b->pos, a->pos);
    RtVec2 rv  = rt_v2_sub(a->vel, b->vel);
    float dist_sq = rt_v2_len2(rel);
    float comb = a->radius + b->radius;
    float comb_sq = comb * comb;
    RtVec2 u;

    if (dist_sq > comb_sq) {
        /* 现在没重叠：投影到「截断圆」或「两条腿」上 */
        RtVec2 w = rt_v2_sub(rv, rt_v2_mul(rel, inv_tau));
        float w_len2 = rt_v2_len2(w);
        float dot1 = rt_v2_dot(w, rel);

        if (dot1 < 0.f && dot1 * dot1 > comb_sq * w_len2) {
            float w_len = sqrtf(w_len2);
            if (w_len < RT_EPS) return 0;
            RtVec2 unit_w = rt_v2_mul(w, 1.f / w_len);
            out->dir = rt_v2(unit_w.z, -unit_w.x);
            u = rt_v2_mul(unit_w, comb * inv_tau - w_len);
        } else {
            float leg = sqrtf(dist_sq - comb_sq);
            if (det2(rel, w) > 0.f) {
                out->dir = rt_v2((rel.x * leg - rel.z * comb) / dist_sq,
                                 (rel.x * comb + rel.z * leg) / dist_sq);
            } else {
                out->dir = rt_v2(-(rel.x * leg + rel.z * comb) / dist_sq,
                                 (rel.x * comb - rel.z * leg) / dist_sq);
            }
            float dot2 = rt_v2_dot(rv, out->dir);
            u = rt_v2_sub(rt_v2_mul(out->dir, dot2), rv);
        }
    } else {
        /* 已经重叠：按一步内分开来解 */
        RtVec2 w = rt_v2_sub(rv, rt_v2_mul(rel, inv_dt));
        float w_len = rt_v2_len(w);
        if (w_len < RT_EPS) return 0;
        RtVec2 unit_w = rt_v2_mul(w, 1.f / w_len);
        out->dir = rt_v2(unit_w.z, -unit_w.x);
        u = rt_v2_mul(unit_w, comb * inv_dt - w_len);
    }

    out->point = rt_v2_add(a->vel, rt_v2_mul(u, share));
    return 1;
}

/* ---------------------------------------------------------------- 墙体 */
static int pos_ok(const RtGrid *g, RtVec2 p, float fp)
{
    if (!g) return 1;
    RtObb2 o = rt_obb_make(p, fp, 0.f);
    return !rt_grid_obb_blocked(g, &o);
}

/* 蹭墙一步（M17）：把期望方向绕一个角度再试，挑**最接近原方向**且不穿墙的那个。
 *
 * 为什么逐轴滑动不够：滑动只在「速度在那个轴上真有分量」时才有效。愿望速度正好
 * 垂直顶向墙角（或者只带 0.01 的横向分量）时，滑动退化成 0.0003 m/帧的蠕行 ——
 * 而它算「滑动成功」，所以连「顶死就停」都不会触发。M17 实测：Z 形通道里单位
 * 停在 (138.99,140.50)，航点已经跳到拐角另一侧 (139.50,135.50)，可 1 m 身体
 * 还差 0.5 m 才进得了竖直臂；pref 满速朝南、前方 0 人，蠕行 0.007 m/帧。
 *
 * 候选角 ±45°/±60°/±90°：±45 够把 OBB 抬过墙线，±90 用于「航点已经拐弯、
 * 身体还卡在这一侧」的情形（实测这一档是必需的，只给 ±60 时它仍然出不去）。
 * 评分 = 与原始方向的方向余弦，取最大者 —— 也就是「能走的方向里最像我想走的方向」。
 * 位移上限仍是 |v|*dt（CON-9 禁传送），每一步都过 pos_ok（永不穿墙）。
 * 确定性：候选顺序固定，候选 dot 相同则先出现者赢（小角度优先）。 */
static int wall_escape_step(const RtGrid *g, RtLocalAgent *a, RtVec2 v, float dt)
{
    static const float kDeg[6] = { 45.f, -45.f, 60.f, -60.f, 90.f, -90.f };
    float speed = rt_v2_len(v);
    if (speed < 1e-6f) return 0;

    float base = atan2f(v.z, v.x);
    float ux = v.x / speed, uz = v.z / speed;
    float best_dot = -2.f;
    RtVec2 best = rt_v2(0.f, 0.f);
    int found = 0;

    for (int k = 0; k < 6; k++) {
        float ang = base + kDeg[k] * (3.14159265f / 180.f);
        RtVec2 d = rt_v2(cosf(ang), sinf(ang));
        float dot = d.x * ux + d.z * uz;
        if (found && dot <= best_dot) continue;        /* 更偏的不用试 */
        RtVec2 np = rt_v2_add(a->pos, rt_v2_mul(d, speed * dt));
        if (!pos_ok(g, np, a->fp)) continue;
        best = d; best_dot = dot; found = 1;
    }
    if (!found) return 0;

    a->pos = rt_v2_add(a->pos, rt_v2_mul(best, speed * dt));
    a->vel = rt_v2_mul(best, speed);
    return 1;
}

/* ---------------------------------------------------------------- 生命周期 */
int rt_local_init(RtLocalCtx *c, float world_w, float world_h, int max_agents,
                  float neighbor_dist)
{
    if (!c || max_agents <= 0) return RT_ERR_INVALID;
    memset(c, 0, sizeof(*c));
    c->neighbor_dist = (neighbor_dist > 0.1f) ? neighbor_dist : 0.1f;
    c->time_horizon = 2.0f;
    c->max_neighbors = RT_LOCAL_MAX_NEIGHBORS;
    c->wall_slide = 1;
    c->wall_escape = 1;
    c->wall_escape_m = 0.8f;
    c->max_accel = 0.f;
    c->cap = max_agents;
    c->cell = c->neighbor_dist;
    c->gw = (int)ceilf(world_w / c->cell);
    c->gh = (int)ceilf(world_h / c->cell);
    if (c->gw < 1) c->gw = 1;
    if (c->gh < 1) c->gh = 1;

    int cells = c->gw * c->gh;
    c->start = (int *)malloc((size_t)(cells + 1) * sizeof(int));
    c->wr = (int *)malloc((size_t)cells * sizeof(int));
    c->items = (int *)malloc((size_t)max_agents * sizeof(int));
    c->cell_of = (int *)malloc((size_t)max_agents * sizeof(int));
    c->newv = (RtVec2 *)malloc((size_t)max_agents * sizeof(RtVec2));
    c->esc_budget = (float *)malloc((size_t)max_agents * sizeof(float));
    if (!c->start || !c->wr || !c->items || !c->cell_of || !c->newv || !c->esc_budget) {
        rt_local_destroy(c);
        return RT_ERR_CAPACITY;
    }
    for (int i = 0; i < max_agents; i++) c->esc_budget[i] = c->wall_escape_m;
    return RT_OK;
}

void rt_local_destroy(RtLocalCtx *c)
{
    if (!c) return;
    free(c->start); free(c->wr); free(c->items); free(c->cell_of); free(c->newv);
    free(c->esc_budget); c->esc_budget = NULL;
    c->start = c->wr = c->items = c->cell_of = NULL;
    c->newv = NULL;
    c->cap = 0;
}

void rt_local_set_params(RtLocalCtx *c, float time_horizon, int max_neighbors,
                         int wall_slide, float max_accel)
{
    if (!c) return;
    if (time_horizon > 0.05f) c->time_horizon = time_horizon;
    if (max_neighbors > 0 && max_neighbors <= RT_LOCAL_MAX_NEIGHBORS)
        c->max_neighbors = max_neighbors;
    c->wall_slide = wall_slide ? 1 : 0;
    c->max_accel = (max_accel > 0.f) ? max_accel : 0.f;
}

/* ---------------------------------------------------------------- step */
int rt_local_step(RtLocalCtx *c, RtLocalAgent *ag, int n, const RtGrid *g, float dt)
{
    if (!c || !ag || n <= 0) return RT_ERR_INVALID;
    if (n > c->cap) return RT_ERR_CAPACITY;
    if (dt <= 0.f) dt = 1.f / 30.f;

    const float inv_dt = 1.f / dt;
    const float inv_tau = 1.f / c->time_horizon;

    grid_build(c, ag, n);

    /* 1. 速度：先算到 newv[]，不写回 —— 否则先处理的单位会影响后处理的单位，
     *    结果依赖索引顺序（RVO2 也是先算 newVelocity 再统一 update）。 */
    for (int i = 0; i < n; i++) {
        RtLocalAgent *a = &ag[i];
        RtVec2 pref = a->pref_vel;
        float pl2 = rt_v2_len2(pref);
        if (pl2 > a->max_speed * a->max_speed) pref = rt_v2_mul(rt_v2_norm(pref), a->max_speed);

        int nb[RT_LOCAL_MAX_NEIGHBORS];
        float nd[RT_LOCAL_MAX_NEIGHBORS];
        int nn = gather(c, ag, i, nb, nd);

        RtOrcaLine lines[RT_LOCAL_MAX_LINES];
        int nl = 0;
        for (int t = 0; t < nn && nl < RT_LOCAL_MAX_LINES; t++) {
            const RtLocalAgent *b = &ag[nb[t]];
            float share = (b->inv_mass > 0.f) ? a->share : 1.f;
            if (orca_line(&lines[nl], a, b, inv_tau, inv_dt, share)) nl++;
        }
        c->stat_lines += (uint32_t)nl;

        RtVec2 nv;
        int fail = lp2(lines, nl, a->max_speed, pref, 0, &nv);
        if (fail < nl) {
            lp3(lines, nl, fail, a->max_speed, &nv);
            c->stat_infeasible++;
        }

        /* 加速度限制（FR-MOV-5）：<=0 表示不限 */
        if (c->max_accel > 0.f) {
            RtVec2 dv = rt_v2_sub(nv, a->vel);
            float maxdv = c->max_accel * dt;
            float l2 = rt_v2_len2(dv);
            if (l2 > maxdv * maxdv) nv = rt_v2_add(a->vel, rt_v2_mul(rt_v2_norm(dv), maxdv));
        }
        /* 防抖（FR-MOV-8）：都不动就真的停住 */
        if (rt_v2_len2(nv) < RT_EPS * RT_EPS && rt_v2_len2(pref) < RT_EPS * RT_EPS)
            nv = rt_v2(0.f, 0.f);

        c->newv[i] = nv;
    }

    /* 2. 墙体约束 + 积分 */
    for (int i = 0; i < n; i++) {
        RtLocalAgent *a = &ag[i];
        RtVec2 v = c->newv[i];
        RtVec2 np = rt_v2_add(a->pos, rt_v2_mul(v, dt));

        if (pos_ok(g, np, a->fp)) {
            a->pos = np;
            a->vel = v;
            /* 正常行驶才回充蹭墙预算（漏桶）。封闭房间里没有「正常行驶」，
             * 所以蹭完 0.8 m 就再也充不上 —— 卡死层照旧能在 10~30 s 给 GAVE_UP。 */
            if (c->esc_budget && c->esc_budget[i] < c->wall_escape_m) {
                c->esc_budget[i] += rt_v2_len(v) * dt;
                if (c->esc_budget[i] > c->wall_escape_m) c->esc_budget[i] = c->wall_escape_m;
            }
            continue;
        }

        c->stat_wall_clamped++;
        if (c->wall_slide) {
            float want = rt_v2_len(v) * dt;
            float got = 0.f;
            RtVec2 bp = a->pos, bv = rt_v2(0.f, 0.f);
            int have = 0;

            RtVec2 px = rt_v2(a->pos.x + v.x * dt, a->pos.z);
            if (pos_ok(g, px, a->fp)) {
                bp = px; bv = rt_v2(v.x, 0.f); got = fabsf(v.x) * dt; have = 1;
            }
            RtVec2 pz = rt_v2(a->pos.x, a->pos.z + v.z * dt);
            if (pos_ok(g, pz, a->fp) && fabsf(v.z) * dt > got) {
                bp = pz; bv = rt_v2(0.f, v.z); got = fabsf(v.z) * dt; have = 1;
            }

            /* 「滑动成功」但只走了意图的一小截 = 事实上的冻住（M17）。
             * 正常擦墙至少能保住一个轴的分量（>35% 的意图位移）；低于它说明
             * 期望方向基本被墙吃掉 —— 继续蹭就是在墙角里爬 0.0003 m/帧，
             * 卡死层会把这当成「没进展」，一路升到 L6 再判放弃。换方向更划算。 */
            if (!have || got < 0.35f * want) {
                if (c->wall_escape && c->esc_budget && c->esc_budget[i] > 0.f &&
                    wall_escape_step(g, a, v, dt)) {
                    c->stat_wall_escape++;
                    c->esc_budget[i] -= rt_v2_len(v) * dt;
                    if (c->esc_budget[i] < 0.f) c->esc_budget[i] = 0.f;
                    continue;
                }
                if (c->wall_escape && c->esc_budget && c->esc_budget[i] <= 0.f)
                    c->stat_escape_denied++;
            }
            if (have) { a->pos = bp; a->vel = bv; continue; }
        }
        a->vel = rt_v2(0.f, 0.f);               /* 顶死：停住（不 teleport） */
    }

    c->stat_steps++;
    return RT_OK;
}

/* ============================================================================
 * probe_m46_merge.c -- 大移除的 merge 路径：成本 + 正确性 + 计数器
 *
 * 背景（19 报告 §5 第 2 条）：
 *   移除大建筑时解锁的格子常常是多块互不相连的空地（建筑底下压着地形/别的建筑）。
 *   旧实现把 unlock 区分成多块就**降级全量**（4.6 ms）。现在按连通块（patch）分别
 *   归属，应该回到亚毫秒，且分区与全量重建逐格一致。
 *
 * 输出：
 *   A. 8x8 ~ 64x64 的加/删各自 apply_dirty 耗时、返回码、计数器增量
 *   B. 每次编辑后与「另一张图全量重建」的划分比对（0 才打印 OK）
 *   C. 同会话的全量参考成本（clearance full + components full）
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c \
 *          _设计验算/probe_m46_merge.c -o probe_m46_merge
 * ==========================================================================*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "rt_grid.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

#define W 256
#define H 256

static RtGrid A, B;
static int32_t map_a2b[20000], map_b2a[20000];

/* 与 test_incremental 相同的口径：比**划分**，不比 id 编号 */
static int partition_equal(void)
{
    for (int i = 0; i < 20000; i++) { map_a2b[i] = -2; map_b2a[i] = -2; }
    for (int z = 0; z < H; z++) {
        for (int x = 0; x < W; x++) {
            size_t i = (size_t)z * W + x;
            int32_t ca = A.component[i], cb = B.component[i];
            if ((ca >= 0) != (cb >= 0)) return 0;
            if (ca < 0) continue;
            if (ca >= 20000 || cb >= 20000) return 0;
            if (map_a2b[ca] == -2) map_a2b[ca] = cb;
            else if (map_a2b[ca] != cb) return 0;
        }
    }
    for (int ca = 0; ca < 20000; ca++) {
        if (map_a2b[ca] == -2) continue;
        int32_t cb = map_a2b[ca];
        if (map_b2a[cb] != -2 && map_b2a[cb] != ca) return 0;
        map_b2a[cb] = ca;
    }
    return 1;
}

static void build_base(RtGrid *g)
{
    rt_grid_init(g, W, H, 1.0f);
    uint64_t st = 0xB5EEDull;
    for (int z = 0; z < H; z++) {
        for (int x = 0; x < W; x++) {
            uint64_t k = (st += 0x9E3779B97F4A7C15ull);
            k = (k ^ (k >> 30)) * 0xBF58476D1CE4E5B9ull;
            k = (k ^ (k >> 27)) * 0x94D049BB133111EBull;
            k ^= k >> 31;
            if ((k >> 40) % 1000 < 100ull) rt_grid_set_terrain(g, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
    }
    for (int z = 0; z < H; z++)
        if (z != 128) rt_grid_set_terrain(g, 128, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int dz = -1; dz <= 1; dz++) {
        rt_grid_set_terrain(g, 127, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(g, 128, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(g, 129, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
    }
    rt_grid_rebuild_all(g);
}

/* 计时：加建筑（每次从「无此建筑」的状态出发） */
static int timed_add(RtGrid *g, int x, int z, int s, double *ms)
{
    double best = 1e30;
    int rc = 0;
    for (int rep = 0; rep < 9; rep++) {
        RtGridDirty d;
        memset(&d, 0, sizeof(d));
        rt_grid_add_building_dirty(g, x, z, s, s, &d);
        double t0 = now_ms();
        rc = rt_grid_apply_dirty(g, &d);
        double dt = now_ms() - t0;
        if (dt < best) best = dt;

        memset(&d, 0, sizeof(d));
        rt_grid_remove_building_dirty(g, x, z, s, s, &d);
        (void)rt_grid_apply_dirty(g, &d);   /* 复原 */
    }
    *ms = best;
    return rc;
}

/* 计时：拆建筑（每次先把建筑加上去，再计时移除）。*full 只统计「移除这一步」的降级次数。 */
static int timed_remove(RtGrid *g, int x, int z, int s, double *ms, uint32_t *full)
{
    double best = 1e30;
    int rc = 0;
    uint32_t acc = 0;
    for (int rep = 0; rep < 9; rep++) {
        RtGridDirty d;
        memset(&d, 0, sizeof(d));
        rt_grid_add_building_dirty(g, x, z, s, s, &d);
        (void)rt_grid_apply_dirty(g, &d);

        memset(&d, 0, sizeof(d));
        rt_grid_remove_building_dirty(g, x, z, s, s, &d);
        uint32_t before = g->full_rebuild_count;
        double t0 = now_ms();
        rc = rt_grid_apply_dirty(g, &d);
        double dt = now_ms() - t0;
        acc += g->full_rebuild_count - before;
        if (dt < best) best = dt;
    }
    *ms = best;
    *full = acc;
    return rc;
}

int main(void)
{
    timer_init();
    build_base(&A);
    build_base(&B);
    printf("=== M4.6-P4 probe: large removal merge ===\n");
    printf("map %dx%d, base components=%d, active=%d\n", W, H, A.component_count, A.active_components);

    /* C. 同会话的全量参考成本（旧路径降级后要付的两个 O(w*h)） */
    {
        double bc = 1e30, bm = 1e30;
        for (int i = 0; i < 7; i++) {
            double t0 = now_ms(); rt_grid_rebuild_clearance_full(&A);       double dt = now_ms() - t0;
            if (dt < bc) bc = dt;
            t0 = now_ms();        rt_grid_rebuild_components_full(&A);     dt = now_ms() - t0;
            if (dt < bm) bm = dt;
        }
        printf("\n-- C. full rebuild reference (same session) --\n");
        printf("  clearance full = %.3f ms | components full = %.3f ms | sum = %.3f ms\n",
               bc, bm, bc + bm);
    }

    printf("\n-- A/B. add/remove apply_dirty (9 reps, best) --\n");
    printf("  %-8s %9s %4s %9s %5s %8s %7s %7s %8s  %s\n",
           "edit", "add ms", "rc", "del ms", "rc", "delFull", "multiP", "mpFall", "repScan", "partition");

    int sizes[8] = { 8, 12, 16, 20, 24, 32, 48, 64 };
    for (int k = 0; k < 8; k++) {
        int s = sizes[k];
        int x = 50 + (k % 3) * 5, z = 40 + k * 12;
        if (z + s >= H) z = 20;

        uint32_t mp0 = A.merge_multipatch_count;
        uint32_t fb0 = A.merge_multipatch_fallbacks, rs0 = A.relabel_rep_rescan;
        uint32_t sd0 = A.split_detected_count, sf0 = A.split_fail_seeds;

        double add_ms = 0, del_ms = 0;
        uint32_t delfull = 0;
        int rc_add = timed_add(&A, x, z, s, &add_ms);
        int rc_del = timed_remove(&A, x, z, s, &del_ms, &delfull);

        /* 正确性：同一次编辑分别走增量(A) / 全量(B)，比划分。
         * 注意 A 在 timed_apply 结束后已复原，这里重新施加一次（不计时）。 */
        RtGridDirty d;
        memset(&d, 0, sizeof(d));
        rt_grid_add_building_dirty(&A, x, z, s, s, &d);
        (void)rt_grid_apply_dirty(&A, &d);
        memset(&d, 0, sizeof(d));
        rt_grid_add_building_dirty(&B, x, z, s, s, &d);
        (void)rt_grid_apply_dirty(&B, &d);
        int ok_add = partition_equal();

        memset(&d, 0, sizeof(d));
        rt_grid_remove_building_dirty(&A, x, z, s, s, &d);
        (void)rt_grid_apply_dirty(&A, &d);
        memset(&d, 0, sizeof(d));
        rt_grid_remove_building_dirty(&B, x, z, s, s, &d);
        (void)rt_grid_apply_dirty(&B, &d);
        int ok_del = partition_equal();

        printf("  %2dx%-6d %9.4f %4d %9.4f %5d %8u %7u %7u %8u  add=%s del=%s  seedsFail+%u splitDet+%u\n",
               s, s, add_ms, rc_add, del_ms, rc_del, delfull,
               A.merge_multipatch_count - mp0,
               A.merge_multipatch_fallbacks - fb0,
               A.relabel_rep_rescan - rs0,
               ok_add ? "OK" : "BAD", ok_del ? "OK" : "BAD",
               A.split_fail_seeds - sf0, A.split_detected_count - sd0);
    }

    printf("\n-- totals --\n");
    printf("  full_rebuild=%u  merge_multipatch=%u  mp_fallbacks=%u  rep_rescan=%u  splitFailSeeds=%u\n",
           A.full_rebuild_count, A.merge_multipatch_count, A.merge_multipatch_fallbacks,
           A.relabel_rep_rescan, A.split_fail_seeds);

    rt_grid_destroy(&A);
    rt_grid_destroy(&B);
    return 0;
}

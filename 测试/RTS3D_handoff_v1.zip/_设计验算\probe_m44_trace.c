/* 临时：M4.4-A 诊断 —— 打印 U 形陷阱里 corridor 与 sample 的实际返回
 * 只用于定位，不进产品代码。跑完可删。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;

static int seg_clear(RtVec2 a, RtVec2 b)
{
    float dx = b.x - a.x, dz = b.z - a.z;
    float len = sqrtf(dx * dx + dz * dz);
    int steps = (int)(len / 0.5f) + 1;
    for (int i = 0; i <= steps; i++) {
        float t = (float)i / (float)steps;
        int cx = rt_grid_cell_x(&G, a.x + dx * t), cz = rt_grid_cell_z(&G, a.z + dz * t);
        if (!rt_grid_walkable(&G, cx, cz)) return 0;
    }
    return 1;
}

static void build_trap(void)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int z = 50; z <= 110; z++) {
        for (int x = 90; x <= 140; x++) {
            int wall = 0;
            if (z == 50 || z == 110) wall = 1;
            if (x == 90) wall = 1;
            if (x >= 110 && x <= 118 && z >= 70 && z <= 78) wall = 1;
            if (wall) rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
    }
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
}

int main(void)
{
    build_trap();
    RtUnitId ids[4];
    int n = 0;
    float starts[4][2] = { {100.5f, 60.5f}, {100.5f, 100.5f}, {130.5f, 60.5f}, {130.5f, 100.5f} };
    for (int i = 0; i < 4; i++)
        ids[n++] = rt_units_spawn(&US, rt_v3(starts[i][0], 0.f, starts[i][1]), RT_FP_SMALL);

    RtVec2 dest = rt_v2(200.5f, 80.5f);
    rt_gw_command(&W, &US, ids, n, dest, 0, RT_CLS_SMALL, 1);
    printf("groups=%d route_count=%d goal_region=%d goal=(%.1f,%.1f)\n",
           W.group_count, W.groups[0].route_count, W.groups[0].goal_region,
           W.groups[0].goal_pos.x, W.groups[0].goal_pos.z);

    for (int r = 0; r < W.groups[0].route_count; r++) {
        RtRoute *rt = &W.groups[0].routes[r].route;
        printf("\nroute[%d] start_region=%d n=%d cost=%.2f\n", r, rt->start_region, rt->n, rt->cost);
        for (int i = 0; i < rt->n; i++) {
            int rx = rt->regions[i] % MAP.rw, rz = rt->regions[i] / MAP.rw;
            printf("   [%2d] region=%5d (rx=%2d rz=%2d) portal=(%6.1f,%6.1f) center=(%6.1f,%6.1f)\n",
                   i, rt->regions[i], rx, rz,
                   rt->portal[i].x, rt->portal[i].z,
                   rt_region_center(&MAP, rt->regions[i]).x, rt_region_center(&MAP, rt->regions[i]).z);
        }
    }

    printf("\n--- walk trace ---\n");
    for (int u = 0; u < n; u++) {
        RtVec3 p0 = rt_units_pos(&US, ids[u]);
        RtVec2 p = rt_v2(p0.x, p0.z);
        RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[u]);
        int gi = (int)ch->group[rt_unit_slot_index(ids[u])] - 1;
        printf("\nunit%d gi=%d\n", u, gi);
        int arrived = 0;
        for (int i = 0; i < 60 && !arrived; i++) {
            RtVec2 tgt;
            if (rt_gw_sample(&W, gi, p, &tgt) != RT_OK) { printf("  sample ERR\n"); break; }
            int cur = rt_region_of_world(&MAP, p.x, p.z);
            RtVec2 d = rt_v2_sub(tgt, p);
            float len = rt_v2_len(d);
            printf("  step%02d pos=(%6.2f,%6.2f) cur_region=%5d tgt=(%6.1f,%6.1f) len=%.2f\n",
                   i, p.x, p.z, cur, tgt.x, tgt.z, len);
            if (len < 1e-4f) { printf("  -> tgt==pos, STOP\n"); break; }
            float step = 6.0f / 30.0f;
            if (step > len) step = len;
            RtVec2 np = rt_v2_add(p, rt_v2_mul(d, step / len));
            if (!seg_clear(p, np)) { printf("  -> BLOCKED\n"); break; }
            p = np;
            if (rt_gw_is_arrived(&W, gi, p, 1.5f)) { printf("  -> ARRIVED\n"); arrived = 1; }
        }
    }

    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return 0;
}

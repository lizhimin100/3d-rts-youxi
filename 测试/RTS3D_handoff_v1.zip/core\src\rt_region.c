/* ============================================================================
 * rt_region.c -- 粗粒度区域图实现
 * ==========================================================================*/
#include "rt_region.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

static const float kRadius[RT_CLEAR_CLASSES] = { 0.5f, 1.0f, 2.0f, 4.0f };

float rt_clear_radius_m(int cls)
{
    if (cls < 0) cls = 0;
    if (cls >= RT_CLEAR_CLASSES) cls = RT_CLEAR_CLASSES - 1;
    return kRadius[cls];
}

int rt_clear_class_for_diameter(float meters)
{
    /* 直径 d -> 半径 d/2，取能容纳它的最小类别 */
    float r = meters * 0.5f;
    for (int c = 0; c < RT_CLEAR_CLASSES; c++)
        if (r <= kRadius[c] + 1e-4f) return c;
    return RT_CLEAR_CLASSES - 1;
}

/* ---------------------------------------------------------------------------
 * 单个区域的聚合：只读本区域 px×px 的格子。
 *
 * 与 M4.1 的全量两遍扫描**逐字段等价**：扫描顺序同为 z 升序、x 升序，
 * 所以 anchor 的平手 tie-break（离区域中心更近者胜）结果一致；
 * mixed 的参照是「本区域第一个可走格」，也与原实现相同。
 * 全量与增量共用这一份实现，避免两条路径漂移（M4.6-P2 的关键决定）。
 * ------------------------------------------------------------------------- */
static void region_aggregate(RtRegionMap *m, int r, int rx, int rz)
{
    RtGrid *g = m->g;
    int px = m->px;
    int x0 = rx * px, x1 = x0 + px;
    int z0 = rz * px, z1 = z0 + px;
    if (x1 > g->w) x1 = g->w;
    if (z1 > g->h) z1 = g->h;

    int ccx = x0 + px / 2, ccz = z0 + px / 2;
    uint16_t maxc = 0;
    int32_t first = -1;
    int mixed = 0;
    int ax = -1, az = -1;

    for (int z = z0; z < z1; z++) {
        const size_t row = (size_t)z * g->w;
        for (int x = x0; x < x1; x++) {
            if (!rt_grid_walkable(g, x, z)) continue;
            uint16_t c = g->clearance[row + x];
            if (c > maxc) maxc = c;

            int32_t cid = g->component[row + x];
            if (first < 0) first = cid;
            else if (cid >= 0 && cid != first) mixed = 1;

            if (ax < 0) { ax = x; az = z; }
            else {
                uint16_t bc = g->clearance[(size_t)az * g->w + ax];
                if (c > bc ||
                    (c == bc && (abs(x - ccx) + abs(z - ccz)) <
                                 (abs(ax - ccx) + abs(az - ccz)))) {
                    ax = x; az = z;
                }
            }
        }
    }

    m->maxclear[r] = maxc;
    m->anchor_x[r] = (int16_t)ax;
    m->anchor_z[r] = (int16_t)az;
    m->mixed[r] = (uint8_t)mixed;
    /* comp **必须**与 anchor 一致（M4.1 bug#5：孤岛墙导致 comp 与锚点不同源） */
    m->comp[r] = (ax < 0) ? -1 : g->component[(size_t)az * g->w + ax];

    float maxcm = (float)maxc * 0.01f;
    for (int c = 0; c < RT_CLEAR_CLASSES; c++)
        m->pass[(size_t)r * RT_CLEAR_CLASSES + c] = (maxcm + 1e-4f >= kRadius[c]) ? 1 : 0;
}

/* 分量被重标号（merge/split）之后，mixed 可能在整个图上变化：
 * 原本「跨 A/B 两个分量」的区域，在 A、B 合并后变成单一分量。
 * 这种区域可能离编辑点很远（1 格厚的长墙两侧全是 mixed），
 * 所以只能全扫；带早退，绝大多数区域读几个格就命中。 */
static void region_mixed_rescan(RtRegionMap *m)
{
    RtGrid *g = m->g;
    int px = m->px;
    int nr = m->rw * m->rh;
    for (int r = 0; r < nr; r++) {
        int ax = m->anchor_x[r], az = m->anchor_z[r];
        if (ax < 0) { m->mixed[r] = 0; continue; }
        int32_t cid = g->component[(size_t)az * g->w + ax];
        int rx = r % m->rw, rz = r / m->rw;
        int x0 = rx * px, x1 = x0 + px;
        int z0 = rz * px, z1 = z0 + px;
        if (x1 > g->w) x1 = g->w;
        if (z1 > g->h) z1 = g->h;
        int mixed = 0;
        for (int z = z0; z < z1 && !mixed; z++) {
            const size_t row = (size_t)z * g->w;
            for (int x = x0; x < x1; x++) {
                if (!rt_grid_walkable(g, x, z)) continue;
                int32_t c = g->component[row + x];
                if (c >= 0 && c != cid) { mixed = 1; break; }
            }
        }
        m->mixed[r] = (uint8_t)mixed;
    }
}

int rt_region_build(RtRegionMap *m, RtGrid *g, int px)
{
    if (!m || !g) return RT_ERR_INVALID;
    if (px < 2) px = 2;
    if (px > 64) px = 64;

    int rw = (g->w + px - 1) / px;
    int rh = (g->h + px - 1) / px;
    if (rw * rh > RT_MAX_REGIONS) return RT_ERR_CAPACITY;

    /* 尺寸变化 -> 重新分配；否则复用（避免每帧 malloc，§七十六） */
    if (m->px != px || m->rw != rw || m->rh != rh || !m->pass) {
        rt_region_destroy(m);
        size_t nr = (size_t)rw * rh;
        m->pass = (uint8_t *)calloc(nr * RT_CLEAR_CLASSES, 1);
        m->maxclear = (uint16_t *)calloc(nr, sizeof(uint16_t));
        m->comp = (int32_t *)malloc(nr * sizeof(int32_t));
        m->mixed = (uint8_t *)calloc(nr, 1);
        m->anchor_x = (int16_t *)malloc(nr * sizeof(int16_t));
        m->anchor_z = (int16_t *)malloc(nr * sizeof(int16_t));
        m->chunk_snap = (uint32_t *)calloc(RT_CHUNK_N, sizeof(uint32_t));
        if (!m->pass || !m->maxclear || !m->comp || !m->mixed ||
            !m->anchor_x || !m->anchor_z) {
            rt_region_destroy(m);
            return RT_ERR_CAPACITY;
        }
        m->px = px; m->rw = rw; m->rh = rh;
        m->bytes = nr * (RT_CLEAR_CLASSES + sizeof(uint16_t) + sizeof(int32_t) + 1
                         + 2 * sizeof(int16_t))
                   + (size_t)RT_CHUNK_N * sizeof(uint32_t);
    } else if (!m->chunk_snap) {
        /* 上次分配失败：重试。没有快照时 refresh_rect 一律整图重建（正确但慢）。 */
        m->chunk_snap = (uint32_t *)calloc(RT_CHUNK_N, sizeof(uint32_t));
    }

    m->g = g;

    /* 一遍区域聚合即可写满全部字段（M4.6-P2）：
     * 原实现是「清零 + 全图逐格累计 + 第二遍修 comp + 第三遍量化」，
     * 现在每个区域的聚合是它自己的 px² 个格子，天然可增量。 */
    for (int rz = 0; rz < rh; rz++)
        for (int rx = 0; rx < rw; rx++)
            region_aggregate(m, rz * rw + rx, rx, rz);

    m->built_epoch = g->nav_epoch;
    m->built_label_epoch = g->label_epoch;
    m->built_active_comps = g->active_components;
    if (m->chunk_snap)
        memcpy(m->chunk_snap, g->chunk_ver, sizeof(uint32_t) * RT_CHUNK_N);
    m->last_full_reason = 0;
    return RT_OK;
}

void rt_region_destroy(RtRegionMap *m)
{
    if (!m) return;
    free(m->pass);        m->pass = NULL;
    free(m->maxclear);    m->maxclear = NULL;
    free(m->comp);        m->comp = NULL;
    free(m->mixed);       m->mixed = NULL;
    free(m->anchor_x);    m->anchor_x = NULL;
    free(m->anchor_z);    m->anchor_z = NULL;
    free(m->chunk_snap);  m->chunk_snap = NULL;
    m->px = m->rw = m->rh = 0;
    m->bytes = 0;
    m->built_epoch = 0;
    m->built_label_epoch = 0;
    m->built_active_comps = 0;
    m->last_full_reason = 0;
    m->refresh_calls = m->refresh_regions = m->refresh_full = 0;
    m->refresh_widened = m->mixed_rescans = 0;
}

int rt_region_refresh(RtRegionMap *m)
{
    if (!m || !m->g) return RT_ERR_INVALID;
    if (m->built_epoch == m->g->nav_epoch && m->pass) return RT_OK;
    m->refresh_calls++;
    m->refresh_full++;
    int rc = rt_region_build(m, m->g, m->px ? m->px : 8);
    if (rc == RT_OK) m->refresh_regions += (uint32_t)(m->rw * m->rh);
    return rc;
}

int rt_region_refresh_rect(RtRegionMap *m, int x0, int z0, int x1, int z1)
{
    if (!m || !m->g) return RT_ERR_INVALID;
    RtGrid *g = m->g;
    if (!m->pass) return rt_region_build(m, g, m->px ? m->px : 8);
    if (g->w <= 0 || g->h <= 0) return RT_ERR_INVALID;

    if (x0 > x1) { int t = x0; x0 = x1; x1 = t; }
    if (z0 > z1) { int t = z0; z0 = z1; z1 = t; }
    if (x0 < 0) x0 = 0;
    if (z0 < 0) z0 = 0;
    if (x1 >= g->w) x1 = g->w - 1;
    if (z1 >= g->h) z1 = g->h - 1;
    if (x0 > x1 || z0 > z1) { m->last_full_reason = 0; return 0; }

    int px = m->px;
    int rx0 = x0 / px, rx1 = x1 / px;
    int rz0 = z0 / px, rz1 = z1 / px;
    if (rx1 >= m->rw) rx1 = m->rw - 1;
    if (rz1 >= m->rh) rz1 = m->rh - 1;

    m->refresh_calls++;
    m->last_full_reason = 0;

    int need_full = 0;
    if (!m->chunk_snap) need_full = 1;                                /* 无快照：无法复核 */
    else if (m->built_label_epoch != g->label_epoch) need_full = 1;   /* GC 重编号 */

    if (!need_full) {
        /* 安全网：矩形必须覆盖所有 chunk 版本变化。覆盖不了说明调用方给的 dirty
         * 不完整（或 grid 内部降级成了全量重建）—— 正确性优先，扩成整图。
         *
         * ⚠ chunk 下标必须用 rt_grid_chunk_of_cell() 的**动态宽度**
         *   cw = ceil(w / 32)，不是常量 RT_CHUNKC_W。
         *   小地图（256）上 cw = 8，用 32 会算到另一组下标去，
         *   结果每一帧都误判「矩形外有变化」——实测 400 次编辑里 381 次误扩成全量。 */
        int cw = (g->w + RT_CHUNK_PX - 1) / RT_CHUNK_PX;
        int chh = (g->h + RT_CHUNK_PX - 1) / RT_CHUNK_PX;
        int cx0 = (rx0 * px) / RT_CHUNK_PX;
        int cx1 = ((rx1 + 1) * px - 1) / RT_CHUNK_PX;
        int cz0 = (rz0 * px) / RT_CHUNK_PX;
        int cz1 = ((rz1 + 1) * px - 1) / RT_CHUNK_PX;
        if (cx1 >= cw) cx1 = cw - 1;
        if (cz1 >= chh) cz1 = chh - 1;
        for (int cz = 0; cz < chh && !need_full; cz++) {
            for (int cx = 0; cx < cw; cx++) {
                int c = cz * cw + cx;
                if (c >= RT_CHUNK_N) break;
                if (g->chunk_ver[c] == m->chunk_snap[c]) continue;
                if (cx < cx0 || cx > cx1 || cz < cz0 || cz > cz1) { need_full = 2; break; }
            }
        }
    }

    if (need_full) {
        m->refresh_full++;
        if (need_full == 2) m->refresh_widened++;
        int rc = rt_region_build(m, g, px);
        if (rc != RT_OK) return rc;
        m->last_full_reason = (uint8_t)need_full;   /* build 会清零，必须在之后写 */
        m->refresh_regions += (uint32_t)(m->rw * m->rh);
        return m->rw * m->rh;
    }

    int n = 0;
    for (int rz = rz0; rz <= rz1; rz++) {
        for (int rx = rx0; rx <= rx1; rx++) {
            region_aggregate(m, rz * m->rw + rx, rx, rz);
            n++;
        }
    }

    /* merge/split 会重标号，可能改到矩形之外的区域（1 格厚长墙的两侧全是 mixed）。
     * active_components 变了就说明发生了重标号：comp 全部重指，mixed 全量重扫。 */
    if (m->built_active_comps != g->active_components) {
        int nr = m->rw * m->rh;
        for (int r = 0; r < nr; r++) {
            int ax = m->anchor_x[r], az = m->anchor_z[r];
            m->comp[r] = (ax < 0) ? -1 : g->component[(size_t)az * g->w + ax];
        }
        region_mixed_rescan(m);
        m->built_active_comps = g->active_components;
        m->mixed_rescans++;
    }

    if (m->chunk_snap)
        memcpy(m->chunk_snap, g->chunk_ver, sizeof(uint32_t) * RT_CHUNK_N);
    m->built_epoch = g->nav_epoch;
    m->built_label_epoch = g->label_epoch;
    m->refresh_regions += (uint32_t)n;
    return n;
}

int rt_region_of_cell(const RtRegionMap *m, int x, int z)
{
    if (!m || !m->g) return -1;
    if (!rt_grid_in_bounds(m->g, x, z)) return -1;
    return rt_region_index(m, x / m->px, z / m->px);
}

int rt_region_of_world(const RtRegionMap *m, float wx, float wz)
{
    if (!m || !m->g) return -1;
    return rt_region_of_cell(m, rt_grid_cell_x(m->g, wx), rt_grid_cell_z(m->g, wz));
}

RtVec2 rt_region_center(const RtRegionMap *m, int region)
{
    int rx = region % m->rw, rz = region / m->rw;
    float x = ((float)rx + 0.5f) * m->px * m->g->cell;
    float z = ((float)rz + 0.5f) * m->px * m->g->cell;
    return rt_v2(x, z);
}

RtVec2 rt_region_anchor(const RtRegionMap *m, int region)
{
    if (!m || !m->g || region < 0 || region >= m->rw * m->rh) return rt_v2(0.f, 0.f);
    int ax = m->anchor_x[region], az = m->anchor_z[region];
    if (ax < 0 || az < 0) return rt_region_center(m, region);
    /* 用格中心（+0.5）而不是格角，避免采样点落在格子边界上 */
    return rt_v2(((float)ax + 0.5f) * m->g->cell, ((float)az + 0.5f) * m->g->cell);
}

int rt_region_edge_ok(const RtRegionMap *m, int r1, int r2, int cls)
{
    if (!m || !m->g) return 0;
    if (!rt_region_passable(m, r1, cls) || !rt_region_passable(m, r2, cls)) return 0;

    int ax = r1 % m->rw, az = r1 / m->rw;
    int bx = r2 % m->rw, bz = r2 / m->rw;
    int dx = bx - ax, dz = bz - az;
    if (dx < -1 || dx > 1 || dz < -1 || dz > 1 || (dx == 0 && dz == 0)) return 0;

    RtGrid *g = m->g;
    int px = m->px;
    float need = kRadius[cls];

    /* 取两区域共享边界上的一排格，检查每一对相邻格 */
    if (dz == 0 && dx != 0) {
        int xa = (dx > 0) ? (ax * px + px - 1) : (ax * px);
        int xb = xa + dx;
        for (int k = 0; k < px; k++) {
            int z = az * px + k;
            if (z >= g->h) break;
            if (!rt_grid_walkable(g, xa, z) || !rt_grid_walkable(g, xb, z)) continue;
            if (rt_grid_clearance_m(g, xa, z) + 1e-4f < need) continue;
            if (rt_grid_clearance_m(g, xb, z) + 1e-4f < need) continue;
            return 1;
        }
        return 0;
    }
    if (dx == 0 && dz != 0) {
        int za = (dz > 0) ? (az * px + px - 1) : (az * px);
        int zb = za + dz;
        for (int k = 0; k < px; k++) {
            int x = ax * px + k;
            if (x >= g->w) break;
            if (!rt_grid_walkable(g, x, za) || !rt_grid_walkable(g, x, zb)) continue;
            if (rt_grid_clearance_m(g, x, za) + 1e-4f < need) continue;
            if (rt_grid_clearance_m(g, x, zb) + 1e-4f < need) continue;
            return 1;
        }
        return 0;
    }

    /* 对角：要求「横 + 竖」两条边都通（与 cell 层防穿角同语义） */
    int horiz = rt_region_index(m, ax + dx, az);
    int vert  = rt_region_index(m, ax, az + dz);
    if (horiz < 0 || vert < 0) return 0;
    return rt_region_edge_ok(m, r1, horiz, cls) && rt_region_edge_ok(m, r1, vert, cls) &&
           rt_region_edge_ok(m, horiz, r2, cls) && rt_region_edge_ok(m, vert, r2, cls);
}

int rt_region_portal(const RtRegionMap *m, int r1, int r2, int cls, RtVec2 *out)
{
    if (!m || !m->g || !out) return 0;
    int ax = r1 % m->rw, az = r1 / m->rw;
    int bx = r2 % m->rw, bz = r2 / m->rw;
    int dx = bx - ax, dz = bz - az;
    if (dx < -1 || dx > 1 || dz < -1 || dz > 1 || (dx == 0 && dz == 0)) return 0;

    RtGrid *g = m->g;
    int px = m->px;
    float need = kRadius[cls];
    float best = -1.f;
    RtVec2 bp = rt_region_center(m, r2);

    if (dz == 0 && dx != 0) {
        int xa = (dx > 0) ? (ax * px + px - 1) : (ax * px);
        int xb = xa + dx;
        for (int k = 0; k < px; k++) {
            int z = az * px + k;
            if (z >= g->h) break;
            if (!rt_grid_walkable(g, xa, z) || !rt_grid_walkable(g, xb, z)) continue;
            float ca = rt_grid_clearance_m(g, xa, z), cb = rt_grid_clearance_m(g, xb, z);
            float mn = ca < cb ? ca : cb;
            if (mn + 1e-4f < need) continue;
            if (mn > best) {
                best = mn;
                bp = rt_v2(((float)xb + 0.5f) * g->cell, ((float)z + 0.5f) * g->cell);
            }
        }
        if (best < 0.f) return 0;
        *out = bp;
        return 1;
    }
    if (dx == 0 && dz != 0) {
        int za = (dz > 0) ? (az * px + px - 1) : (az * px);
        int zb = za + dz;
        for (int k = 0; k < px; k++) {
            int x = ax * px + k;
            if (x >= g->w) break;
            if (!rt_grid_walkable(g, x, za) || !rt_grid_walkable(g, x, zb)) continue;
            float ca = rt_grid_clearance_m(g, x, za), cb = rt_grid_clearance_m(g, x, zb);
            float mn = ca < cb ? ca : cb;
            if (mn + 1e-4f < need) continue;
            if (mn > best) {
                best = mn;
                bp = rt_v2(((float)x + 0.5f) * g->cell, ((float)zb + 0.5f) * g->cell);
            }
        }
        if (best < 0.f) return 0;
        *out = bp;
        return 1;
    }
    /* 对角：取两个相邻边界的中点（两个正交边都通才用） */
    RtVec2 p1, p2;
    int h1 = rt_region_index(m, ax + dx, az);
    int v1 = rt_region_index(m, ax, az + dz);
    int ok1 = (h1 >= 0) ? rt_region_portal(m, r1, h1, cls, &p1) : 0;
    int ok2 = (v1 >= 0) ? rt_region_portal(m, r1, v1, cls, &p2) : 0;
    if (ok1 && ok2) { *out = rt_v2((p1.x + p2.x) * 0.5f, (p1.z + p2.z) * 0.5f); return 1; }
    if (ok1) { *out = p1; return 1; }
    if (ok2) { *out = p2; return 1; }
    return 0;
}

int rt_region_nearest_passable(const RtRegionMap *m, int region, int cls, int max_ring)
{
    if (!m || region < 0) return -1;
    if (rt_region_passable(m, region, cls)) return region;
    int cx = region % m->rw, cz = region / m->rw;
    int best = -1, best_d = 1 << 30;
    for (int ring = 1; ring <= max_ring && best < 0; ring++) {
        for (int dz = -ring; dz <= ring; dz++) {
            for (int dx = -ring; dx <= ring; dx++) {
                if (abs(dx) != ring && abs(dz) != ring) continue;
                int x = cx + dx, z = cz + dz;
                if (x < 0 || z < 0 || x >= m->rw || z >= m->rh) continue;
                int r = rt_region_index(m, x, z);
                if (!rt_region_passable(m, r, cls)) continue;
                int d = dx * dx + dz * dz;
                if (d < best_d) { best_d = d; best = r; }
            }
        }
    }
    return best;
}

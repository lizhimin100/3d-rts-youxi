/* ============================================================================
 * bench_m16.c -- 落脚点五级搜索的成本（FR-FOR-5）
 *
 * 只有一个问题：**命令时**各花多久。它不在 tick 里，所以判据不是 8 ms，
 * 而是「点一下鼠标不要卡住」（经验上 < 30 ms 无感）。
 *
 * 场景与 test_m16 一一对应（这里的数字和报告里的表是同一套口径）：
 *   L0 空地 / L1 墙心 / L2 45° 斜带 / L3 3 m 隧道 / L4 5x12 压缩 / L5 口袋
 * 另外给 4x4 大 footprint 与 400 人两行，用来看扫描量随 n 与候选数的增长。
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_math.h"
#include "rt_form.h"
#include "rt_grid.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

/* ---- 与 test_m16 相同的解析探针 ---- */
typedef struct {
    RtAabb2 solids[8];
    int     ns;
    float   wx, wz;
} SolidWorld;

static int solid_state(void *ud, const RtObb2 *o)
{
    SolidWorld *w = (SolidWorld *)ud;
    RtAabb2 bb = rt_obb_aabb(o);
    if (bb.min_x < 0.f || bb.min_z < 0.f || bb.max_x > w->wx || bb.max_z > w->wz) return 2;
    for (int i = 0; i < w->ns; i++)
        if (rt_obb_overlaps_aabb(o, &w->solids[i])) return 1;
    return 0;
}

typedef struct {
    RtAabb2 free_r[8];
    int     nf;
    float   wx, wz;
} TunnelWorld;

static int tunnel_state(void *ud, const RtObb2 *o)
{
    TunnelWorld *w = (TunnelWorld *)ud;
    RtVec2 c[4];
    rt_obb_corners(o, c);
    for (int i = 0; i < 4; i++)
        if (c[i].x < 0.f || c[i].z < 0.f || c[i].x > w->wx || c[i].z > w->wz) return 2;
    for (int r = 0; r < w->nf; r++) {
        const RtAabb2 *b = &w->free_r[r];
        int in = 1;
        for (int i = 0; i < 4; i++)
            if (c[i].x < b->min_x - 1e-4f || c[i].x > b->max_x + 1e-4f ||
                c[i].z < b->min_z - 1e-4f || c[i].z > b->max_z + 1e-4f) { in = 0; break; }
        if (in) return 0;
    }
    return 1;
}

typedef struct {
    RtVec2 c;
    float  nx, nz, half_w, half_len, wx, wz;
} BandWorld;

static int band_state(void *ud, const RtObb2 *o)
{
    BandWorld *b = (BandWorld *)ud;
    RtAabb2 bb = rt_obb_aabb(o);
    if (bb.min_x < 0.f || bb.min_z < 0.f || bb.max_x > b->wx || bb.max_z > b->wz) return 2;
    float dx = o->center.x - b->c.x, dz = o->center.z - b->c.z;
    float ax = o->cos_a, az = o->sin_a, bx = -o->sin_a, bz = o->cos_a;
    float hn = fabsf(b->nx * ax + b->nz * az) * o->half.x + fabsf(b->nx * bx + b->nz * bz) * o->half.z;
    if (fabsf(dx * b->nx + dz * b->nz) + hn > b->half_w + 1e-4f) return 1;
    float tx = -b->nz, tz = b->nx;
    float ht = fabsf(tx * ax + tz * az) * o->half.x + fabsf(tx * bx + tz * bz) * o->half.z;
    if (fabsf(dx * tx + dz * tz) + ht > b->half_len + 1e-4f) return 1;
    return 0;
}

/* ---- 计时 ---- */
static int cmp_double(const void *a, const void *b)
{
    double x = *(const double *)a, y = *(const double *)b;
    return (x < y) ? -1 : (x > y) ? 1 : 0;
}

static void run_case_rings(const char *name, int count, float fp, float gap,
                           RtVec2 anchor, float yaw, const RtFormProbe *p, int reps,
                           int rings, int orbit)
{
    static RtFormation F;
    static double t[64];
    if (reps > 64) reps = 64;

    RtFormPlaceStat s;
    memset(&s, 0, sizeof(s));

    RtFormPlaceCfg cfg;
    rt_form_place_default(&cfg);
    cfg.rings = rings;
    if (orbit != 0) cfg.orbit_rings = orbit;   /* -1 = 关闭，用于 L5 的 A/B */

    rt_form_destroy(&F);
    rt_form_init(&F, count > 512 ? count : 512);

    for (int r = 0; r < reps; r++) {
        double t0 = now_ms();
        rt_form_place(&F, count, fp, gap, anchor, yaw, p, &cfg, &s);
        t[r] = now_ms() - t0;
    }
    double sum = 0.0, mx = 0.0;
    for (int r = 0; r < reps; r++) { sum += t[r]; if (t[r] > mx) mx = t[r]; }
    qsort(t, (size_t)reps, sizeof(double), cmp_double);
    double med = t[reps / 2];

    printf("%-30s n=%-4d fp=%-3.0f L%d evals=%-6d median=%7.3f ms  mean=%7.3f  max=%7.3f\n",
           name, count, fp, s.level, s.evals, med, sum / (double)reps, mx);
    rt_form_destroy(&F);
}

static void run_case(const char *name, int count, float fp, float gap,
                     RtVec2 anchor, float yaw, const RtFormProbe *p, int reps)
{
    run_case_rings(name, count, fp, gap, anchor, yaw, p, reps, 40, 0);
}

int main(void)
{
    timer_init();
    printf("=== M16 bench: formation landing search (command-time only) ===\n");
    printf("machine: i5-10210U (低压 4 核), zig -O2；每行 10~20 次重复，取中位数\n\n");

    /* L0 空地 */
    SolidWorld open_w;
    memset(&open_w, 0, sizeof(open_w));
    open_w.wx = open_w.wz = 256.f;
    RtFormProbe p_open = { &open_w, solid_state };
    run_case("L0 open field", 100, 1.f, 1.f, rt_v2(128.f, 128.f), 0.f, &p_open, 20);
    run_case("L0 open field", 400, 1.f, 1.f, rt_v2(128.f, 128.f), 0.f, &p_open, 20);

    /* L1 墙心 */
    SolidWorld wall_w = open_w;
    wall_w.ns = 1;
    wall_w.solids[0].min_x = 124.f; wall_w.solids[0].max_x = 132.f;
    wall_w.solids[0].min_z = 124.f; wall_w.solids[0].max_z = 132.f;
    RtFormProbe p_wall = { &wall_w, solid_state };
    run_case("L1 anchor in 8x8 building", 100, 1.f, 1.f, rt_v2(128.f, 128.f), 0.f, &p_wall, 20);
    run_case("L1 anchor in 8x8 building", 100, 4.f, 1.f, rt_v2(128.f, 128.f), 0.f, &p_wall, 20);

    /* L2 45° 斜带 */
    BandWorld band;
    memset(&band, 0, sizeof(band));
    band.c = rt_v2(128.f, 128.f);
    band.nx = 0.70710678f; band.nz = 0.70710678f;
    band.half_w = 7.5f; band.half_len = 45.f;
    band.wx = band.wz = 256.f;
    RtFormProbe p_band = { &band, band_state };
    run_case("L2 45-deg band (w=15)", 49, 1.f, 1.f, rt_v2(128.f, 128.f), 0.f, &p_band, 20);

    /* L3 3 m 隧道：100 人纵队 200 m，隧道给 230 m */
    TunnelWorld tun;
    memset(&tun, 0, sizeof(tun));
    tun.nf = 1;
    tun.free_r[0].min_x = 10.f; tun.free_r[0].max_x = 240.f;
    tun.free_r[0].min_z = 30.f; tun.free_r[0].max_z = 33.f;
    tun.wx = tun.wz = 256.f;
    RtFormProbe p_tun = { &tun, tunnel_state };
    run_case("L3 3 m tunnel, n=100 @r=0", 100, 1.f, 1.f, rt_v2(220.f, 31.5f), 0.f, &p_tun, 20);
    run_case_rings("L3 3 m tunnel, n=20 @r=36", 20, 1.f, 1.f, rt_v2(12.f, 31.5f), 0.f, &p_tun, 20, 60, 0);

    /* L4 5x12 隧道，fp=2 */
    TunnelWorld tun4;
    memset(&tun4, 0, sizeof(tun4));
    tun4.nf = 1;
    tun4.free_r[0].min_x = 40.f; tun4.free_r[0].max_x = 52.f;
    tun4.free_r[0].min_z = 30.f; tun4.free_r[0].max_z = 35.f;
    tun4.wx = tun4.wz = 256.f;
    RtFormProbe p_tun4 = { &tun4, tunnel_state };
    run_case("L4 5x12 tunnel (compress)", 9, 2.f, 1.f, rt_v2(46.f, 32.5f), 0.f, &p_tun4, 20);

    /* L5 6x6 口袋 + 100 人 */
    TunnelWorld pocket;
    memset(&pocket, 0, sizeof(pocket));
    pocket.nf = 1;
    pocket.free_r[0].min_x = 125.f; pocket.free_r[0].max_x = 131.f;
    pocket.free_r[0].min_z = 125.f; pocket.free_r[0].max_z = 131.f;
    pocket.wx = pocket.wz = 256.f;
    RtFormProbe p_pocket = { &pocket, tunnel_state };
    run_case("L5 6x6 pocket (partial)", 100, 1.f, 1.f, rt_v2(128.f, 128.f), 0.f, &p_pocket, 10);
    run_case_rings("L5 pocket, orbit OFF (A/B)", 100, 1.f, 1.f, rt_v2(128.f, 128.f), 0.f, &p_pocket, 10, 40, -1);

    /* L5 全实心：最坏情况（每一级都要扫完） */
    TunnelWorld solid;
    memset(&solid, 0, sizeof(solid));
    solid.wx = solid.wz = 256.f;
    RtFormProbe p_solid = { &solid, tunnel_state };
    run_case("L5 fully solid (worst case)", 100, 1.f, 1.f, rt_v2(128.f, 128.f), 0.f, &p_solid, 10);
    run_case_rings("L5 solid, orbit OFF (A/B)", 100, 1.f, 1.f, rt_v2(128.f, 128.f), 0.f, &p_solid, 10, 40, -1);

    /* 网格适配器：确认胶水层不额外收费 */
    static RtGrid G;
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int z = 0; z < 256; z++)
        for (int x = 0; x < 256; x++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN,
                                (x < 10 || x > 240 || z < 30 || z > 33) ? 1 : 0);
    rt_grid_rebuild_all(&G);
    RtFormProbe p_grid;
    rt_form_probe_grid(&p_grid, &G);
    run_case("L3 tunnel via RtGrid adapter", 100, 1.f, 1.f, rt_v2(220.f, 31.5f), 0.f, &p_grid, 20);
    rt_grid_destroy(&G);

    printf("\n读法：L0 只做 1 次评估；L1~L4 的候选按切比雪夫半径递增，坏候选在第 1~2 个槽短路；\n");
    printf("      L5 要对每个候选做完整扫描（要算 cost），所以是最贵的一级。\n");
    return 0;
}

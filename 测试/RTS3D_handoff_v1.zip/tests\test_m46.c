/* ============================================================================
 * test_m46.c -- M4.6：fine flow 建场分帧（P1）+ 区域图增量刷新（P2）
 *
 * P1：M4.4 的采样路径会在**第一次遍历**里连建多个 fine flow（实测 3 个，
 * 13.9 µs/个 → 0.04 ms 的帧尖峰），把 cold 采样推到 0.173~0.187 ms，越过 0.16 硬线。
 * 现在建场改成「每次 command / update 之后最多建 budget 个」：
 *   - 采样路径不再可能一次建多个场（尖峰变成定额）；
 *   - 预算用尽时退回「节点 + 直线」并计 fine_budget_skip（不静默）；
 *   - 缓存命中不消耗预算，所以稳态不受影响。
 *
 * M1 预算生效：budget=1 时首次遍历只建 1 个场，其余计入 skip
 * M2 无限预算对照：同一场景 budget=-1 时首次遍历建 >=2 个场（证明 M1 不是「本来只要 1 个」）
 * M3 跨帧补齐：每次 rt_gw_update 续一帧额度，最终把需要的场全部建出来，skip 停止增长
 * M4 budget=0：只查缓存、绝不建场；采样仍返回合法局部目标
 * M5 语义不回退：T2 场景（直线被挡）在 budget=1 + 每帧 update 下仍 4/4 到达、0 穿墙
 *
 * P2：区域图（RtRegionMap）每次编辑全量重建 0.4~0.9 ms。改成按 dirty 矩形增量：
 * M6 增量 == 整图：120 次随机 add/remove，逐字段比较（pass/maxclear/comp/mixed/anchor）
 * M7 成本：矩形刷新至少比整图便宜 3×，且只碰 < 1/4 的区域
 * M8 安全网：矩形外的 chunk 变化必须被抓住并扩成整图
 * M9 label_epoch 变化（GC 重编号）必须整图重建
 * M10 端到端：走到一半建墙，route 失效重建，4/4 绕行、0 穿墙
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m46.c -o test_m46
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", m); } } while (0)

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;

static void world_reset(int w)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_grid_init(&G, w, w, 1.0f);
}

static void world_build(void)
{
    rt_grid_rebuild_all(&G);
    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
}

/* bench_m42 同图：10% 噪声 + 竖墙 + 3 格门（这张图首次遍历会触发多个建场） */
static void map_noisy_wall(void)
{
    world_reset(256);
    uint64_t st = 0xC0FFEEull + 257ull;
    for (int z = 0; z < 256; z++)
        for (int x = 0; x < 256; x++) {
            uint64_t k = (st += 0x9E3779B97F4A7C15ull);
            k = (k ^ (k >> 30)) * 0xBF58476D1CE4E5B9ull;
            k = (k ^ (k >> 27)) * 0x94D049BB133111EBull;
            k ^= k >> 31;
            if ((k >> 40) % 1000 < 100ull) rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
    for (int z = 0; z < 256; z++)
        if (z != 128) rt_grid_set_terrain(&G, 128, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int dz = -1; dz <= 1; dz++) {
        rt_grid_set_terrain(&G, 127, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, 128, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, 129, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
    }
    world_build();
}

static int spawn_disc(RtUnitId *ids, int n, float cx, float cz, float r)
{
    int k = 0;
    for (int i = 0; i < n * 4 && k < n; i++) {
        float rad = r * sqrtf((float)i / (float)(n * 4));
        float ang = (float)i * 2.39996323f;
        int x = rt_grid_cell_x(&G, cx + cosf(ang) * rad);
        int z = rt_grid_cell_z(&G, cz + sinf(ang) * rad);
        if (!rt_grid_walkable(&G, x, z)) continue;
        RtUnitId id = rt_units_spawn(&US, rt_v3((float)x + 0.5f, 0.f, (float)z + 0.5f), RT_FP_SMALL);
        if (id != RT_UNIT_ID_NONE) ids[k++] = id;
    }
    return k;
}

/* 一次完整采样遍历（就是游戏里的一帧） */
static double sample_pass(const RtUnitId *ids, int n, volatile float *acc)
{
    double t0 = now_ms();
    for (int i = 0; i < n; i++) {
        RtVec3 p = rt_units_pos(&US, ids[i]);
        RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[i]);
        int gi = (int)ch->group[rt_unit_slot_index(ids[i])] - 1;
        RtVec2 tgt;
        if (gi >= 0 && rt_gw_sample(&W, gi, rt_v2(p.x, p.z), &tgt) == RT_OK) *acc += tgt.x;
    }
    return now_ms() - t0;
}

/* ========================================================================== */
static uint32_t run_first_pass(int budget, int *out_units)
{
    map_noisy_wall();
    rt_gw_set_fine_budget(&W, budget);
    static RtUnitId ids[1024];
    int n = spawn_disc(ids, 1000, 50.f, 60.f, 12.f);
    rt_gw_command(&W, &US, ids, n, rt_v2(210.5f, 190.5f), 0, RT_CLS_SMALL, 1);
    volatile float acc = 0.f;
    (void)sample_pass(ids, n, &acc);
    if (out_units) *out_units = n;
    return W.stats.fine_builds;
}

static void m1_budget_caps_first_pass(void)
{
    printf("\n[M1] 预算生效：首次遍历最多建 budget 个场\n");
    int n = 0;
    uint32_t b1 = run_first_pass(1, &n);
    uint32_t skip1 = W.stats.fine_budget_skip;
    uint32_t used1 = W.stats.fine_used;
    printf("  budget=1 : units=%d builds=%u skip=%u used=%u\n", n, b1, skip1, used1);
    OK(n == 1000, "M1 1000 units spawned");
    OK(b1 == 1, "M1 budget=1 -> exactly one build in the first pass");
    OK(skip1 >= 1, "M1 the rest are counted as fine_budget_skip (not silently dropped)");
}

static void m2_unlimited_reference(void)
{
    printf("\n[M2] 对照：budget=-1（M4.4 旧行为）在同一场景会建多个场\n");
    int n = 0;
    uint32_t b = run_first_pass(-1, &n);
    printf("  budget=-1: units=%d builds=%u skip=%u\n", n, b, W.stats.fine_budget_skip);
    OK(b >= 2, "M2 unlimited budget builds >= 2 fields in one pass (so M1 is a real cap)");
    OK(W.stats.fine_budget_skip == 0, "M2 unlimited budget never skips");
}

static void m3_refill_across_frames(void)
{
    printf("\n[M3] 跨帧补齐：每次 rt_gw_update 续一帧额度\n");
    map_noisy_wall();
    rt_gw_set_fine_budget(&W, 1);
    static RtUnitId ids[1024];
    int n = spawn_disc(ids, 1000, 50.f, 60.f, 12.f);
    rt_gw_command(&W, &US, ids, n, rt_v2(210.5f, 190.5f), 0, RT_CLS_SMALL, 1);

    volatile float acc = 0.f;
    uint32_t prev_builds = 0, prev_skip = 0;
    int frames = 0;
    for (int f = 0; f < 8; f++) {
        (void)sample_pass(ids, n, &acc);
        frames = f + 1;
        uint32_t b = W.stats.fine_builds, s = W.stats.fine_budget_skip;
        printf("  frame%d : builds=%u (+%u) skip=%u (+%u) budget_left=%d\n",
               f, b, b - prev_builds, s, s - prev_skip, rt_gw_fine_budget_left(&W));
        prev_builds = b; prev_skip = s;
        if (f < 7) rt_gw_update(&W);          /* 下一帧 */
    }
    printf("  after %d frames: builds=%u skip=%u\n", frames, W.stats.fine_builds, W.stats.fine_budget_skip);
    OK(W.stats.fine_builds >= 2, "M3 fields accumulate across frames (budget refilled by update)");
    OK(rt_gw_fine_count(&W) <= RT_FINE_SLOTS, "M3 fine flow slots bounded");
}

static void m4_budget_zero(void)
{
    printf("\n[M4] budget=0：只查缓存，绝不建场\n");
    map_noisy_wall();
    rt_gw_set_fine_budget(&W, 0);
    static RtUnitId ids[1024];
    int n = spawn_disc(ids, 1000, 50.f, 60.f, 12.f);
    rt_gw_command(&W, &US, ids, n, rt_v2(210.5f, 190.5f), 0, RT_CLS_SMALL, 1);
    volatile float acc = 0.f;
    double ms = sample_pass(ids, n, &acc);
    printf("  budget=0 : builds=%u skip=%u used=%u sample=%.4f ms\n",
           W.stats.fine_builds, W.stats.fine_budget_skip, W.stats.fine_used, ms);
    OK(W.stats.fine_builds == 0, "M4 budget=0 builds nothing");
    OK(W.stats.fine_budget_skip > 0, "M4 blocked samples are counted as skipped");
    OK(ms > 0.0, "M4 sampling still runs (no hang, no NaN path)");
}

/* ---- M5：语义不回退（斜向薄墙，直线被挡）---- */static int seg_clear(RtVec2 a, RtVec2 b)
{
    float dx = b.x - a.x, dz = b.z - a.z;
    float len = sqrtf(dx * dx + dz * dz);
    int steps = (int)(len / 0.25f) + 1;
    for (int i = 0; i <= steps; i++) {
        float t = (float)i / (float)steps;
        int cx = rt_grid_cell_x(&G, a.x + dx * t), cz = rt_grid_cell_z(&G, a.z + dz * t);
        if (!rt_grid_walkable(&G, cx, cz)) return 0;
    }
    return 1;
}

static void m5_semantics_kept(void)
{
    printf("\n[M5] 分帧之后语义不回退：斜向薄墙 4 单位仍全部到达\n");
    world_reset(256);
    for (int i = 0; i < 8; i++)
        for (int t = 0; t < 2; t++)
            rt_grid_set_terrain(&G, 64 + i, 80 + i + t, RT_CELL_BLOCKED_TERRAIN, 1);
    world_build();
    rt_gw_set_fine_budget(&W, 1);

    static RtUnitId ids[4];
    RtVec2 s[4] = { { 20.5f, 76.5f }, { 20.5f, 83.5f }, { 20.5f, 90.5f }, { 30.5f, 83.5f } };
    for (int i = 0; i < 4; i++)
        ids[i] = rt_units_spawn(&US, rt_v3(s[i].x, 0.f, s[i].z), RT_FP_SMALL);
    rt_gw_command(&W, &US, ids, 4, rt_v2(230.5f, 84.5f), 0, RT_CLS_SMALL, 1);
    RtVec2 goal = W.groups[0].goal_pos;

    int arrived = 0, penetrated = 0, deferred_frames = 0;
    for (int u = 0; u < 4; u++) {
        RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[u]);
        int gi = (int)ch->group[rt_unit_slot_index(ids[u])] - 1;
        RtVec2 p = s[u];
        int arr = 0, pen = 0;
        for (int step = 0; step < 6000 && !arr; step++) {
            RtVec2 tgt;
            if (rt_gw_sample(&W, gi, p, &tgt) != RT_OK) break;
            RtVec2 d = rt_v2_sub(tgt, p);
            float len = rt_v2_len(d);
            if (len < 1e-4f) break;
            float st = 0.2f;
            if (st > len) st = len;
            RtVec2 np = rt_v2_add(p, rt_v2_mul(d, st / len));
            if (!seg_clear(p, np)) { pen = 1; break; }
            p = np;
            if (rt_gw_is_arrived(&W, gi, p, 1.5f)) arr = 1;
            if (W.stats.fine_budget_skip > 0 && !arr) deferred_frames++;
            rt_gw_update(&W);                 /* 每帧续额度，模拟游戏循环 */
        }
        if (arr) arrived++;
        if (pen) penetrated++;
    }
    printf("  arrived=%d/4 penetrated_units=%d builds=%u skip=%u goal=(%.1f,%.1f)\n",
           arrived, penetrated, W.stats.fine_builds, W.stats.fine_budget_skip, goal.x, goal.z);
    OK(arrived == 4, "M5 all 4 units still arrive with a 1-per-frame build budget");
    OK(penetrated == 0, "M5 no wall penetration");
    OK(W.stats.fine_builds >= 1, "M5 a fine flow was actually built (test is not vacuous)");
}

/* ==========================================================================
 * M4.6-P2：区域图增量刷新（rt_region_refresh_rect / rt_gw_note_edit）
 *
 * 这一组测试的核心不是「跑得快」，而是「增量 == 整图」：
 * 每次编辑后拿一张整图重建的参照表逐字段比较 pass/maxclear/comp/mixed/anchor。
 * 只要有一个区域不一致，M6 就失败 —— 快而错等于没做。
 * ========================================================================== */
static RtRegionMap REF;

/* 返回不一致的区域数；0 = 与整图重建逐字段相同 */
static int region_cmp(void)
{
    int nr = MAP.rw * MAP.rh, bad = 0;
    for (int r = 0; r < nr; r++) {
        if (MAP.maxclear[r] != REF.maxclear[r]) { bad++; continue; }
        if (MAP.comp[r] != REF.comp[r]) { bad++; continue; }
        if (MAP.mixed[r] != REF.mixed[r]) { bad++; continue; }
        if (MAP.anchor_x[r] != REF.anchor_x[r] || MAP.anchor_z[r] != REF.anchor_z[r]) { bad++; continue; }
        for (int c = 0; c < RT_CLEAR_CLASSES; c++)
            if (MAP.pass[r * 4 + c] != REF.pass[r * 4 + c]) { bad++; break; }
    }
    return bad;
}

static uint64_t r_st = 0x20261020ull;
static uint32_t rnd(void)
{
    r_st += 0x9E3779B97F4A7C15ull;
    uint64_t k = r_st;
    k = (k ^ (k >> 30)) * 0xBF58476D1CE4E5B9ull;
    k = (k ^ (k >> 27)) * 0x94D049BB133111EBull;
    return (uint32_t)(k ^ (k >> 31));
}

/* 地形：噪声 + 一条竖墙 + 一条横墙（长墙会制造大量 mixed 区域和整片的重标号） */
static void map_region_stress(void)
{
    world_reset(256);
    uint64_t st = 0x1357ull;
    for (int z = 0; z < 256; z++)
        for (int x = 0; x < 256; x++) {
            uint64_t k = (st += 0x9E3779B97F4A7C15ull);
            k = (k ^ (k >> 30)) * 0xBF58476D1CE4E5B9ull;
            k = (k ^ (k >> 27)) * 0x94D049BB133111EBull;
            k ^= k >> 31;
            if ((k >> 40) % 1000 < 50ull) rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
    for (int z = 40; z < 200; z++) rt_grid_set_terrain(&G, 60, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int x = 60; x < 200; x++) rt_grid_set_terrain(&G, x, 150, RT_CELL_BLOCKED_TERRAIN, 1);
    world_build();
}

static void m6_incremental_equals_full(void)
{
    printf("\n[M6] 增量区域图 == 整图重建（随机 add/remove 120 次，逐字段）\n");
    map_region_stress();
    rt_region_build(&REF, &G, 8);
    int bad0 = region_cmp();

    enum { MAXB = 256 };
    static int bx[MAXB], bz[MAXB], bw[MAXB], bh[MAXB];
    int nb = 0, edits = 0, bad = 0, full = 0, widened = 0;
    uint32_t calls0 = MAP.refresh_calls;
    uint32_t regs0 = MAP.refresh_regions;

    for (int it = 0; it < 120; it++) {
        RtGridDirty d;
        memset(&d, 0, sizeof(d));
        int do_remove = (nb > 0) && (rnd() % 100 < 35);
        if (do_remove) {
            int i = (int)(rnd() % (uint32_t)nb);
            if (rt_grid_remove_building_dirty(&G, bx[i], bz[i], bw[i], bh[i], &d) != RT_OK) continue;
            bx[i] = bx[nb - 1]; bz[i] = bz[nb - 1]; bw[i] = bw[nb - 1]; bh[i] = bh[nb - 1];
            nb--;
        } else {
            int w = 2 + (int)(rnd() % 5), h = 2 + (int)(rnd() % 5);
            int x = 2 + (int)(rnd() % 250), z = 2 + (int)(rnd() % 250);
            if (x + w > 256) x = 256 - w;
            if (z + h > 256) z = 256 - h;
            if (rt_grid_add_building_dirty(&G, x, z, w, h, &d) != RT_OK) continue;
            if (nb < MAXB) { bx[nb] = x; bz[nb] = z; bw[nb] = w; bh[nb] = h; nb++; }
        }
        if (rt_grid_apply_dirty(&G, &d) != RT_OK) {
            rt_region_refresh(&MAP);            /* grid 内部降级全量：区域图跟上 */
            full++;
        } else {
            if (rt_gw_note_edit(&W, &d) != RT_OK) { bad++; break; }
            if (W.stats.region_widened) widened++;
        }
        edits++;
        rt_region_build(&REF, &G, 8);
        if (region_cmp() != 0) bad++;
    }

    uint32_t calls = MAP.refresh_calls - calls0;
    uint32_t regs = MAP.refresh_regions - regs0;
    double avg = calls ? (double)regs / (double)calls : 0.0;
    printf("  initial_diff=%d edits=%d mismatched=%d grid_full=%d widened=%d\n",
           bad0, edits, bad, full, widened);
    printf("  refresh calls=%u regions=%u avg=%.1f/%d  mixed_rescans=%u\n",
           calls, regs, avg, MAP.rw * MAP.rh, MAP.mixed_rescans);
    OK(bad0 == 0, "M6 baseline map identical");
    OK(edits >= 100, "M6 enough edits executed");
    OK(bad == 0, "M6 incremental refresh is field-identical to a full rebuild");
    OK(avg < (double)(MAP.rw * MAP.rh) * 0.5, "M6 average refreshed regions < half of the map");
    OK(widened == 0, "M6 complete dirty never triggers the widening safety net");
}

static void m7_region_cost(void)
{
    printf("\n[M7] 成本：整图重建 vs 矩形刷新\n");
    map_region_stress();
    RtGridDirty d;
    memset(&d, 0, sizeof(d));

    /* 2x2 建筑：反复 remove/add 同一位置 */
    double best_full = 1e30, best_rect = 1e30;
    int regs = 0;
    for (int rep = 0; rep < 21; rep++) {
        rt_grid_add_building_dirty(&G, 100, 100, 2, 2, &d);
        rt_grid_apply_dirty(&G, &d);
        double t0 = now_ms();
        rt_region_refresh(&MAP);
        double dt = now_ms() - t0;
        if (dt < best_full) best_full = dt;

        rt_grid_remove_building_dirty(&G, 100, 100, 2, 2, &d);
        rt_grid_apply_dirty(&G, &d);
        t0 = now_ms();
        regs = rt_region_refresh_rect(&MAP, d.cx0, d.cz0, d.cx1, d.cz1);
        dt = now_ms() - t0;
        if (dt < best_rect) best_rect = dt;
    }
    printf("  2x2: full=%.4f ms  rect=%.4f ms  x%.1f  regions=%d/%d\n",
           best_full, best_rect, best_full / (best_rect > 1e-9 ? best_rect : 1e-9),
           regs, MAP.rw * MAP.rh);
    OK(best_rect * 3.0 < best_full, "M7 rect refresh is at least 3x cheaper than a full rebuild");
    OK(regs > 0 && regs < MAP.rw * MAP.rh / 4, "M7 rect refresh touches < 1/4 of the regions");
}

static void m8_widening_safety_net(void)
{
    printf("\n[M8] 安全网：dirty 裁到 chunk 内/外\n");
    map_region_stress();
    RtGridDirty d;
    memset(&d, 0, sizeof(d));

    /* 跨 chunk 的编辑（x=63..66 跨 chunk 1/2），只上报 x=63 */
    rt_grid_add_building_dirty(&G, 63, 100, 4, 4, &d);
    rt_grid_apply_dirty(&G, &d);
    int n = rt_region_refresh_rect(&MAP, 63, 100, 63, 103);
    rt_region_build(&REF, &G, 8);
    printf("  cross-chunk: regions=%d reason=%u equal=%d\n", n, MAP.last_full_reason, region_cmp() == 0);
    OK(MAP.last_full_reason == 2, "M8 changes outside the rect are detected at chunk granularity");
    OK(region_cmp() == 0, "M8 widened rebuild is still identical to a full rebuild");

    /* 另一半：矩形覆盖全图时也必须正确（不能因为「几乎全量」而算错） */
    rt_grid_add_building_dirty(&G, 20, 20, 180, 180, &d);
    int rc_apply = rt_grid_apply_dirty(&G, &d);
    int n2 = rt_region_refresh_rect(&MAP, d.cx0, d.cz0, d.cx1, d.cz1);
    rt_region_build(&REF, &G, 8);
    printf("  whole-map  : apply_rc=%d regions=%d/%d equal=%d\n",
           rc_apply, n2, MAP.rw * MAP.rh, region_cmp() == 0);
    OK(n2 > 0, "M8 whole-map rect refresh runs");
    OK(region_cmp() == 0, "M8 whole-map rect refresh equals a full rebuild");
}

static void m9_label_epoch_forces_full(void)
{
    printf("\n[M9] label_epoch 变化（id 空间重编号）必须整图重建\n");
    map_region_stress();
    RtGridDirty d;
    memset(&d, 0, sizeof(d));
    rt_grid_add_building_dirty(&G, 90, 90, 3, 3, &d);
    rt_grid_apply_dirty(&G, &d);

    G.label_epoch++;                  /* 模拟 GC 重编号 */
    int rc = rt_gw_note_edit(&W, &d);
    rt_region_build(&REF, &G, 8);
    printf("  rc=%d reason=%u regions=%u equal=%d\n",
           rc, MAP.last_full_reason, MAP.refresh_calls, region_cmp() == 0);
    OK(rc == RT_OK, "M9 note_edit returns ok");
    OK(MAP.last_full_reason == 1, "M9 label_epoch change forces a full rebuild");
    OK(region_cmp() == 0, "M9 full rebuild equals reference");
}

/* ---- M10：编辑真实生效（封住正在走的那道门，单位改走另一道）----
 *
 * 场景刻意把墙**对齐到 8 m 区域边界**（x=120 是 8 的倍数）：
 * 区域层只能表达「整块可通行/不可通行」，细墙落在区域内部时走廊会横穿它，
 * 那是 M4.4 fine flow 的职责（且只在 ±12 格内），不适合用来验收 P2。
 * 这里要验证的是：编辑 -> 区域图增量 -> route 失效重建 -> 改道，整条链路通。 */
static void m10_edit_end_to_end(void)
{
    printf("\n[M10] 端到端：封住正在走的大门 -> note_edit -> update -> 改走另一道门\n");
    world_reset(256);
    /* x=120 一堵竖墙，留两道 3 格高（24 m）的门：z=40..63 与 z=104..127 */
    for (int z = 0; z < 256; z++) {
        if ((z >= 40 && z <= 63) || (z >= 104 && z <= 127)) continue;
        rt_grid_set_terrain(&G, 120, z, RT_CELL_BLOCKED_TERRAIN, 1);
    }
    world_build();
    rt_gw_set_fine_budget(&W, 1);

    static RtUnitId ids[4];
    RtVec2 s[4] = { { 20.5f, 44.5f }, { 20.5f, 48.5f }, { 20.5f, 52.5f }, { 20.5f, 56.5f } };
    for (int i = 0; i < 4; i++)
        ids[i] = rt_units_spawn(&US, rt_v3(s[i].x, 0.f, s[i].z), RT_FP_SMALL);
    rt_gw_command(&W, &US, ids, 4, rt_v2(230.5f, 50.5f), 0, RT_CLS_SMALL, 1);

    int arrived = 0, penetrated = 0, edited = 0;
    uint32_t inval = 0, rect_refresh = 0;
    for (int u = 0; u < 4; u++) {
        RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[u]);
        int gi = (int)ch->group[rt_unit_slot_index(ids[u])] - 1;
        RtVec2 p = s[u];
        int arr = 0, pen = 0;
        for (int step = 0; step < 6000 && !arr; step++) {
            /* 走过 60 m 之后封住 1 号门（z=40..63），只能改走 2 号门（z=104..127） */
            if (!edited && p.x > 60.f) {
                RtGridDirty d;
                memset(&d, 0, sizeof(d));
                rt_grid_add_building_dirty(&G, 119, 40, 3, 24, &d);
                (void)rt_grid_apply_dirty(&G, &d);
                (void)rt_gw_note_edit(&W, &d);
                rt_gw_update(&W);
                inval = W.stats.route_invalidated;
                rect_refresh = W.stats.region_rect_refresh;
                edited = 1;
            }
            RtVec2 tgt;
            if (rt_gw_sample(&W, gi, p, &tgt) != RT_OK) break;
            RtVec2 dd = rt_v2_sub(tgt, p);
            float len = rt_v2_len(dd);
            if (len < 1e-4f) break;
            float st = 0.2f;
            if (st > len) st = len;
            RtVec2 np = rt_v2_add(p, rt_v2_mul(dd, st / len));
            if (!seg_clear(p, np)) { pen = 1; break; }
            p = np;
            if (rt_gw_is_arrived(&W, gi, p, 1.5f)) arr = 1;
            rt_gw_update(&W);
        }
        if (arr) arrived++;
        if (pen) penetrated++;
    }
    printf("  arrived=%d/4 pen=%d edited=%d route_invalidated=%u rect_refresh=%u "
           "region_regions=%u\n",
           arrived, penetrated, edited, inval, rect_refresh, W.stats.region_regions);
    OK(edited == 1, "M10 wall was placed mid-run");
    OK(rect_refresh >= 1, "M10 edit went through the incremental path");
    OK(inval >= 1, "M10 routes were invalidated and rebuilt after the edit");
    OK(arrived == 4, "M10 all units re-route around the new wall");
    OK(penetrated == 0, "M10 no penetration");
}

/* ============================================================================
 * M4.6-P5（路线 B）：异步 split
 *
 * 门禁三件事：
 *   1. 大分量的 split **不再一帧跑完**（分帧 + 单帧成本有上界）；
 *   2. 提交后与全量重建**逐格一致**（分区、区域图）；
 *   3. 挂起期间下命令 / 继续编辑都不会读到中间态，也不会丢编辑。
 * ========================================================================== */
static RtGrid GREF;

static int grid_partition_equal(const RtGrid *a, const RtGrid *b)
{
    static int32_t a2b[4096], b2a[4096];
    for (int i = 0; i < 4096; i++) { a2b[i] = -2; b2a[i] = -2; }
    for (int z = 0; z < a->h; z++) {
        for (int x = 0; x < a->w; x++) {
            size_t i = (size_t)z * a->w + x;
            int32_t ca = a->component[i], cb = b->component[i];
            if ((ca >= 0) != (cb >= 0)) return 0;
            if (ca < 0) continue;
            if (ca >= 4096 || cb >= 4096) return 0;
            if (a2b[ca] == -2) a2b[ca] = cb;
            else if (a2b[ca] != cb) return 0;
        }
    }
    for (int ca = 0; ca < 4096; ca++) {
        if (a2b[ca] == -2) continue;
        int32_t cb = a2b[ca];
        if (b2a[cb] != -2 && b2a[cb] != ca) return 0;
        b2a[cb] = ca;
    }
    return 1;
}

/* 参考图：同一地形，编辑后全量重建 */
static void ref_build(void)
{
    rt_grid_destroy(&GREF);
    rt_grid_init(&GREF, 256, 256, 1.0f);
    for (int z = 0; z < 256; z++)
        if (z < 126 || z > 129) rt_grid_set_terrain(&GREF, 128, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&GREF);
}

static void ref_apply(int x, int z, int w, int h)
{
    RtGridDirty d;
    memset(&d, 0, sizeof(d));
    rt_grid_add_building_dirty(&GREF, x, z, w, h, &d);
    rt_grid_rebuild_all(&GREF);
}

/* 竖墙 + 3 格门：整张图是一个约 6.5 万格的分量（> RT_JOB_SPLIT_THRESHOLD） */
static void wall_door_world(void)
{
    world_reset(256);
    for (int z = 0; z < 256; z++)
        if (z < 126 || z > 129) rt_grid_set_terrain(&G, 128, z, RT_CELL_BLOCKED_TERRAIN, 1);
    world_build();
    ref_build();
}

static void m11_async_split(void)
{
    printf("\n[M11] 异步 split：6.5 万格分量切开 -> 分帧推进 -> 与全量重建一致\n");
    wall_door_world();
    int32_t c0 = G.component[0];
    printf("  base components=%d main_size=%d threshold=20000\n",
           G.active_components, G.component_size[c0]);
    OK(G.component_size[c0] > 20000, "M11 base component is large enough to go async");

    RtGridDirty d;
    memset(&d, 0, sizeof(d));
    rt_grid_add_building_dirty(&G, 128, 126, 1, 4, &d);
    int rc = rt_gw_submit_edit(&W, &d);
    OK(rc == RT_OK, "M11 submit returns RT_OK");
    int pending = rt_gw_split_pending(&W);
    printf("  after submit: pending=%d scheduled=%u budget=%d\n",
           pending, W.sched.stat_scheduled, rt_gw_split_budget(&W));
    OK(pending == 1, "M11 big split is deferred instead of blocking the frame");

    ref_apply(128, 126, 1, 4);

    double worst = 0.0;
    int frames = 0;
    while (rt_gw_split_pending(&W) && frames < 5000) {
        double t0 = now_ms();
        (void)rt_gw_update(&W);
        double dt = now_ms() - t0;
        if (dt > worst) worst = dt;
        frames++;
    }
    printf("  frames=%d worst_frame=%.3f ms  split_max_frames=%u spans=%u steps=%u\n",
           frames, worst, W.split_max_frames, W.split_spans, W.sched.stat_commit);
    OK(!rt_gw_split_pending(&W), "M11 split finished");
    OK(frames >= 2, "M11 split was spread over 2+ frames");
    OK(worst < 1.5, "M11 no single frame exceeded 1.5 ms");
    OK(grid_partition_equal(&G, &GREF) == 1, "M11 partition equals full rebuild");

    rt_region_build(&REF, &G, 8);
    printf("  region: rect_refresh=%u rebuilds=%u regions=%u mismatched=%d\n",
           W.stats.region_rect_refresh, W.stats.region_rebuilds,
           W.stats.region_regions, region_cmp());
    OK(W.stats.region_rect_refresh >= 1, "M11 region map refreshed incrementally after commit");
    OK(region_cmp() == 0, "M11 region map equals full rebuild");
}

static void m12_command_drains(void)
{
    printf("\n[M12] 挂起期间下命令：先 drain 再拆组；期间采样仍可用\n");
    wall_door_world();

    static RtUnitId ids[8];
    int n = spawn_disc(ids, 8, 40.f, 40.f, 5.f);
    rt_gw_command(&W, &US, ids, n, rt_v2(60.5f, 200.5f), 0, RT_CLS_SMALL, 1);

    RtGridDirty d;
    memset(&d, 0, sizeof(d));
    rt_grid_add_building_dirty(&G, 128, 126, 1, 4, &d);
    rt_gw_submit_edit(&W, &d);
    OK(rt_gw_split_pending(&W) == 1, "M12 split is pending");

    /* 挂起期间采样：旧 route 仍然可服务（flags 已生效，物理上不穿墙） */
    int ok_samples = 0;
    for (int i = 0; i < n; i++) {
        RtVec3 p = rt_units_pos(&US, ids[i]);
        RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[i]);
        int gi = (int)ch->group[rt_unit_slot_index(ids[i])] - 1;
        RtVec2 tgt;
        if (gi >= 0 && rt_gw_sample(&W, gi, rt_v2(p.x, p.z), &tgt) == RT_OK) ok_samples++;
    }
    printf("  pending samples ok=%d/%d\n", ok_samples, n);
    OK(ok_samples == n, "M12 sampling keeps working while the split is pending");

    int rc = rt_gw_command(&W, &US, ids, n, rt_v2(80.5f, 220.5f), 0, RT_CLS_SMALL, 2);
    OK(rc == RT_OK, "M12 command during pending succeeds");
    OK(rt_gw_split_pending(&W) == 0, "M12 command drained the pending split");
    ref_apply(128, 126, 1, 4);
    OK(grid_partition_equal(&G, &GREF) == 1, "M12 partition equals full rebuild after drain");
}

static void m13_edit_while_pending(void)
{
    printf("\n[M13] 挂起期间又来一次编辑（同 chunk）：取消并重来，不丢更新\n");
    wall_door_world();

    RtGridDirty d;
    memset(&d, 0, sizeof(d));
    rt_grid_add_building_dirty(&G, 128, 126, 1, 4, &d);
    rt_gw_submit_edit(&W, &d);
    OK(rt_gw_split_pending(&W) == 1, "M13 first split is pending");

    (void)rt_gw_update(&W);        /* 推进一帧：job 已经跑了一部分 */

    /* 第二笔编辑命中同一个 chunk：job 的依赖被踩 -> 取消 + 用合并后的 dirty 重来 */
    RtGridDirty d2;
    memset(&d2, 0, sizeof(d2));
    rt_grid_add_building_dirty(&G, 130, 124, 3, 8, &d2);
    rt_gw_submit_edit(&W, &d2);
    printf("  after 2nd edit: pending=%d cancels=%u coalesced=%u\n",
           rt_gw_split_pending(&W), W.sched.stat_cancel, W.sched.stat_coalesced);

    int guard = 0;
    while (rt_gw_split_pending(&W) && guard++ < 5000) (void)rt_gw_update(&W);
    OK(!rt_gw_split_pending(&W), "M13 both edits finished");

    ref_apply(128, 126, 1, 4);
    ref_apply(130, 124, 3, 8);
    OK(grid_partition_equal(&G, &GREF) == 1, "M13 partition equals full rebuild (no lost update)");
}

/* M14：单位正走向门时把门封死。挂起期间它们只能用旧 route，
 * 验收点：**0 穿墙**（flags 立即生效），且提交后拓扑与全量一致。 */
static void m14_pending_no_penetration(void)
{
    printf("\n[M14] 走向门时封门：挂起期间 0 穿墙，提交后拓扑正确\n");
    wall_door_world();

    static RtUnitId ids[4];
    int n = 0;
    for (int i = 0; i < 4; i++) {
        RtUnitId id = rt_units_spawn(&US, rt_v3(100.5f, 0.f, 126.5f + (float)i), RT_FP_SMALL);
        if (id != RT_UNIT_ID_NONE) ids[n++] = id;
    }
    rt_gw_command(&W, &US, ids, n, rt_v2(210.5f, 128.5f), 0, RT_CLS_SMALL, 1);

    int gi[4];
    RtVec2 p[4];
    for (int i = 0; i < n; i++) {
        RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[i]);
        gi[i] = (int)ch->group[rt_unit_slot_index(ids[i])] - 1;
        RtVec3 q = rt_units_pos(&US, ids[i]);
        p[i] = rt_v2(q.x, q.z);
    }

    int pen = 0, edited = 0, pending_frames = 0;
    for (int step = 0; step < 6000; step++) {
        if (!edited && p[0].x > 120.f) {
            RtGridDirty d;
            memset(&d, 0, sizeof(d));
            rt_grid_add_building_dirty(&G, 128, 126, 1, 4, &d);
            rt_gw_submit_edit(&W, &d);
            edited = 1;
            ref_apply(128, 126, 1, 4);
        }
        for (int i = 0; i < n; i++) {
            if (gi[i] < 0) continue;
            RtVec2 tgt;
            if (rt_gw_sample(&W, gi[i], p[i], &tgt) != RT_OK) continue;
            RtVec2 dd = rt_v2_sub(tgt, p[i]);
            float len = rt_v2_len(dd);
            if (len < 1e-4f) continue;
            float st = 0.2f;
            if (st > len) st = len;
            RtVec2 np = rt_v2_add(p[i], rt_v2_mul(dd, st / len));
            if (!seg_clear(p[i], np)) { pen++; continue; }
            p[i] = np;
        }
        (void)rt_gw_update(&W);
        if (rt_gw_split_pending(&W)) pending_frames++;
    }
    printf("  edited=%d pen=%d pending_frames=%d final_x=%.1f\n",
           edited, pen, pending_frames, p[0].x);
    OK(edited == 1, "M14 door was closed while units were walking");
    OK(pending_frames >= 1, "M14 units actually walked during the pending window");
    OK(pen == 0, "M14 no segment crossed the new building");
    OK(grid_partition_equal(&G, &GREF) == 1, "M14 topology equals full rebuild");
}

int main(void)
{
    timer_init();
    printf("=== M4.6 tests: P1 fine-flow build budget + P2 incremental region map ===\n");
    printf("P1 default budget = 1 build per command/update; -1 = unlimited (M4.4 behaviour)\n");

    m1_budget_caps_first_pass();
    m2_unlimited_reference();
    m3_refill_across_frames();
    m4_budget_zero();
    m5_semantics_kept();
    m6_incremental_equals_full();
    m7_region_cost();
    m8_widening_safety_net();
    m9_label_epoch_forces_full();
    m10_edit_end_to_end();
    m11_async_split();
    m12_command_drains();
    m13_edit_while_pending();
    m14_pending_no_penetration();

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    if (g_fail == 0) printf("ALL PASS (%d asserts)\n", g_pass);

    rt_gw_destroy(&W);
    rt_region_destroy(&REF);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    rt_grid_destroy(&GREF);
    return g_fail == 0 ? 0 : 1;
}

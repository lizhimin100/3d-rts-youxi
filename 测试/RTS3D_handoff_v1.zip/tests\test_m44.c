/* ============================================================================
 * test_m44.c -- M4.4 走廊推进语义 + 有界 fine flow
 *
 * T1 U 形陷阱 4 单位：全部到达、0 穿墙、推进单调（无 >8 m 回退、无 tgt==pos）
 * T2 斜向薄墙横穿一个区域（凹角/柱状障碍的等价情形，直线被挡）：到达、0 穿墙、
 *    fine flow 真的被用到、且「关掉 fine 就到不了」的反证
 * T3 被推离走廊：能重新挂回前方，倒退不超过 8 m
 * T4 开放地图 1000 单位：采样中位数 <= 0.16 ms，且全部到达
 * T5 fine flow 复用：同目标第二次 fine_builds 不增加
 * T6 fine flow 失效：窗口内建楼 -> 失效重建；窗口外建楼 -> 不失效
 * T7 回归：M4.3 自适应（32 源走 flow、warm 0 builds、per-source route 仍在）
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m44.c -o test_m44
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", m); } } while (0)

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;

/* ------------------------------------------------------------------ 基础 */
static void world_reset(int w)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_grid_init(&G, w, w, 1.0f);
}

static void world_build(void)
{
    rt_grid_rebuild_all(&G);
    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
}

/* 线段不穿墙：0.25 m 步长逐点判定 walkability（与 test_m4 同口径） */
static int segment_clear(RtVec2 a, RtVec2 b)
{
    float dx = b.x - a.x, dz = b.z - a.z;
    float len = sqrtf(dx * dx + dz * dz);
    int steps = (int)(len / 0.25f) + 1;
    for (int i = 0; i <= steps; i++) {
        float t = (float)i / (float)steps;
        int cx = rt_grid_cell_x(&G, a.x + dx * t), cz = rt_grid_cell_z(&G, a.z + dz * t);
        if (!rt_grid_walkable(&G, cx, cz)) return 0;
    }
    return 1;
}

typedef struct {
    RtVec2 pos;
    int    arrived, penetrations, stalls, steps;
    float  best_dist, worst_back;   /* 到目标的最小距离 / 最大回退量 */
} Walk;

static void walk_init(Walk *k, RtVec2 p, RtVec2 goal)
{
    memset(k, 0, sizeof(*k));
    k->pos = p;
    k->best_dist = sqrtf((p.x - goal.x) * (p.x - goal.x) + (p.z - goal.z) * (p.z - goal.z));
}

/* 无避障、无碰撞，只验证「方向对不对」：每帧 0.2 m（6 m/s @30Hz） */
static void walk_step(Walk *k, int gi, RtVec2 goal, int speed)
{
    RtVec2 tgt;
    if (rt_gw_sample(&W, gi, k->pos, &tgt) != RT_OK) return;
    RtVec2 d = rt_v2_sub(tgt, k->pos);
    float len = rt_v2_len(d);
    if (len < 1e-4f) { k->stalls++; return; }
    float step = (float)speed * (1.0f / 30.0f);
    if (step > len) step = len;
    RtVec2 np = rt_v2_add(k->pos, rt_v2_mul(d, step / len));
    if (!segment_clear(k->pos, np)) { k->penetrations++; return; }
    k->pos = np;
    k->steps++;

    float dist = sqrtf((np.x - goal.x) * (np.x - goal.x) + (np.z - goal.z) * (np.z - goal.z));
    if (dist < k->best_dist) k->best_dist = dist;
    else if (dist - k->best_dist > k->worst_back) k->worst_back = dist - k->best_dist;
    if (rt_gw_is_arrived(&W, gi, np, 1.5f)) k->arrived = 1;
}

static void walk_run(Walk *k, int gi, RtVec2 goal, int max_steps, int speed)
{
    for (int i = 0; i < max_steps && !k->arrived; i++) walk_step(k, gi, goal, speed);
}

/* ------------------------------------------------------------- 场景构造 */

/* U 形陷阱 + 内部柱子（与 _设计验算/probe_fineflow.c 同图） */
static void map_u_trap(void)
{
    world_reset(256);
    for (int z = 50; z <= 110; z++) {
        for (int x = 90; x <= 140; x++) {
            int wall = 0;
            if (z == 50 || z == 110) wall = 1;
            if (x == 90) wall = 1;
            if (x >= 110 && x <= 118 && z >= 70 && z <= 78) wall = 1;   /* 柱子 */
            if (wall) rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
    }
    world_build();
}

/* 斜向薄墙横穿一个 8 m 区域：区域级 A* 认为这段可走（区域两半都通，
 * 可以绕到区域外），但门户到门户的直线穿墙 —— M4.4-B 的触发条件。 */
static void map_diagonal_wall(int thick)
{
    world_reset(256);
    int x0 = 8 * 8, z0 = 10 * 8;         /* 区域 (rx=8, rz=10) */
    for (int i = 0; i < 8; i++)
        for (int t = 0; t < thick; t++)
            rt_grid_set_terrain(&G, x0 + i, z0 + i + t, RT_CELL_BLOCKED_TERRAIN, 1);
    world_build();
}

/* 开放地图（T4 / T7 用） */
static void map_open(int noise_permille)
{
    world_reset(256);
    if (noise_permille > 0) {
        uint64_t st = 0xC0FFEEull;
        for (int z = 0; z < 256; z++)
            for (int x = 0; x < 256; x++) {
                uint64_t k = (st += 0x9E3779B97F4A7C15ull);
                k = (k ^ (k >> 30)) * 0xBF58476D1CE4E5B9ull;
                k = (k ^ (k >> 27)) * 0x94D049BB133111EBull;
                k ^= k >> 31;
                if ((k >> 40) % 1000 < (uint64_t)noise_permille)
                    rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
            }
    }
    world_build();
}

/* ==========================================================================
 * T1 U 形陷阱：4 单位全部到达、0 穿墙、推进单调
 * ======================================================================== */
static void t1_u_trap(void)
{
    printf("\n[T1] U-shaped trap, 4 units, monotone corridor progression\n");
    map_u_trap();

    RtUnitId ids[4];
    RtVec2 starts[4] = { { 100.5f, 60.5f }, { 100.5f, 100.5f }, { 130.5f, 60.5f }, { 130.5f, 100.5f } };
    for (int i = 0; i < 4; i++)
        ids[i] = rt_units_spawn(&US, rt_v3(starts[i].x, 0.f, starts[i].z), RT_FP_SMALL);

    RtVec2 dest = rt_v2(200.5f, 80.5f);
    int rc = rt_gw_command(&W, &US, ids, 4, dest, 0, RT_CLS_SMALL, 1);
    OK(rc == RT_OK, "T1 command");
    OK(W.group_count == 1, "T1 one group");
    OK(W.groups[0].route_count == 4, "T1 four per-source routes");
    RtVec2 goal = W.groups[0].goal_pos;
    printf("  groups=%d routes=%d segs=%u blocked=%u\n",
           W.group_count, W.groups[0].route_count,
           W.stats.corridor_segments, W.stats.corridor_blocked);

    int all_arrived = 1, all_clean = 1, all_monotone = 1, no_stall = 1;
    for (int u = 0; u < 4; u++) {
        RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[u]);
        int gi = (int)ch->group[rt_unit_slot_index(ids[u])] - 1;
        Walk k; walk_init(&k, starts[u], goal);
        walk_run(&k, gi, goal, 4000, 6);
        printf("  unit%d gi=%d steps=%d arrived=%d pen=%d stall=%d back=%.2f end=(%.1f,%.1f)\n",
               u, gi, k.steps, k.arrived, k.penetrations, k.stalls, k.worst_back, k.pos.x, k.pos.z);
        if (!k.arrived) all_arrived = 0;
        if (k.penetrations) all_clean = 0;
        if (k.worst_back > 8.0f) all_monotone = 0;   /* 允许小幅回退，不允许来回大跳 */
        if (k.stalls) no_stall = 0;
    }
    OK(all_arrived, "T1 all 4 units arrive");
    OK(all_clean, "T1 no wall penetration");
    OK(all_monotone, "T1 progression monotone (no backward jump > 8 m)");
    OK(no_stall, "T1 no tgt==pos frame at all");
    OK(W.stats.fine_builds == 0, "T1 fine flow not needed on this map (documented)");
}

/* ==========================================================================
 * T2 斜向薄墙（直线被挡）：必须靠 fine flow 才能绕过去
 * ======================================================================== */
static int t2_probe(const char *tag, int thick, int fine_on, int verbose)
{
    map_diagonal_wall(thick);
    rt_gw_set_fine_enabled(&W, fine_on);

    RtVec2 s = rt_v2(20.5f, 83.5f);
    RtUnitId id = rt_units_spawn(&US, rt_v3(s.x, 0.f, s.z), RT_FP_SMALL);
    RtUnitId one[1] = { id };
    rt_gw_command(&W, &US, one, 1, rt_v2(230.5f, 83.5f), 0, RT_CLS_SMALL, 1);
    int gi = (int)((RtUnitChunk *)rt_units_chunk_c(&US, id))->group[rt_unit_slot_index(id)] - 1;
    RtVec2 goal = W.groups[gi].goal_pos;

    Walk k; walk_init(&k, s, goal);
    walk_run(&k, gi, goal, 6000, 6);

    /* 最长连续 tgt==pos 帧数（单独统计，Walk.stalls 只是总数） */
    int run_len = 0, max_run = 0;
    RtVec2 p = s;
    for (int i = 0; i < 600 && !rt_gw_is_arrived(&W, gi, p, 1.5f); i++) {
        RtVec2 tgt;
        if (rt_gw_sample(&W, gi, p, &tgt) != RT_OK) break;
        RtVec2 d = rt_v2_sub(tgt, p);
        float len = rt_v2_len(d);
        if (len < 1e-4f) { if (++run_len > max_run) max_run = run_len; }
        else {
            run_len = 0;
            float st = 0.2f;
            if (st > len) st = len;
            RtVec2 np = rt_v2_add(p, rt_v2_mul(d, st / len));
            if (!segment_clear(p, np)) break;
            p = np;
        }
    }

    if (verbose) {
        printf("  %-18s thick=%d fine=%d : blocked=%u/%u steps=%d arrived=%d pen=%d "
               "max_stall_run=%d fine(b=%u h=%u used=%u rej=%u out=%u)\n",
               tag, thick, fine_on, W.stats.corridor_blocked, W.stats.corridor_segments,
               k.steps, k.arrived, k.penetrations, max_run,
               W.stats.fine_builds, W.stats.fine_hits, W.stats.fine_used,
               W.stats.fine_rejected, W.stats.fine_outside);
    }
    return k.arrived && k.penetrations == 0 && max_run <= 5;
}

static void t2_diagonal_wall(void)
{
    printf("\n[T2] diagonal wall blocks the straight line (needs bounded fine flow)\n");
    int ok_on = t2_probe("fine on", 2, 1, 1);
    int ok_off = t2_probe("fine off", 2, 0, 1);
    OK(ok_on, "T2 arrives with fine flow, no penetration, no tgt==pos run > 5");
    OK(!ok_off, "T2 counter-proof: without fine flow this map is not solvable");
    /* 三个厚度都过一遍，避免「只有某个厚度碰巧能过」 */
    int all = 1;
    for (int t = 1; t <= 3; t++) if (!t2_probe("fine on", t, 1, 0)) all = 0;
    OK(all, "T2 works for wall thickness 1..3");
}

/* ==========================================================================
 * T3 被推离走廊：重新挂回前方，倒退不超过 8 m
 * ======================================================================== */
static void t3_reattach(void)
{
    printf("\n[T3] displaced off the corridor -> re-attach forward, no backtrack > 8 m\n");
    map_u_trap();

    RtVec2 s = rt_v2(100.5f, 60.5f);
    RtUnitId id = rt_units_spawn(&US, rt_v3(s.x, 0.f, s.z), RT_FP_SMALL);
    RtUnitId one[1] = { id };
    rt_gw_command(&W, &US, one, 1, rt_v2(200.5f, 80.5f), 0, RT_CLS_SMALL, 1);
    int gi = (int)((RtUnitChunk *)rt_units_chunk_c(&US, id))->group[rt_unit_slot_index(id)] - 1;
    RtVec2 goal = W.groups[gi].goal_pos;

    Walk k; walk_init(&k, s, goal);
    for (int i = 0; i < 120 && !k.arrived; i++) walk_step(&k, gi, goal, 6);

    /* 手动把位置挪到旁边 5 m（模拟碰撞/避障把单位推开），不改变命令 */
    RtVec2 before = k.pos;
    k.pos.z += 5.0f;
    int stuck_in_wall = !rt_grid_walkable(&G, rt_grid_cell_x(&G, k.pos.x), rt_grid_cell_z(&G, k.pos.z));
    printf("  displace (%.1f,%.1f) -> (%.1f,%.1f) walkable=%d\n",
           before.x, before.z, k.pos.x, k.pos.z, !stuck_in_wall);
    OK(!stuck_in_wall, "T3 displaced spot is walkable (test setup sane)");

    /* 重置回退统计：从被推开的这一刻开始算 */
    k.best_dist = sqrtf((k.pos.x - goal.x) * (k.pos.x - goal.x) + (k.pos.z - goal.z) * (k.pos.z - goal.z));
    k.worst_back = 0.f;
    walk_run(&k, gi, goal, 4000, 6);
    printf("  after displace: steps=%d arrived=%d pen=%d back=%.2f\n",
           k.steps, k.arrived, k.penetrations, k.worst_back);
    OK(k.arrived, "T3 arrives after being displaced");
    OK(k.penetrations == 0, "T3 no penetration after re-attach");
    OK(k.worst_back <= 8.0f, "T3 backtrack bounded by 8 m");
}

/* ==========================================================================
 * T4 开放地图 1000 单位：采样 <= 0.16 ms 且全部到达
 * ======================================================================== */
static int spawn_disc(RtUnitId *ids, int n, float cx, float cz, float r)
{
    int k = 0;
    for (int i = 0; i < n * 4 && k < n; i++) {
        float rad = r * sqrtf((float)i / (float)(n * 4));
        float ang = (float)i * 2.39996323f;
        int x = rt_grid_cell_x(&G, cx + cosf(ang) * rad);
        int z = rt_grid_cell_z(&G, cz + sinf(ang) * rad);
        if (!rt_grid_walkable(&G, x, z)) continue;
        RtUnitId id = rt_units_spawn(&US, rt_v3((float)x + 0.5f, 0.f, (float)z + 0.5f), RT_FP_SMALL);
        if (id != RT_UNIT_ID_NONE) ids[k++] = id;
    }
    return k;
}

static void t4_sample_cost(void)
{
    printf("\n[T4] 1000 units: arrival on an open map, sampling cost on the M4.2 map\n");

    /* --- 4a. 开放地图：1000 单位必须全部到达（M4.3 一致性的判据） --- */
    map_open(0);
    static RtUnitId ids[1024];
    int n = spawn_disc(ids, 1000, 50.f, 60.f, 12.f);
    RtVec2 dest = rt_v2(210.5f, 190.5f);
    rt_gw_command(&W, &US, ids, n, dest, 0, RT_CLS_SMALL, 1);
    int routes = 0;
    for (int i = 0; i < W.group_count; i++) routes += W.groups[i].route_count;
    printf("  open: units=%d groups=%d routes=%d builds=%u extracts=%u\n",
           n, W.group_count, routes, W.stats.route_builds, W.stats.flow_route_extracts);

    int arrived = 0, penetrated = 0;
    RtVec2 goal = W.groups[0].goal_pos;
    for (int i = 0; i < n; i++) {
        RtVec3 p0 = rt_units_pos(&US, ids[i]);
        RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[i]);
        int gi = (int)ch->group[rt_unit_slot_index(ids[i])] - 1;
        Walk k; walk_init(&k, rt_v2(p0.x, p0.z), goal);
        walk_run(&k, gi, goal, 3000, 6);       /* 6 m/s @30Hz = 0.2 m/帧 */
        if (k.arrived) arrived++;
        if (k.penetrations) penetrated++;
    }
    printf("  open: arrived=%d/%d penetrated_units=%d\n", arrived, n, penetrated);
    OK(arrived == n, "T4 all 1000 units arrive on an open map");
    OK(penetrated == 0, "T4 no unit clipped a wall");

    /* --- 4b. 采样成本：与 bench_m42 同图（10% 噪声 + 墙/门） --- */
    map_open(100);
    n = spawn_disc(ids, 1000, 50.f, 60.f, 12.f);
    rt_gw_command(&W, &US, ids, n, dest, 0, RT_CLS_SMALL, 1);
    double samples[9];
    volatile float acc = 0.f;
    for (int rep = 0; rep < 9; rep++) {
        double t0 = now_ms();
        for (int i = 0; i < n; i++) {
            RtVec3 p = rt_units_pos(&US, ids[i]);
            RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[i]);
            int gi = (int)ch->group[rt_unit_slot_index(ids[i])] - 1;
            RtVec2 tgt;
            if (gi >= 0 && rt_gw_sample(&W, gi, rt_v2(p.x, p.z), &tgt) == RT_OK) acc += tgt.x;
        }
        samples[rep] = now_ms() - t0;
    }
    (void)acc;
    printf("  1000-unit sample (10%% noise): best=%.4f ms median=%.4f ms (%.1f ns/unit)\n",
           samples[0], samples[4], samples[4] * 1e6 / (double)n);
    printf("  fine layer on this map: checks=%u builds=%u used=%u (blocked segs=%u)\n",
           W.stats.fine_checks, W.stats.fine_builds, W.stats.fine_used, W.stats.corridor_blocked);
    OK(samples[4] <= 0.16, "T4 sample 1000 units <= 0.16 ms");
}

/* ==========================================================================
 * T5 fine flow 复用：同目标第二次不重建
 * ======================================================================== */
static void t5_reuse(void)
{
    printf("\n[T5] fine flow reuse: same target must not rebuild\n");
    map_diagonal_wall(2);
    RtVec2 s = rt_v2(20.5f, 83.5f);
    RtUnitId id = rt_units_spawn(&US, rt_v3(s.x, 0.f, s.z), RT_FP_SMALL);
    RtUnitId one[1] = { id };
    rt_gw_command(&W, &US, one, 1, rt_v2(230.5f, 83.5f), 0, RT_CLS_SMALL, 1);
    int gi = (int)((RtUnitChunk *)rt_units_chunk_c(&US, id))->group[rt_unit_slot_index(id)] - 1;

    /* 走到被挡段前面 */
    Walk k; walk_init(&k, s, W.groups[gi].goal_pos);
    while (k.steps < 260 && !k.arrived) walk_step(&k, gi, W.groups[gi].goal_pos, 6);

    uint32_t b_walk = W.stats.fine_builds;
    uint32_t h0 = W.stats.fine_hits;
    RtVec2 t1, t2, t3;
    rt_gw_sample(&W, gi, k.pos, &t1);
    uint32_t b1 = W.stats.fine_builds;
    rt_gw_sample(&W, gi, k.pos, &t2);
    rt_gw_sample(&W, gi, k.pos, &t3);
    uint32_t b2 = W.stats.fine_builds;
    printf("  builds: after_walk=%u after1=%u after3=%u hits=%u->%u\n",
           b_walk, b1, b2, h0, W.stats.fine_hits);
    OK(b_walk >= 1, "T5 blocked segment triggers a fine flow build during the walk");
    OK(b2 == b1, "T5 repeated samples with the same target reuse it (fine_builds unchanged)");
    OK(fabsf(t2.x - t1.x) < 1e-4f && fabsf(t2.z - t1.z) < 1e-4f,
       "T5 cached answer is identical");
    OK(rt_gw_fine_count(&W) <= RT_FINE_SLOTS, "T5 fine flow slots bounded");
}

/* ==========================================================================
 * T6 fine flow 失效：窗口内建楼 -> 重建；窗口外建楼 -> 不失效
 * ======================================================================== */
static void t6_invalidate(int inside)
{
    map_diagonal_wall(2);
    /* T6 只验证「依赖失效 -> 整块重建」这一条语义，与 M4.6 的建场分帧解耦：
     * 默认预算是 1 次/帧，会把「失效后重建」挡在预算外（那是分帧的行为，见 test_m46）。 */
    rt_gw_set_fine_budget(&W, -1);
    RtVec2 s = rt_v2(20.5f, 83.5f);
    RtUnitId id = rt_units_spawn(&US, rt_v3(s.x, 0.f, s.z), RT_FP_SMALL);
    RtUnitId one[1] = { id };
    rt_gw_command(&W, &US, one, 1, rt_v2(230.5f, 83.5f), 0, RT_CLS_SMALL, 1);
    int gi = (int)((RtUnitChunk *)rt_units_chunk_c(&US, id))->group[rt_unit_slot_index(id)] - 1;

    Walk k; walk_init(&k, s, W.groups[gi].goal_pos);
    while (k.steps < 260 && !k.arrived) walk_step(&k, gi, W.groups[gi].goal_pos, 6);

    RtVec2 tgt;
    rt_gw_sample(&W, gi, k.pos, &tgt);
    uint32_t b0 = W.stats.fine_builds, iv0 = W.stats.fine_invalid;
    int kx = rt_grid_cell_x(&G, tgt.x), kz = rt_grid_cell_z(&G, tgt.z);

    /* inside：目标格 +6（在 ±12 窗口内，且不在走廊线上，避免改坏可达性）
     * outside：地图左上角，与窗口覆盖的 chunk 不相交 */
    int bx, bz;
    if (inside) { bx = kx + 6; bz = kz + 6; }
    else        { bx = 4;      bz = 4; }
    RtGridDirty d;
    rt_grid_add_building_dirty(&G, bx, bz, 2, 2, &d);
    rt_grid_apply_dirty(&G, &d);

    RtVec2 tgt2;
    rt_gw_sample(&W, gi, k.pos, &tgt2);
    uint32_t b1 = W.stats.fine_builds, iv1 = W.stats.fine_invalid;
    printf("  %s edit at (%d,%d) [target cell (%d,%d)]: builds %u->%u invalid %u->%u\n",
           inside ? "inside " : "outside", bx, bz, kx, kz, b0, b1, iv0, iv1);
    if (inside) {
        OK(iv1 > iv0, "T6 edit inside window invalidates the fine flow");
        OK(b1 == b0 + 1, "T6 invalidated flow is rebuilt exactly once");
    } else {
        OK(iv1 == iv0, "T6 edit outside window does not invalidate");
        OK(b1 == b0, "T6 no rebuild for an unrelated edit");
    }
}

/* ==========================================================================
 * T7 回归：M4.1/M4.2/M4.3 的可观测不变式
 * ======================================================================== */
static void t7_regression(void)
{
    printf("\n[T7] M4.1/M4.2/M4.3 invariants on a wall+gate map\n");
    world_reset(256);
    for (int z = 0; z < 256; z++)
        if (z != 128) rt_grid_set_terrain(&G, 128, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int dz = -1; dz <= 1; dz++) {
        rt_grid_set_terrain(&G, 127, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, 128, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, 129, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
    }
    world_build();

    static RtUnitId ids[64];
    int n = 0;
    float pos[32][2] = {
        {30,30},{60,30},{90,30},{30,60},{60,60},{90,60},{30,90},{60,90},
        {40,120},{70,120},{100,120},{40,150},{70,150},{100,150},{40,180},{70,180},
        {40,210},{70,210},{100,210},{100,60},{100,90},{120,150},{150,150},
        {180,40},{180,80},{180,120},{180,160},{180,200},{210,60},{210,120},{210,180},{230,230}
    };
    for (int i = 0; i < 32; i++) {
        RtUnitId id = rt_units_spawn(&US, rt_v3(pos[i][0] + 0.5f, 0.f, pos[i][1] + 0.5f), RT_FP_SMALL);
        if (id != RT_UNIT_ID_NONE) ids[n++] = id;
    }
    RtVec2 dest = rt_v2(215.5f, 115.5f);
    rt_gw_command(&W, &US, ids, n, dest, 0, RT_CLS_SMALL, 1);
    uint32_t cold_builds = W.stats.route_builds + W.stats.flow_route_extracts;
    uint32_t cold_flow = W.stats.goal_flow_builds;
    uint32_t ada_flow = W.stats.adaptive_flow;
    int routes = 0, per_source_ok = 1;
    for (int i = 0; i < W.group_count; i++) {
        routes += W.groups[i].route_count;
        for (int r = 0; r < W.groups[i].route_count; r++)
            if (W.groups[i].routes[r].route.n <= 0) per_source_ok = 0;
    }
    printf("  cold: groups=%d routes=%d builds+extracts=%u flow_builds=%u flow_cmd=%u routes_ok=%d\n",
           W.group_count, routes, cold_builds, cold_flow, ada_flow, per_source_ok);
    OK(cold_builds > 0, "T7 cold command materialises per-source routes");
    OK(ada_flow >= 1, "T7 >=16 unique sources switches to goal flow");
    OK(cold_flow >= 1, "T7 goal flow built on the cold command");
    OK(per_source_ok, "T7 per-source RtRoute still materialised (M4.1 invariant)");

    rt_gw_command(&W, &US, ids, n, dest, 0, RT_CLS_SMALL, 2);
    printf("  warm: builds=%u goal_hits=%u flow_hits=%u flow_builds=%u\n",
           W.stats.route_builds, W.stats.goal_cache_hits,
           W.stats.goal_flow_hits, W.stats.goal_flow_builds);
    OK(W.stats.route_builds == 0, "T7 warm command does 0 A* builds (M4.2 invariant)");
    OK(W.stats.goal_cache_hits > 0, "T7 goal cache hits on warm");
    OK(W.stats.goal_flow_builds == 0, "T7 goal flow not rebuilt on warm (M4.3 invariant)");
    OK(rt_gw_fine_count(&W) == 0, "T7 fine flow untouched by command path");
}

int main(void)
{
    timer_init();
    printf("=== M4.4 tests: corridor progression + bounded fine flow ===\n");
    printf("fine window = %d x %d cells (target cell +/- %d), slots = %d\n\n",
           RT_FINE_WIN, RT_FINE_WIN, RT_FINE_RADIUS, RT_FINE_SLOTS);

    t1_u_trap();
    t2_diagonal_wall();
    t3_reattach();
    t4_sample_cost();
    t5_reuse();
    t6_invalidate(1);
    t6_invalidate(0);
    t7_regression();

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    if (g_fail == 0) printf("ALL PASS (%d asserts)\n", g_pass);

    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return g_fail == 0 ? 0 : 1;
}

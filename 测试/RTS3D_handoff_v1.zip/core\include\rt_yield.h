/* ============================================================================
 * rt_yield.h -- 静止单位让路（FR-YLD，M7）
 *
 * 问题：一队人要从 A 到 B，路上站着一个不动的单位。M5 的 ORCA 只会「绕」，
 *       走廊窄的时候绕不过去，整队就被一个不动的单位堵死（M6 的 T4 就是这样）。
 *       正确行为是：**站着的那个让开，队伍过去，它再回原位**。
 *
 * 做法（01 §8 的设计，不做逐对检测）：
 *   1. 交通压力场：mover 的 |v| < actual_ratio * |pref| 时，给它所在格 pressure += 1；
 *      压力每 decay_interval 衰减 ×decay。成本 O(N)/帧，不是 O(N·N_idle)。
 *   2. 触发：静止单位所在 3×3 格的压力和 > enter_pressure（默认 12）。
 *   3. 选位：16 方向 × 2 半径（2 m / 4 m）共 32 个候选，要求可走 + OBB 不撞 +
 *      候选格压力低；评分偏好「近、空、别站到下一股人流里」。
 *   4. 回位：压力 < exit_pressure（滞回）且原位仍空 → 走回去；
 *      回位后 reentry_cooldown 内不再触发（FR-YLD-3 不许反复横跳）。
 *
 * 与队形的冲突：`formation_locked` 的单位不让路（01 §8）。本层用一个回调
 * `may_yield(ud, idx)` 让上层否决；未接回调 = 全部允许。
 *
 * 本层只写 pref_vel，位置一律由 rt_local_step 积分（CON-9 禁止传送）。
 * ==========================================================================*/
#ifndef RT_YIELD_H
#define RT_YIELD_H

#include "rt_types.h"
#include "rt_grid.h"
#include "rt_local.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RT_YIELD_DIRS 16
#define RT_YIELD_RADII 2

typedef enum {
    RT_YIELD_IDLE = 0,      /* 站着，没在让 */
    RT_YIELD_OUT = 1,       /* 正在走到让位点 */
    RT_YIELD_HOLD = 2,      /* 到位，等压力下去 */
    RT_YIELD_BACK = 3       /* 压力下去了，正在回原位 */
} RtYieldState;

typedef struct {
    float actual_ratio;     /* |v| < ratio*|pref| 视为被堵（默认 0.20） */
    float enter_pressure;   /* 3×3 压力和 > 此值触发让路（默认 12） */
    float exit_pressure;    /* 低于此值开始回位（默认 4，必须 < enter） */
    float decay;            /* 每次衰减系数（默认 0.80） */
    float decay_interval;   /* 衰减间隔 s（默认 0.5） */
    float reentry_cooldown; /* 回位后多久不再触发 s（默认 3.0） */
    float arrive_dist;      /* 到让位点多近算到位（默认 0.7 m） */
    float home_dist;        /* 回原位多近算到家（默认 0.6 m） */
    float max_out_time;     /* 一次让位最多持续多久（默认 6 s，超时计 timeout） */
    float cell;             /* 压力场格边长（默认 2 m） */
    float radii[RT_YIELD_RADII];   /* 候选半径（默认 2 / 4 m） */
} RtYieldConfig;

typedef struct {
    int32_t  state;      /* RtYieldState */
    RtVec2   home;       /* 原位 */
    RtVec2   target;     /* 让位点 */
    RtVec2   wrote;      /* 本层上一帧写进 pref_vel 的值（检测上层接管） */
    float    timer;      /* 当前状态已持续 */
    float    cooldown;   /* 回位冷却 */
    uint32_t yields;     /* 累计让路次数 */
    int32_t  cand;       /* 上次选中的候选编号（诊断） */
} RtYieldUnit;

typedef struct {
    uint32_t triggers;
    uint32_t completed;      /* 让完并回到原位 */
    uint32_t no_candidate;   /* 32 个候选全不可用 */
    uint32_t home_blocked;   /* 想回位但原位被占 */
    uint32_t timeouts;
    uint32_t denied;         /* 上层回调否决 */
    uint32_t count[4];       /* 当前四种状态人数 */
} RtYieldStats;

typedef struct {
    RtYieldConfig cfg;
    RtYieldUnit *u;
    int cap;

    float *press;    /* pw*ph 压力场 */
    int pw, ph;
    float pcell, px0, pz0;
    float acc_t, dec_t;

    RtYieldStats st;
} RtYieldCtx;

void rt_yield_config_default(RtYieldConfig *c);

int  rt_yield_init(RtYieldCtx *c, int max_units, const RtYieldConfig *cfg,
                   const RtGrid *g);
void rt_yield_destroy(RtYieldCtx *c);

/* 上层否决让路（如 formation_locked）。返回 0 = 不许让。可为 NULL。 */
typedef int (*RtYieldMayFn)(void *ud, int idx);

/* 每帧一次，**在调用方填完 mover 的 pref_vel 之后、rt_local_step 之前**。
 * 只处理「没有命令」的单位（|pref_vel| < move_eps 且 inv_mass > 0）。 */
void rt_yield_step(RtYieldCtx *c, RtLocalAgent *ag, int n, const RtGrid *g,
                   float dt, RtYieldMayFn may_yield, void *ud);

float rt_yield_pressure_at(const RtYieldCtx *c, RtVec2 p);
const char *rt_yield_state_name(int s);

#ifdef __cplusplus
}
#endif

#endif /* RT_YIELD_H */

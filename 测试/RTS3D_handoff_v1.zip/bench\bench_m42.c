/* ============================================================================
 * bench_m42.c -- M4.2：目标维度 Route Cache + 精确失效
 *
 * 与 bench_m4 同图同 seed（256²、10% 噪声、竖墙 + 3 格门），四段对照：
 *   cold     首次命令
 *   warm     完全相同命令重复
 *   unrelated edit  远端建楼（不碰任何 route dependency）
 *   related edit    走廊上建楼（只影响经过它的 route）
 *
 * 另测：
 *   D. 50 sequential targets × 20 units（原报告误称 "50 groups"，这里按真实语义命名）
 *   E. commit 失效成本 vs cache 条目数（16 / 50 / 100 / 256）
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c bench/bench_m42.c -o bench_m42
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void t_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void t_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static uint64_t g_state = 0xC0FFEEull;
static uint64_t nu(void)
{
    uint64_t z = (g_state += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
}

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static uint32_t g_ver = 0;

static void build_map_ex(int w, int noise_permille, int with_wall)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_grid_init(&G, w, w, 1.0f);
    g_state = 0xC0FFEEull + (uint64_t)w + (uint64_t)with_wall;
    for (int z = 0; z < w; z++)
        for (int x = 0; x < w; x++)
            if ((nu() >> 40) % 1000 < (uint64_t)noise_permille)
                rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    if (with_wall) {
        for (int z = 0; z < w; z++)
            if (z != w / 2) rt_grid_set_terrain(&G, w / 2, z, RT_CELL_BLOCKED_TERRAIN, 1);
        for (int dz = -1; dz <= 1; dz++) {
            rt_grid_set_terrain(&G, w / 2 - 1, w / 2 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
            rt_grid_set_terrain(&G, w / 2,     w / 2 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
            rt_grid_set_terrain(&G, w / 2 + 1, w / 2 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        }
    }
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
    g_ver = 0;
}

static void build_map(int w, int noise_permille)
{
    build_map_ex(w, noise_permille, 1);
}

static int spawn_disc(RtUnitId *ids, int n, float cx, float cz, float r)
{
    int k = 0;
    for (int i = 0; i < n * 3 && k < n; i++) {
        float rad = r * sqrtf((float)i / (float)(n * 3));
        float ang = (float)i * 2.39996323f;
        int x = rt_grid_cell_x(&G, cx + cosf(ang) * rad);
        int z = rt_grid_cell_z(&G, cz + sinf(ang) * rad);
        if (!rt_grid_walkable(&G, x, z)) continue;
        RtUnitId id = rt_units_spawn(&US, rt_v3((float)x + 0.5f, 0.f, (float)z + 0.5f), RT_FP_SMALL);
        if (id != RT_UNIT_ID_NONE) ids[k++] = id;
    }
    return k;
}

typedef struct {
    uint32_t builds, hits, misses, invalidated, evicted, goal_h, goal_m;
    int routes;
    double cmd_ms, sample_ms;
} Row;

static double sample_all(const RtUnitId *ids, int n)
{
    double t0 = now_ms();
    volatile float acc = 0.f;
    for (int i = 0; i < n; i++) {
        RtVec3 p = rt_units_pos(&US, ids[i]);
        RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[i]);
        int gi = (int)ch->group[rt_unit_slot_index(ids[i])] - 1;
        RtVec2 tgt;
        if (gi >= 0 && rt_gw_sample(&W, gi, rt_v2(p.x, p.z), &tgt) == RT_OK) acc += tgt.x;
    }
    double t1 = now_ms();
    (void)acc;
    return t1 - t0;
}

static Row run_stage(const RtUnitId *ids, int n, RtVec2 dest, int do_sample)
{
    Row r;
    memset(&r, 0, sizeof(r));
    double t0 = now_ms();
    rt_gw_command(&W, &US, ids, n, dest, 0, RT_CLS_SMALL, ++g_ver);
    double t1 = now_ms();
    r.cmd_ms = t1 - t0;
    r.builds = W.stats.route_builds;
    r.hits = W.stats.route_cache_hits;
    r.misses = W.stats.route_cache_misses;
    r.invalidated = W.stats.route_invalidated;
    r.evicted = W.stats.route_evicted;
    r.goal_h = W.stats.goal_cache_hits;
    r.goal_m = W.stats.goal_cache_misses;
    for (int i = 0; i < W.group_count; i++) r.routes += W.groups[i].route_count;
    r.sample_ms = do_sample ? sample_all(ids, n) : 0.0;
    return r;
}

static void print_row(const char *case_name, const char *stage, Row r)
{
    printf("  %-10s %-15s %-6d %-7u %-6u %-6u %-6u %-6u %-7u %-8.3f %-8.4f\n",
           case_name, stage, r.routes, r.builds, r.hits, r.misses, r.invalidated,
           r.evicted, r.goal_h, r.cmd_ms, r.sample_ms);
}

/* 找一块离所有 route dependency ≥ pad 格 的空地（用于「无关编辑」） */
static int find_isolated_spot(int pad, int *out_x, int *out_z)
{
    static uint8_t used[RT_CHUNK_N];
    memset(used, 0, sizeof(used));
    for (int i = 0; i < W.group_count; i++)
        for (int k = 0; k < W.groups[i].route_count; k++) {
            RtRoute *rt = &W.groups[i].routes[k].route;
            for (int j = 0; j < rt->dep_n; j++)
                if (rt->dep_chunks[j] < RT_CHUNK_N) used[rt->dep_chunks[j]] = 1;
        }
    for (int z = pad; z + pad < G.h; z += 4)
        for (int x = pad; x + pad < G.w; x += 4) {
            int ok = 1;
            for (int dz = -pad; dz <= pad && ok; dz += 4)
                for (int dx = -pad; dx <= pad; dx += 4) {
                    int c = rt_grid_chunk_of_cell(&G, x + dx, z + dz);
                    if (c >= 0 && c < RT_CHUNK_N && used[c]) { ok = 0; break; }
                }
            if (ok) { *out_x = x; *out_z = z; return 1; }
        }
    return 0;
}

/* 找一块「只被一条 route 依赖」的 chunk：用于「局部相关编辑」 */
static int find_unique_chunk(int *out_cx, int *out_cz, int *out_route_idx)
{
    int cw = (G.w + RT_CHUNK_PX - 1) / RT_CHUNK_PX;
    for (int i = 0; i < W.group_count; i++)
        for (int k = 0; k < W.groups[i].route_count; k++) {
            RtRoute *rt = &W.groups[i].routes[k].route;
            for (int j = 0; j < rt->dep_n; j++) {
                uint32_t ch = rt->dep_chunks[j];
                int shared = 0;
                for (int a = 0; a < W.group_count && !shared; a++)
                    for (int b = 0; b < W.groups[a].route_count && !shared; b++) {
                        if (a == i && b == k) continue;
                        RtRoute *o = &W.groups[a].routes[b].route;
                        for (int q = 0; q < o->dep_n; q++)
                            if (o->dep_chunks[q] == ch) { shared = 1; break; }
                    }
                if (!shared) {
                    *out_cx = (int)(ch % (uint32_t)cw);
                    *out_cz = (int)(ch / (uint32_t)cw);
                    *out_route_idx = k;
                    return 1;
                }
            }
        }
    return 0;
}

static void run_scaling(void)
{
    printf("\n-- A. unit scaling: cold / warm / unrelated edit / related edit --\n");
    printf("  %-10s %-15s %-6s %-7s %-6s %-6s %-6s %-6s %-7s %-8s %-8s\n",
           "case", "stage", "routes", "builds", "hits", "miss", "inval", "evict",
           "goal_h", "cmd_ms", "sample_ms");

    int counts[] = { 1, 50, 300, 1000 };
    for (int c = 0; c < 4; c++) {
        int n = counts[c];
        char name[32];
        snprintf(name, sizeof(name), "%d units", n);
        build_map(256, 100);
        static RtUnitId ids[1024];
        int got = spawn_disc(ids, n, 50.f, 60.f, 12.f);
        RtVec2 dest = rt_v2(210.5f, 190.5f);

        Row a = run_stage(ids, got, dest, 1);
        print_row(name, "cold", a);
        Row b = run_stage(ids, got, dest, 1);
        print_row(name, "warm", b);

        int ix = 0, iz = 0;
        if (find_isolated_spot(26, &ix, &iz)) {
            RtGridDirty d;
            rt_grid_add_building_dirty(&G, ix, iz, 6, 6, &d);
            rt_grid_apply_dirty(&G, &d);
        }
        /* 把「区域图全量重建」单独计时：它属于 M4.6，不该算进 M4.2 的 command 成本 */
        double rr0 = now_ms();
        rt_region_refresh(&MAP);
        double rr1 = now_ms();
        Row u = run_stage(ids, got, dest, 0);
        print_row(name, "unrelated edit", u);
        printf("    (region map refresh after edit: %.3f ms -- M4.6 territory)\n", rr1 - rr0);

        RtGridDirty d2;
        rt_grid_add_building_dirty(&G, 140, 125, 8, 8, &d2);   /* 压住门后走廊 */
        rt_grid_apply_dirty(&G, &d2);
        double rr2 = now_ms();
        rt_region_refresh(&MAP);
        double rr3 = now_ms();
        Row r = run_stage(ids, got, dest, 1);
        print_row(name, "related edit", r);
        printf("    (region map refresh after edit: %.3f ms)\n\n", rr3 - rr2);
    }
}

/* F. 分散源区域下的局部相关编辑：只有 1 条 route 应该被重建 */
static void run_localized(void)
{
    printf("-- F. localized related edit (dispersed sources, open map) --\n");
    build_map_ex(256, 0, 0);
    static RtUnitId ids[16];
    float pos[8][2] = { {30,30},{100,30},{170,30},{225,40},{30,110},{30,190},{30,240},{100,240} };
    int n = 0;
    for (int i = 0; i < 8; i++) {
        RtUnitId id = rt_units_spawn(&US, rt_v3(pos[i][0] + 0.5f, 0.f, pos[i][1] + 0.5f), RT_FP_SMALL);
        if (id != RT_UNIT_ID_NONE) ids[n++] = id;
    }
    RtVec2 dest = rt_v2(215.5f, 115.5f);
    Row cold = run_stage(ids, n, dest, 0);
    Row warm = run_stage(ids, n, dest, 0);

    int routes = 0;
    for (int i = 0; i < W.group_count; i++) routes += W.groups[i].route_count;

    int cx = 0, cz = 0, ri = -1;
    int found = find_unique_chunk(&cx, &cz, &ri);
    printf("  units=%d routes=%d cold_builds=%u warm_builds=%u | unique chunk: %s (%d,%d) route_slot=%d\n",
           n, routes, cold.builds, warm.builds, found ? "yes" : "no", cx, cz, ri);
    if (!found) { printf("\n"); return; }

    int bx = cx * RT_CHUNK_PX + 12, bz = cz * RT_CHUNK_PX + 12;
    if (bx < 0) bx = 0;
    if (bz < 0) bz = 0;
    if (bx + 6 > G.w) bx = G.w - 6;
    if (bz + 6 > G.h) bz = G.h - 6;
    RtGridDirty d;
    rt_grid_add_building_dirty(&G, bx, bz, 6, 6, &d);
    rt_grid_apply_dirty(&G, &d);

    uint32_t b0 = W.stats.route_builds, i0 = W.stats.route_invalidated;
    int rebuilt = rt_gw_update(&W);
    printf("  edit at (%d,%d): rebuilt=%d invalidated=%u builds=%u  (total routes=%d)\n",
           bx, bz, rebuilt, W.stats.route_invalidated - i0, W.stats.route_builds - b0, routes);
    printf("\n");
}

/* D. 50 sequential targets × 20 units（不是并发 50 组，M4.5 才做并发） */
static void run_sequential_targets(int targets, int per)
{
    printf("-- D. %d sequential targets x %d units (NOT concurrent groups) --\n", targets, per);
    build_map(256, 60);
    static RtUnitId ids[1024];
    double t_cmd = 0, t_samp = 0;
    uint32_t builds = 0, hits = 0, miss = 0, inval = 0, evict = 0;
    int total_routes = 0;

    for (int g = 0; g < targets; g++) {
        rt_units_init(&US);
        float sx = 30.f + (float)(g % 5) * 40.f;
        float sz = 30.f + (float)(g / 5) * 40.f;
        float gx = 220.f - (float)(g % 5) * 30.f;
        float gz = 220.f - (float)(g / 5) * 30.f;
        int got = spawn_disc(ids, per, sx, sz, 5.f);
        Row r = run_stage(ids, got, rt_v2(gx, gz), 0);
        t_cmd += r.cmd_ms;
        t_samp += sample_all(ids, got);
        builds += r.builds; hits += r.hits; miss += r.misses;
        inval += r.invalidated; evict += r.evicted;
        total_routes += r.routes;
    }
    printf("  units=%d routes=%d builds=%u hits=%u miss=%u inval=%u evict=%u "
           "cmd_total=%.3f ms (%.3f/target) sample=%.4f ms\n\n",
           targets * per, total_routes, builds, hits, miss, inval, evict,
           t_cmd, t_cmd / targets, t_samp);
}

/* E. commit 失效成本 vs cache 条目数 */
static void run_commit_cost(void)
{
    printf("-- E. invalidation / lookup cost vs cached route count --\n");
    printf("  %-8s %-16s %-16s %-16s %-16s %-10s\n",
           "entries", "update_first_us", "update_steady_us", "cmd_new_goal_us", "cmd_warm_us", "cache_KB");

    int wants[] = { 16, 50, 100, 256 };
    for (int w = 0; w < 4; w++) {
        build_map(256, 0);
        RtUnitId id = rt_units_spawn(&US, rt_v3(20.5f, 0.f, 20.5f), RT_FP_SMALL);
        RtUnitId ids[1] = { id };
        int want = wants[w];

        /* 用不同目标把 cache 填到 want 条 */
        for (int i = 0; i < want; i++) {
            float gx = 40.f + (float)(i % 16) * 12.f;
            float gz = 60.f + (float)(i / 16) * 12.f;
            rt_gw_command(&W, &US, ids, 1, rt_v2(gx, gz), 0, RT_CLS_SMALL, ++g_ver);
        }
        /* 一次远端小编辑，然后测 update（第一次含区域图刷新，之后为稳态无变化） */
        RtGridDirty d;
        rt_grid_add_building_dirty(&G, 240, 240, 4, 4, &d);
        rt_grid_apply_dirty(&G, &d);

        double f0 = now_ms();
        rt_gw_update(&W);
        double f1 = now_ms();

        double best = 1e30;
        for (int rep = 0; rep < 9; rep++) {
            double t0 = now_ms();
            rt_gw_update(&W);
            double t1 = now_ms();
            if (t1 - t0 < best) best = t1 - t0;
        }

        /* new goal：每次一个全新目标（miss + insert，可能触发淘汰） */
        double cold = 1e30;
        for (int rep = 0; rep < 15; rep++) {
            float gx = 60.f + (float)(rep % 5) * 17.f, gz = 150.f + (float)(rep % 5) * 11.f;
            double c0 = now_ms();
            rt_gw_command(&W, &US, ids, 1, rt_v2(gx, gz), 0, RT_CLS_SMALL, ++g_ver);
            double c1 = now_ms();
            if (c1 - c0 < cold) cold = c1 - c0;
        }
        /* warm：重复同一个已缓存目标（纯 lookup + copy 路径）。
         * 先跑一次确保它还在缓存里（高装载时可能已被 LRU 淘汰）。 */
        rt_gw_command(&W, &US, ids, 1, rt_v2(40.f, 60.f), 0, RT_CLS_SMALL, ++g_ver);
        double warm = 1e30;
        for (int rep = 0; rep < 15; rep++) {
            double c0 = now_ms();
            rt_gw_command(&W, &US, ids, 1, rt_v2(40.f, 60.f), 0, RT_CLS_SMALL, ++g_ver);
            double c1 = now_ms();
            if (c1 - c0 < warm) warm = c1 - c0;
        }

        printf("  %-8d %-16.2f %-16.2f %-16.2f %-16.2f %-10.1f\n",
               rt_gw_route_cache_count(&W), (f1 - f0) * 1000.0, best * 1000.0,
               cold * 1000.0, warm * 1000.0,
               (double)rt_gw_cache_bytes(&W) / 1024.0);
    }
    printf("\n");
}

int main(void)
{
    t_init();
    printf("=== M4.2 bench: goal-dimension route cache + precise invalidation ===\n");
    printf("grid 256x256, 10%% terrain noise, wall + 3-cell gate\n");
    printf("route cache = %d slots (load %.2f), goal cache = %d slots\n\n",
           RT_ROUTE_CACHE_CAP, (double)RT_CACHE_LOAD_NUM / (double)RT_CACHE_LOAD_DEN,
           RT_GOAL_CACHE_CAP);

    run_scaling();
    run_localized();
    run_sequential_targets(50, 20);
    run_commit_cost();

    printf("-- notes --\n");
    printf("  builds = real A* runs; hits = key present AND dependency valid;\n");
    printf("  miss = key absent; inval = key present but dependency stale (counted separately)\n");
    printf("  'related edit' builds a wall on the gate corridor -> all converging routes depend on it\n");
    return 0;
}

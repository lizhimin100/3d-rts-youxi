/* ============================================================================
 * bench_m2.c -- M2 区域增量导航重建基准（B1~B8 + Incremental/Full 交叉点）
 *
 * 口径纪律（裁定 C-1 / M2 要求）：
 *   - 每条测量打印 runs 与 min/med/p95；
 *   - **同时**报告 Full 与 Incremental，Speedup 由实测得出；
 *   - 打印 dirty area 比例与「是否降级全量」；
 *   - 不把 microbenchmark 当生产保证：这里的数字只覆盖"导航重建"这一段，
 *     不含 ORCA / 流场 / job dispatch。
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c bench/bench_m2.c -o bench_m2
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

typedef struct { double mn, med, p95; int n; } Stat;
static int cmp_d(const void *a, const void *b) { double x = *(const double *)a, y = *(const double *)b; return (x > y) - (x < y); }
static Stat stat_of(double *v, int n)
{
    Stat s; memset(&s, 0, sizeof(s));
    if (!n) return s;
    qsort(v, (size_t)n, sizeof(double), cmp_d);
    s.n = n; s.mn = v[0]; s.med = v[n / 2];
    s.p95 = v[(int)(n * 0.95) >= n ? n - 1 : (int)(n * 0.95)];
    return s;
}

/* ---------------------------------------------------------------- RNG */
static uint64_t g_state = 0xDEADBEEFCAFEull;
static uint64_t nu(void) {
    uint64_t z = (g_state += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
}
static int rr(int lo, int hi) { return hi <= lo ? lo : lo + (int)(nu() % (uint64_t)(hi - lo)); }

/* ---------------------------------------------------------------- 场景 */
#define W 512
#define H 512
static RtGrid G;

static void build_base(void)
{
    rt_grid_destroy(&G);
    if (rt_grid_init(&G, W, H, 1.0f) != RT_OK) { printf("init fail\n"); exit(2); }
    g_state = 0xC0FFEEull;
    for (int z = 0; z < H; z++)
        for (int x = 0; x < W; x++)
            if ((nu() >> 40) % 1000 < 120)      /* 12% 随机地形 */
                rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);
}

/* 在副本上测全量成本：用同一张图，做同样的数据修改，然后 rebuild_all。
 * 为避免「增量已改动、全量无法复现」的问题，这里采用：
 *   测增量：G 上直接做；
 *   测全量：把编辑撤掉，再做一次 rebuild_all（作为全量成本的代表）。
 * 因为 rebuild_all 的成本与内容无关（O(w*h)），这样测得成立。 */
static void measure_pair(const char *tag, int x, int z, int bw, int bh, int add,
                         int runs, double *inc_ms, double *full_ms, int *degraded,
                         double *dirty_ratio)
{
    static double vi[256], vf[256];
    if (runs > 256) runs = 256;
    int deg = 0;
    RtGridDirty d;

    for (int r = 0; r < runs; r++) {
        /* 增量 */
        double t0 = now_ms();
        if (add) rt_grid_add_building_dirty(&G, x, z, bw, bh, &d);
        else     rt_grid_remove_building_dirty(&G, x, z, bw, bh, &d);
        int rc = rt_grid_apply_dirty(&G, &d);
        double t1 = now_ms();
        vi[r] = t1 - t0;
        if (rc != RT_OK) deg++;

        if (r == 0) {
            double area = (double)bw * (double)bh;
            *dirty_ratio = area / ((double)W * (double)H);
        }

        /* 撤销本次编辑（不测时），再测全量 */
        if (add) rt_grid_remove_building_dirty(&G, x, z, bw, bh, NULL);
        else     rt_grid_add_building_dirty(&G, x, z, bw, bh, NULL);

        double t2 = now_ms();
        rt_grid_rebuild_all(&G);
        double t3 = now_ms();
        vf[r] = t3 - t2;
    }

    Stat si = stat_of(vi, runs);
    Stat sf = stat_of(vf, runs);
    *inc_ms = si.med;
    *full_ms = sf.med;
    *degraded = deg;

    printf("  %-34s inc: min=%7.3f med=%7.3f p95=%7.3f | full: med=%7.2f | x%6.1f | dirty=%5.2f%% deg=%d/%d\n",
           tag, si.mn, si.med, si.p95, sf.med,
           si.med > 1e-6 ? sf.med / si.med : 0.0,
           *dirty_ratio * 100.0, deg, runs);
}

int main(void)
{
    timer_init();
    printf("=== M2 bench: regional incremental navigation rebuild ===\n");
    printf("grid %dx%d  base: 12%% random terrain\n", W, H);

    build_base();
    {
        RtGridStats st;
        rt_grid_stats(&G, &st);
        printf("base stats: walkable=%d components=%d clearance_max=%.2f m mean=%.2f m\n\n",
               st.walkable_cells, st.component_count, st.clearance_max_m, st.clearance_mean_m);
    }

    double inc, full, dr;
    int deg;

    printf("-- B1~B3: single building edits --\n");
    measure_pair("B1 add 2x2", 200, 200, 2, 2, 1, 120, &inc, &full, &deg, &dr);
    measure_pair("B2 add 20x20", 200, 200, 20, 20, 1, 60, &inc, &full, &deg, &dr);
    {   /* B3 删除：先放一个 20x20，再反复删/加 */
        rt_grid_add_building_dirty(&G, 300, 300, 20, 20, NULL);
        rt_grid_rebuild_all(&G);
        measure_pair("B3 remove 20x20", 300, 300, 20, 20, 0, 60, &inc, &full, &deg, &dr);
        /* 清理：恢复到「没有该建筑」 */
        rt_grid_remove_building_dirty(&G, 300, 300, 20, 20, NULL);
        rt_grid_rebuild_all(&G);
    }

    printf("\n-- B4/B5: corridor split / merge --\n");
    {
        /* 造一条 4m 宽的通道：两道竖墙夹一条可走带 */
        for (int z = 60; z < 460; z++) {
            for (int x = 120; x <= 124; x++) {
                if (x == 120 || x == 124)
                    rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
            }
        }
        rt_grid_rebuild_all(&G);

        /* B4: 用 4x4 建筑堵死通道 -> split */
        measure_pair("B4 block 4m corridor (split)", 121, 250, 4, 4, 1, 30, &inc, &full, &deg, &dr);
        /* 保证真的堵上了，再测 B5 */
        rt_grid_add_building(&G, 121, 250, 4, 4);
        { RtGridStats st; rt_grid_stats(&G, &st);
          printf("  after block: components=%d (expect +1 due to split)\n", st.component_count); }
        measure_pair("B5 unblock (merge)", 121, 250, 4, 4, 0, 30, &inc, &full, &deg, &dr);
        rt_grid_remove_building(&G, 121, 250, 4, 4);
    }

    printf("\n-- B6/B7: batch and sustained edits --\n");
    {
        /* B6: 一帧 10 个建筑 */
        static double v[40];
        int runs = 30;
        for (int r = 0; r < runs; r++) {
            double t0 = now_ms();
            for (int k = 0; k < 10; k++) {
                int x = 40 + rr(0, 400), z = 40 + rr(0, 400);
                RtGridDirty d;
                rt_grid_add_building_dirty(&G, x, z, 3, 3, &d);
                rt_grid_apply_dirty(&G, &d);
            }
            double t1 = now_ms();
            v[r] = t1 - t0;
            /* 清理：整图重建（不计时） */
            rt_grid_clear_buildings(&G);
            rt_grid_rebuild_all(&G);
        }
        Stat s = stat_of(v, runs);
        printf("  %-34s inc: min=%7.3f med=%7.3f p95=%7.3f (10 buildings/frame)\n",
               "B6 10 buildings in one frame", s.mn, s.med, s.p95);

        /* B7: 连续 100 帧随机编辑 */
        double t0 = now_ms();
        int added = 0, deg7 = 0;
        for (int f = 0; f < 100; f++) {
            RtGridDirty d;
            int x = 40 + rr(0, 400), z = 40 + rr(0, 400);
            if (rr(0, 100) < 60) {
                rt_grid_add_building_dirty(&G, x, z, 2, 2, &d);
                added++;
            } else if (added > 0) {
                rt_grid_remove_building_dirty(&G, x, z, 2, 2, &d);
                added--;
            } else {
                continue;
            }
            if (rt_grid_apply_dirty(&G, &d) != RT_OK) deg7++;
        }
        double t1 = now_ms();
        printf("  %-34s total=%7.2f ms  avg=%6.3f ms/frame  degraded=%d/100\n",
               "B7 100 frames continuous edits", t1 - t0, (t1 - t0) / 100.0, deg7);
        rt_grid_clear_buildings(&G);
        rt_grid_rebuild_all(&G);
    }

    printf("\n-- B8 + crossover: dirty area ratio sweep --\n");
    printf("  %-10s %-10s %-12s %-12s %-10s %-8s\n",
           "side", "area%", "inc_med(ms)", "full_med(ms)", "speedup", "degraded");
    {
        int sides[] = { 4, 8, 11, 16, 23, 32, 45, 64, 90, 128, 181, 256 };
        for (int k = 0; k < (int)(sizeof(sides) / sizeof(sides[0])); k++) {
            int side = sides[k];
            int runs = (side <= 45) ? 40 : (side <= 90 ? 20 : 10);
            RtGridDirty d;
            static double vi[64], vf[64];
            int deg = 0;
            for (int r = 0; r < runs; r++) {
                int x = W / 2 - side / 2, z = H / 2 - side / 2;
                double t0 = now_ms();
                rt_grid_add_building_dirty(&G, x, z, side, side, &d);
                int rc = rt_grid_apply_dirty(&G, &d);
                double t1 = now_ms();
                vi[r] = t1 - t0;
                if (rc != RT_OK) deg++;

                rt_grid_remove_building_dirty(&G, x, z, side, side, NULL);
                double t2 = now_ms();
                rt_grid_rebuild_all(&G);
                double t3 = now_ms();
                vf[r] = t3 - t2;
            }
            Stat si = stat_of(vi, runs);
            Stat sf = stat_of(vf, runs);
            double area = (double)side * side / ((double)W * H) * 100.0;
            printf("  %-10d %-10.2f %-12.3f %-12.2f %-10.2f %d/%d\n",
                   side, area, si.med, sf.med,
                   si.med > 1e-6 ? sf.med / si.med : 0.0, deg, runs);
        }
    }

    printf("\n-- crossover sweep 2: corner-anchored (不切断连通，纯成本对比) --\n");
    printf("  %-10s %-10s %-12s %-12s %-10s %-8s\n",
           "side", "area%", "inc_med(ms)", "full_med(ms)", "speedup", "degraded");
    {
        int sides[] = { 16, 32, 45, 64, 90, 128, 181, 256 };
        for (int k = 0; k < (int)(sizeof(sides) / sizeof(sides[0])); k++) {
            int side = sides[k];
            int runs = (side <= 45) ? 30 : (side <= 90 ? 15 : 8);
            RtGridDirty d;
            static double vi[64], vf[64];
            int deg = 0;
            for (int r = 0; r < runs; r++) {
                int x = 1, z = 1;
                double t0 = now_ms();
                rt_grid_add_building_dirty(&G, x, z, side, side, &d);
                int rc = rt_grid_apply_dirty(&G, &d);
                double t1 = now_ms();
                vi[r] = t1 - t0;
                if (rc != RT_OK) deg++;
                rt_grid_remove_building_dirty(&G, x, z, side, side, NULL);
                double t2 = now_ms();
                rt_grid_rebuild_all(&G);
                double t3 = now_ms();
                vf[r] = t3 - t2;
            }
            Stat si = stat_of(vi, runs);
            Stat sf = stat_of(vf, runs);
            double area = (double)side * side / ((double)W * H) * 100.0;
            printf("  %-10d %-10.2f %-12.3f %-12.2f %-10.2f %d/%d\n",
                   side, area, si.med, sf.med,
                   si.med > 1e-6 ? sf.med / si.med : 0.0, deg, runs);
        }
    }

    printf("\n-- counters --\n");
    printf("  full_rebuild_count (degraded) : %u\n", G.full_rebuild_count);
    printf("  split_detected_count          : %u\n", G.split_detected_count);
    printf("  merge_detected_count          : %u\n", G.merge_detected_count);

    rt_grid_destroy(&G);
    printf("\nbench_m2 done\n");
    return 0;
}

/* 临时：找一个确定性的「必须绕柱子」场景，并验证 fine flow 的真实作用
 * （fine off 会卡住 / 撞墙，fine on 能到达）。跑完即删。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;

typedef struct { int arr, pen, steps, stall_pos; float endx, endz; } WalkRes;

static WalkRes walk(RtVec2 start, int gi, int max_steps);
static WalkRes walk(RtVec2 start, int gi, int max_steps)
{
    WalkRes r; memset(&r, 0, sizeof(r));
    RtVec2 p = start;
    for (int i = 0; i < max_steps && !r.arr; i++) {
        RtVec2 tgt;
        if (rt_gw_sample(&W, gi, p, &tgt) != RT_OK) break;
        RtVec2 d = rt_v2_sub(tgt, p);
        float len = rt_v2_len(d);
        if (len < 1e-4f) { r.pen += 1000; break; }
        float step = 0.2f;
        if (step > len) step = len;
        RtVec2 np = rt_v2_add(p, rt_v2_mul(d, step / len));
        if (!rt_los_clear(&G, p, np)) { r.pen++; break; }
        p = np; r.steps++;
        if (rt_gw_is_arrived(&W, gi, p, 1.5f)) r.arr = 1;
    }
    r.endx = p.x; r.endz = p.z;
    return r;
}

static void scene(int px, int pz, int pw, int ph)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int z = pz; z < pz + ph; z++)
        for (int x = px; x < px + pw; x++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
}

static WalkRes run_one(RtVec2 s, RtVec2 d, int fine_on, int *blocked)
{
    rt_gw_set_fine_enabled(&W, fine_on);
    RtUnitId id = rt_units_spawn(&US, rt_v3(s.x, 0.f, s.z), RT_FP_SMALL);
    RtUnitId ids[1] = { id };
    rt_gw_command(&W, &US, ids, 1, d, 0, RT_CLS_SMALL, 1);
    int gi = (int)((RtUnitChunk *)rt_units_chunk_c(&US, id))->group[rt_unit_slot_index(id)] - 1;
    *blocked = (int)W.stats.corridor_blocked;
    return walk(s, gi, 6000);
}

int main(void)
{
    printf("=== find a deterministic 'must go around the pillar' scene ===\n");
    printf("  (pillar placed so a corridor segment crosses it)\n");

    RtVec2 s = rt_v2(100.5f, 100.5f), d = rt_v2(170.5f, 100.5f);
    for (int pz = 96; pz <= 104; pz++) {
        for (int pw = 1; pw <= 4; pw++) {
            int px = 128 + (pz % 3);
            scene(px, pz, pw, 3);
            int blk_on = 0, blk_off = 0;
            WalkRes off = run_one(s, d, 0, &blk_off);
            scene(px, pz, pw, 3);
            WalkRes on = run_one(s, d, 1, &blk_on);
            if (blk_on > 0 || off.arr == 0) {
                printf("  pillar x=%d z=%d w=%d h=3 : blocked=%d | OFF arr=%d pen=%d steps=%d end=(%.1f,%.1f)"
                       " | ON arr=%d pen=%d steps=%d end=(%.1f,%.1f) fine(b=%u used=%u)\n",
                       px, pz, pw, blk_on, off.arr, off.pen, off.steps, off.endx, off.endz,
                       on.arr, on.pen, on.steps, on.endx, on.endz,
                       W.stats.fine_builds, W.stats.fine_used);
            }
        }
    }

    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return 0;
}

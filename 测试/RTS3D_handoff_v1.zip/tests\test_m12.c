/* ============================================================================
 * test_m12.c -- 队形接入流水线（FR-FOR，M8 的 rt_form 第一次进仿真）
 *
 * M8 只验证了「slot 生成 / 分配 / 窄道降级」的正确性（单元级）。
 * 本文件把它接到真实四层流水线里，回答一个集成问题：
 *   **「让每个人去自己的 slot」和「让所有人去同一个坐标」到底差多少？**
 *
 * 指标：
 *   slot 覆盖率   —— 有多少个 slot 被恰好一个人占住（1.5 m 内）
 *   凝聚度        —— rt_form_cohesion（1 - 平均偏差 / R）
 *   最小间距      —— 队形应该 ≈ pitch（2.2 m），挤一个点会掉到 1 m 左右
 *   到位时间      —— 95% 的人进到自己 slot 的 2 m 内
 *   帧成本 / 穿透 / 永久放弃
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_stuck.h"
#include "rt_yield.h"
#include "rt_form.h"
#include "rt_region.h"
#include "rt_group.h"
#include "rt_unit.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", (m)); } } while (0)

#define MAXA 512
#define N_UNITS 144          /* 12×12 方阵 */

static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;
static RtStuckCtx SC;
static RtYieldCtx YC;
static RtFormation FM;
static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static RtUnitId IDS[MAXA];
static int SLOT_OF[MAXA];
static RtFormMember MEM[MAXA];      /* 落脚状态（带滞回，库里的） */
static RtFormSettle SET;
static int N = 0;

typedef struct {
    int    on_slot;
    int    slots_covered;   /* 1.5 m 内有人的 slot 数 */
    double t95;             /* 95% 到位时刻（秒），-1 = 未达成 */
    float  cohesion;
    float  min_pair;
    float  nn_min;          /* 每单位最近邻距离的 min / p10 / 中位数 */
    float  nn_p10;
    float  nn_median;
    float  pitch_x_meas;    /* 实测晶格间距（列均值的相邻差中位数） */
    float  pitch_z_meas;
    int    pairs_lt_140;    /* < 1.40 m 的对数（ORCA 接触距离 1.00 说明在互相顶） */
    float  mean_gap;        /* 到目标（slot / 点）的平均距离 */
    float  centroid_err;    /* 质心到 anchor 的距离（队形应当以 anchor 为中心） */
    float  spread;          /* 到质心的平均距离 */
    int    overlap_pairs;
    float  max_pen;
    double t_mean, t_worst;
    uint32_t stuck_perm;
    uint32_t reengages;
    int    frames;
} Metrics;

static void build_world(void)
{
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    rt_grid_rebuild_all(&G);

    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);

    rt_local_destroy(&LC);
    rt_local_init(&LC, 256.f, 256.f, MAXA, 4.0f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);
    rt_stuck_destroy(&SC);
    rt_stuck_init(&SC, MAXA, NULL);
    rt_yield_destroy(&YC);
    rt_yield_init(&YC, MAXA, NULL, &G);
}

static void spawn_block(int n, float x0, float z0, int cols)
{
    N = 0;
    for (int i = 0; i < n; i++) {
        float x = x0 + (float)(i % cols) * 1.6f;
        float z = z0 + (float)(i / cols) * 1.6f;
        RtUnitId id = rt_units_spawn(&US, rt_v3(x, 0.f, z), RT_FP_SMALL);
        if (id == RT_UNIT_ID_NONE) break;
        IDS[N] = id;
        rt_form_member_reset(&MEM[N]);
        memset(&AG[N], 0, sizeof(AG[N]));
        AG[N].pos = rt_v2(x, z);
        AG[N].radius = 0.5f;
        AG[N].max_speed = 2.0f;
        AG[N].fp = 1.0f;
        AG[N].share = 0.5f;
        AG[N].inv_mass = 1.f;
        N++;
    }
}

static int cmp_float(const void *a, const void *b)
{
    float x = *(const float *)a, y = *(const float *)b;
    return (x < y) ? -1 : (x > y ? 1 : 0);
}

/* 晶格间距直测：把 slot 按列分组，取每列实际 x 的均值，再取相邻列差的中位数。
 * 这是「方阵到底有没有 2.2 m 的格距」的**直接**量：每个单位在自己的格点附近随机
 * 抖 ±0.35 不会改变列均值，但整列被推、方阵被压扁会立刻显形。
 * 为什么不用「最近邻距离的最小值」：它是 10 368 对里最差的一对，
 * 只要有一个人被挤一下就红，信息量几乎为零（84 人贴着和 1 人贴着结果一样）。 */
static void measure_pitch(const int *slot_of, int n, int cols, int rows,
                          RtVec2 *pos, float *out_px, float *out_pz)
{
    float *sx = (float *)malloc((size_t)cols * sizeof(float));
    float *sz = (float *)malloc((size_t)rows * sizeof(float));
    int *cn = (int *)calloc((size_t)(cols > rows ? cols : rows), sizeof(int));
    int *rn = (int *)calloc((size_t)(cols > rows ? cols : rows), sizeof(int));
    if (!sx || !sz || !cn || !rn) { free(sx); free(sz); free(cn); free(rn);
        *out_px = *out_pz = 0.f; return; }
    for (int c = 0; c < cols; c++) { sx[c] = 0.f; }
    for (int r = 0; r < rows; r++) { sz[r] = 0.f; }
    for (int i = 0; i < n; i++) {
        int c = slot_of[i] % cols;
        int r = slot_of[i] / cols;
        sx[c] += pos[i].x; cn[c]++;
        sz[r] += pos[i].z; rn[r]++;
    }
    for (int c = 0; c < cols; c++) if (cn[c]) sx[c] /= (float)cn[c];
    for (int r = 0; r < rows; r++) if (rn[r]) sz[r] /= (float)rn[r];
    qsort(sx, (size_t)cols, sizeof(float), cmp_float);
    qsort(sz, (size_t)rows, sizeof(float), cmp_float);

    float gx[64], gz[64];
    int nx = 0, nz = 0;
    for (int c = 1; c < cols && nx < 64; c++) gx[nx++] = sx[c] - sx[c - 1];
    for (int r = 1; r < rows && nz < 64; r++) gz[nz++] = sz[r] - sz[r - 1];
    qsort(gx, (size_t)nx, sizeof(float), cmp_float);
    qsort(gz, (size_t)nz, sizeof(float), cmp_float);
    *out_px = nx ? gx[nx / 2] : 0.f;      /* 中位数：允许个别列被挤，看整体 */
    *out_pz = nz ? gz[nz / 2] : 0.f;
    free(sx); free(sz); free(cn); free(rn);
}

static Metrics run(const char *name, int use_form, RtVec2 dest, int frames_max, int verbose)
{
    Metrics m;
    memset(&m, 0, sizeof(m));

    build_world();
    spawn_block(N_UNITS, 32.f, 108.f, 12);

    const float dt = 1.f / 30.f;

    /* 队形：12×12，pitch = fp + gap = 2.2 m，以 dest 为中心 */
    rt_form_destroy(&FM);
    rt_form_init(&FM, MAXA);
    rt_form_build(&FM, RT_FORM_RECT, N, 1.0f, 1.2f);
    rt_form_set_anchor(&FM, dest);
    rt_form_set_yaw(&FM, 0.f, dt, NULL);

    {
        RtVec2 ps[MAXA];
        for (int i = 0; i < N; i++) ps[i] = AG[i].pos;
        (void)rt_form_assign(&FM, ps, N, SLOT_OF);
    }

    (void)rt_gw_command(&W, &US, IDS, N, dest, 0, RT_CLS_SMALL, 1);
    rt_form_settle_default(&SET);

    double sum = 0, worst = 0;
    int frames = 0;
    float d95_buf[MAXA];
    int n95 = 0;

    for (int s = 0; s < frames_max; s++) {
        frames = s;
        double t0 = now_ms();

        for (int i = 0; i < N; i++) {
            RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, IDS[i]);
            int gi = (int)ch->group[rt_unit_slot_index(IDS[i])] - 1;
            RtVec2 pref = rt_v2(0.f, 0.f);
            int on = 0;

            /* 两组用**同一个**落脚策略，只换目标：
             *   队形 -> 各自的 slot；点目标 -> 同一个 dest。
             * 这样数字差异只可能来自「去哪」，不来自「怎么停」。 */
            if (use_form && rt_v2_dist(AG[i].pos, dest) < 40.f) {
                pref = rt_form_member_steer(&FM, SLOT_OF[i], AG[i].pos,
                                            &MEM[i], &SET, 2.0f, dt);
                on = rt_form_member_arrived(&MEM[i]);
            } else if (gi >= 0) {
                RtVec2 tgt;
                if (rt_gw_sample(&W, gi, AG[i].pos, &tgt) == RT_OK) {
                    RtVec2 aim = use_form ? tgt : dest;
                    if (rt_v2_dist(AG[i].pos, aim) < 40.f) {
                        pref = rt_form_steer_point(aim, AG[i].pos, &MEM[i], &SET, 2.0f, dt);
                        on = rt_form_member_arrived(&MEM[i]);
                    } else {
                        RtVec2 d = rt_v2_sub(aim, AG[i].pos);
                        float l = rt_v2_len(d);
                        if (l > 1e-3f) pref = rt_v2_mul(d, 2.0f / l);
                    }
                }
            }
            AG[i].pref_vel = pref;
            rt_stuck_set_hold(&SC, i, on);
        }

        rt_stuck_step(&SC, AG, N, &G, dt, NULL);
        rt_yield_step(&YC, AG, N, &G, dt, NULL, NULL);
        (void)rt_local_step(&LC, AG, N, &G, dt);
        (void)rt_gw_update(&W);

        double d = now_ms() - t0;
        sum += d;
        if (d > worst) worst = d;

        if ((s % 30) == 0) {
            int done = 0;
            if (use_form) {
                for (int i = 0; i < N; i++) {
                    if (MEM[i].arrived) { done++; continue; }
                    if (rt_v2_dist(AG[i].pos, rt_form_slot_world(&FM, SLOT_OF[i])) < 2.0f) done++;
                }
            } else {
                for (int i = 0; i < N; i++)
                    if (MEM[i].arrived || rt_v2_dist(AG[i].pos, dest) < 2.0f) done++;
            }
            if (m.t95 <= 0.0 && done >= (N * 95 + 99) / 100)
                m.t95 = (double)s * (double)dt;
            if (done == N) break;
        }
    }

    m.frames = frames;
    m.t_mean = sum / (double)(frames + 1);
    m.t_worst = worst;
    m.stuck_perm = SC.st.permanent_stuck;

    /* ---- 终局指标 ---- */
    RtVec2 c = rt_v2(0.f, 0.f);
    for (int i = 0; i < N; i++) c = rt_v2_add(c, AG[i].pos);
    c = rt_v2_mul(c, 1.f / (float)N);

    float spread = 0.f;
    for (int i = 0; i < N; i++) spread += rt_v2_dist(AG[i].pos, c);
    m.spread = spread / (float)N;
    m.centroid_err = rt_v2_dist(c, dest);

    for (int i = 0; i < N; i++)
        for (int j = i + 1; j < N; j++) {
            float d = rt_v2_dist(AG[i].pos, AG[j].pos);
            float pen = (AG[i].radius + AG[j].radius) - d;
            if (pen > 0.01f) {
                m.overlap_pairs++;
                if (pen > m.max_pen) m.max_pen = pen;
            }
            if (d < m.min_pair || m.min_pair == 0.f) m.min_pair = d;
            if (d < 1.40f) m.pairs_lt_140++;
        }

    /* 最近邻距离分布（每单位取最近的那个，再排序取 min/p10/中位）。
     * 为什么不用「全场最小间距」当判据：它是 10368 对里最差的一对，
     * 一个单位被挤一下整条断言就红，信息量几乎为零 —— 84 人贴着和 1 人贴着
     * 在 min 上完全一样。分布才分得开「方阵」和「挤一堆」。 */
    {
        float nn[MAXA];
        for (int i = 0; i < N; i++) {
            float bd = 1e30f;
            for (int j = 0; j < N; j++) {
                if (j == i) continue;
                float d = rt_v2_dist(AG[i].pos, AG[j].pos);
                if (d < bd) bd = d;
            }
            nn[i] = bd;
        }
        qsort(nn, (size_t)N, sizeof(float), cmp_float);
        m.nn_min = nn[0];
        m.nn_p10 = nn[(int)((float)N * 0.10f)];
        m.nn_median = nn[N / 2];
    }

    /* slot 覆盖：每个 slot 1.5 m 内有没有人（点目标模式下会很低） */
    for (int k = 0; k < FM.slot_count; k++) {
        RtVec2 sp = rt_form_slot_world(&FM, k);
        for (int i = 0; i < N; i++)
            if (rt_v2_dist(AG[i].pos, sp) < 1.5f) { m.slots_covered++; break; }
    }

    for (int i = 0; i < N; i++) {
        if (MEM[i].arrived) m.on_slot++;
        m.reengages += MEM[i].reengages;
    }

    {
        RtVec2 ps[MAXA];
        for (int i = 0; i < N; i++) ps[i] = AG[i].pos;
        m.cohesion = rt_form_cohesion(&FM, ps, SLOT_OF, N, 25.f);
        measure_pitch(SLOT_OF, N, FM.cols, FM.rows, ps, &m.pitch_x_meas, &m.pitch_z_meas);
    }

    /* 到「自己的目标」的平均距离：队形 = slot，点目标 = dest */
    {
        float g = 0.f;
        for (int i = 0; i < N; i++)
            g += use_form ? rt_v2_dist(AG[i].pos, rt_form_slot_world(&FM, SLOT_OF[i]))
                          : rt_v2_dist(AG[i].pos, dest);
        m.mean_gap = g / (float)N;
    }

    /* 距离分布（点目标模式用它看「挤成什么样」） */
    for (int i = 0; i < N; i++) d95_buf[n95++] = rt_v2_dist(AG[i].pos, dest);
    qsort(d95_buf, (size_t)n95, sizeof(float), cmp_float);

    if (verbose) {
        printf("  %-8s n=%d frames=%d  95%%=%s  coverage=%d/%d  cohesion=%.2f"
               "  mean_gap=%.2f  spread=%.1f\n",
               name, N, m.frames,
               (m.t95 > 0.0) ? "ok" : "never",
               m.slots_covered, FM.slot_count, m.cohesion, m.mean_gap, m.spread);
        printf("           nn min/p10/median = %.2f / %.2f / %.2f m"
               "  pairs<1.40=%d  min_pair=%.2f\n",
               m.nn_min, m.nn_p10, m.nn_median, m.pairs_lt_140, m.min_pair);
        printf("           lattice pitch x/z = %.2f / %.2f m (target %.2f/%.2f)"
               "  centroid_err=%.2f\n",
               m.pitch_x_meas, m.pitch_z_meas, FM.pitch_x, FM.pitch_z,
               m.centroid_err);
        printf("           dist-to-dest p50=%.1f p95=%.1f max=%.1f  on_slot=%d"
               "  reengage=%u  overlap=%d max_pen=%.3f  stuck_perm=%u\n",
               d95_buf[n95 / 2], d95_buf[(int)((float)n95 * 0.95f)],
               d95_buf[n95 - 1], m.on_slot, m.reengages, m.overlap_pairs,
               m.max_pen, m.stuck_perm);
        printf("           frame mean/worst = %.2f / %.2f ms\n", m.t_mean, m.t_worst);
    }
    return m;
}

int main(void)
{
    timer_init();
    printf("=== M12 tests: formation in the pipeline (FR-FOR) ===\n");

    RtVec2 dest = rt_v2(180.f, 128.f);
    Metrics f = run("formation", 1, dest, 3600, 1);
    Metrics p = run("point",     0, dest, 3600, 1);

    printf("\n-- assertions --\n");
    OK(f.slots_covered >= N_UNITS * 95 / 100, "T1 formation: >=95% slots occupied");
    OK(f.on_slot >= N_UNITS * 98 / 100, "T1 formation: >=98% units standing on their slot");
    OK(f.t95 > 0.0, "T1 formation: 95% on slot inside the budget");
    OK(f.cohesion > 0.90f, "T1 formation: cohesion > 0.90");
    /* 间距：直测晶格间距（列均值相邻差的中位数），要求落在 pitch ±0.25 内。
     * 参考：改前实测 pitch 量出来 2.2 但列/行整体被推、最近邻中位数 1.0~1.5。 */
    OK(f.pitch_x_meas > FM.pitch_x - 0.25f && f.pitch_x_meas < FM.pitch_x + 0.25f,
       "T1 formation: measured column pitch ~= 2.20 m");
    OK(f.pitch_z_meas > FM.pitch_z - 0.25f && f.pitch_z_meas < FM.pitch_z + 0.25f,
       "T1 formation: measured row pitch ~= 2.20 m");
    /* 最近邻中位数的理论基线：位移 sd≈0.2 时，「每人取 4 邻居的最小值」的中位数
     * 天然落在 2.2 - 0.35 ≈ 1.85，所以这里只作为「不是挤成一堆」的下限。 */
    OK(f.nn_median >= 1.75f, "T1 formation: median nearest-neighbour >= 1.75 m");
    OK(f.nn_min >= 1.30f, "T1 formation: nobody jammed at ORCA contact distance (nn_min >= 1.30)");
    OK(f.mean_gap < 0.50f, "T1 formation: mean distance to own slot < 0.50 m");

    OK(p.slots_covered < f.slots_covered, "T2 point target covers far fewer slots");
    OK(p.nn_median < f.nn_median * 0.80f, "T2 point target packs much tighter (nn median)");
    OK(p.pitch_x_meas < f.pitch_x_meas * 0.75f, "T2 point target has no lattice pitch");
    OK(p.spread < f.spread, "T2 point target is more clumped (smaller spread)");
    /* 队形的质心必须钉在 anchor 上；点目标是**队列**，只可能「围在点附近」，
     * 质心天然被后来的人挤向西侧（实测 3.5 m），所以给它一个宽松得多的界。 */
    OK(f.centroid_err < 1.0f, "T2 formation centroid sits on the anchor (<1 m)");
    OK(p.centroid_err < 6.0f, "T2 point-target clump stays around the point (<6 m)");

    OK(f.max_pen < 0.60f && p.max_pen < 0.60f, "T3 penetration < 0.6 m in both runs");
    OK(f.stuck_perm == 0 && p.stuck_perm == 0, "T3 no PermanentStuck");
    OK(f.t_mean < 8.0 && p.t_mean < 8.0, "T3 mean frame < 8 ms");

    printf("\n  队形:   %d/%d 就位，slot 覆盖 %d，凝聚度 %.2f，平均误差 %.2f m，"
           "晶格 %.2f×%.2f m，最近邻 %.2f/%.2f/%.2f (min/p10/med)\n",
           f.on_slot, N_UNITS, f.slots_covered, f.cohesion, f.mean_gap,
           f.pitch_x_meas, f.pitch_z_meas, f.nn_min, f.nn_p10, f.nn_median);
    printf("  点目标: %d 就位，slot 覆盖 %d，凝聚度 %.2f，平均误差 %.2f m，"
           "晶格 %.2f×%.2f m，最近邻 %.2f/%.2f/%.2f\n",
           p.on_slot, p.slots_covered, p.cohesion, p.mean_gap,
           p.pitch_x_meas, p.pitch_z_meas, p.nn_min, p.nn_p10, p.nn_median);
    printf("  被挤开后重新接管：队形 %u 次 / 点目标 %u 次\n", f.reengages, p.reengages);

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    if (g_fail == 0) printf("ALL PASS (%d asserts)\n", g_pass);

    rt_form_destroy(&FM);
    rt_stuck_destroy(&SC);
    rt_yield_destroy(&YC);
    rt_local_destroy(&LC);
    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return g_fail == 0 ? 0 : 1;
}

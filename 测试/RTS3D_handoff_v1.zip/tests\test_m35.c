/* ============================================================================
 * test_m35.c -- M3.5 / M3.6 / M3.7 测试
 *
 * V1 Chunk 版本只影响受影响 chunk
 * V2 Command Version：乱序完成时只有最新命令生效
 * V3 Path 依赖：无关区域编辑不影响结果，相关区域编辑必须失效
 * V4 Label Epoch：id 空间压缩后旧引用全部失效（无 ABA）
 * F1 FlowField 只失效与 dirty chunk 相交的 entry
 * F2 失效策略 A（全扫）vs B（反查索引）在 100/1000/5000 entry 下的成本
 * F3 构建期间地图变化 -> 不许标 VALID
 * C1..C5 连续编辑：合并 / 取消 / 背压 / 收敛一致
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m35.c -o test_m35
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_navjob.h"
#include "rt_navver.h"
#include "rt_flowcache.h"
#include "rt_navsched.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", m); } } while (0)

static uint64_t g_state = 0x5EED5EEDull;
static uint64_t nu(void) {
    uint64_t z = (g_state += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
}
static int rr(int lo, int hi) { return hi <= lo ? lo : lo + (int)(nu() % (uint64_t)(hi - lo)); }

static RtGrid A, B;
static int g_w, g_h;

static void pair_init(int w)
{
    g_w = g_h = w;
    rt_grid_destroy(&A); rt_grid_destroy(&B);
    if (rt_grid_init(&A, w, w, 1.0f) != RT_OK) exit(2);
    if (rt_grid_init(&B, w, w, 1.0f) != RT_OK) exit(2);
}
static void pair_terrain(int x, int z, int on)
{
    rt_grid_set_terrain(&A, x, z, RT_CELL_BLOCKED_TERRAIN, on);
    rt_grid_set_terrain(&B, x, z, RT_CELL_BLOCKED_TERRAIN, on);
}
static void pair_background(int permille)
{
    for (int z = 0; z < g_h; z++)
        for (int x = 0; x < g_w; x++)
            if ((int)((nu() >> 40) % 1000) < permille) pair_terrain(x, z, 1);
}
static void pair_rebuild(void) { rt_grid_rebuild_all(&A); rt_grid_rebuild_all(&B); }

/* 竖墙贯穿 + 3 格门（与 test_m34 的 build_wall_map 同构） */
static void pair_wall_gate(int w)
{
    for (int z = 0; z < w; z++)
        if (z != w / 2) pair_terrain(w / 2, z, 1);
    pair_terrain(w / 2 - 1, w / 2, 0);
    pair_terrain(w / 2, w / 2, 0);
    pair_terrain(w / 2 + 1, w / 2, 0);
}

/* A 增量 / B 全量；划分等价（双射） */
static int partition_equal_dbg(const char *tag);
static int partition_equal(void) { return partition_equal_dbg(NULL); }
static int partition_equal_dbg(const char *tag)
{
    static int32_t ma[1 << 21], mb[1 << 21];
    size_t n = (size_t)g_w * g_h;
    if (n > (1u << 21)) return 0;
    for (size_t i = 0; i < n; i++) { ma[i] = -2; mb[i] = -2; }
    for (size_t i = 0; i < n; i++) {
        int32_t ca = A.component[i], cb = B.component[i];
        if ((ca >= 0) != (cb >= 0)) {
            if (tag) printf("  [%s] walkability mismatch at cell %u: A=%d B=%d\n",
                            tag, (unsigned)i, ca, cb);
            return 0;
        }
        if (ca < 0) continue;
        if (ca >= (1 << 21) || cb >= (1 << 21)) return 0;
        if (ma[ca] == -2) ma[ca] = cb;
        else if (ma[ca] != cb) {
            if (tag) printf("  [%s] mismatch at cell %u: A.comp=%d maps to B.comp=%d and %d\n",
                            tag, (unsigned)i, ca, ma[ca], cb);
            return 0;
        }
    }
    for (size_t ca = 0; ca < n; ca++) {
        if (ma[ca] == -2) continue;
        int32_t cb = ma[ca];
        if (mb[cb] != -2 && mb[cb] != (int32_t)ca) return 0;
        mb[cb] = (int32_t)ca;
    }
    return 1;
}

static void mirror_add(int x, int z, int w, int h)
{
    rt_grid_add_building_dirty(&B, x, z, w, h, NULL);
    rt_grid_rebuild_all(&B);
}

/* ==========================================================================
 * V1：chunk 版本只影响受影响 chunk
 * ========================================================================*/
static void v1_chunk_locality(void)
{
    printf("\n[V1] chunk version locality\n");
    pair_init(512);
    pair_background(60);
    pair_rebuild();

    uint32_t before[RT_CHUNK_N];
    memcpy(before, A.chunk_ver, sizeof(before));
    uint32_t epoch0 = A.nav_epoch;

    RtGridDirty d;
    rt_grid_add_building_dirty(&A, 100, 100, 2, 2, &d);
    rt_grid_apply_dirty(&A, &d);
    mirror_add(100, 100, 2, 2);

    int changed = 0, bad = 0;
    for (int c = 0; c < RT_CHUNK_N; c++) {
        int in_mask = (d.chunk_mask[c >> 5] & (1u << (c & 31))) != 0;
        int ch = (A.chunk_ver[c] != before[c]);
        if (ch) changed++;
        if (ch && !in_mask) bad++;
    }
    printf("  chunks changed=%d (mask has %d), epoch %u -> %u\n",
           changed, rt_grid_mask_count(d.chunk_mask), epoch0, A.nav_epoch);
    OK(bad == 0, "V1 no chunk bumped outside dirty mask");
    OK(changed > 0 && changed <= 4, "V1 version bumped only locally (<=4 chunks)");
    OK(A.nav_epoch == epoch0 + 1, "V1 nav_epoch += 1");
    OK(partition_equal(), "V1 partition equal");
}

/* ==========================================================================
 * V2：命令版本（乱序完成）
 * ========================================================================*/
static void v2_command_version(void)
{
    printf("\n[V2] command version (completion order C,A,B)\n");
    RtPathDep dep;
    rt_pathdep_capture(&dep, &A, (const uint32_t *)A.chunk_ver); /* mask 全 1 也行，这里不重要 */
    uint32_t cur_cmd = 3;     /* 玩家已经点到 C */
    RtPathVerdict vc = rt_path_result_check(&dep, &A, 3, cur_cmd, -1);
    RtPathVerdict va = rt_path_result_check(&dep, &A, 1, cur_cmd, -1);
    RtPathVerdict vb = rt_path_result_check(&dep, &A, 2, cur_cmd, -1);
    printf("  C -> %s, A -> %s, B -> %s\n",
           rt_path_verdict_name(vc), rt_path_verdict_name(va), rt_path_verdict_name(vb));
    OK(vc == RT_PATH_ACCEPT, "V2 newest command accepted");
    OK(va == RT_PATH_DISCARD_COMMAND, "V2 A discarded");
    OK(vb == RT_PATH_DISCARD_COMMAND, "V2 B discarded");
}

/* ==========================================================================
 * V3/V4：路径依赖 + label epoch
 * ========================================================================*/
static void v3_v4_deps(void)
{
    printf("\n[V3] path dependency granularity\n");
    pair_init(512);
    pair_background(60);
    pair_rebuild();

    uint32_t mask[RT_CHUNK_MASK_WORDS];
    memset(mask, 0, sizeof(mask));
    rt_grid_mask_set(mask, rt_grid_chunk_of_cell(&A, 100, 100));   /* 依赖 chunk */
    RtPathDep dep;
    rt_pathdep_capture(&dep, &A, mask);

    RtGridDirty d;
    rt_grid_add_building_dirty(&A, 400, 400, 2, 2, &d);            /* 无关区域 */
    rt_grid_apply_dirty(&A, &d);
    printf("  after unrelated edit: valid=%d (expect 1)\n", rt_pathdep_valid(&dep, &A));
    OK(rt_pathdep_valid(&dep, &A) == 1, "V3 unrelated edit keeps path valid");

    rt_grid_add_building_dirty(&A, 101, 101, 2, 2, &d);            /* 依赖 chunk 内 */
    rt_grid_apply_dirty(&A, &d);
    printf("  after dependent edit : valid=%d (expect 0)\n", rt_pathdep_valid(&dep, &A));
    OK(rt_pathdep_valid(&dep, &A) == 0, "V3 dependent edit invalidates path");

    printf("\n[V4] label epoch invalidates everything (ABA guard)\n");
    uint32_t e0 = A.label_epoch;
    RtPathDep dep2;
    rt_pathdep_capture(&dep2, &A, mask);
    /* 人为压缩 id 空间：直接把阈值条件打通（复现 GC 路径） */
    A.component_count = 4 * A.active_components + 5000;
    RtGridDirty d2;
    rt_grid_add_building_dirty(&A, 200, 200, 1, 1, &d2);
    rt_grid_apply_dirty(&A, &d2);
    printf("  label_epoch %u -> %u, dep valid=%d (expect 0)\n",
           e0, A.label_epoch, rt_pathdep_valid(&dep2, &A));
    OK(A.label_epoch > e0, "V4 compaction bumps label_epoch");
    OK(rt_pathdep_valid(&dep2, &A) == 0, "V4 old dependency rejected after compaction");
}

/* ==========================================================================
 * F1/F2/F3：流场缓存
 * ========================================================================*/
static void f1_f3_flow(void)
{
    printf("\n[F1] flow cache invalidates only intersecting entries\n");
    RtFlowCache c;
    if (rt_flowcache_init(&c, 64) != RT_OK) { OK(0, "init"); return; }

    uint32_t m1[RT_CHUNK_MASK_WORDS], m2[RT_CHUNK_MASK_WORDS], m3[RT_CHUNK_MASK_WORDS];
    memset(m1, 0, sizeof(m1)); memset(m2, 0, sizeof(m2)); memset(m3, 0, sizeof(m3));
    rt_grid_mask_set(m1, 1); rt_grid_mask_set(m1, 2); rt_grid_mask_set(m1, 3);
    rt_grid_mask_set(m2, 10); rt_grid_mask_set(m2, 11);
    rt_grid_mask_set(m3, 3); rt_grid_mask_set(m3, 4); rt_grid_mask_set(m3, 5);
    int ia = rt_flowcache_put(&c, 1001, m1, 0, 0, &A, 4096);
    int ib = rt_flowcache_put(&c, 1002, m2, 0, 0, &A, 4096);
    int ic = rt_flowcache_put(&c, 1003, m3, 0, 0, &A, 4096);

    uint32_t dirty[RT_CHUNK_MASK_WORDS];
    memset(dirty, 0, sizeof(dirty));
    rt_grid_mask_set(dirty, 3);
    int n = rt_flowcache_invalidate_scan(&c, dirty);
    printf("  invalidated=%d  A=%d B=%d C=%d (expect A,C stale; B valid)\n",
           n, c.e[ia].state, c.e[ib].state, c.e[ic].state);
    OK(n == 2, "F1 exactly two fields invalidated");
    OK(c.e[ia].state == RT_FLOW_STALE, "F1 field A stale");
    OK(c.e[ib].state == RT_FLOW_VALID, "F1 field B still valid");
    OK(c.e[ic].state == RT_FLOW_STALE, "F1 field C stale");

    printf("\n[F3] build finishing after a nav commit must be rejected\n");
    uint32_t m4[RT_CHUNK_MASK_WORDS];
    memset(m4, 0, sizeof(m4));
    rt_grid_mask_set(m4, 20);
    int idx = rt_flowcache_put(&c, 2001, m4, 0, 0, &A, 4096);
    RtGridDirty dd;
    rt_grid_add_building_dirty(&A, 500, 60, 1, 1, &dd);
    rt_grid_apply_dirty(&A, &dd);      /* nav_epoch 变 */
    int ok = rt_flowcache_finish_build(&c, idx, &A);
    printf("  finish_build -> %d, state=%d (expect 0 / STALE)\n", ok, c.e[idx].state);
    OK(ok == 0 && c.e[idx].state == RT_FLOW_STALE, "F3 stale build rejected");

    rt_flowcache_destroy(&c);
}

static double bench_invalidate(int entries, int use_index, int *out_n)
{
    RtFlowCache c;
    if (rt_flowcache_init(&c, entries) != RT_OK) return -1;
    int stride = entries > RT_CHUNK_N ? entries / RT_CHUNK_N : 1;
    for (int i = 0; i < entries; i++) {
        uint32_t m[RT_CHUNK_MASK_WORDS];
        memset(m, 0, sizeof(m));
        /* 每个 entry 覆盖 ~8 个连续 chunk（模拟流场覆盖范围） */
        int base = (i * 8 * stride) % RT_CHUNK_N;
        for (int k = 0; k < 8; k++) rt_grid_mask_set(m, (base + k) % RT_CHUNK_N);
        rt_flowcache_put(&c, (uint32_t)(10000 + i), m, 0, 0, &A, 8192);
    }
    uint32_t dirty[RT_CHUNK_MASK_WORDS];
    memset(dirty, 0, sizeof(dirty));
    rt_grid_mask_set(dirty, 5);

    double t0 = now_ms();
    int n = use_index ? rt_flowcache_invalidate_index(&c, dirty)
                      : rt_flowcache_invalidate_scan(&c, dirty);
    double dt = now_ms() - t0;
    *out_n = n;
    rt_flowcache_destroy(&c);
    return dt;
}

static void f2_strategy(void)
{
    printf("\n[F2] invalidation strategy: scan vs reverse index\n");
    printf("  %-8s %-14s %-14s %-10s %s\n", "entries", "scan(ms)", "index(ms)", "ratio", "invalidated");
    int ens[] = { 100, 1000, 5000 };
    for (int k = 0; k < 3; k++) {
        int na = 0, nb = 0;
        double ta = bench_invalidate(ens[k], 0, &na);
        double tb = bench_invalidate(ens[k], 1, &nb);
        printf("  %-8d %-14.4f %-14.4f %-10.2f %d/%d\n",
               ens[k], ta, tb, tb > 1e-9 ? ta / tb : 0.0, na, nb);
        OK(na == nb, "F2 both strategies invalidate the same count");
    }
}

/* ==========================================================================
 * C1..C5：连续编辑 / 合并 / 背压
 * ========================================================================*/
static void c1_c2_continuous(int frames, int per_frame, int bsize, const char *name)
{
    pair_init(256);
    pair_background(60);
    pair_rebuild();

    RtNavSched s;
    rt_navsched_init(&s, &A);

    int max_age = 0;
    for (int f = 0; f < frames; f++) {
        for (int k = 0; k < per_frame; k++) {
            int x = rr(4, 250), z = rr(4, 250);
            RtGridDirty d;
            rt_grid_add_building_dirty(&A, x, z, bsize, bsize, &d);
            rt_navsched_submit(&s, &d);
            mirror_add(x, z, bsize, bsize);
        }
        rt_navsched_tick(&s, 4096);
        if (s.pend_age > max_age) max_age = s.pend_age;
    }
    rt_navsched_drain(&s);

    printf("\n[%s] %d frames x %d buildings (%dx%d)\n", name, frames, per_frame, bsize, bsize);
    printf("  submit=%u immediate=%u scheduled=%u commit=%u cancel=%u stale=%u coalesced=%u max_age=%d\n",
           s.stat_submit, s.stat_immediate, s.stat_scheduled, s.stat_commit,
           s.stat_cancel, s.stat_stale, s.stat_coalesced, max_age);
    OK(partition_equal_dbg(name), "final partition == full rebuild");
    OK(max_age <= 8, "commit latency bounded (<= 8 ticks)");
    OK(s.pend_age == 0, "backlog drained");
    rt_navsched_shutdown(&s);
}

static void c3_toggle(void)
{
    printf("\n[C3] same region build/remove 2000x\n");
    pair_init(256);
    pair_background(60);
    pair_rebuild();
    RtNavSched s;
    rt_navsched_init(&s, &A);

    for (int i = 0; i < 2000; i++) {
        RtGridDirty d;
        if (i & 1) {
            rt_grid_remove_building_dirty(&A, 120, 120, 6, 6, &d);
            rt_grid_remove_building_dirty(&B, 120, 120, 6, 6, NULL);
        } else {
            rt_grid_add_building_dirty(&A, 120, 120, 6, 6, &d);
            rt_grid_add_building_dirty(&B, 120, 120, 6, 6, NULL);
        }
        rt_navsched_submit(&s, &d);
        if ((i % 8) == 0) rt_navsched_tick(&s, 8192);
        rt_grid_rebuild_all(&B);   /* 参考实现：每次都全量 */
    }
    rt_navsched_drain(&s);
    printf("  submit=%u coalesced=%u commit=%u cancel=%u immediate=%u\n",
           s.stat_submit, s.stat_coalesced, s.stat_commit, s.stat_cancel, s.stat_immediate);
    OK(partition_equal(), "C3 final partition == full rebuild");
    OK(s.stat_coalesced > 0, "C3 edits were coalesced");
    rt_navsched_shutdown(&s);
}

static void c4_c5_cancel(void)
{
    printf("\n[C4] edit the running job's region -> cancel + restart\n");
    pair_init(512);
    pair_background(80);
    pair_wall_gate(512);
    pair_rebuild();

    RtNavSched s;
    rt_navsched_init(&s, &A);

    RtGridDirty d;
    rt_grid_add_building_dirty(&A, 256, 256, 1, 1, &d);   /* 切通道 -> 大 split */
    rt_navsched_submit(&s, &d);
    mirror_add(256, 256, 1, 1);
    rt_navsched_tick(&s, 4096);                            /* 启动 job */
    OK(s.job != NULL, "C4 job started");

    RtGridDirty d2;
    rt_grid_add_building_dirty(&A, 255, 256, 1, 1, &d2);   /* 同一区域再来一次 */
    rt_navsched_submit(&s, &d2);
    mirror_add(255, 256, 1, 1);
    printf("  after same-region edit: job=%p cancel=%u coalesced=%u\n",
           (void *)s.job, s.stat_cancel, s.stat_coalesced);
    OK(s.stat_cancel >= 1, "C4 running job cancelled by dependent edit");

    rt_navsched_drain(&s);
    OK(partition_equal(), "C4 final partition == full rebuild (no update lost)");
    rt_navsched_shutdown(&s);

    printf("\n[C5] edit an unrelated region -> job must survive\n");
    pair_init(512);
    pair_background(80);
    pair_wall_gate(512);
    pair_rebuild();
    rt_navsched_init(&s, &A);
    rt_grid_add_building_dirty(&A, 256, 256, 1, 1, &d);
    rt_navsched_submit(&s, &d);
    mirror_add(256, 256, 1, 1);
    rt_navsched_tick(&s, 4096);
    OK(s.job != NULL, "C5 job started");

    uint32_t cancel_before = s.stat_cancel;
    RtGridDirty d3;
    rt_grid_add_building_dirty(&A, 30, 480, 2, 2, &d3);
    rt_navsched_submit(&s, &d3);
    mirror_add(30, 480, 2, 2);
    printf("  after unrelated edit : job=%p cancel %u -> %u\n",
           (void *)s.job, cancel_before, s.stat_cancel);
    OK(s.stat_cancel == cancel_before, "C5 unrelated edit does not cancel job");
    OK(s.has_pend == 1, "C5 second edit queued");

    rt_navsched_drain(&s);
    OK(partition_equal(), "C5 final partition == full rebuild");
    rt_navsched_shutdown(&s);
}

int main(void)
{
    timer_init();
    printf("=== M3.5~M3.7 tests ===\n");

    v1_chunk_locality();
    v2_command_version();
    v3_v4_deps();
    f1_f3_flow();
    f2_strategy();
    c1_c2_continuous(1000, 1, 2, "C1");
    c1_c2_continuous(300, 10, 2, "C2");
    c3_toggle();
    c4_c5_cancel();

    rt_grid_destroy(&A);
    rt_grid_destroy(&B);
    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}

/* ============================================================================
 * probe_m12_pair.c -- M12 队形集成：间距到底是怎么丢的？
 *
 * 第一轮（2026-10-26 上午版）结论：min_pair=1.00 不是单个异常单位，
 *   144 人里 88 人的最近邻在 1.0~1.5 m，方阵被压扁。
 *
 * 第二轮（本版）：落脚策略换成库里的滞回版之后，gap p50=0.34 但最近邻
 *   中位数仍只有 1.86（pitch 2.2）。本探针做「晶格审计」：
 *   按列/行打印实际坐标，直接看 2.2 的间距去了哪里。
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_stuck.h"
#include "rt_yield.h"
#include "rt_form.h"
#include "rt_region.h"
#include "rt_group.h"
#include "rt_unit.h"

#define MAXA 512
#define N_UNITS 144
#define COLS 12

static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;
static RtStuckCtx SC;
static RtYieldCtx YC;
static RtFormation FM;
static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static RtUnitId IDS[MAXA];
static int SLOT_OF[MAXA];
static RtFormMember MEM[MAXA];
static RtFormSettle SET;
static int N = 0;

static void build_world(void)
{
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    rt_grid_rebuild_all(&G);
    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
    rt_local_destroy(&LC);
    rt_local_init(&LC, 256.f, 256.f, MAXA, 4.0f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);
    rt_stuck_destroy(&SC);
    rt_stuck_init(&SC, MAXA, NULL);
    rt_yield_destroy(&YC);
    rt_yield_init(&YC, MAXA, NULL, &G);
}

static void spawn_block(int n, float x0, float z0, int cols)
{
    N = 0;
    for (int i = 0; i < n; i++) {
        float x = x0 + (float)(i % cols) * 1.6f;
        float z = z0 + (float)(i / cols) * 1.6f;
        RtUnitId id = rt_units_spawn(&US, rt_v3(x, 0.f, z), RT_FP_SMALL);
        if (id == RT_UNIT_ID_NONE) break;
        IDS[N] = id;
        rt_form_member_reset(&MEM[N]);
        memset(&AG[N], 0, sizeof(AG[N]));
        AG[N].pos = rt_v2(x, z);
        AG[N].radius = 0.5f;
        AG[N].max_speed = 2.0f;
        AG[N].fp = 1.0f;
        AG[N].share = 0.5f;
        AG[N].inv_mass = 1.f;
        N++;
    }
}

static float gap_to_slot(int i)
{
    return rt_v2_dist(AG[i].pos, rt_form_slot_world(&FM, SLOT_OF[i]));
}

static int cmp_float(const void *a, const void *b)
{
    float x = *(const float *)a, y = *(const float *)b;
    return (x < y) ? -1 : (x > y ? 1 : 0);
}

static int main_run(RtVec2 dest, int frames_max)
{
    build_world();
    spawn_block(N_UNITS, 32.f, 108.f, 12);
    const float dt = 1.f / 30.f;

    rt_form_destroy(&FM);
    rt_form_init(&FM, MAXA);
    rt_form_build(&FM, RT_FORM_RECT, N, 1.0f, 1.2f);
    rt_form_set_anchor(&FM, dest);
    rt_form_set_yaw(&FM, 0.f, dt, NULL);
    {
        RtVec2 ps[MAXA];
        for (int i = 0; i < N; i++) ps[i] = AG[i].pos;
        (void)rt_form_assign(&FM, ps, N, SLOT_OF);
    }
    (void)rt_gw_command(&W, &US, IDS, N, dest, 0, RT_CLS_SMALL, 1);
    rt_form_settle_default(&SET);

    int frames = 0;
    for (int s = 0; s < frames_max; s++) {
        frames = s;
        for (int i = 0; i < N; i++) {
            RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, IDS[i]);
            int gi = (int)ch->group[rt_unit_slot_index(IDS[i])] - 1;
            RtVec2 pref = rt_v2(0.f, 0.f);
            int on = 0;
            if (rt_v2_dist(AG[i].pos, dest) < 40.f) {
                pref = rt_form_member_steer(&FM, SLOT_OF[i], AG[i].pos,
                                            &MEM[i], &SET, 2.0f, dt);
                on = rt_form_member_arrived(&MEM[i]);
            } else if (gi >= 0) {
                RtVec2 tgt;
                if (rt_gw_sample(&W, gi, AG[i].pos, &tgt) == RT_OK) {
                    RtVec2 d = rt_v2_sub(tgt, AG[i].pos);
                    float l = rt_v2_len(d);
                    if (l > 1e-3f) pref = rt_v2_mul(d, 2.0f / l);
                }
            }
            AG[i].pref_vel = pref;
            rt_stuck_set_hold(&SC, i, on);
        }
        rt_stuck_step(&SC, AG, N, &G, dt, NULL);
        rt_yield_step(&YC, AG, N, &G, dt, NULL, NULL);
        (void)rt_local_step(&LC, AG, N, &G, dt);
        (void)rt_gw_update(&W);

        if ((s % 30) == 0) {
            int done = 0;
            for (int i = 0; i < N; i++) {
                if (MEM[i].arrived) { done++; continue; }
                if (gap_to_slot(i) < 2.0f) done++;
            }
            if (done == N) break;
        }
    }
    printf("frames=%d (%.1f s)\n", frames, frames * dt);

    /* ---- 晶格审计 ---- */
    printf("\n-- 每列的 x 坐标（slot col 相同的 12 个人，按 x 排序）--\n");
    for (int c = 0; c < COLS; c++) {
        float xs[COLS];
        int k = 0;
        for (int i = 0; i < N && k < COLS; i++)
            if (SLOT_OF[i] % COLS == c) xs[k++] = AG[i].pos.x;
        qsort(xs, (size_t)k, sizeof(float), cmp_float);
        printf("  col %2d x:", c);
        for (int t = 0; t < k; t++) printf(" %6.2f", xs[t]);
        printf("\n            dx:");
        for (int t = 1; t < k; t++) printf(" %6.2f", xs[t] - xs[t - 1]);
        printf("\n");
    }

    printf("\n-- 每行的 z 坐标（slot row 相同的 12 个人，按 z 排序）--\n");
    for (int rr = 0; rr < COLS; rr++) {
        float zs[COLS];
        int k = 0;
        for (int i = 0; i < N && k < COLS; i++)
            if (SLOT_OF[i] / COLS == rr) zs[k++] = AG[i].pos.z;
        qsort(zs, (size_t)k, sizeof(float), cmp_float);
        printf("  row %2d z:", rr);
        for (int t = 0; t < k; t++) printf(" %6.2f", zs[t]);
        printf("\n            dz:");
        for (int t = 1; t < k; t++) printf(" %6.2f", zs[t] - zs[t - 1]);
        printf("\n");
    }

    /* ---- 最近的一对 ---- */
    printf("\n-- closest pair --\n");
    {
        float d01 = 1e30f; int ai = -1, aj = -1;
        for (int i = 0; i < N; i++)
            for (int j = i + 1; j < N; j++) {
                float d = rt_v2_dist(AG[i].pos, AG[j].pos);
                if (d < d01) { d01 = d; ai = i; aj = j; }
            }
        printf("  min pair: #%d(slot %d) <-> #%d(slot %d)  d=%.3f\n",
               ai, SLOT_OF[ai], aj, SLOT_OF[aj], d01);
        printf("     gap_i=%.2f gap_j=%.2f  slotpos_i=(%.1f,%.1f) slotpos_j=(%.1f,%.1f)\n",
               gap_to_slot(ai), gap_to_slot(aj),
               rt_form_slot_world(&FM, SLOT_OF[ai]).x, rt_form_slot_world(&FM, SLOT_OF[ai]).z,
               rt_form_slot_world(&FM, SLOT_OF[aj]).x, rt_form_slot_world(&FM, SLOT_OF[aj]).z);
    }

    /* ---- 误差方向的系统偏置 ---- */
    {
        float sx = 0.f, sz = 0.f;
        for (int i = 0; i < N; i++) {
            RtVec2 sp = rt_form_slot_world(&FM, SLOT_OF[i]);
            sx += AG[i].pos.x - sp.x;
            sz += AG[i].pos.z - sp.z;
        }
        printf("\nmean(pos-slot) = (%+.3f, %+.3f)  <- 系统性平移\n",
               sx / (float)N, sz / (float)N);
        /* 径向分量：正值 = 往外散，负值 = 往里缩 */
        float rad = 0.f;
        RtVec2 c = rt_v2(0.f, 0.f);
        for (int i = 0; i < N; i++) c = rt_v2_add(c, AG[i].pos);
        c = rt_v2_mul(c, 1.f / (float)N);
        for (int i = 0; i < N; i++) {
            RtVec2 sp = rt_form_slot_world(&FM, SLOT_OF[i]);
            RtVec2 e = rt_v2_sub(sp, c);
            float l = rt_v2_len(e);
            if (l < 1e-3f) continue;
            rad += ((AG[i].pos.x - sp.x) * e.x + (AG[i].pos.z - sp.z) * e.z) / l;
        }
        printf("radial(pos-slot) = %+.3f  <- 负 = 整体往内缩\n", rad / (float)N);
    }
    return 0;
}

int main(void)
{
    printf("=== probe M12 lattice audit (settle policy on) ===\n");
    return main_run(rt_v2(180.f, 128.f), 3600);
}

/* ============================================================================
 * test_m15.c -- 跨通道协调：通道链（多条相接的窄通道共享一个 owner）
 *
 * 要证明的事（M14 §4.3 留下的死锁）：
 *   一条 Z 形 2 m 走廊会被切成三段直走廊。三种做法：
 *     0 不仲裁            —— 两队在 2 m 单车道里正面相遇
 *     1 逐段独立仲裁      —— A 占一段、B 占一段，在拐角互锁（**这就是要消掉的**）
 *     2 链级原子仲裁(M15) —— 整条链一个 owner，拐角互锁这个状态不可达
 *
 *   T1 分组：3 段同一组
 *   T2 退化：单条隧道 = 1 段 1 链，行为等同 M11
 *   T3 原子性：某段被别人占 -> 整条申请失败，且不残留半占
 *   T4 三方对照（30 s 预算与 260 s 预算各一次）
 *   T5 两条互不相接的隧道 -> 两条链，互不干扰
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_stuck.h"
#include "rt_yield.h"
#include "rt_corridor.h"
#include "rt_chain.h"
#include "rt_portal.h"
#include "rt_region.h"
#include "rt_group.h"
#include "rt_unit.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", (m)); } } while (0)

#define MAXA 512
#define BLK_X0 120
#define BLK_X1 159          /* 屏障：x ∈ [120,159]，纵向贯穿全图，只能走 Z 形通道 */
#define ARM1_Z0 140
#define ARM1_Z1 141
#define ARM2_X0 139
#define ARM2_X1 140
#define ARM3_Z0 120
#define ARM3_Z1 121

static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;
static RtStuckCtx SC;
static RtYieldCtx YC;
static RtCorrCtx CC;
static RtChainCtx CH;
static RtPortalMap PM;
static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static RtUnitId IDS[MAXA];
static int TEAM[MAXA];
static int CROSSED[MAXA];
static uint8_t HELD[MAXA];
static int N = 0;

/* ---------------------------------------------------------------------------
 * 世界
 * -------------------------------------------------------------------------*/
/* Z 形：横向臂1（西口）-> 纵向臂2 -> 横向臂3（东口），三段都是 2 m 宽。
 *
 * **拐角必须留出 2×2 的自由块**：先试的版本两臂只在 1 个格子上相接，
 * 1×1 的单位转身时 OBB 一定会压到墙角（零余量），实测 12 人过不去 5 个。
 * 这和 M13 的「射线通 ≠ 身体过」同源：给的不是通行性，是**余量**。 */
static void map_z(void)
{
    for (int x = BLK_X0; x <= BLK_X1; x++)
        for (int z = 0; z < 256; z++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int x = BLK_X0; x <= ARM2_X1; x++)                 /* 臂1 直到 x=140 */
        for (int z = ARM1_Z0; z <= ARM1_Z1; z++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 0);
    for (int x = ARM2_X0; x <= ARM2_X1; x++)                /* 臂2 直到 z=141 */
        for (int z = ARM3_Z1 + 1; z <= ARM1_Z1; z++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 0);
    for (int x = ARM2_X0; x <= BLK_X1; x++)                 /* 臂3 */
        for (int z = ARM3_Z0; z <= ARM3_Z1; z++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 0);
}

static void map_tunnel(int z0, int z1, int z2, int z3)
{
    for (int x = BLK_X0; x <= BLK_X1; x++)
        for (int z = 0; z < 256; z++) {
            if ((z >= z0 && z <= z1) || (z >= z2 && z <= z3)) continue;
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
}

static void world_build(void)
{
    rt_grid_rebuild_all(&G);
    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
    rt_local_destroy(&LC);
    rt_local_init(&LC, 256.f, 256.f, MAXA, 4.5f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);
    rt_yield_destroy(&YC);
    rt_yield_init(&YC, MAXA, NULL, &G);
    rt_corr_destroy(&CC);
    rt_corr_init(&CC, 8, 60.f, 600.f);
    rt_corr_set_gate_params(&CC, 28.f, 1.2f);
    /* stall 窗口要配得上通道的长度：这条 Z 形链约 60 m，一段到下一段就要 30~40 s，
     * 20 s 的默认值会把**正常排队**判成「占着不走」。和 M11 里 permanent_time
     * 从 20 s 放宽到 60 s 是同一类问题：参数，不是逻辑。 */
    rt_corr_set_stall_limit(&CC, 90.f);
    rt_chain_destroy(&CH);
    rt_chain_init(&CH, &CC, RT_CHAIN_MAX, 0.f);
    N = 0;
}

static void spawn_team(int team, int n, float x0, float z0, int cols)
{
    for (int k = 0; k < n && N < MAXA; k++) {
        float x = x0 + (float)(k % cols) * 1.6f;
        float z = z0 + (float)(k / cols) * 1.6f;
        RtUnitId id = rt_units_spawn(&US, rt_v3(x, 0.f, z), RT_FP_SMALL);
        if (id == RT_UNIT_ID_NONE) break;
        IDS[N] = id;
        TEAM[N] = team;
        CROSSED[N] = 0;
        HELD[N] = 0;
        memset(&AG[N], 0, sizeof(AG[N]));
        AG[N].pos = rt_v2(x, z);
        AG[N].radius = 0.5f;
        AG[N].max_speed = 2.0f;
        AG[N].fp = 1.0f;
        AG[N].share = 0.5f;
        AG[N].inv_mass = 1.f;
        N++;
    }
}

static float rect_dist(const RtPortal *p, RtVec2 q)
{
    float dx = 0.f, dz = 0.f;
    if (q.x < p->x0)      dx = p->x0 - q.x;
    else if (q.x > p->x1) dx = q.x - p->x1;
    if (q.z < p->z0)      dz = p->z0 - q.z;
    else if (q.z > p->z1) dz = q.z - p->z1;
    return sqrtf(dx * dx + dz * dz);
}

/* 队伍 0 向西->东，队伍 1 反向；"穿过"= 走到对面口 */
static int is_crossed(int i)
{
    if (TEAM[i] == 0) return AG[i].pos.x > (float)BLK_X1 + 3.f;
    return AG[i].pos.x < (float)BLK_X0 - 3.f;
}

/* 是否已经**走过**这一段（沿自己队伍的行进方向）。
 * 必须按段算，不能拿「走完整条链的人数」当 passed：
 * 一条 60 m 的链头一个人要 40 s 才走完，20 s 的 stall 窗口里 passed 恒为 0，
 * owner 每 20 s 就被当成「占着不走」收走（实测 seg_lost=8、handoffs=0，
 * B 队永远进不来）。段级 passed 才是这一段真正的吞吐。 */
static int unit_past_seg(const RtPortal *p, int i)
{
    RtVec2 q = AG[i].pos;
    if (TEAM[i] == 0) {
        if (p->axis == 0) return q.x > p->x1;
        return q.z < p->z0;             /* 队伍 0 在竖直臂上从 z 大走到 z 小 */
    }
    if (p->axis == 0) return q.x < p->x0;
    return q.z > p->z1;
}

static int seg_passed(const RtPortal *p, int team)
{
    int c = 0;
    for (int i = 0; i < N; i++)
        if (TEAM[i] == team && unit_past_seg(p, i)) c++;
    return c;
}

/* 链级进度 = 各段 passed 之和。
 * 为什么不能直接用某一段的 passed：那一段走空之后就**饱和**了，
 * 后面几十秒里人在别的段上正常前进，这一段却一直 12/12 不动 ->
 * 20 s 的 stall 窗口一到就把 owner 收走（实测 seg_lost=9、B 队 0/12 永远进不来）。
 * 求和之后「从臂1 挪到臂2」也会 +1，直到整条链走完才饱和。 */
static int chain_passed(int team)
{
    int c = 0;
    for (int k = 0; k < PM.n; k++) {
        if (PM.p[k].cid < 0) continue;
        c += seg_passed(&PM.p[k], team);
    }
    return c;
}

typedef struct {
    int crossA, crossB;
    int frames;
    double t_mean;
    uint32_t perm;
    uint32_t grants, handoffs, stalls, seg_lost, partial_fail;
    float max_pen;
} Tun;

/* mode: 0 = 不仲裁 / 1 = 逐段独立 / 2 = 链级原子 */
static Tun run_z(int mode, int nA, int nB, int sim_s, int verbose, const char *name)
{
    Tun m;
    memset(&m, 0, sizeof(m));

    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    map_z();
    world_build();

    rt_portal_destroy(&PM);
    rt_portal_init(&PM, RT_PORTAL_MAX, NULL);
    (void)rt_portal_scan(&PM, &G);
    if (mode >= 1) (void)rt_portal_register_chained(&PM, &CC, &CH);
    const int nseg = (int)PM.st.registered;
    const int chain = (CH.n > 0) ? 0 : -1;

    {
        RtStuckConfig cfg;
        rt_stuck_config_default(&cfg);
        cfg.permanent_time = 60.f;     /* 2 m 单车道里正常排队就会超 20 s（M11 §5） */
        rt_stuck_destroy(&SC);
        rt_stuck_init(&SC, MAXA, &cfg);
    }

    spawn_team(0, nA, 96.f, 132.f, 6);
    spawn_team(1, nB, 176.f, 118.f, 6);

    const float dt = 1.f / 30.f;
    const RtVec2 goalA = rt_v2(210.f, 60.f);
    const RtVec2 goalB = rt_v2(70.f, 200.f);
    {
        RtUnitId a[MAXA], b[MAXA];
        int na = 0, nb = 0;
        for (int i = 0; i < N; i++) { if (TEAM[i] == 0) a[na++] = IDS[i]; else b[nb++] = IDS[i]; }
        if (na) (void)rt_gw_command(&W, &US, a, na, goalA, 0, RT_CLS_SMALL, 1);
        if (nb) (void)rt_gw_command(&W, &US, b, nb, goalB, 0, RT_CLS_SMALL, 2);
    }

    double sum = 0;
    int frames = 0;
    for (int s = 0; s < sim_s * 30; s++) {
        frames = s;
        const float now = (float)s * dt;
        double t0 = now_ms();

        /* ---- 仲裁 ---- */
        if (mode >= 1 && nseg > 0) {
            /* 每队：还需要链吗 / 还要多少人 / 门口近处几人 / 已过几人
             * （变量名不能叫 near —— windows.h 里 near/far 是空宏，build.md 记过） */
            int n_need[2] = {0, 0}, n_pend[2] = {0, 0}, n_near[2] = {0, 0}, n_pass[2] = {0, 0};
            for (int i = 0; i < N; i++) {
                if (is_crossed(i)) CROSSED[i] = 1;
                if (CROSSED[i]) { n_pass[TEAM[i]]++; continue; }
                /* 这里曾经有一行 `if (state == GAVE_UP) continue;`，理由是「放弃的单位
                 * 永远把链攥在手里，B 队老老实实等在等待区却永远轮不到」（当时实测
                 * handoffs=0、B 0/12）。那是**症状**不是需求：真正的病是放弃者根本不
                 * 复活（M17 取证：两个放弃者相距 1.86 m，互相把对方算进「2 m 内有人」，
                 * 谁都不复活），而它们之所以放弃，是因为 1 m 身体在 2 m 拐角处被逐轴
                 * 滑动冻住（pref 满速、前方 0 人、0.007 m/帧）。
                 * M17 修好这两处之后，这个场景 0 人放弃、A/B 各 12/12，这行补丁就
                 * 没有存在理由了 —— 需求定义恢复成「还想去的人都算」，不留特例。 */
                /* 离通道最近的一段 */
                float best = 1e30f;
                for (int k = 0; k < PM.n; k++) {
                    if (PM.p[k].cid < 0) continue;
                    float d = rect_dist(&PM.p[k], AG[i].pos);
                    if (d < best) best = d;
                }
                if (best > 30.f) continue;         /* 还远，不算要用 */
                n_need[TEAM[i]] = 1;
                n_pend[TEAM[i]]++;
                if (best < 12.f) n_near[TEAM[i]]++;
            }

            if (mode == 2) {
                for (int t = 0; t < 2; t++) {
                    if (n_need[t]) rt_chain_want(&CH, chain, t, now);
                    else           rt_chain_unwant(&CH, chain, t);
                }
                (void)rt_chain_acquire(&CH, chain);
                int owner = (chain >= 0) ? CH.c[chain].owner : -1;
                int prog = (owner >= 0) ? chain_passed(owner) : 0;
                for (int k = 0; k < PM.n; k++) {
                    int cid = PM.p[k].cid;
                    if (cid < 0) continue;
                    rt_corr_note_state(&CC, cid,
                                       (owner >= 0) ? n_pend[owner] : 0,
                                       (owner >= 0) ? n_near[owner] : 0,
                                       prog);
                }
                rt_corr_tick(&CC, dt);
                rt_chain_tick(&CH, dt);
            } else {
                /* 朴素做法：每队各要「最近的那一段」，段与段之间没有任何协调 */
                for (int t = 0; t < 2; t++) {
                    int want_cid = -1;
                    float best = 1e30f;
                    for (int i = 0; i < N; i++) {
                        if (TEAM[i] != t || CROSSED[i]) continue;
                        for (int k = 0; k < PM.n; k++) {
                            int cid = PM.p[k].cid;
                            if (cid < 0) continue;
                            float d = rect_dist(&PM.p[k], AG[i].pos);
                            if (d < best) { best = d; want_cid = cid; }
                        }
                    }
                    if (want_cid >= 0) {
                        rt_corr_want(&CC, want_cid, t, now);
                        (void)rt_corr_acquire(&CC, want_cid);
                    }
                }
                int ownerA = -1, ownerB = -1;
                for (int k = 0; k < PM.n; k++) {
                    int cid = PM.p[k].cid;
                    if (cid < 0) continue;
                    int ow = CC.c[cid].owner;
                    if (ow == 0) ownerA = cid;
                    if (ow == 1) ownerB = cid;
                    rt_corr_note_state(&CC, cid,
                                       (ow >= 0) ? n_pend[ow] : 0,
                                       (ow >= 0) ? n_near[ow] : 0,
                                       (ow >= 0) ? seg_passed(&PM.p[k], ow) : 0);
                }
                (void)ownerA; (void)ownerB;
                rt_corr_tick(&CC, dt);
            }
        }

        /* ---- 期望速度 ---- */
        for (int i = 0; i < N; i++) {
            RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, IDS[i]);
            int gi = (int)ch->group[rt_unit_slot_index(IDS[i])] - 1;
            RtVec2 pref = rt_v2(0.f, 0.f);
            if (gi >= 0) {
                RtVec2 tgt;
                if (rt_gw_sample(&W, gi, AG[i].pos, &tgt) == RT_OK) {
                    RtVec2 d = rt_v2_sub(tgt, AG[i].pos);
                    float l = rt_v2_len(d);
                    if (l > 1e-3f) pref = rt_v2_mul(d, 2.0f / l);
                }
            }
            HELD[i] = 0;
            if (mode >= 1 && nseg > 0 && !CROSSED[i]) {
                int owner = (mode == 2) ? ((chain >= 0) ? CH.c[chain].owner : -1) : -2;
                /* 找离自己最近、且不是自己队 owner 的段 */
                int gating_cid = -1;
                float best = 1e30f;
                for (int k = 0; k < PM.n; k++) {
                    int cid = PM.p[k].cid;
                    if (cid < 0) continue;
                    float d = rect_dist(&PM.p[k], AG[i].pos);
                    if (d > 28.f) continue;
                    int bad = (mode == 2) ? (owner >= 0 && owner != TEAM[i])
                                          : (CC.c[cid].owner >= 0 && CC.c[cid].owner != TEAM[i]);
                    if (!bad) continue;
                    if (d < best) { best = d; gating_cid = cid; }
                }
                if (gating_cid >= 0) {
                    HELD[i] = 1;
                    int side = rt_corr_side(&CC.c[gating_cid], AG[i].pos);
                    if (side >= 0) {
                        RtVec2 wp = rt_corr_staging_point(&CC, gating_cid, side, i % 64, 64);
                        pref = rt_corr_gate(&CC, gating_cid, TEAM[i], AG[i].pos, pref, wp);
                    }
                }
            }
            AG[i].pref_vel = pref;
            rt_stuck_set_hold(&SC, i, HELD[i]);
        }

        rt_stuck_step(&SC, AG, N, &G, dt, NULL);
        rt_yield_step(&YC, AG, N, &G, dt, NULL, NULL);
        (void)rt_local_step(&LC, AG, N, &G, dt);
        (void)rt_gw_update(&W);

        sum += now_ms() - t0;

        int ca = 0, cb = 0;
        for (int i = 0; i < N; i++) {
            if (is_crossed(i)) { CROSSED[i] = 1; }
            if (CROSSED[i]) { if (TEAM[i] == 0) ca++; else cb++; }
        }
        m.crossA = ca; m.crossB = cb;
        if (ca >= nA && cb >= nB) break;
    }

    m.frames = frames;
    m.t_mean = sum / (double)(frames + 1);
    m.perm = SC.st.permanent_stuck;
    for (int i = 0; i < N; i++)
        for (int j = i + 1; j < N; j++) {
            float d = rt_v2_dist(AG[i].pos, AG[j].pos);
            float pen = (AG[i].radius + AG[j].radius) - d;
            if (pen > m.max_pen) m.max_pen = pen;
        }
    if (mode == 2 && chain >= 0) {
        m.grants = CH.c[chain].grants;
        m.handoffs = CH.c[chain].handoffs;
        m.stalls = CH.c[chain].stalls;
        m.seg_lost = CH.st.seg_lost;
        m.partial_fail = CH.st.partial_fail;
    } else if (mode == 1) {
        for (int k = 0; k < PM.n; k++) {
            int cid = PM.p[k].cid;
            if (cid < 0) continue;
            m.grants += CC.c[cid].grants;
            m.stalls += CC.c[cid].stalls;
        }
    }

    if (verbose) {
        printf("  %-18s nseg=%d chain=%d  crossed A=%d/%d B=%d/%d  (%.1f s)  %.2f ms/frame\n",
               name, nseg, CH.n, m.crossA, nA, m.crossB, nB,
               (double)frames / 30.0, m.t_mean);
        if (mode == 2)
            printf("  %-18s grants=%u handoffs=%u stalls=%u seg_lost=%u partial_fail=%u  perm=%u\n",
                   "", m.grants, m.handoffs, m.stalls, m.seg_lost, m.partial_fail, m.perm);
        else if (mode == 1)
            printf("  %-18s sum(grants)=%u sum(stalls)=%u  perm=%u\n",
                   "", m.grants, m.stalls, m.perm);

        /* 没过去的单位在哪、状态是什么 —— 不看这个就只能猜 */
        for (int i = 0; i < N; i++) {
            if (CROSSED[i]) continue;
            int cx = rt_grid_cell_x(&G, AG[i].pos.x), cz = rt_grid_cell_z(&G, AG[i].pos.z);
            printf("      stuck#%2d team=%d pos=(%6.2f,%6.2f) walk=%d clr=%.2f"
                   " pref=(%.2f,%.2f) held=%d state=%s lvl=%d bay=%d\n",
                   i, TEAM[i], AG[i].pos.x, AG[i].pos.z,
                   rt_grid_walkable(&G, cx, cz), rt_grid_clearance_m(&G, cx, cz),
                   AG[i].pref_vel.x, AG[i].pref_vel.z, HELD[i],
                   rt_stuck_state_name(SC.u[i].state), SC.u[i].level, SC.u[i].bay_ok);
        }
    }
    return m;
}

/* ---------------------------------------------------------------------------
 * T1 / T2：分组与退化
 * -------------------------------------------------------------------------*/
static void t1_groups(void)
{
    printf("\n[T1] Z-shaped corridor: 3 straight segments in ONE chain\n");
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    map_z();
    world_build();
    rt_portal_destroy(&PM);
    rt_portal_init(&PM, RT_PORTAL_MAX, NULL);
    int n = rt_portal_scan(&PM, &G);
    printf("      portals=%d chained=%u\n", n, PM.st.rejected_chained);
    for (int i = 0; i < n; i++)
        printf("        p%d rect=[%.0f,%.0f]x[%.0f,%.0f] w=%.1f fill=%.2f chain=%d chained=%d\n",
               i, PM.p[i].x0, PM.p[i].x1, PM.p[i].z0, PM.p[i].z1,
               PM.p[i].width_m, PM.p[i].fill, PM.p[i].chain, PM.p[i].chained);

    OK(n == 3, "T1 the Z corridor is split into 3 straight segments");
    if (n == 3) {
        OK(PM.p[0].chain == PM.p[1].chain && PM.p[1].chain == PM.p[2].chain,
           "T1 all three segments share one chain id");
        OK(PM.p[0].chained && PM.p[2].chained, "T1 segments are marked chained");
        for (int i = 0; i < 3; i++)
            OK(fabsf(PM.p[i].width_m - 2.f) < 0.01f, "T1 every segment is 2 m wide");
    } else {
        OK(0, "T1 one chain id");
        OK(0, "T1 chained flags");
    }

    int reg = rt_portal_register_chained(&PM, &CC, &CH);
    printf("      registered=%d corridors  chains=%d  chain0.nseg=%d\n",
           reg, CH.n, (CH.n > 0) ? CH.c[0].nseg : 0);
    OK(reg == 3 && CC.n == 3, "T1 all three segments registered");
    OK(CH.n == 1 && CH.c[0].nseg == 3, "T1 one chain containing three segments");

    /* 安全默认：不接链路协调器时，相接的段一条都不注册 */
    rt_corr_clear_all(&CC);
    int reg2 = rt_portal_register(&PM, &CC);
    printf("      safe default (no chain ctx): registered=%d\n", reg2);
    OK(reg2 == 0, "T1 safe default still refuses chained segments");
}

static void t2_single(void)
{
    printf("\n[T2] single tunnel degenerates to a 1-segment chain\n");
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    map_tunnel(126, 127, 190, 191);
    world_build();
    rt_portal_destroy(&PM);
    rt_portal_init(&PM, RT_PORTAL_MAX, NULL);
    int n = rt_portal_scan(&PM, &G);
    int reg = rt_portal_register_chained(&PM, &CC, &CH);
    printf("      portals=%d registered=%d chains=%d segs=%d/%d\n",
           n, reg, CH.n, CH.c[0].nseg, CH.c[1].nseg);
    OK(n == 2, "T2 two independent tunnels detected");
    OK(reg == 2 && CH.n == 2, "T2 two independent chains");
    OK(CH.n == 2 && CH.c[0].nseg == 1 && CH.c[1].nseg == 1,
       "T2 each chain has exactly one segment (no behaviour change vs M11)");
}

/* ---------------------------------------------------------------------------
 * T3：原子性
 * -------------------------------------------------------------------------*/
static void t3_atomic(void)
{
    printf("\n[T3] atomicity: half a chain must be unreachable\n");
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    map_z();
    world_build();
    rt_portal_destroy(&PM);
    rt_portal_init(&PM, RT_PORTAL_MAX, NULL);
    (void)rt_portal_scan(&PM, &G);
    (void)rt_portal_register_chained(&PM, &CC, &CH);
    const int ch = 0;
    OK(CH.c[ch].nseg == 3, "T3 chain has 3 segments");

    /* 人为让 team1 先占住第 2 段 */
    int seg1 = CH.c[ch].seg[1];
    OK(rt_corr_request(&CC, seg1, 1) == 1, "T3 team1 grabs the middle segment");

    rt_chain_want(&CH, ch, 0, 1.0f);
    int got = rt_chain_acquire(&CH, ch);
    printf("      acquire with middle segment taken: owner=%d partial_fail=%u\n",
           got, CH.st.partial_fail);
    OK(got < 0, "T3 chain acquisition fails when one segment is taken");
    OK(CH.st.partial_fail >= 1, "T3 partial failure is counted");
    OK(CH.c[ch].owner < 0, "T3 chain stays free (no half-ownership)");
    /* 关键：失败的申请不能把其它段留在手里 */
    int leaked = 0;
    for (int k = 0; k < CH.c[ch].nseg; k++) {
        int cid = CH.c[ch].seg[k];
        if (cid != seg1 && CC.c[cid].owner >= 0) leaked++;
    }
    printf("      segments left owned by team0 after the failure: %d\n", leaked);
    OK(leaked == 0, "T3 no segment leaks after a failed acquisition");

    /* 放开之后应该整条拿到 */
    rt_corr_release(&CC, seg1, 1);
    got = rt_chain_acquire(&CH, ch);
    OK(got == 0, "T3 once free, the whole chain is granted to team0");
    int owned = 0;
    for (int k = 0; k < CH.c[ch].nseg; k++)
        if (CC.c[CH.c[ch].seg[k]].owner == 0) owned++;
    OK(owned == 3, "T3 team0 owns all three segments");

    /* 段被强制释放 -> 整条收回 */
    rt_corr_release(&CC, CH.c[ch].seg[2], 0);
    rt_chain_tick(&CH, 1.f / 30.f);
    printf("      after one segment is force-released: chain owner=%d seg_lost=%u\n",
           CH.c[ch].owner, CH.st.seg_lost);
    OK(CH.c[ch].owner < 0 && CH.st.seg_lost >= 1,
       "T3 losing one segment releases the whole chain");
    int still = 0;
    for (int k = 0; k < CH.c[ch].nseg; k++)
        if (CC.c[CH.c[ch].seg[k]].owner >= 0) still++;
    OK(still == 0, "T3 no segment is left owned after the chain is revoked");
}

int main(void)
{
    timer_init();
    printf("=== M15 tests: corridor chains (cross-corridor coordination) ===\n");

    t1_groups();
    t2_single();
    t3_atomic();

    printf("\n[T4] Z corridor, three strategies compared (420 s so both teams get a turn)\n");
    Tun a = run_z(0, 12, 12, 420, 1, "0 no arbitration");
    Tun b = run_z(1, 12, 12, 420, 1, "1 per-segment");
    Tun c = run_z(2, 12, 12, 420, 1, "2 chain (M15)");

    /* 结论要分开说：
     *   · 这条 Z 形带 2×2 的拐角**有会车空间**，所以「不仲裁」也能自组织通过
     *     （M15 实测 23/24；M17 修好墙角冻住后 24/24、70.2 s）—— 这一轮的收益
     *     **不是吞吐**，别硬吹：链级要串行，反而比不仲裁慢（100.9 s vs 70.2 s），
     *     它买的是**确定顺序**（handoffs=1）和「半个链在 A 手里」这个状态不可达；
     *   · 真正的病是「逐段独立仲裁」：两队各持一段、互等对方那一段，
     *     把一个本来能过的场景变成 4/24（M15 时是 0/24）—— 比不仲裁更差；
     *   · 链级原子仲裁把这个状态变成不可达，恢复通行（24/24）。
     *
     * 阈值重新定基线（M17）：旧值 `<= 2` 是在「单位会冻在拐角里」的基座上标定的，
     * 那个基座本身少过了 4 个人（2+2 是**冻住**不是**互锁**）。基座修好后物理
     * 下限变了，但「逐段仲裁会互锁」的定性结论没变，差距从 0 vs 22 变成 4 vs 24。 */
    OK(b.crossA + b.crossB <= 8, "T4 per-segment arbitration collapses (the deadlock we are fixing)");
    OK(b.crossA <= 5 && b.crossB <= 5,
       "T4 per-segment: neither team gets through (a real interlock, not one team winning)");
    OK(c.crossA + c.crossB >= 20, "T4 chain: both teams get through");
    OK(c.crossA + c.crossB > b.crossA + b.crossB,
       "T4 chain beats per-segment arbitration");
    OK(c.grants >= 2, "T4 chain ownership is handed over at least once");
    OK(c.handoffs >= 1, "T4 the chain actually changed hands");
    OK(c.max_pen < 0.60f, "T4 penetration < 0.6 m");
    OK(c.perm == 0, "T4 chain run abandons nobody (M17: no GAVE_UP in the queue)");

    printf("\n[T5] two independent tunnels: chains must not interfere\n");
    {
        /* 两条互不相接的隧道，A 走上面那条、B 走下面那条，应同时通过 */
        rt_grid_destroy(&G);
        rt_grid_init(&G, 256, 256, 1.0f);
        map_tunnel(60, 61, 190, 191);
        world_build();
        rt_portal_destroy(&PM);
        rt_portal_init(&PM, RT_PORTAL_MAX, NULL);
        (void)rt_portal_scan(&PM, &G);
        int reg = rt_portal_register_chained(&PM, &CC, &CH);
        printf("      portals=%d registered=%d chains=%d segs=%d/%d\n",
               PM.n, reg, CH.n, CH.c[0].nseg, CH.c[1].nseg);
        OK(PM.n == 2 && CH.n == 2, "T5 two separate chains");
        /* 分别给两条链授予不同队伍：互不影响 */
        rt_chain_want(&CH, 0, 0, 1.0f);
        rt_chain_want(&CH, 1, 1, 1.0f);
        int o0 = rt_chain_acquire(&CH, 0);
        int o1 = rt_chain_acquire(&CH, 1);
        printf("      chain0 owner=%d  chain1 owner=%d\n", o0, o1);
        OK(o0 == 0 && o1 == 1, "T5 two chains are granted independently");
    }

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    if (g_fail == 0) printf("ALL PASS (%d asserts)\n", g_pass);

    rt_portal_destroy(&PM);
    rt_chain_destroy(&CH);
    rt_corr_destroy(&CC);
    rt_stuck_destroy(&SC);
    rt_yield_destroy(&YC);
    rt_local_destroy(&LC);
    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return g_fail == 0 ? 0 : 1;
}

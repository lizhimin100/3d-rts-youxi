#!/usr/bin/env bash
# ============================================================================
# gate_all.sh -- 全回归门禁（M16 起）：**先编译全部，再依次运行**
#
# 为什么必须分开两步（M14/M15 各踩一次）：
#   交替「编译一个 + 跑一个」会让 4 条单次计时门禁
#   （m3 S4 4ms / m44 T4 0.16ms / m46 M11 1.5ms / m6 T5 1ms）偶发超时，
#   并且会把 zig 自己的缓存搅乱（偶发 0 字节 exe）。先全编译，再按序跑，干净。
#
# 用法：
#   bash gate_all.sh              # 全部（缺 .c 的自动跳过）
#   bash gate_all.sh test_m16     # 只跑指定的几个
# ============================================================================
set -u
cd "$(dirname "$0")" || exit 1

ZIG="${ZIG:-$HOME/.workbuddy/binaries/python/envs/default/Lib/site-packages/ziglang/zig.exe}"
if [ ! -x "$ZIG" ]; then
    if command -v zig >/dev/null 2>&1; then ZIG="$(command -v zig)";
    else echo "[FATAL] no zig"; exit 127; fi
fi

ALL="test_core test_m3 test_m4 test_m42 test_m43 test_m44 test_m45 test_m46 \
     test_m5 test_m6 test_m7 test_m8 test_m9 test_m10 test_m11 test_m12 \
     test_m13 test_m14 test_m15 test_m16 test_m17"

if [ $# -gt 0 ]; then LIST="$*"; else LIST="$ALL"; fi

echo "=== gate ($(date '+%Y-%m-%d %H:%M')) compiler=$ZIG"
fail=0
for t in $LIST; do
    [ -f "tests/$t.c" ] || { echo "skip $t (no source)"; continue; }
    if ! "$ZIG" cc -O2 -std=c11 -Wall -Wextra -Icore/include core/src/*.c "tests/$t.c" -o "$t.exe" 2>"$t.build.log"; then
        echo "[FAIL] compile $t"; sed -n '1,20p' "$t.build.log"; fail=1; break
    fi
done
[ $fail -eq 0 ] && echo "compile: ok"

for t in $LIST; do
    [ -x "$t.exe" ] || continue
    out=$("./$t.exe" 2>&1); rc=$?
    line=$(printf '%s\n' "$out" | grep -E "passed, [0-9]+ failed" | tail -1)
    printf '%-12s exit=%d  %s\n' "$t" "$rc" "${line:-<no summary>}"
    if [ $rc -ne 0 ]; then fail=1; printf '%s\n' "$out" | tail -20; fi
done

if [ $fail -ne 0 ]; then echo "=== GATE FAILED"; exit 1; fi
echo "=== GATE GREEN"

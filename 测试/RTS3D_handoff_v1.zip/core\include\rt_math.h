/* ============================================================================
 * rt_math.h -- 数学接口层（可替换为定点）
 *
 * 为什么要有这一层（而不是到处直接调用 libm）：
 *   1. 确定性：所有浮点运算都经过同一条路径，将来换定点/软浮点时只改这里；
 *      2.0 工程题的教训：引擎向量默认 float32，坐标 16384 处 ULP 已到 0.002，
 *      精度假设必须写在一处并留注释。
 *   2. 可审计：热点路径禁止出现 sinf/cosf；朝向统一在「改变朝向」时预算 cos/sin。
 *   3. 端口无关：x86/ARM 的 sqrtf 都是 IEEE 正确舍入，确定性安全；sinf 不是。
 *
 * 纪律：本文件**全部** static inline，无 .c；只依赖 <math.h> 的 sqrtf/fabsf。
 * ==========================================================================*/
#ifndef RT_MATH_H
#define RT_MATH_H

#include <math.h>
#include "rt_types.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RT_PI       3.14159265358979323846f
#define RT_2PI      6.28318530717958647692f
#define RT_DEG2RAD  0.01745329251994329577f
#define RT_RAD2DEG  57.2957795130823208768f
#define RT_EPS      1e-6f
#define RT_SQRT2    1.41421356237309504880f

/* ------------------------------------------------------------ 标量 */
static inline float rt_min(float a, float b) { return a < b ? a : b; }
static inline float rt_max(float a, float b) { return a > b ? a : b; }
static inline float rt_clamp(float v, float lo, float hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}
static inline float rt_clamp01(float v) { return rt_clamp(v, 0.f, 1.f); }
static inline float rt_abs(float v) { return v < 0.f ? -v : v; }
static inline float rt_lerp(float a, float b, float t) { return a + (b - a) * t; }
static inline int   rt_imin(int a, int b) { return a < b ? a : b; }
static inline int   rt_imax(int a, int b) { return a > b ? a : b; }
static inline int   rt_iclamp(int v, int lo, int hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}
static inline float rt_sqrt(float v) { return sqrtf(v < 0.f ? 0.f : v); }

/* 角度归一化到 (-pi, pi]（确定性写法：不依赖 fmod 的边界行为） */
static inline float rt_wrap_pi(float a)
{
    while (a >  RT_PI) a -= RT_2PI;
    while (a <= -RT_PI) a += RT_2PI;
    return a;
}

/* 朝目标角插值，限制最大角速度（用于朝向平滑，避免抖动） */
static inline float rt_approach_angle(float cur, float target, float max_delta)
{
    float d = rt_wrap_pi(target - cur);
    if (d >  max_delta) d =  max_delta;
    if (d < -max_delta) d = -max_delta;
    return rt_wrap_pi(cur + d);
}

/* ------------------------------------------------------------ Vec2 */
static inline RtVec2 rt_v2(float x, float z) { RtVec2 r; r.x = x; r.z = z; return r; }
static inline RtVec2 rt_v2_add(RtVec2 a, RtVec2 b) { return rt_v2(a.x + b.x, a.z + b.z); }
static inline RtVec2 rt_v2_sub(RtVec2 a, RtVec2 b) { return rt_v2(a.x - b.x, a.z - b.z); }
static inline RtVec2 rt_v2_mul(RtVec2 a, float s) { return rt_v2(a.x * s, a.z * s); }
static inline float  rt_v2_dot(RtVec2 a, RtVec2 b) { return a.x * b.x + a.z * b.z; }
static inline float  rt_v2_cross(RtVec2 a, RtVec2 b) { return a.x * b.z - a.z * b.x; }
static inline float  rt_v2_len2(RtVec2 a) { return a.x * a.x + a.z * a.z; }
static inline float  rt_v2_len(RtVec2 a) { return sqrtf(rt_v2_len2(a)); }
static inline float  rt_v2_dist2(RtVec2 a, RtVec2 b) { return rt_v2_len2(rt_v2_sub(a, b)); }
static inline float  rt_v2_dist(RtVec2 a, RtVec2 b) { return sqrtf(rt_v2_dist2(a, b)); }

static inline RtVec2 rt_v2_norm(RtVec2 a)
{
    float l2 = rt_v2_len2(a);
    if (l2 < RT_EPS * RT_EPS) return rt_v2(0.f, 0.f);
    float inv = 1.f / sqrtf(l2);
    return rt_v2(a.x * inv, a.z * inv);
}

/* 绕原点旋转（用预存的 cos/sin，避免热点调用 sinf/cosf） */
static inline RtVec2 rt_v2_rotate_cs(RtVec2 a, float c, float s)
{
    return rt_v2(a.x * c - a.z * s, a.x * s + a.z * c);
}

/* ------------------------------------------------------------ Vec3 */
static inline RtVec3 rt_v3(float x, float y, float z) { RtVec3 r; r.x = x; r.y = y; r.z = z; return r; }
static inline RtVec3 rt_v3_add(RtVec3 a, RtVec3 b) { return rt_v3(a.x + b.x, a.y + b.y, a.z + b.z); }
static inline RtVec3 rt_v3_sub(RtVec3 a, RtVec3 b) { return rt_v3(a.x - b.x, a.y - b.y, a.z - b.z); }
static inline RtVec3 rt_v3_mul(RtVec3 a, float s) { return rt_v3(a.x * s, a.y * s, a.z * s); }
static inline float  rt_v3_dot(RtVec3 a, RtVec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static inline float  rt_v3_len2(RtVec3 a) { return a.x * a.x + a.y * a.y + a.z * a.z; }
static inline float  rt_v3_len(RtVec3 a) { return sqrtf(rt_v3_len2(a)); }

/* XZ 平面距离（地面单位的主度量） */
static inline float rt_v3_dist_xz(RtVec3 a, RtVec3 b)
{
    float dx = a.x - b.x, dz = a.z - b.z;
    return sqrtf(dx * dx + dz * dz);
}

/* ------------------------------------------------------------ OBB2 */
/* 构造：footprint 边长 fp（米），朝向 yaw（弧度）。
 * 关键决策：OBB 用**内切**语义 —— half = fp/2，用于「是否与阻挡相交」的精确判定。
 * 而避障（ORCA）用**内切圆**半径 fp/2：允许多边形角落的极小视觉重叠，
 * 换取推进平滑。两者的差异在测试里单独量化（见 tests/test_core.c）。 */
static inline RtObb2 rt_obb_make(RtVec2 c, float fp, float yaw)
{
    RtObb2 o;
    o.center = c;
    o.half = rt_v2(fp * 0.5f, fp * 0.5f);
    o.cos_a = cosf(yaw);
    o.sin_a = sinf(yaw);
    return o;
}

/* 用预存 cos/sin 构造（热点路径：朝向未变时复用） */
static inline RtObb2 rt_obb_make_cs(RtVec2 c, float half_fp, float c_, float s_)
{
    RtObb2 o;
    o.center = c;
    o.half = rt_v2(half_fp, half_fp);
    o.cos_a = c_;
    o.sin_a = s_;
    return o;
}

static inline RtAabb2 rt_obb_aabb(const RtObb2 *o)
{
    /* |h.x*cos| + |h.z*sin| */
    float ex = rt_abs(o->half.x * o->cos_a) + rt_abs(o->half.z * o->sin_a);
    float ez = rt_abs(o->half.x * o->sin_a) + rt_abs(o->half.z * o->cos_a);
    RtAabb2 b;
    b.min_x = o->center.x - ex; b.max_x = o->center.x + ex;
    b.min_z = o->center.z - ez; b.max_z = o->center.z + ez;
    return b;
}

/* 4 个角点（顺序：(-,-), (+,-), (+,+), (-,+) 局部） */
static inline void rt_obb_corners(const RtObb2 *o, RtVec2 out[4])
{
    RtVec2 axes[2];
    axes[0] = rt_v2(o->cos_a, o->sin_a);      /* 局部 x 轴 */
    axes[1] = rt_v2(-o->sin_a, o->cos_a);     /* 局部 z 轴 */
    const float sx[4] = { -1.f,  1.f,  1.f, -1.f };
    const float sz[4] = { -1.f, -1.f,  1.f,  1.f };
    for (int i = 0; i < 4; i++) {
        RtVec2 p = o->center;
        p = rt_v2_add(p, rt_v2_mul(axes[0], o->half.x * sx[i]));
        p = rt_v2_add(p, rt_v2_mul(axes[1], o->half.z * sz[i]));
        out[i] = p;
    }
}

/* OBB vs AABB：分离轴（2 条世界轴 + 2 条 OBB 轴） */
static inline int rt_obb_overlaps_aabb(const RtObb2 *o, const RtAabb2 *b)
{
    /* 轴 1/2：世界 X/Z（等价于把 OBB 投影到世界轴） */
    RtAabb2 oa = rt_obb_aabb(o);
    if (oa.max_x < b->min_x || oa.min_x > b->max_x) return 0;
    if (oa.max_z < b->min_z || oa.min_z > b->max_z) return 0;

    /* 轴 3/4：OBB 局部轴。把 AABB 的 4 个角投影到 OBB 局部轴 */
    RtVec2 ax[2];
    ax[0] = rt_v2(o->cos_a, o->sin_a);
    ax[1] = rt_v2(-o->sin_a, o->cos_a);
    RtAabb2 bl = *b;
    RtVec2 bc = rt_v2((bl.min_x + bl.max_x) * 0.5f, (bl.min_z + bl.max_z) * 0.5f);
    RtVec2 bh = rt_v2((bl.max_x - bl.min_x) * 0.5f, (bl.max_z - bl.min_z) * 0.5f);
    RtVec2 d = rt_v2_sub(bc, o->center);
    for (int i = 0; i < 2; i++) {
        float proj_c = rt_abs(rt_v2_dot(d, ax[i]));
        float proj_a = rt_abs(bh.x * ax[i].x) + rt_abs(bh.z * ax[i].z);
        float proj_o = (i == 0) ? o->half.x : o->half.z;
        if (proj_c > proj_o + proj_a) return 0;
    }
    return 1;
}

/* 点是否在 OBB 内（把点转到局部坐标） */
static inline int rt_obb_contains(const RtObb2 *o, RtVec2 p)
{
    RtVec2 d = rt_v2_sub(p, o->center);
    float lx = d.x * o->cos_a + d.z * o->sin_a;
    float lz = -d.x * o->sin_a + d.z * o->cos_a;
    return (rt_abs(lx) <= o->half.x) && (rt_abs(lz) <= o->half.z);
}

/* OBB 的外接圆半径（用于 clearance 快速拒绝） */
static inline float rt_obb_circumradius(const RtObb2 *o)
{
    return sqrtf(o->half.x * o->half.x + o->half.z * o->half.z);
}

/* 圆 vs OBB（窄相位）：返回穿透深度的近似（0 = 不相交） */
static inline float rt_circle_obb_penetration(RtVec2 c, float r, const RtObb2 *o)
{
    RtVec2 d = rt_v2_sub(c, o->center);
    float lx = d.x * o->cos_a + d.z * o->sin_a;
    float lz = -d.x * o->sin_a + d.z * o->cos_a;
    float dx = rt_abs(lx) - o->half.x;
    float dz = rt_abs(lz) - o->half.z;
    if (dx <= 0.f && dz <= 0.f) {
        /* 圆心在盒内：穿透 = r + 最近边距 */
        float m = rt_min(-dx, -dz);
        return r + m;
    }
    float qx = dx > 0.f ? dx : 0.f;
    float qz = dz > 0.f ? dz : 0.f;
    float dist = sqrtf(qx * qx + qz * qz);
    return r - dist;   /* >0 表示相交 */
}

/* ------------------------------------------------------- 线段 vs AABB */
/* 用于「路径是否穿过新阻挡」的快速测试（slab method） */
static inline int rt_segment_hits_aabb(RtVec2 a, RtVec2 b, const RtAabb2 *box, float pad)
{
    float dx = b.x - a.x, dz = b.z - a.z;
    float t0 = 0.f, t1 = 1.f;
    float mnx = box->min_x - pad, mxx = box->max_x + pad;
    float mnz = box->min_z - pad, mxz = box->max_z + pad;

    if (rt_abs(dx) < RT_EPS) {
        if (a.x < mnx || a.x > mxx) return 0;
    } else {
        float inv = 1.f / dx;
        float ta = (mnx - a.x) * inv, tb = (mxx - a.x) * inv;
        if (ta > tb) { float t = ta; ta = tb; tb = t; }
        t0 = rt_max(t0, ta); t1 = rt_min(t1, tb);
        if (t0 > t1) return 0;
    }
    if (rt_abs(dz) < RT_EPS) {
        if (a.z < mnz || a.z > mxz) return 0;
    } else {
        float inv = 1.f / dz;
        float ta = (mnz - a.z) * inv, tb = (mxz - a.z) * inv;
        if (ta > tb) { float t = ta; ta = tb; tb = t; }
        t0 = rt_max(t0, ta); t1 = rt_min(t1, tb);
        if (t0 > t1) return 0;
    }
    return 1;
}

#ifdef __cplusplus
}
#endif

#endif /* RT_MATH_H */

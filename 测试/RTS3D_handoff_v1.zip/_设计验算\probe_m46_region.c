/* ============================================================================
 * probe_m46_region.c -- M4.6-P2 差分验证（不是测试，是取证）
 *
 * 1) 增量刷新 vs 整图重建：每次编辑后逐字段比较 pass/maxclear/comp/mixed/anchor。
 * 2) 成本：整图重建 vs 2x2/8x8 建筑的矩形刷新。
 * 3) 安全网：故意把 dirty 裁到同一个 chunk 里 / 裁到另一个 chunk 外，观察是否被发现。
 * ==========================================================================*/
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

#include "rt_grid.h"
#include "rt_region.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static uint64_t g_st = 0x123456789ABCDEFull;
static uint32_t rnd(void)
{
    g_st += 0x9E3779B97F4A7C15ull;
    uint64_t k = g_st;
    k = (k ^ (k >> 30)) * 0xBF58476D1CE4E5B9ull;
    k = (k ^ (k >> 27)) * 0x94D049BB133111EBull;
    return (uint32_t)(k ^ (k >> 31));
}

static RtGrid G;
static RtRegionMap MAP;   /* 增量 */
static RtRegionMap REF;   /* 整图参照 */

static int cmp_maps(const char *tag)
{
    int nr = MAP.rw * MAP.rh;
    int bad_pass = 0, bad_max = 0, bad_comp = 0, bad_mixed = 0, bad_anchor = 0;
    int first = -1;
    for (int r = 0; r < nr; r++) {
        for (int c = 0; c < RT_CLEAR_CLASSES; c++)
            if (MAP.pass[r * 4 + c] != REF.pass[r * 4 + c]) bad_pass++;
        if (MAP.maxclear[r] != REF.maxclear[r]) bad_max++;
        if (MAP.comp[r] != REF.comp[r]) bad_comp++;
        if (MAP.mixed[r] != REF.mixed[r]) bad_mixed++;
        if (MAP.anchor_x[r] != REF.anchor_x[r] || MAP.anchor_z[r] != REF.anchor_z[r]) bad_anchor++;
        if (first < 0 && (bad_pass || bad_max || bad_comp || bad_mixed || bad_anchor)) first = r;
    }
    if (bad_pass || bad_max || bad_comp || bad_mixed || bad_anchor) {
        printf("  !! %s mismatch: pass=%d max=%d comp=%d mixed=%d anchor=%d (first r=%d)\n",
               tag, bad_pass, bad_max, bad_comp, bad_mixed, bad_anchor, first);
        return 0;
    }
    return 1;
}

int main(void)
{
    timer_init();
    printf("=== M4.6-P2 region incremental refresh: differential + cost ===\n");

    rt_grid_init(&G, 256, 256, 1.0f);
    /* 10% 噪声 + 几条长墙（长墙两侧会产生大量 mixed 区域，专门打 merge 重标号） */
    uint64_t st = 0xC0FFEEull;
    for (int z = 0; z < 256; z++)
        for (int x = 0; x < 256; x++) {
            uint64_t k = (st += 0x9E3779B97F4A7C15ull);
            k = (k ^ (k >> 30)) * 0xBF58476D1CE4E5B9ull;
            k = (k ^ (k >> 27)) * 0x94D049BB133111EBull;
            k ^= k >> 31;
            if ((k >> 40) % 1000 < 60ull) rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
    for (int z = 40; z < 200; z++) rt_grid_set_terrain(&G, 60, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int x = 60; x < 200; x++) rt_grid_set_terrain(&G, x, 150, RT_CELL_BLOCKED_TERRAIN, 1);

    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_region_build(&REF, &G, 8);
    printf("regions = %dx%d (%d), px=%d\n", MAP.rw, MAP.rh, MAP.rw * MAP.rh, MAP.px);
    printf("initial: %s\n", cmp_maps("initial") ? "identical" : "MISMATCH");

    /* ---- 1. 随机 add/remove，逐次差分 ---- */
    enum { MAXB = 512 };
    static int bx[MAXB], bz[MAXB], bw[MAXB], bh[MAXB];
    int nb = 0;
    int edits = 0, bad = 0, widened = 0, full1 = 0;
    for (int it = 0; it < 400; it++) {
        RtGridDirty d;
        int rc_apply;
        int do_remove = (nb > 0) && (rnd() % 100 < 35);
        if (do_remove) {
            int i = (int)(rnd() % (uint32_t)nb);
            if (rt_grid_remove_building_dirty(&G, bx[i], bz[i], bw[i], bh[i], &d) != RT_OK) continue;
            bx[i] = bx[nb - 1]; bz[i] = bz[nb - 1]; bw[i] = bw[nb - 1]; bh[i] = bh[nb - 1];
            nb--;
        } else {
            int w = 2 + (int)(rnd() % 5), h = 2 + (int)(rnd() % 5);
            int x = 4 + (int)(rnd() % 240), z = 4 + (int)(rnd() % 240);
            if (rt_grid_add_building_dirty(&G, x, z, w, h, &d) != RT_OK) continue;
            if (nb < MAXB) { bx[nb] = x; bz[nb] = z; bw[nb] = w; bh[nb] = h; nb++; }
        }
        rc_apply = rt_grid_apply_dirty(&G, &d);
        if (rc_apply != RT_OK) {
            /* 降级全量：区域图必须整图追上 */
            rt_region_refresh(&MAP);
        } else {
            int x0 = d.x0, z0 = d.z0, x1 = d.x1, z1 = d.z1;
            if (d.cx0 < x0) x0 = d.cx0;
            if (d.cz0 < z0) z0 = d.cz0;
            if (d.cx1 > x1) x1 = d.cx1;
            if (d.cz1 > z1) z1 = d.cz1;
            int n = rt_region_refresh_rect(&MAP, x0, z0, x1, z1);
            if (n < 0) { printf("  refresh_rect rc=%d\n", n); return 1; }
            if (MAP.last_full_reason == 2) widened++;
            if (MAP.last_full_reason == 1) full1++;
        }
        rt_region_build(&REF, &G, 8);
        edits++;
        if (!cmp_maps("edit")) bad++;
    }
    printf("edits=%d mismatched=%d widened=%d full1=%d mixed_rescans=%u\n",
           edits, bad, widened, full1, MAP.mixed_rescans);
    printf("refresh: calls=%u regions=%u full=%u (avg regions/call=%.1f)\n",
           MAP.refresh_calls, MAP.refresh_regions, MAP.refresh_full,
           MAP.refresh_calls ? (double)MAP.refresh_regions / (double)MAP.refresh_calls : 0.0);

    /* ---- 2. 成本 ---- */
    {
        RtGridDirty d;
        /* 先放一个 2x2 建筑，然后反复 remove/add 同一位置，测两种刷新 */
        rt_grid_add_building_dirty(&G, 100, 100, 2, 2, &d);
        rt_grid_apply_dirty(&G, &d);
        rt_region_refresh(&MAP);
        rt_region_refresh(&REF);

        double best_full = 1e30, best_rect = 1e30;
        int regs = 0;
        for (int rep = 0; rep < 15; rep++) {
            double t0, dt;
            rt_grid_remove_building_dirty(&G, 100, 100, 2, 2, &d);
            rt_grid_apply_dirty(&G, &d);
            t0 = now_ms();
            rt_region_refresh(&MAP);
            dt = now_ms() - t0;
            if (dt < best_full) best_full = dt;

            rt_grid_add_building_dirty(&G, 100, 100, 2, 2, &d);
            rt_grid_apply_dirty(&G, &d);
            t0 = now_ms();
            regs = rt_region_refresh_rect(&MAP, d.cx0, d.cz0, d.cx1, d.cz1);
            dt = now_ms() - t0;
            if (dt < best_rect) best_rect = dt;
        }
        printf("2x2 building: full=%.4f ms  rect=%.4f ms  (x%.1f, regions=%d/%d)\n",
               best_full, best_rect, best_full / (best_rect > 1e-9 ? best_rect : 1e-9),
               regs, MAP.rw * MAP.rh);

        /* 8x8 */
        double b8 = 1e30;
        int r8 = 0;
        rt_grid_add_building_dirty(&G, 130, 130, 8, 8, &d);
        rt_grid_apply_dirty(&G, &d);
        rt_region_build(&MAP, &G, 8);
        for (int rep = 0; rep < 15; rep++) {
            double t0;
            rt_grid_remove_building_dirty(&G, 130, 130, 8, 8, &d);
            rt_grid_apply_dirty(&G, &d);
            rt_grid_add_building_dirty(&G, 130, 130, 8, 8, &d);
            rt_grid_apply_dirty(&G, &d);
            t0 = now_ms();
            r8 = rt_region_refresh_rect(&MAP, d.cx0, d.cz0, d.cx1, d.cz1);
            double dt = now_ms() - t0;
            if (dt < b8) b8 = dt;
        }
        printf("8x8 building: rect=%.4f ms (regions=%d)\n", b8, r8);
    }

    /* ---- 3. 安全网：把 dirty 裁到别的 chunk ---- */
    {
        RtGridDirty d;
        rt_grid_add_building_dirty(&G, 200, 200, 4, 4, &d);
        rt_grid_apply_dirty(&G, &d);
        /* 只上报 (200..201) —— 202..203 与 200 同 chunk（200/32=6）→ 发现不了；
         * 构造一个跨 chunk 的编辑：x=63..66 跨 chunk 1/2，只上报 x<=63。 */
        int n = rt_region_refresh_rect(&MAP, 200, 200, 201, 201);
        printf("same-chunk truncation: regions=%d full_reason=%u (<-- 允许漏，见头文件契约)\n",
               n, MAP.last_full_reason);
        rt_region_build(&MAP, &G, 8);   /* 强制整图，回到干净状态 */

        rt_grid_add_building_dirty(&G, 63, 100, 4, 4, &d);   /* 63..66 跨 chunk */
        rt_grid_apply_dirty(&G, &d);
        n = rt_region_refresh_rect(&MAP, 63, 100, 63, 103);  /* 故意只报 x=63 */
        printf("cross-chunk truncation: regions=%d full_reason=%u (2 = 被安全网抓到)\n",
               n, MAP.last_full_reason);
        rt_region_build(&REF, &G, 8);
        printf("after widened: %s\n", cmp_maps("widened") ? "identical" : "MISMATCH");
    }

    /* ---- 4. 非 8 倍数地图：边界区域是「残缺块」，聚合不能越界读 ---- */
    {
        rt_region_destroy(&REF);
        rt_region_destroy(&MAP);
        rt_grid_destroy(&G);
        rt_grid_init(&G, 100, 90, 1.0f);
        for (int z = 0; z < 90; z++)
            for (int x = 0; x < 100; x++)
                if (((x * 7 + z * 13) % 23) == 0)
                    rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        rt_grid_rebuild_all(&G);
        rt_region_build(&MAP, &G, 8);
        rt_region_build(&REF, &G, 8);
        int bad2 = 0, edits2 = 0;
        for (int it = 0; it < 40; it++) {
            RtGridDirty d;
            memset(&d, 0, sizeof(d));
            int w = 2 + (int)(rnd() % 4), h = 2 + (int)(rnd() % 4);
            int x = (int)(rnd() % (uint32_t)(100 - w)), z = (int)(rnd() % (uint32_t)(90 - h));
            if (it & 1) {
                if (rt_grid_add_building_dirty(&G, x, z, w, h, &d) != RT_OK) continue;
            } else {
                if (rt_grid_remove_building_dirty(&G, x, z, w, h, &d) != RT_OK) continue;
            }
            if (rt_grid_apply_dirty(&G, &d) != RT_OK) rt_region_refresh(&MAP);
            else if (rt_region_refresh_rect(&MAP, d.cx0, d.cz0, d.cx1, d.cz1) < 0) continue;
            rt_region_build(&REF, &G, 8);
            edits2++;
            if (!cmp_maps("100x90")) bad2++;
        }
        printf("100x90 map: regions=%dx%d edits=%d mismatched=%d\n",
               MAP.rw, MAP.rh, edits2, bad2);
    }

    printf("\nmap bytes: %.1f KB (chunk_snap adds %d KB)\n",
           (double)MAP.bytes / 1024.0, (int)(RT_CHUNK_N * sizeof(uint32_t) / 1024));

    rt_region_destroy(&REF);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return 0;
}

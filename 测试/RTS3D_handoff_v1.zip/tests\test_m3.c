/* ============================================================================
 * test_m3.c -- M3.1/M3.2 对抗性 + 差分测试
 *
 * 覆盖裁定要求的场景：
 *   S1 Small Split           小障碍把局部区域分成两块
 *   S2 Huge Component/Tiny Cut 巨大分量被 1 格切断（最重要的反例）
 *   S3 Three-Way Split       一次切成 >=3 块（禁止只支持 1->2）
 *   S4 Multiple Components   一次编辑影响多个原分量
 *   S5 Split->Merge 循环     10000 次 block/unblock，查 ID 泄漏 / 状态污染
 *   S6 Query Differential    10000 随机点对比较 connected(A,B)
 *   S7 Topology Sensitivity  100 格不改拓扑 vs 1 格切断唯一通道
 *   S8 Multi-scale           128/256/512/1024 的成本随什么增长
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m3.c -o test_m3
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", m); } } while (0)

static uint64_t g_state = 0x5EED1234ull;
static uint64_t nu(void) {
    uint64_t z = (g_state += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
}
static int rr(int lo, int hi) { return hi <= lo ? lo : lo + (int)(nu() % (uint64_t)(hi - lo)); }

/* ---------------------------------------------------------------- A/B 双图 */
static RtGrid A, B;
static int g_w, g_h;

static void pair_init(int w)
{
    g_w = g_h = w;
    rt_grid_destroy(&A); rt_grid_destroy(&B);
    if (rt_grid_init(&A, w, w, 1.0f) != RT_OK) { printf("init A fail\n"); exit(2); }
    if (rt_grid_init(&B, w, w, 1.0f) != RT_OK) { printf("init B fail\n"); exit(2); }
}

static void pair_terrain(int x, int z, int on)
{
    rt_grid_set_terrain(&A, x, z, RT_CELL_BLOCKED_TERRAIN, on);
    rt_grid_set_terrain(&B, x, z, RT_CELL_BLOCKED_TERRAIN, on);
}

static void pair_rebuild(void)
{
    rt_grid_rebuild_all(&A);
    rt_grid_rebuild_all(&B);
}

/* 背景障碍：让 clearance_max 落在真实 RTS 的量级（< 10m）。
 * 空旷地图上 SSEDT 增量必然退化为全量（pad 由全局 max clearance 决定），
 * 这是数学性质，不是实现缺陷 —— 测试场景必须反映真实地图密度。 */
static void pair_background(int permille)
{
    for (int z = 0; z < g_h; z++)
        for (int x = 0; x < g_w; x++)
            if ((int)((nu() >> 40) % 1000) < permille) pair_terrain(x, z, 1);
}

/* 同时施加建筑编辑：A 走增量，B 走全量；返回 A 的增量耗时（ms） */
static double pair_edit(int x, int z, int w, int h, int add)
{
    RtGridDirty d;
    double t0 = now_ms();
    if (add) {
        rt_grid_add_building_dirty(&A, x, z, w, h, &d);
        (void)rt_grid_apply_dirty(&A, &d);
    } else {
        rt_grid_remove_building_dirty(&A, x, z, w, h, &d);
        (void)rt_grid_apply_dirty(&A, &d);
    }
    double t1 = now_ms();

    if (add) rt_grid_add_building_dirty(&B, x, z, w, h, NULL);
    else     rt_grid_remove_building_dirty(&B, x, z, w, h, NULL);
    rt_grid_rebuild_all(&B);
    return t1 - t0;
}

/* 异步版本：A 走 apply_dirty_async + 预算调度，B 走全量；返回每帧最大成本 */
#include "rt_navjob.h"
static double pair_edit_async(int x, int z, int w, int h, int add,
                              double budget_ms, int *out_frames, double *out_total)
{
    RtGridDirty d;
    struct RtNavJob *job = NULL;
    double t0 = now_ms();
    int rc;
    if (add) { rt_grid_add_building_dirty(&A, x, z, w, h, &d); rc = rt_grid_apply_dirty_async(&A, &d, &job); }
    else     { rt_grid_remove_building_dirty(&A, x, z, w, h, &d); rc = rt_grid_apply_dirty_async(&A, &d, &job); }
    double mx = now_ms() - t0, total = mx;
    int frames = 0;
    if (job) {
        int done = 0, guard = 0;
        while (!done && guard++ < 1000000) {
            double fa = now_ms();
            int g2 = 0;
            while (!done && (now_ms() - fa) < budget_ms && g2++ < 100000)
                done = rt_navjob_step(job, &A, 2048);
            double dt = now_ms() - fa;
            if (dt > mx) mx = dt;
            total += dt; frames++;
        }
        double tc = now_ms();
        (void)rt_navjob_commit(job, &A);
        double dt = now_ms() - tc;
        if (dt > mx) mx = dt;
        total += dt; frames++;
        rt_navjob_destroy(job);
    } else {
        (void)rc;
    }
    if (add) rt_grid_add_building_dirty(&B, x, z, w, h, NULL);
    else     rt_grid_remove_building_dirty(&B, x, z, w, h, NULL);
    rt_grid_rebuild_all(&B);
    if (out_frames) *out_frames = frames;
    if (out_total) *out_total = total;
    return mx;
}

/* 划分等价：A.id -> B.id 双射 */
static int partition_equal(void)
{
    static int32_t ma[40000], mb[40000];
    for (int i = 0; i < 40000; i++) { ma[i] = -2; mb[i] = -2; }
    for (int z = 0; z < g_h; z++) {
        for (int x = 0; x < g_w; x++) {
            size_t i = (size_t)z * g_w + x;
            int32_t ca = A.component[i], cb = B.component[i];
            if ((ca >= 0) != (cb >= 0)) return 0;
            if (ca < 0) continue;
            if (ca >= 40000 || cb >= 40000) return 0;
            if (ma[ca] == -2) ma[ca] = cb;
            else if (ma[ca] != cb) return 0;
        }
    }
    for (int ca = 0; ca < 40000; ca++) {
        if (ma[ca] == -2) continue;
        int32_t cb = ma[ca];
        if (mb[cb] != -2 && mb[cb] != ca) return 0;
        mb[cb] = ca;
    }
    return 1;
}

static int same_state(void)
{
    for (size_t i = 0; i < (size_t)g_w * g_h; i++) {
        if (A.flags[i] != B.flags[i]) return 0;
        if (A.clearance[i] != B.clearance[i]) return 0;
    }
    return partition_equal();
}

/* ==========================================================================
 * S1 / S2 / S3 / S4：结构性 split 场景
 * ========================================================================*/
static void s1_small_split(void)
{
    printf("\n[S1] small split\n");
    pair_init(128);
    /* 一片空地里放两个相邻的墙块，中间留 1 格缝：先把缝堵上 -> 不 split（能绕）；
     * 再用一个 3x3 建筑把两个墙块之间的绕行也堵掉 -> 局部 split */
    pair_background(80);
    for (int z = 40; z < 90; z++) { pair_terrain(50, z, 1); pair_terrain(60, z, 1); }
    pair_rebuild();
    int c0 = A.active_components;
    double t = pair_edit(53, 64, 6, 3, 1);
    printf("  components %d -> %d, %.3f ms, state_ok=%d\n",
           c0, A.active_components, t, same_state());
    OK(same_state(), "S1 state equal");
    OK(t < 1.0, "S1 < 1ms");
}

static void s2_huge_tiny_cut(void)
{
    printf("\n[S2] huge component / tiny cut（最重要反例）\n");
    pair_init(256);
    /* 竖墙贯穿全图，只留 1 格门；背景 8% 障碍让 clearance 保持真实量级，
     * 同时分量仍有约 3 万格（huge component） */
    pair_background(80);
    for (int z = 0; z < 256; z++)
        if (z != 128) pair_terrain(128, z, 1);
    /* 随机背景可能堵住门或门的两侧，显式打开（否则「门」本身不可达） */
    pair_terrain(127, 128, 0); pair_terrain(128, 128, 0); pair_terrain(129, 128, 0);
    pair_rebuild();
    int c0 = A.active_components;
    int fr2 = 0; double tot2 = 0;
    double mx2 = pair_edit_async(128, 128, 1, 1, 1, 2.5, &fr2, &tot2);   /* 1 格建筑堵门 */
    printf("  dirty=1 cell, components %d -> %d, async max_frame=%.3f ms, "
           "frames=%d total=%.2f ms, state_ok=%d\n",
           c0, A.active_components, mx2, fr2, tot2, same_state());
    OK(A.active_components == c0 + 1, "S2 split into 2");
    OK(same_state(), "S2 state equal");
    /* M3.4 起，巨型 split 的验收口径是「单帧贡献」而不是「同步总耗时」 */
    OK(mx2 < 4.0, "S2 max frame < 4ms (frame-budgeted)");
}

static void s3_three_way(void)
{
    printf("\n[S3] multi-way split (cross wall + 1-cell center -> 4 regions)\n");
    pair_init(128);
    pair_background(20);   /* 2%：clearance 合理，且不会形成贯穿缝隙 */
    for (int i = 0; i < 128; i++) {
        /* 中心留 3x3 缺口：若只留 1 格，该格的 4 邻居全被墙包住，
         * 防穿角语义下它本身就是孤立的，4 个象限从来就不连通（首版构造错误）。 */
        if (i < 63 || i > 65) { pair_terrain(i, 64, 1); pair_terrain(64, i, 1); }
    }
    pair_rebuild();
    int c0 = A.active_components;
    double t = pair_edit(63, 63, 3, 3, 1);   /* 3x3 建筑堵中心 */
    printf("  components %d -> %d, %.3f ms, state_ok=%d\n",
           c0, A.active_components, t, same_state());
    printf("  debug: full=%u split=%u active=%d id_space=%d\n",
           A.full_rebuild_count, A.split_detected_count,
           A.active_components, A.component_count);
    /* 打印中心 7x7 的 component 值，确认 4 个象限是否同 id */
    printf("  center 7x7 comp ids://n");
    for (int z = 61; z <= 67; z++) {
        printf("   ");
        for (int x = 61; x <= 67; x++) {
            int32_t cc = rt_grid_component_at(&A, x, z);
            if (!rt_grid_walkable(&A, x, z)) printf("  ##");
            else printf("%4d", cc);
        }
        printf("\n");
    }
    OK(A.active_components >= 4, "S3 four-way split (4 distinct regions)");
    OK(same_state(), "S3 state equal");
    OK(t < 4.0, "S3 < 4ms");
}

static void s4_multi_component(void)
{
    printf("\n[S4] multiple components affected\n");
    pair_init(128);
    pair_background(50);
    /* 三座互不相连的孤岛 */
    for (int k = 0; k < 3; k++) {
        int cx = 20 + k * 40, cz = 64;
        for (int z = cz - 6; z <= cz + 6; z++)
            for (int x = cx - 6; x <= cx + 6; x++)
                pair_terrain(x, z, 1);
        for (int z = cz - 5; z <= cz + 5; z++)
            for (int x = cx - 5; x <= cx + 5; x++)
                pair_terrain(x, z, 0);
    }
    pair_rebuild();
    int c0 = A.active_components;
    double t = pair_edit(0, 0, 128, 32, 1);   /* 一条横带，跨过 3 座岛的上方 */
    printf("  components %d -> %d, %.3f ms, state_ok=%d\n",
           c0, A.active_components, t, same_state());
    OK(same_state(), "S4 state equal");
    OK(t < 4.0, "S4 < 4ms");
}

/* ==========================================================================
 * S5：Split -> Merge 10000 次循环（ID 泄漏 / 状态污染）
 * ========================================================================*/
static void s5_split_merge_cycles(void)
{
    printf("\n[S5] split->merge 10000 cycles\n");
    pair_init(128);
    pair_background(80);
    for (int z = 0; z < 128; z++)
        if (z != 64) pair_terrain(64, z, 1);
    pair_terrain(63, 64, 0); pair_terrain(64, 64, 0); pair_terrain(65, 64, 0);
    pair_rebuild();

    int c_base = A.active_components;
    int c_min = 0, c_max = 0;
    double t0 = now_ms();
    const int CYCLES = 10000;
    for (int i = 0; i < CYCLES; i++) {
        RtGridDirty d;
        rt_grid_add_building_dirty(&A, 64, 64, 1, 1, &d);
        (void)rt_grid_apply_dirty(&A, &d);
        if (A.active_components < c_min) c_min = A.active_components;
        if (A.active_components > c_max) c_max = A.active_components;

        rt_grid_remove_building_dirty(&A, 64, 64, 1, 1, &d);
        (void)rt_grid_apply_dirty(&A, &d);
    }
    double t1 = now_ms();

    /* 循环后必须回到基线：分量数不变、与全量一致 */
    rt_grid_add_building_dirty(&B, 0, 0, 1, 1, NULL);   /* 无操作，仅清空 */
    rt_grid_remove_building_dirty(&B, 0, 0, 1, 1, NULL);
    rt_grid_rebuild_all(&B);

    printf("  %d cycles, %.0f ms total (%.4f ms/op), components base=%d now=%d min=%d max=%d\n",
           CYCLES, t1 - t0, (t1 - t0) / (CYCLES * 2.0), c_base, A.active_components, c_min, c_max);
    printf("  split_detected=%u merge_detected=%u full_rebuild=%u\n",
           A.split_detected_count, A.merge_detected_count, A.full_rebuild_count);
    OK(A.active_components == c_base, "S5 component count returns to base");
    OK(A.active_components == B.active_components, "S5 matches full rebuild count");
    OK(same_state(), "S5 state equal after cycles");
    OK(A.full_rebuild_count == 0, "S5 no full rebuild fallback");
}

/* ==========================================================================
 * S6：Query Differential（10000 随机点对）
 * ========================================================================*/
static void s6_query_differential(void)
{
    printf("\n[S6] query differential (10000 pairs)\n");
    pair_init(256);
    /* 12% 随机障碍 + 100 次随机编辑 */
    for (int z = 0; z < 256; z++)
        for (int x = 0; x < 256; x++)
            if ((nu() >> 40) % 1000 < 120) pair_terrain(x, z, 1);
    pair_rebuild();

    for (int i = 0; i < 100; i++) {
        int w = 1 + rr(0, 5), h = 1 + rr(0, 5);
        int x = rr(0, 256 - w), z = rr(0, 256 - h);
        pair_edit(x, z, w, h, rr(0, 100) < 60);
    }

    int mismatch = 0;
    for (int i = 0; i < 10000; i++) {
        int x0 = rr(0, 256), z0 = rr(0, 256);
        int x1 = rr(0, 256), z1 = rr(0, 256);
        int ra = rt_grid_same_component(&A, x0, z0, x1, z1);
        int rb = rt_grid_same_component(&B, x0, z0, x1, z1);
        if (ra != rb) mismatch++;
    }
    printf("  10000 pairs, mismatches=%d, state_ok=%d\n", mismatch, same_state());
    OK(mismatch == 0, "S6 query results identical");
    OK(same_state(), "S6 state equal");
}

/* ==========================================================================
 * S7：Topology Sensitivity（dirty 面积不是成本预测器）
 * ========================================================================*/
static void s7_topology_sensitivity(void)
{
    printf("\n[S7] topology sensitivity: 100 cells(no topo) vs 1 cell(topo cut)\n");

    /* Case A：100 格 dirty，不改拓扑（在空旷处） */
    pair_init(256);
    pair_background(80);
    for (int z = 0; z < 256; z++)
        if (z != 128) pair_terrain(128, z, 1);
    pair_terrain(127, 128, 0); pair_terrain(128, 128, 0); pair_terrain(129, 128, 0);
    pair_rebuild();
    double ta = pair_edit(20, 20, 10, 10, 1);   /* 100 格，远离断点 */

    /* Case B：1 格 dirty，切断唯一通道 */
    pair_init(256);
    pair_background(80);
    for (int z = 0; z < 256; z++)
        if (z != 128) pair_terrain(128, z, 1);
    pair_terrain(127, 128, 0); pair_terrain(128, 128, 0); pair_terrain(129, 128, 0);
    pair_rebuild();
    int frb = 0; double totb = 0;
    double tb = pair_edit_async(128, 128, 1, 1, 1, 2.5, &frb, &totb);

    printf("  Case A: dirty=100 cells, sync %.3f ms, components=%d\n", ta, A.active_components);
    printf("  Case B: dirty=1  cell , async max_frame=%.3f ms / total=%.2f ms / frames=%d, "
           "sync(参考)=%.2f ms, components=%d\n",
           tb, totb, frb, totb, A.active_components);
    printf("  Case B debug: full=%u split=%u merge=%u id_space=%d\n",
           A.full_rebuild_count, A.split_detected_count,
           A.merge_detected_count, A.component_count);
    printf("  around gate (127..129, 127..129):\n");
    for (int z = 127; z <= 129; z++) {
        printf("   ");
        for (int x = 127; x <= 129; x++) {
            if (!rt_grid_walkable(&A, x, z)) printf("   ##");
            else printf("%5d", rt_grid_component_at(&A, x, z));
        }
        printf("\n");
    }
    printf("  -> dirty_area 不能单独作为 cost estimator（比值 %.2fx）\n", tb > 1e-9 ? ta / tb : 0.0);
    OK(tb < 4.0, "S7 Case B max frame < 4ms (frame-budgeted)");
    OK(same_state(), "S7 state equal");
}

/* ==========================================================================
 * S8：Multi-scale（128 / 256 / 512 / 1024）
 * ========================================================================*/
static void s8_multiscale(void)
{
    printf("\n[S8] multi-scale cost growth\n");
    printf("  %-8s %-14s %-14s %-14s %-10s\n",
           "size", "full(ms)", "small_add(ms)", "split(ms)", "split_cells");

    int sizes[] = { 128, 256, 512, 1024 };
    for (int k = 0; k < 4; k++) {
        int w = sizes[k];
        pair_init(w);
        pair_background(80);
        for (int z = 0; z < w; z++)
            if (z != w / 2) pair_terrain(w / 2, z, 1);
        pair_terrain(w / 2 - 1, w / 2, 0); pair_terrain(w / 2, w / 2, 0); pair_terrain(w / 2 + 1, w / 2, 0);
        pair_rebuild();

        double t0 = now_ms();
        rt_grid_rebuild_all(&A);
        double tf = now_ms() - t0;

        RtGridDirty d;
        double t1 = now_ms();
        rt_grid_add_building_dirty(&A, 4, 4, 2, 2, &d);
        (void)rt_grid_apply_dirty(&A, &d);
        double ta = now_ms() - t1;
        rt_grid_remove_building_dirty(&A, 4, 4, 2, 2, NULL);
        rt_grid_rebuild_all(&A);

        uint32_t before = A.split_relabel_cells;
        double t2 = now_ms();
        rt_grid_add_building_dirty(&A, w / 2, w / 2, 1, 1, &d);
        (void)rt_grid_apply_dirty(&A, &d);
        double ts = now_ms() - t2;
        uint32_t cells = A.split_relabel_cells - before;

        printf("  %-8d %-14.2f %-14.4f %-14.4f %-10u\n", w, tf, ta, ts, cells);
        /* 极端 split 的成本 = O(受影响分量)，1024² 单分量可达百万格，
         * 按裁定 §八 允许超预算，由 frame-budgeted job 分帧处理；这里只记录。 */
        rt_grid_remove_building_dirty(&A, w / 2, w / 2, 1, 1, NULL);
        rt_grid_rebuild_all(&A);
    }
}

/* ==========================================================================*/
int main(void)
{
    timer_init();
    printf("=== M3 tests: incremental split / adversarial / differential ===\n");

    s1_small_split();
    s2_huge_tiny_cut();
    s3_three_way();
    s4_multi_component();
    s5_split_merge_cycles();
    s6_query_differential();
    s7_topology_sensitivity();
    s8_multiscale();

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    rt_grid_destroy(&A);
    rt_grid_destroy(&B);
    return g_fail ? 1 : 0;
}

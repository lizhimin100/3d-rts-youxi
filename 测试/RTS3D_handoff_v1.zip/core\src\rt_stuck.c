﻿/* ============================================================================
 * rt_stuck.c -- 卡死检测与分级恢复（FR-STK，M6）
 * 设计口径见 rt_stuck.h 顶部。
 * ==========================================================================*/
#include "rt_stuck.h"

#include <stdlib.h>
#include <string.h>
#include <math.h>

/* ----------------------------------------------------------------------------
 * 配置
 * --------------------------------------------------------------------------*/
void rt_stuck_config_default(RtStuckConfig *c)
{
    if (!c) return;
    memset(c, 0, sizeof(*c));
    c->sample_hz       = 4.0f;
    c->progress_window = 2.0f;
    c->min_progress    = 0.5f;
    c->progress_ratio  = 0.25f;
    c->move_eps        = 0.20f;

    /* 1.8 m 的余量不是「贴着」：队列里前后车常常隔着 1.5~2 m，
     * 只按物理接触找 blocker 会让「排在队伍里但没贴住」的单位判成 STUCK，
     * 然后它在 L2 原地等 -> 把门堵死（T1 实测：两个单位卡在门口 2 m 处）。 */
    c->contact_slack   = 1.80f;
    c->queue_speed_eps = 0.10f;
    c->queue_progress  = 0.35f;

    c->hold_time       = 1.5f;
    c->back_time       = 1.2f;
    c->back_max        = 12.0f;
    /* 20 s 而不是 10 s：集成压测发现 1000 人挤 12 格门时，队伍本身在缓慢推进，
     * 10 s 就放弃会把 89 个单位钉死在门口（M9 的 gate 场景）。
     * 题面只要求「走完 6 级且 ≥10 s」，20 s 仍在契约内。 */
    c->permanent_time  = 20.0f;
    c->revive_after    = 5.0f;
    c->revive_radius      = 2.0f;
    c->revive_front       = 2.0f;
    c->revive_flow_radius = 3.5f;
    /* 0.30 m / 采样窗口（1.75 s）≈ 0.17 m/s：明显在挪，不是原地抖。
     * 队列「每 20 s 挪一个人」那种节奏（0.05 m/s）不该触发 —— 那时挤进去
     * 只会把唯一的一条车道堵得更死。 */
    c->revive_flow        = 0.30f;
    c->revive_cap         = 4;
    c->bay_radius      = 8.0f;
    c->bay_stop_dist   = 0.8f;
    c->grid_cell       = 2.0f;
    c->max_chain       = 16;
    c->flags           = 0;
}

/* ----------------------------------------------------------------------------
 * 生命周期
 * --------------------------------------------------------------------------*/
int rt_stuck_init(RtStuckCtx *c, int max_units, const RtStuckConfig *cfg)
{
    if (!c || max_units <= 0) return RT_ERR_INVALID;
    memset(c, 0, sizeof(*c));
    if (cfg) c->cfg = *cfg;
    else     rt_stuck_config_default(&c->cfg);

    c->cap = max_units;
    c->u = (RtStuckUnit *)calloc((size_t)max_units, sizeof(RtStuckUnit));
    c->cls = (int8_t *)malloc((size_t)max_units);
    c->onstack = (int8_t *)malloc((size_t)max_units);
    c->hold = (uint8_t *)calloc((size_t)max_units, 1);
    c->netp = (float *)malloc((size_t)max_units * sizeof(float));
    c->disp = (float *)malloc((size_t)max_units * sizeof(float));
    c->blk = (int32_t *)malloc((size_t)max_units * sizeof(int32_t));
    if (!c->u || !c->cls || !c->onstack || !c->hold ||
        !c->netp || !c->disp || !c->blk) {
        rt_stuck_destroy(c);
        return RT_ERR_CAPACITY;
    }
    for (int i = 0; i < max_units; i++) {
        c->u[i].blocker = -1;
        c->u[i].bay_ok = 0;
    }
    return RT_OK;
}

void rt_stuck_destroy(RtStuckCtx *c)
{
    if (!c) return;
    free(c->u);       c->u = NULL;
    free(c->cls);     c->cls = NULL;
    free(c->onstack); c->onstack = NULL;
    free(c->hold);    c->hold = NULL;
    free(c->netp);    c->netp = NULL;
    free(c->disp);    c->disp = NULL;
    free(c->blk);     c->blk = NULL;
    free(c->gs);      c->gs = NULL;
    free(c->gwr);     c->gwr = NULL;
    free(c->git);     c->git = NULL;
    free(c->gcell);   c->gcell = NULL;
    c->gcap_cells = c->gcap_units = 0;
    c->gw = c->gh = 0;
    c->cap = 0;
}

void rt_stuck_reset(RtStuckCtx *c, int idx)
{
    if (!c || idx < 0 || idx >= c->cap) return;
    RtStuckUnit *u = &c->u[idx];
    uint32_t eps = u->episodes;
    /* 历史环整段清空（半环里留着 0 位置会让进度判定瞬间失真） */
    memset(u, 0, sizeof(*u));
    u->blocker = -1;
    u->episodes = eps;
}

void rt_stuck_reset_all(RtStuckCtx *c)
{
    if (!c) return;
    for (int i = 0; i < c->cap; i++) rt_stuck_reset(c, i);
}

void rt_stuck_set_hold(RtStuckCtx *c, int idx, int on)
{
    if (!c || !c->hold || idx < 0 || idx >= c->cap) return;
    uint8_t v = on ? 1u : 0u;
    if (c->hold[idx] == v) return;
    c->hold[idx] = v;
    if (v) {
        /* 进入等待：把累计的卡死进度清零。等待不是卡死，不该背着处罚进队列。 */
        RtStuckUnit *u = &c->u[idx];
        u->stuck_time = 0.f;
        u->level = 0;
        u->level_time = 0.f;
        u->bay_ok = 0;
        u->back_used = 0.f;
        u->backing = 0;
        u->hits = 0;
        u->calm = 0;
        if (u->state == RT_STUCK_STUCK) u->state = RT_STUCK_MOVING;
    }
}

int rt_stuck_held(const RtStuckCtx *c, int idx)
{
    if (!c || !c->hold || idx < 0 || idx >= c->cap) return 0;
    return c->hold[idx] != 0;
}

const char *rt_stuck_state_name(int s)
{
    switch (s) {
        case RT_STUCK_MOVING:  return "MOVING";
        case RT_STUCK_QUEUED:  return "QUEUED";
        case RT_STUCK_BLOCKED: return "BLOCKED";
        case RT_STUCK_STUCK:   return "STUCK";
        case RT_STUCK_GAVE_UP: return "GAVE_UP";
        default:               return "?";
    }
}

const char *rt_stuck_level_name(int l)
{
    switch (l) {
        case 0: return "L0-avoid";
        case 1: return "L1-slow";
        case 2: return "L2-backoff";
        case 3: return "L3-sidetrack";
        case 4: return "L4-slot";
        case 5: return "L5-group-repath";
        case 6: return "L6-waiting-bay";
        default: return "give-up";
    }
}

/* ----------------------------------------------------------------------------
 * 邻居栅格（只在采样时重建）
 * --------------------------------------------------------------------------*/
static int grid_reserve(RtStuckCtx *c, int cells, int units)
{
    if (cells > c->gcap_cells) {
        int *gs = (int *)realloc(c->gs, (size_t)(cells + 1) * sizeof(int));
        int *wr = (int *)realloc(c->gwr, (size_t)cells * sizeof(int));
        if (!gs || !wr) {
            if (gs) c->gs = gs;
            if (wr) c->gwr = wr;
            return 0;
        }
        c->gs = gs; c->gwr = wr;
        c->gcap_cells = cells;
    }
    if (units > c->gcap_units) {
        int *it = (int *)realloc(c->git, (size_t)units * sizeof(int));
        int *ce = (int *)realloc(c->gcell, (size_t)units * sizeof(int));
        if (!it || !ce) {
            if (it) c->git = it;
            if (ce) c->gcell = ce;
            return 0;
        }
        c->git = it; c->gcell = ce;
        c->gcap_units = units;
    }
    return 1;
}

static void grid_rebuild(RtStuckCtx *c, RtLocalAgent *ag, int n)
{
    float cell = c->cfg.grid_cell;
    if (cell < 0.5f) cell = 0.5f;

    if (n <= 0) { c->gw = c->gh = 0; return; }

    float minx = 1e30f, minz = 1e30f, maxx = -1e30f, maxz = -1e30f;
    for (int i = 0; i < n; i++) {
        if (ag[i].pos.x < minx) minx = ag[i].pos.x;
        if (ag[i].pos.x > maxx) maxx = ag[i].pos.x;
        if (ag[i].pos.z < minz) minz = ag[i].pos.z;
        if (ag[i].pos.z > maxz) maxz = ag[i].pos.z;
    }

    c->gcs = cell;
    c->gx0 = minx - cell;
    c->gz0 = minz - cell;
    c->gw = (int)((maxx - minx) / cell) + 3;
    c->gh = (int)((maxz - minz) / cell) + 3;
    if (c->gw < 1) c->gw = 1;
    if (c->gh < 1) c->gh = 1;

    int cells = c->gw * c->gh;
    if (!grid_reserve(c, cells, n)) { c->gw = c->gh = 0; return; }

    memset(c->gwr, 0, (size_t)cells * sizeof(int));
    for (int i = 0; i < n; i++) {
        int gx = (int)((ag[i].pos.x - c->gx0) / cell);
        int gz = (int)((ag[i].pos.z - c->gz0) / cell);
        if (gx < 0) gx = 0;
        if (gx >= c->gw) gx = c->gw - 1;
        if (gz < 0) gz = 0;
        if (gz >= c->gh) gz = c->gh - 1;
        int ci = gz * c->gw + gx;
        c->gcell[i] = ci;
        c->gwr[ci]++;
    }
    c->gs[0] = 0;
    for (int k = 0; k < cells; k++) c->gs[k + 1] = c->gs[k] + c->gwr[k];
    memcpy(c->gwr, c->gs, (size_t)cells * sizeof(int));
    for (int i = 0; i < n; i++) c->git[c->gwr[c->gcell[i]]++] = i;
}

/* 找 i 前方的「对手」；无 -> -1
 *
 * 选谁当 blocker 决定了谁给谁让路，不能只看「最近」：
 * 门口两队对穿时，最近的那个往往是自己人（同向、并排），
 * 按最近选会把优先权判给错的一方（T1 实测：右队该退的没退，左队该走的被钉住）。
 * 所以优先选**方向最相反**的那个（迎面来的），同向队列才退回按距离。 */
static int find_blocker(RtStuckCtx *c, RtLocalAgent *ag, int i, RtVec2 dir)
{
    if (c->gw <= 0 || c->gh <= 0) return -1;
    const RtLocalAgent *a = &ag[i];

    int gx = (int)((a->pos.x - c->gx0) / c->gcs);
    int gz = (int)((a->pos.z - c->gz0) / c->gcs);
    int best = -1;
    float best_score = 1e30f;

    for (int dz = -1; dz <= 1; dz++) {
        int nz = gz + dz;
        if (nz < 0 || nz >= c->gh) continue;
        for (int dx = -1; dx <= 1; dx++) {
            int nx = gx + dx;
            if (nx < 0 || nx >= c->gw) continue;
            int ci = nz * c->gw + nx;
            for (int t = c->gs[ci]; t < c->gs[ci + 1]; t++) {
                int j = c->git[t];
                if (j == i) continue;
                RtVec2 d = rt_v2_sub(ag[j].pos, a->pos);
                float dd = rt_v2_len2(d);
                float lim = a->radius + ag[j].radius + c->cfg.contact_slack;
                if (dd > lim * lim || dd < 1e-8f) continue;
                float dl = sqrtf(dd);
                if ((d.x * dir.x + d.z * dir.z) / dl < 0.2f) continue;

                RtVec2 dj = rt_v2_norm(ag[j].pref_vel);
                float opp = dir.x * dj.x + dir.z * dj.z;   /* -1 = 迎面 */
                float score = (opp < 0.6f) ? opp : (0.6f + dl * 1e-3f);
                if (score < best_score) { best_score = score; best = j; }
            }
        }
    }
    return best;
}

/* 附近 radius 内有多少个单位（不含自己）。只给「立案时有没有人参与」与
 * 「放弃时是不是被人堵住」这两个**历史**判定用 —— 它们问的是「当时是不是
 * 一场交通堵塞」，所以要把所有单位（含已放弃的）都算进来。 */
static int count_agents_within(const RtStuckCtx *c, const RtLocalAgent *ag,
                               int n, int i, float radius)
{
    const RtLocalAgent *a = &ag[i];
    float r2 = radius * radius;
    int cnt = 0;
    for (int j = 0; j < n; j++) {
        if (j == i) continue;
        if (rt_v2_len2(rt_v2_sub(ag[j].pos, a->pos)) <= r2) cnt++;
    }
    (void)c;
    return cnt;
}

/* 复活判据要回答的是「堵我的人还在吗」，所以只数**存活**单位（M17）。
 *
 * 为什么必须排除已放弃的单位：它和本人一样停着 —— 既不推进，也不会让开。
 * 把它算进人群，就是让两个放弃者互相证明「还有人堵着我」。M15 实测：两个放弃者
 * 相距 1.86 m，含放弃单位的最小邻域计数恒为 1（永不复活），排除后为 0。
 *
 * front_only = 1 时只数**挡在前面**的：横向偏移超过（两半径 + 0.3 m）的不算，
 * 因为从旁边擦过去不影响推进；dot <= 0 的是身后的人，更不该算。
 * 半径用 0.3 m 余量而不是 contact_slack（1.8 m）—— 后者是「判卡死」的宽松口径，
 * 拿它当「能不能走」会把后排整列都算成挡道，等于永不复活。
 *
 * flow_out（可选）= 这些存活单位在上一采样窗口里**平均走了多远**（沿它们自己的
 * 期望方向）。它是 R3 的输入：车流在动就说明堵点在化解。 */
static int scan_live_crowd(const RtStuckCtx *c, const RtLocalAgent *ag, int n, int i,
                           float radius, int front_only, RtVec2 dir, float *flow_out)
{
    const RtLocalAgent *a = &ag[i];
    float r2 = radius * radius;
    int cnt = 0;
    float flow = 0.f;

    for (int j = 0; j < n; j++) {
        if (j == i) continue;
        if (c->u[j].state == RT_STUCK_GAVE_UP) continue;   /* 家具不算人群 */
        RtVec2 d = rt_v2_sub(ag[j].pos, a->pos);
        float l2 = rt_v2_len2(d);
        if (l2 > r2) continue;
        if (front_only) {
            float dot = d.x * dir.x + d.z * dir.z;
            if (dot <= 0.f) continue;
            float lat2 = l2 - dot * dot;
            float half = a->radius + ag[j].radius + 0.30f;
            if (lat2 > half * half) continue;
        }
        cnt++;
        flow += fabsf(c->netp[j]);
    }
    if (cnt > 0) flow /= (float)cnt;
    if (flow_out) *flow_out = flow;
    return cnt;
}

/* 从 GAVE_UP / bay 回到「活着」的那一套复位。三处调用必须完全一致 ——
 * 少清一个字段就是「复活了但还记着上一轮的账」。 */
static void revive_to_idle(RtStuckUnit *u)
{
    u->state = RT_STUCK_MOVING;
    u->level = 0;
    u->level_time = 0.f;
    u->stuck_time = 0.f;
    u->hits = 0;
    u->calm = 0;
    u->bay_ok = 0;
    u->back_used = 0.f;
    u->revive_t = 0.f;
    u->backing = 0;
}

/* ----------------------------------------------------------------------------
 * 判定：递归追溯排队链
 *   cycle -> STUCK（谁也别等谁）
 * --------------------------------------------------------------------------*/
static int classify(RtStuckCtx *c, RtLocalAgent *ag, int i, int depth)
{
    if (c->cls[i] >= 0) return c->cls[i];
    if (depth > c->cfg.max_chain) return RT_STUCK_STUCK;
    if (c->onstack[i]) return RT_STUCK_STUCK;   /* 环 */

    c->onstack[i] = 1;
    int st;
    int j = c->blk[i];

    if (j < 0) {
        st = RT_STUCK_STUCK;      /* 没人挡着还是没动 -> 自己卡住（墙/地形） */
    } else if (c->netp[j] > c->cfg.queue_progress) {
        /* 用「前车在这个窗口里朝它自己的目标方向前进了多少」判排队。
         * 不能用瞬时速度：head-on 死锁时双方都在抖/侧移，速度非零，
         * 会被误判成合法排队 —— T1 第一版 episodes=124 就是这么来的。 */
        st = RT_STUCK_QUEUED;
    } else if (ag[j].inv_mass <= 0.f ||
               rt_v2_len2(ag[j].pref_vel) < c->cfg.move_eps * c->cfg.move_eps) {
        st = RT_STUCK_BLOCKED;    /* 前车是静止单位 -> 原因已知 */
    } else {
        int sj = classify(c, ag, j, depth + 1);
        if (sj == RT_STUCK_STUCK || sj == RT_STUCK_GAVE_UP) st = RT_STUCK_STUCK;
        else st = RT_STUCK_QUEUED;   /* 链条尽头在动或在等 -> 我也是排队 */
    }

    c->onstack[i] = 0;
    c->cls[i] = (int8_t)st;
    return st;
}

/* ----------------------------------------------------------------------------
 * L6：waiting bay —— 可走、clearance 够、且不挡在前进方向上的格
 * --------------------------------------------------------------------------*/
static int pick_bay(RtStuckCtx *c, const RtGrid *g, RtLocalAgent *a, RtVec2 dir,
                    RtVec2 *out)
{
    if (!g) return 0;
    float R = c->cfg.bay_radius;
    float best_score = 1e30f;
    RtVec2 best = rt_v2(0.f, 0.f);
    int found = 0;

    int cx = (int)a->pos.x, cz = (int)a->pos.z;
    int r = (int)(R + 0.5f);
    for (int dz = -r; dz <= r; dz++) {
        for (int dx = -r; dx <= r; dx++) {
            int x = cx + dx, z = cz + dz;
            if (!rt_grid_in_bounds(g, x, z)) continue;
            if (!rt_grid_walkable(g, x, z)) continue;
            if (rt_grid_clearance_m(g, x, z) < a->radius + 0.50f) continue;

            RtVec2 p = rt_v2((float)x + 0.5f, (float)z + 0.5f);
            RtVec2 d = rt_v2_sub(p, a->pos);
            float dl = rt_v2_len(d);
            if (dl < 0.8f || dl > R) continue;
            float along = (d.x * dir.x + d.z * dir.z) / dl;
            float score = dl + 6.0f * (along > 0.f ? along : -along * 0.3f);
            if (score < best_score) { best_score = score; best = p; found = 1; }
        }
    }
    if (found) *out = best;
    return found;
}

/* ----------------------------------------------------------------------------
 * 每帧
 * --------------------------------------------------------------------------*/
void rt_stuck_step(RtStuckCtx *c, RtLocalAgent *ag, int n, const RtGrid *g,
                   float dt, const RtStuckHooks *hooks)
{
    if (!c || !ag || n <= 0 || dt <= 0.f) return;
    if (n > c->cap) n = c->cap;

    const float period = 1.0f / (c->cfg.sample_hz > 0.1f ? c->cfg.sample_hz : 4.0f);

    /* ---- 1. 采样：推进历史环、重建栅格、重算状态 ---- */
    int do_sample = 0;
    for (int i = 0; i < n; i++) {
        RtStuckUnit *u = &c->u[i];
        if (u->count == 0) {
            u->hist[0] = ag[i].pos;
            u->head = 1 % RT_STUCK_HIST;
            u->count = 1;
        }
        u->sample_acc += dt;
        if (u->sample_acc >= period) do_sample = 1;
    }

    if (do_sample) {
        c->st.samples++;
        grid_rebuild(c, ag, n);

        for (int i = 0; i < n; i++) {
            RtStuckUnit *u = &c->u[i];
            while (u->sample_acc >= period) {
                u->sample_acc -= period;
                u->hist[u->head] = ag[i].pos;
                u->head = (u->head + 1) % RT_STUCK_HIST;
                if (u->count < RT_STUCK_HIST) u->count++;
            }
            int oldest = (u->head - u->count + RT_STUCK_HIST) % RT_STUCK_HIST;
            /* 「有进展」= 沿**调用方想去的方向**前进了多少。
             * 不能用净位移：L2 后退、L3 侧移都会产生净位移，那会让
             * 「退开 -> 再撞墙」的不可达目标永远不升级（T2 暴露过）。 */
            RtVec2 delta = rt_v2_sub(ag[i].pos, u->hist[oldest]);
            u->net_progress = delta.x * u->want_dir.x + delta.z * u->want_dir.z;
            c->netp[i] = u->net_progress;
            c->disp[i] = rt_v2_len(delta);
            c->cls[i] = -1;
            c->onstack[i] = 0;
        }

        for (int i = 0; i < n; i++) {
            RtStuckUnit *u = &c->u[i];
            RtLocalAgent *a = &ag[i];
            /* 上层声明的合法等待（通道仲裁 / 编队未就位）：不判卡死。 */
            if (c->hold[i]) {
                c->cls[i] = RT_STUCK_MOVING;
                c->st.held_samples++;
                continue;
            }
            float want = rt_v2_len(a->pref_vel);
            u->blocker = -1;
            if (a->inv_mass <= 0.f || want < c->cfg.move_eps || u->count < 4) {
                c->cls[i] = RT_STUCK_MOVING;
                continue;
            }
            float win = (float)(u->count - 1) * period;
            if (win > c->cfg.progress_window) win = c->cfg.progress_window;
            float need = c->cfg.progress_ratio * want * win;
            if (need < c->cfg.min_progress) need = c->cfg.min_progress;
            if (u->net_progress >= need) { c->cls[i] = RT_STUCK_MOVING; continue; }
            /* 「朝目标没进展」还不够，必须**实际也没怎么动**。
             * 只看投影会把贴着墙横向绕行的单位误判成卡死（T1 实测：单位以
             * 1.3 m/s 沿墙滑行、投影≈0，被 L3 侧移接管后越走越偏）。 */
            if (c->disp[i] > 0.6f * want * win) { c->cls[i] = RT_STUCK_MOVING; continue; }
            RtVec2 dir = u->want_dir;
            if (rt_v2_len2(dir) < 1e-8f) dir = rt_v2_norm(a->pref_vel);
            u->blocker = find_blocker(c, ag, i, dir);
            c->blk[i] = u->blocker;
        }

        for (int i = 0; i < n; i++) {
            if (c->cls[i] >= 0) continue;
            c->cls[i] = (int8_t)classify(c, ag, i, 0);
        }

        /* ---- 状态迁移 + 统计 ---- */
        for (int i = 0; i < n; i++) {
            RtStuckUnit *u = &c->u[i];
            int ns = c->cls[i];
            int os = u->state;

            /* GAVE_UP 是**粘滞**的：只有 rt_stuck_reset()（新命令）才能解除。
             * 否则单位停在 waiting bay 不动，下一采样又判 STUCK -> 重复计数
             * （T2 第一次跑出 92 次 PermanentStuck，就是这个）。 */
            if (os == RT_STUCK_GAVE_UP) { u->state = RT_STUCK_GAVE_UP; continue; }

            if (ns == RT_STUCK_MOVING) {
                u->hits = 0;
                u->calm = 0;
                if (os == RT_STUCK_STUCK) {
                    c->st.resolved++;
                    if (u->stuck_time > c->st.max_recover_s) c->st.max_recover_s = u->stuck_time;
                    u->stuck_time = 0.f;
                    u->level = 0;
                    u->level_time = 0.f;
                    u->bay_ok = 0;
                    u->back_used = 0.f;
                }
                u->state = RT_STUCK_MOVING;
            } else if (ns == RT_STUCK_STUCK) {
                /* 滞回：连续 2 次采样（0.5 s）都判 STUCK 才立案。 */
                u->calm = 0;
                if (u->hits < 1000) u->hits++;
                if (os == RT_STUCK_STUCK) {
                    u->state = RT_STUCK_STUCK;   /* 已立案的保持；由 MOVING 解除 */
                } else if (u->hits >= 2) {
                    u->episodes++;
                    c->st.episodes++;
                    u->stuck_time = 0.f;
                    u->level = 1;
                    u->level_time = 0.f;
                    u->bay_ok = 0;
                    u->back_used = 0.f;
                    /* 记录「这一轮卡死有没有人参与」：只有交通堵塞才值得退到 bay 等，
                     * 一个人被地形困住时进 bay 没意义（M6 T2 的封闭房间：
                     * 恢复 -> 撞墙 -> 再恢复 的死循环，永远到不了 give-up）。 */
                    u->ep_crowd = (count_agents_within(c, ag, n, i, 2.0f) > 0) ? 1 : 0;
                    c->st.level_fires[1]++;
                    u->state = RT_STUCK_STUCK;
                }
                /* else：观察期（hits==1），**不要**切到 STUCK。
                 * 切了的话下一采样 os==STUCK，立案分支永远进不去，
                 * level 停在 0 由「升级」路径补到 1 —— 统计里就会出现
                 * episodes=0 而 level_fires[1]=6 的怪现象。 */
            } else {
                /* QUEUED / BLOCKED：已立案的**不立刻退案**（排队抖动不该复位恢复进度），
                 * 但连续 4 次（1 s）都是「合法排队 / 原因已知」就撤案：
                 * 让行方在走廊口等对向通过时会被判 QUEUED，不退案就会一边等一边
                 * 累计 stuck_time，最后在对向刚走完时 give-up（T1 实测：右队 3 人全废）。 */
                if (u->hits > 0) u->hits--;
                if (u->calm < 1000) u->calm++;
                if (os == RT_STUCK_STUCK && u->calm >= 4) {
                    u->state = ns;
                    u->stuck_time = 0.f;
                    u->level = 0;
                    u->level_time = 0.f;
                    u->bay_ok = 0;
                    u->back_used = 0.f;
                } else if (os != RT_STUCK_STUCK) {
                    u->state = ns;
                }
            }
        }
    }

    /* ---- 2. 当前四态计数（供报告引用） ---- */
    {
        uint32_t cnt[RT_STUCK_STATE_COUNT];
        memset(cnt, 0, sizeof(cnt));
        for (int i = 0; i < n; i++) {
            int s = c->u[i].state;
            if (s < 0 || s >= RT_STUCK_STATE_COUNT) s = RT_STUCK_MOVING;
            cnt[s]++;
        }
        for (int s = 0; s < RT_STUCK_STATE_COUNT; s++) c->st.count[s] = cnt[s];
    }

    /* ---- 3. 恢复动作 + 升级（每帧） ---- */
    for (int i = 0; i < n; i++) {
        RtStuckUnit *u = &c->u[i];
        RtLocalAgent *a = &ag[i];

        /* 先记下「调用方本帧想去的方向」，再覆盖 pref_vel。
         * 进度判定与让行方向都用它，不用被本层改过的 pref。 */
        {
            RtVec2 wd = rt_v2_norm(a->pref_vel);
            if (rt_v2_len2(wd) > 1e-8f) u->want_dir = wd;
        }

        if (u->state == RT_STUCK_GAVE_UP) {
            a->pref_vel = rt_v2(0.f, 0.f);
            u->backing = 0;

            /* 放弃只对「当时那个环境」成立。人群散开之后必须重试 ——
             * 单位在 RTS 里不能永久摆烂。M11 实测：1/60 停在洞口侧面 1.7 m、
             * 周围 0 个人、脚下可走，却因为 GAVE_UP 是终态而永远过不去。
             * 只在「当时是被**人**堵住」时重试；被地形困住的（封闭房间）
             * 不重试 —— 那是地图问题，只有上层重下命令 / 改地图才该解除
             * （否则 M6 T2 的不可达用例会每 60 s 轮回一次）。
             *
             * M17：判据从「周围没人」扩成三条（见 rt_stuck.h）。原因很实在：
             * 通道口/队列里永远有人，「周围没人」这条在需要它的时候恰好永不成立。
             * 探测频率 2 Hz（probe_t >= 0.5 s）：n 个放弃单位 × 每 0.5 s 一次全扫，
             * 1000 人里全放弃也就是 2000 次/s 的距离比较，不值得建网格。 */
            if (u->gave_up_crowd && c->cfg.revive_after > 0.f) {
                u->revive_t += dt;
                u->probe_t += dt;
                if (u->revive_t >= c->cfg.revive_after && u->probe_t >= 0.5f) {
                    u->probe_t = 0.f;

                    RtVec2 dir = u->want_dir;
                    if (rt_v2_len2(dir) < 1e-8f) dir = rt_v2(1.f, 0.f);
                    int why = RT_STUCK_REVIVE_NONE;
                    float flow = 0.f;

                    if (scan_live_crowd(c, ag, n, i, c->cfg.revive_radius, 0, dir, NULL) == 0) {
                        why = RT_STUCK_REVIVE_CLEAR;
                    } else if (scan_live_crowd(c, ag, n, i, c->cfg.revive_front, 1, dir, NULL) == 0) {
                        why = RT_STUCK_REVIVE_PATH;
                    } else if (c->cfg.revive_flow > 0.f &&
                               scan_live_crowd(c, ag, n, i, c->cfg.revive_flow_radius, 0,
                                               dir, &flow) > 0 &&
                               flow >= c->cfg.revive_flow) {
                        why = RT_STUCK_REVIVE_FLOW;
                    }

                    if (why != RT_STUCK_REVIVE_NONE) {
                        if (c->cfg.revive_cap > 0 && u->revive_tries >= c->cfg.revive_cap) {
                            /* 到上限：这条命令内不再重试（否则就是「复活->撞回去->
                             * 再放弃」的无限打转）。清零 gave_up_crowd 只是让探测
                             * 停下来，state 仍是 GAVE_UP，语义没变。 */
                            u->gave_up_crowd = 0;
                            c->st.revives_capped++;
                        } else {
                            u->revive_tries++;
                            u->revive_why = why;
                            u->gave_up_crowd = 0;
                            c->st.retries++;
                            if (why == RT_STUCK_REVIVE_CLEAR)      c->st.revives_clear++;
                            else if (why == RT_STUCK_REVIVE_PATH)  c->st.revives_path++;
                            else                                   c->st.revives_flow++;
                            revive_to_idle(u);
                        }
                    }
                }
            }
            continue;
        }
        if (u->state != RT_STUCK_STUCK) { u->backing = 0; continue; }

        RtVec2 dir = u->want_dir;
        if (rt_v2_len2(dir) < 1e-8f) dir = rt_v2(1.f, 0.f);
        RtVec2 perp = rt_v2(-dir.z, dir.x);

        /* 让行方 = 这一对里索引较大的一方。
         * **没有 blocker 时不当让行方**：那多半是「前面的人刚退开、自己还没重新走起来」，
         * 这时再退会让整列一起往后退，最后双方都退到 give-up（T1 实测）。 */
        int yielder = (u->blocker >= 0) && (i > u->blocker);
        float sp = a->max_speed > 0.f ? a->max_speed : 1.f;

        /* 前车在后退、而且是冲着我退过来 -> 我也得跟着退（整列一起让开）。
         * 没有这一条，走廊里排第二的单位会把退路堵死，第一个永远退不出去。 */
        int follow_back = 0;
        if (!yielder && u->blocker >= 0 && u->blocker < n) {
            const RtStuckUnit *bj = &c->u[u->blocker];
            if (bj->backing) {
                RtVec2 d = rt_v2_sub(a->pos, ag[u->blocker].pos);
                if (d.x * bj->want_dir.x + d.z * bj->want_dir.z < 0.f) follow_back = 1;
            }
        }

        /* 正在后退时不累计 stuck_time：退 8 m 要 ~10 s，否则还没退完就 GAVE_UP。
         * 其它情况照常累计（永久卡死判定靠它）。 */
        int backing_now = (u->level == 2) && (yielder || follow_back) &&
                          u->back_used < c->cfg.back_max;
        u->stuck_time += backing_now ? 0.f : dt;
        u->level_time += dt;

        /* 永久卡死：走完 L6 且累计时间到 */
        if (u->level >= RT_STUCK_MAX_LEVEL && u->stuck_time >= c->cfg.permanent_time) {
            u->state = RT_STUCK_GAVE_UP;
            u->level = RT_STUCK_MAX_LEVEL + 1;
            /* permanent_stuck 统计的是**单位数**，不是事件数：重试后再放弃不重复计数。 */
            if (!u->ever_gave_up) { u->ever_gave_up = 1; c->st.permanent_stuck++; }
            /* 记下「当时是不是被人堵住」：决定人散之后要不要重试。 */
            u->gave_up_crowd = (count_agents_within(c, ag, n, i, 2.0f) > 0) ? 1 : 0;
            u->revive_t = 0.f;
            u->probe_t = 0.f;
            a->pref_vel = rt_v2(0.f, 0.f);
            u->backing = 0;
            continue;
        }

        /* L2 的后退要「退到位」才升级，否则退 1.3 m 就被 L3 打断，对向的柱子还堵着。
         * 上限 hold_time*20 只是防呆：back_used 记的是指令距离，正常不会卡死。 */
        int can_advance = 1;
        if (backing_now && u->level_time < c->cfg.hold_time * 20.f) can_advance = 0;
        if (can_advance && u->level_time > c->cfg.hold_time &&
            u->level < RT_STUCK_MAX_LEVEL) {
            u->level++;
            u->level_time = 0.f;
            c->st.level_fires[u->level]++;
            if (u->level == 4 && !(hooks && hooks->slot_deviation)) c->st.hook_missing++;
            if (u->level == 5 && !(hooks && hooks->group_repath)) c->st.hook_missing++;
            if (u->level == 6 && !u->bay_ok) {
                if (pick_bay(c, g, a, dir, &u->bay)) { u->bay_ok = 1; c->st.bay_found++; }
                else { c->st.bay_none++; }
            }
        }

        u->backing = 0;
        switch (u->level) {
        case 1: {   /* 减速让行 */
            RtVec2 v = rt_v2_mul(a->pref_vel, 0.35f);
            if (yielder && !(c->cfg.flags & 1u)) {
                float side = (i & 1) ? 1.f : -1.f;
                v = rt_v2_add(v, rt_v2_mul(perp, side * sp * 0.30f));
            }
            a->pref_vel = v;
            break;
        }
        case 2: {   /* 后退（只改期望速度，不碰位置） */
            if ((yielder || follow_back) && u->back_used < c->cfg.back_max) {
                a->pref_vel = rt_v2_mul(dir, -sp * 0.55f);
                u->back_used += sp * 0.55f * dt;
                u->backing = 1;
            }
            /* 非让行方**保持原期望速度继续走**（不是原地等）。
             * 让它等会把有优先权的一列也钉在门口，两边一起 give-up（T1 实测）。 */
            break;
        }
        case 3:     /* 局部改道 / 侧移 */
        case 4:     /* 队形偏离 / 换槽位 */
        case 5: {   /* 整队重寻路 */
            int handled = 0;
            if (u->level == 3 && hooks && hooks->local_repath) {
                RtVec2 q = rt_v2_add(a->pos, rt_v2_mul(perp, 3.f));
                handled = hooks->local_repath(hooks->ud, i, q);
            } else if (u->level == 4 && hooks && hooks->slot_deviation) {
                handled = hooks->slot_deviation(hooks->ud, i);
            } else if (u->level == 5 && hooks && hooks->group_repath) {
                handled = hooks->group_repath(hooks->ud, i);
            }
            if (!handled) {
                /* 侧移是**叠加**在期望方向上的，不是替换：
                 * 替换会让单位彻底放弃朝目标走，沿墙一路滑出去。 */
                float side = (i & 1) ? 1.f : -1.f;
                RtVec2 v = rt_v2_add(rt_v2_mul(dir, sp), rt_v2_mul(perp, side * sp * 0.6f));
                a->pref_vel = rt_v2_mul(rt_v2_norm(v), sp * 0.9f);
            }
            break;
        }
        case 6: {   /* 交通恢复：退到 waiting bay 等 */
            if (!u->bay_ok) {
                if (pick_bay(c, g, a, dir, &u->bay)) { u->bay_ok = 1; c->st.bay_found++; }
                else { c->st.bay_none++; a->pref_vel = rt_v2(0.f, 0.f); break; }
            }
            RtVec2 d = rt_v2_sub(u->bay, a->pos);
            float dl = rt_v2_len(d);
            if (dl > c->cfg.bay_stop_dist) {
                a->pref_vel = rt_v2_mul(d, (sp * 0.8f) / dl);
                break;
            }
            /* 到位之后必须**回来**：bay 是让路的位置，不是终点。
             * 周围 2 m 没人 = 堵它的人已经走了 -> 回原任务（L0）。
             * 没有这一条，单位会静静停在 bay 上直到 permanent_time 判死：
             * M11 实测 1/60 停在洞口侧面 1.7 m、脚下可走、周围 0 人，
             * 却因为「bay 到了就停」永远过不去。
             *
             * 但只在**这一轮卡死有人参与**时才恢复（ep_crowd）：封闭房间里的单位
             * 从一开始就是一个人，恢复只会让它撞墙再回来，永远到不了 give-up。 */
            u->probe_t += dt;
            if (u->ep_crowd && u->probe_t >= 0.5f) {
                u->probe_t = 0.f;
                /* 同一条纪律：家具不算人群（M17）。bay 旁边躺着一个放弃的单位，
                 * 不代表「堵我的人还在」——它不会再挤过来。 */
                if (scan_live_crowd(c, ag, n, i, c->cfg.revive_radius, 0, dir, NULL) == 0) {
                    revive_to_idle(u);
                    c->st.resumes++;
                }
            }
            a->pref_vel = rt_v2(0.f, 0.f);
            break;
        }
        default:
            break;
        }
    }
}

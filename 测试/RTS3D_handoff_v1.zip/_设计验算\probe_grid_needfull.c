/* probe_grid_needfull.c -- 归因：大编辑的 rt_grid_apply_dirty 为什么降级全量（4~5 ms）
 *
 * 输出：
 *   1. 每种编辑尺寸的 apply_dirty 耗时 / 返回码 / pad / 计数器增量
 *   2. 全量 clearance 重建 与 全量 components 重建 各自的耗时（4.5 ms 的构成）
 *   3. pad 与 RT_SSEDT_MAX_PAD 的关系（排除「pad 撞顶」这一条）
 */
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "rt_grid.h"

#define RT_SSEDT_MAX_PAD_LOCAL 64

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static RtGrid G;

static void build_map(void)
{
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    uint64_t st = 0xB5EEDull;
    for (int z = 0; z < 256; z++)
        for (int x = 0; x < 256; x++) {
            uint64_t k = (st += 0x9E3779B97F4A7C15ull);
            k = (k ^ (k >> 30)) * 0xBF58476D1CE4E5B9ull;
            k = (k ^ (k >> 27)) * 0x94D049BB133111EBull;
            k ^= k >> 31;
            if ((k >> 40) % 1000 < 100ull) rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
    for (int z = 0; z < 256; z++)
        if (z != 128) rt_grid_set_terrain(&G, 128, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);
}

int main(void)
{
    timer_init();
    build_map();
    printf("=== why does a large edit fall back to a full rebuild? ===\n");
    printf("clearance_max=%.2f m  RT_SSEDT_MAX_PAD=%d  (pad_add = max/100+3, pad_rm = max/50+6)\n",
           (double)G.clearance_max * 0.01, RT_SSEDT_MAX_PAD_LOCAL);

    /* 全量两段各自的成本 */
    double bc = 1e30, bp = 1e30;
    for (int i = 0; i < 7; i++) {
        double t0 = now_ms();
        rt_grid_rebuild_clearance_full(&G);
        double dt = now_ms() - t0;
        if (dt < bc) bc = dt;
        t0 = now_ms();
        rt_grid_rebuild_components_full(&G);
        dt = now_ms() - t0;
        if (dt < bp) bp = dt;
    }
    printf("full clearance rebuild = %.4f ms | full components rebuild = %.4f ms\n", bc, bp);

    printf("\n  size   add(ms) rc   pad  full+  split+  ringFail seedsFail relabelFail lostOvf single@fail\n");
    int sizes[] = { 4, 8, 12, 16, 24, 32, 48, 64 };
    for (int i = 0; i < (int)(sizeof(sizes) / sizeof(sizes[0])); i++) {
        int s = sizes[i];
        int x = 60, z = 60;
        RtGridDirty d;
        memset(&d, 0, sizeof(d));

        uint32_t f0 = G.full_rebuild_count, sp0 = G.split_detected_count;
        uint32_t r0 = G.split_fail_ring, sd0 = G.split_fail_seeds, rl0 = G.split_fail_relabel;
        uint32_t ov0 = G.detach_lost_overflow;
        rt_grid_add_building_dirty(&G, x, z, s, s, &d);
        double t0 = now_ms();
        int rc = rt_grid_apply_dirty(&G, &d);
        double ta = now_ms() - t0;
        uint32_t f1 = G.full_rebuild_count - f0, sp1 = G.split_detected_count - sp0;
        uint32_t r1 = G.split_fail_ring - r0, sd1 = G.split_fail_seeds - sd0;
        uint32_t rl1 = G.split_fail_relabel - rl0, ov1 = G.detach_lost_overflow - ov0;

        memset(&d, 0, sizeof(d));
        uint32_t f2 = G.full_rebuild_count, mg0 = G.merge_detected_count;
        rt_grid_remove_building_dirty(&G, x, z, s, s, &d);
        t0 = now_ms();
        int rc2 = rt_grid_apply_dirty(&G, &d);
        double tr = now_ms() - t0;
        uint32_t f3 = G.full_rebuild_count - f2, mg1 = G.merge_detected_count - mg0;

        printf("  %2dx%-3d %8.4f %3d %5d %5u %5u %9u %9u %11u %7u %9u   | remove %8.4f rc=%d full+=%u merge+=%u\n",
               s, s, ta, rc, d.pad, f1, sp1, r1, sd1, rl1, ov1, G.split_ring_single_at_fail,
               tr, rc2, f3, mg1);
    }

    /* 单个 2x2：确认小编辑不会降级 */
    {
        RtGridDirty d;
        memset(&d, 0, sizeof(d));
        uint32_t f0 = G.full_rebuild_count;
        rt_grid_add_building_dirty(&G, 100, 100, 2, 2, &d);
        double t0 = now_ms();
        int rc = rt_grid_apply_dirty(&G, &d);
        printf("\n2x2 reference: %.4f ms rc=%d pad=%d full+=%u\n",
               now_ms() - t0, rc, d.pad, G.full_rebuild_count - f0);
    }

    printf("\nstats: full_rebuilds=%u splits=%u merges=%u comp_count=%d active=%d\n",
           G.full_rebuild_count, G.split_detected_count, G.merge_detected_count,
           G.component_count, G.active_components);
    rt_grid_destroy(&G);
    return 0;
}

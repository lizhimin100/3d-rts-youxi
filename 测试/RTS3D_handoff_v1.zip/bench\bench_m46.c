/* ============================================================================
 * bench_m46.c -- M4.6-P2：区域图增量刷新的成本与正确性抽样
 *
 * 输出四段：
 *   A. 整图重建 vs 矩形刷新（2×2 ~ 64×64 编辑）
 *   B. 编辑管线全程（rt_grid_apply_dirty + note_edit）vs 旧路径（+ 整图刷新）
 *   C. 抽样正确性：50 次随机编辑后与整图逐字段比对（必须 0 不一致）
 *   D. 汇总
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c bench/bench_m46.c -o bench_m46
 * ==========================================================================*/
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

#include "rt_grid.h"
#include "rt_region.h"
#include "rt_group.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static RtGrid G;
static RtRegionMap MAP;
static RtRegionMap REF;

static void map_build(void)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_region_destroy(&REF);
    rt_grid_init(&G, 256, 256, 1.0f);

    uint64_t st = 0xB5EEDull;
    for (int z = 0; z < 256; z++)
        for (int x = 0; x < 256; x++) {
            uint64_t k = (st += 0x9E3779B97F4A7C15ull);
            k = (k ^ (k >> 30)) * 0xBF58476D1CE4E5B9ull;
            k = (k ^ (k >> 27)) * 0x94D049BB133111EBull;
            k ^= k >> 31;
            if ((k >> 40) % 1000 < 100ull) rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
    for (int z = 0; z < 256; z++)
        if (z != 128) rt_grid_set_terrain(&G, 128, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int dz = -1; dz <= 1; dz++) {
        rt_grid_set_terrain(&G, 127, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, 128, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, 129, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
    }
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_region_build(&REF, &G, 8);
}

static int region_cmp(void)
{
    int bad = 0;
    for (int r = 0; r < MAP.rw * MAP.rh; r++) {
        if (MAP.maxclear[r] != REF.maxclear[r]) { bad++; continue; }
        if (MAP.comp[r] != REF.comp[r]) { bad++; continue; }
        if (MAP.mixed[r] != REF.mixed[r]) { bad++; continue; }
        if (MAP.anchor_x[r] != REF.anchor_x[r] || MAP.anchor_z[r] != REF.anchor_z[r]) { bad++; continue; }
        for (int c = 0; c < RT_CLEAR_CLASSES; c++)
            if (MAP.pass[r * 4 + c] != REF.pass[r * 4 + c]) { bad++; break; }
    }
    return bad;
}

/* 一次「编辑 + 刷新」。mode 0 = 整图刷新（M4.6-P1 及之前的行为），1 = 矩形增量。 */
static double one_edit(int size, int mode, int *out_regions)
{
    RtGridDirty d;
    memset(&d, 0, sizeof(d));
    int x = 60, z = 60 + (size % 7);           /* 固定位置，避免噪声格重合造成抖动 */

    double t0 = now_ms();
    rt_grid_add_building_dirty(&G, x, z, size, size, &d);
    (void)rt_grid_apply_dirty(&G, &d);
    int n;
    if (mode == 0) {
        rt_region_refresh(&MAP);
        n = MAP.rw * MAP.rh;
    } else {
        n = rt_region_refresh_rect(&MAP, d.cx0, d.cz0, d.cx1, d.cz1);
        if (n < 0) n = 0;
    }
    double dt = now_ms() - t0;

    /* 还原：保证下一轮从同一状态出发 */
    memset(&d, 0, sizeof(d));
    rt_grid_remove_building_dirty(&G, x, z, size, size, &d);
    (void)rt_grid_apply_dirty(&G, &d);
    if (mode == 0) rt_region_refresh(&MAP);
    else            rt_region_refresh_rect(&MAP, d.cx0, d.cz0, d.cx1, d.cz1);

    if (out_regions) *out_regions = n;
    return dt;
}

static double best_of(int size, int mode, int reps, int *regions)
{
    double best = 1e30;
    int n = 0;
    for (int i = 0; i < reps; i++) {
        double dt = one_edit(size, mode, &n);
        if (dt < best) best = dt;
    }
    if (regions) *regions = n;
    return best;
}

/* 整图重建（= rt_region_refresh 在 built_epoch 落后时走的那条路径） */
static double time_full_rebuild(int reps)
{
    double best = 1e30;
    for (int i = 0; i < reps; i++) {
        double t0 = now_ms();
        rt_region_build(&MAP, &G, 8);
        double dt = now_ms() - t0;
        if (dt < best) best = dt;
    }
    return best;
}

/* 只测矩形刷新本身（编辑与还原都不计时） */
static double time_rect_refresh(int size, int reps, int *regions_out, int *reason_out)
{
    double best = 1e30;
    int n = 0, reason = 0;
    for (int i = 0; i < reps; i++) {
        RtGridDirty d;
        memset(&d, 0, sizeof(d));
        rt_grid_add_building_dirty(&G, 60, 60, size, size, &d);
        (void)rt_grid_apply_dirty(&G, &d);
        double t0 = now_ms();
        n = rt_region_refresh_rect(&MAP, d.cx0, d.cz0, d.cx1, d.cz1);
        double dt = now_ms() - t0;
        if (dt < best) { best = dt; reason = MAP.last_full_reason; }

        memset(&d, 0, sizeof(d));
        rt_grid_remove_building_dirty(&G, 60, 60, size, size, &d);
        (void)rt_grid_apply_dirty(&G, &d);
        rt_region_refresh_rect(&MAP, d.cx0, d.cz0, d.cx1, d.cz1);
    }
    if (regions_out) *regions_out = n;
    if (reason_out) *reason_out = reason;
    return best;
}

int main(void)
{
    timer_init();
    printf("=== M4.6-P2 bench: incremental region map ===\n");
    map_build();
    printf("map 256x256, regions %dx%d (px=%d), map bytes=%.1f KB\n",
           MAP.rw, MAP.rh, MAP.px, (double)MAP.bytes / 1024.0);

    /* ---- A. 刷新本身的成本 ---- */
    printf("\n-- A. refresh cost only (edit excluded) --\n");
    printf("  %-8s %10s %10s %8s %10s %6s\n", "edit", "full(ms)", "rect(ms)", "speedup", "regions", "mode");
    int sizes[5] = { 2, 8, 16, 32, 64 };
    double full_ms = time_full_rebuild(9);
    for (int i = 0; i < 5; i++) {
        int s = sizes[i];
        int rr = 0, reason = 0;
        double r = time_rect_refresh(s, 9, &rr, &reason);
        printf("  %2dx%-5d %10.4f %10.4f %7.1fx %5d/%d %6s\n",
               s, s, full_ms, r, full_ms / (r > 1e-9 ? r : 1e-9), rr, MAP.rw * MAP.rh,
               reason == 0 ? "rect" : (reason == 1 ? "label" : "widen"));
    }

    /* ---- B. 编辑管线全程（apply_dirty 是共同成本，看的是总时间）---- */
    printf("\n-- B. edit pipeline: add_building + apply_dirty + region refresh --\n");
    printf("  %-8s %10s %10s %8s %12s\n", "edit", "legacy(ms)", "pipeline(ms)", "speedup", "grid_full/ed");
    for (int i = 0; i < 5; i++) {
        int s = sizes[i];
        uint32_t fr0 = G.full_rebuild_count;
        double a = best_of(s, 0, 9, NULL);
        double b = best_of(s, 1, 9, NULL);
        uint32_t fr = G.full_rebuild_count - fr0;   /* 两次 best_of 共 18 次编辑 */
        printf("  %2dx%-5d %10.4f %10.4f %7.2fx %12.2f\n", s, s, a, b,
               a / (b > 1e-9 ? b : 1e-9), (double)fr / 18.0);
    }

    /* ---- C. 抽样正确性 ---- */
    printf("\n-- C. correctness sampling: 50 random edits, incremental vs full --\n");
    {
        uint64_t st = 0x5150ull;
        int bad = 0, edits = 0;
        uint32_t full0 = MAP.refresh_full, mix0 = MAP.mixed_rescans, wid0 = MAP.refresh_widened;
        int nb = 0, bxx[64], bzz[64], bww[64], bhh[64];
        for (int it = 0; it < 50; it++) {
            st += 0x9E3779B97F4A7C15ull;
            uint64_t k = (st ^ (st >> 30)) * 0xBF58476D1CE4E5B9ull;
            k = (k ^ (k >> 27)) * 0x94D049BB133111EBull;
            k ^= k >> 31;
            RtGridDirty d;
            memset(&d, 0, sizeof(d));
            int rem = (nb > 0) && (k % 100 < 35);
            if (rem) {
                int i = (int)((k >> 8) % (uint64_t)nb);
                if (rt_grid_remove_building_dirty(&G, bxx[i], bzz[i], bww[i], bhh[i], &d) != RT_OK) continue;
                bxx[i] = bxx[nb - 1]; bzz[i] = bzz[nb - 1]; bww[i] = bww[nb - 1]; bhh[i] = bhh[nb - 1]; nb--;
            } else {
                int w = 2 + (int)((k >> 12) % 5), h = 2 + (int)((k >> 16) % 5);
                int x = 4 + (int)((k >> 20) % 240), z = 4 + (int)((k >> 24) % 240);
                if (rt_grid_add_building_dirty(&G, x, z, w, h, &d) != RT_OK) continue;
                if (nb < 64) { bxx[nb] = x; bzz[nb] = z; bww[nb] = w; bhh[nb] = h; nb++; }
            }
            if (rt_grid_apply_dirty(&G, &d) != RT_OK) rt_region_refresh(&MAP);
            else { rt_region_refresh_rect(&MAP, d.cx0, d.cz0, d.cx1, d.cz1); }
            rt_region_build(&REF, &G, 8);
            edits++;
            if (region_cmp() != 0) bad++;
        }
        printf("  edits=%d mismatched=%d  (refresh_calls=%u avg_regions=%.1f)\n",
               edits, bad, MAP.refresh_calls,
               MAP.refresh_calls ? (double)MAP.refresh_regions / (double)MAP.refresh_calls : 0.0);
        printf("  in this section: full rebuilds=%u (of which widened=%u), mixed rescans=%u\n",
               MAP.refresh_full - full0, MAP.refresh_widened - wid0, MAP.mixed_rescans - mix0);
    }

    /* ---- D. 汇总 ---- */
    printf("\n-- D. summary --\n");
    printf("  2x2 edit: legacy refresh = full map (%.0f regions), incremental = a few regions\n",
           (double)(MAP.rw * MAP.rh));
    printf("  map bytes = %.1f KB (+ chunk snapshot %d KB)\n",
           (double)MAP.bytes / 1024.0, (int)(RT_CHUNK_N * sizeof(uint32_t) / 1024));

    rt_region_destroy(&REF);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return 0;
}

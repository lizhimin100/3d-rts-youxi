/* ============================================================================
 * rt_navjob.h -- 可分帧、可暂停、可取消的导航更新任务（M3.4）
 *
 * 设计要点（对应任务书 §五~§十四）：
 *   1. **不在 Active 数据上分帧写**：分区结果写在 staging 的 label[]（1B/格），
 *      Active 的 component[] 只在 READY 之后由 commit 一次性改写。
 *      Job 期间查询看到的仍是「上一个完整一致版本」。
 *   2. **工作单位可数**：step(max_units) 按 BFS 节点推进（phase-1 扫描按 64 格
 *      折 1 单位），毫秒预算只是外层调度器的保险（§十）。
 *   3. **stale 检测用 `revision`**（只在真实地图编辑时 +1），不是 `version`
 *      （派生数据重建也会 +1，会把自己 commit 的动作误判成输入变化）。
 *   4. **取消零副作用**：cancel 只清 staging，Active 数据一字未动。
 *   5. **Live Obstacle 立即生效**：flags 的更新在 job 创建之前就完成了，
 *      所以 Job 运行期间物理上绝不穿墙（§六/§十四）。
 *
 * 状态机：
 *   PARTITION -> RELABEL -> READY -> (COMMIT) -> DONE
 *        \          \         \
 *         +----------+---------+--> STALE / CANCELLED
 * ==========================================================================*/
#ifndef RT_NAVJOB_H
#define RT_NAVJOB_H

#include "rt_types.h"
#include "rt_grid.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    RT_JOB_IDLE = 0,
    RT_JOB_PARTITION,    /* 分组 BFS（可暂停，单位 = 节点） */
    RT_JOB_RELABEL,      /* O(1) 过渡：归属已在 label[] 里 */
    RT_JOB_READY,        /* 结果就绪，等待 commit（此状态查询可见 PENDING） */
    RT_JOB_DONE,
    RT_JOB_STALE,        /* 期间 map 变了 -> 不可提交 */
    RT_JOB_CANCELLED
} RtJobState;

typedef struct RtNavJob {
    RtJobState state;
    uint32_t   job_id;
    uint32_t   base_version;      /* 创建时的 g->version（诊断用） */
    uint32_t   base_revision;     /* 创建时的 g->revision（stale 判据） */
    int        w, h;
    RtGrid    *grid;              /* 非拥有；staging 缓冲由 grid 持有 */

    /* 输入 */
    int32_t    target_comp;       /* 被切开的旧分量 */
    int32_t    seeds[256];
    int        nseeds;
    int32_t    old_size;          /* 旧分量大小（摘掉 blocked 之后） */

    /* staging（borrowed from grid：queue/label 都由 grid 分配并复用） */
    int32_t   *queue;             /* w*h */
    uint8_t   *label;             /* w*h：0 = 未访问，1..250 = 组号 */
    int        head, tail;

    /* 进度 */
    int        ngroups;
    int        next_seed;         /* 下一个待开始的 seed 下标 */
    size_t     scan_cursor;       /* 扫描「被围住成员」的游标 */
    int        phase;             /* 0 = seed BFS, 1 = scan uncovered */
    size_t     relabel_cursor;
    int32_t    cnt[256];
    int32_t    keep_group;
    int32_t    new_id_of[256];
    int32_t    rep_of[256];       /* 每组一个代表格（建组时的种子），省掉 commit 里的 rep 维护 */

    /* 统计 / 成本估计 */
    uint64_t   work_units;        /* 已处理的节点数（用于成本模型校准） */
    uint64_t   affected_cells;
    uint32_t   estimated_units;   /* 创建时的预估工作量（= 旧分量大小） */
    uint32_t   mask[RT_CHUNK_MASK_WORDS];  /* 本次编辑影响的 chunk（commit 时按它 bump 版本） */

    /* 依赖级 stale 判定（M3.7）：只关心自己 mask 覆盖的 chunk 的 **edit_ver**。
     * 用全局 revision 会让「无关区域的一栋房子」取消正在跑的任务（§C5 禁止）。 */
    uint32_t   dep_n;
    uint32_t   dep_chunks[32];
    uint32_t   dep_edit_ver[32];
    uint8_t    dep_overflow;
} RtNavJob;

/* ---- 生命周期 ---- */
/* 为「一个被切开的旧分量」创建 job；返回 NULL 表示参数非法。
 * staging 缓冲由 grid 持有并复用 -> 同一时刻只能有一个活跃 job。 */
RtNavJob *rt_navjob_create(RtGrid *g, uint32_t job_id,
                           int32_t target_comp, const int32_t *seeds, int nseeds,
                           int32_t old_size, const uint32_t *chunk_mask);

void rt_navjob_destroy(RtNavJob *j);

/* 推进至多 max_units 个工作单位；返回 1 = READY/DONE，0 = 仍需继续。 */
int rt_navjob_step(RtNavJob *j, RtGrid *g, int max_units);

/* 把 staging 应用到 grid（一次顺序遍历）。返回 RT_OK / RT_ERR_NOT_FOUND(stale)。 */
int rt_navjob_commit(RtNavJob *j, RtGrid *g);

/* 取消：清 staging，Active 数据不变。 */
void rt_navjob_cancel(RtNavJob *j);

/* stale 检查（不修改状态）：revision 是否已偏离 base_revision */
int rt_navjob_is_stale(const RtNavJob *j, const RtGrid *g);

/* 该 job 是否让某个分量处于 PENDING（查询保护用） */
int rt_navjob_touches_component(const RtNavJob *j, int32_t comp);

const char *rt_navjob_state_name(RtJobState s);

#ifdef __cplusplus
}
#endif

#endif /* RT_NAVJOB_H */

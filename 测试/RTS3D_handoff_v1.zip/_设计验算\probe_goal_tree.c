/* ============================================================================
 * probe_goal_tree.c -- M4.2 设计前置取证（一次性探针，用完即删）
 *
 * 要回答的问题：把「每个源区域各跑一次 A*」换成「以 goal 为根跑一次有界
 * Dijkstra，多个源区域从同一棵树上摘走廊」，在什么规模下才划算？
 *
 * 对照两列（同图、同 goal、同源区域集合、同 clearance）：
 *   A) N × rt_route_build()                  —— M4.1 现状
 *   B) 1 × bounded multi-target Dijkstra     —— 候选 B（M4.2 的最小可行形态）
 *      「有界」= 最后一个请求源区域 settle 即停，不展开全图。
 *
 * 两种源区域分布：
 *   cluster —— 12 m 圆盘内的源区域（模拟框选 1000 单位的真实形状）
 *   spread  —— 全图均匀取（模拟 50 个不同起点/多组）
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c _设计验算/probe_goal_tree.c
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void t_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void t_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static uint64_t g_state = 0xC0FFEEull;
static uint64_t nu(void)
{
    uint64_t z = (g_state += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
}

static RtGrid G;
static RtRegionMap MAP;
static RtRouteSolver S;

/* ---- 有界多目标 Dijkstra（探针版，不是产品代码） ------------------------- */
static float   *DG;      /* gscore */
static int32_t *DPAR;    /* parent */
static uint8_t *DST;     /* 0 未访问 1 open 2 closed */
static int32_t *DHEAP;
static int      DHN;
static int      DCAP;

static void dheap_push(int node)
{
    if (DHN >= DCAP) return;    /* 只可能发生在容量算错时；探针里不静默丢弃，直接截断会偏乐观 */
    int i = DHN++;
    DHEAP[i] = node;
    while (i > 0) {
        int p = (i - 1) >> 1;
        if (DG[DHEAP[p]] <= DG[DHEAP[i]]) break;
        int32_t t = DHEAP[p]; DHEAP[p] = DHEAP[i]; DHEAP[i] = t;
        i = p;
    }
}
static int dheap_pop(void)
{
    if (DHN <= 0) return -1;
    int top = DHEAP[0];
    DHN--;
    if (DHN > 0) {
        DHEAP[0] = DHEAP[DHN];
        int i = 0;
        for (;;) {
            int l = 2 * i + 1, r = l + 1, b = i;
            if (l < DHN && DG[DHEAP[l]] < DG[DHEAP[b]]) b = l;
            if (r < DHN && DG[DHEAP[r]] < DG[DHEAP[b]]) b = r;
            if (b == i) break;
            int32_t t = DHEAP[b]; DHEAP[b] = DHEAP[i]; DHEAP[i] = t;
            i = b;
        }
    }
    return top;
}

static const int DX8[8] = { 1, -1, 0, 0, 1, 1, -1, -1 };
static const int DZ8[8] = { 0, 0, 1, -1, -1, 1, 1, -1 };

/* 从 goal 出发，直到 need[] 里所有区域 closed 为止；返回展开节点数 */
static int goal_tree(int goal_region, int cls, const int32_t *need, int need_n)
{
    int nn = MAP.rw * MAP.rh;
    for (int i = 0; i < nn; i++) { DG[i] = 1e30f; DPAR[i] = -1; DST[i] = 0; }
    DHN = 0;
    DG[goal_region] = 0.f;
    DST[goal_region] = 1;
    dheap_push(goal_region);

    int remaining = need_n;
    int expanded = 0;
    while (DHN > 0 && remaining > 0) {
        int cur = dheap_pop();
        if (cur < 0) break;
        if (DST[cur] == 2) continue;
        DST[cur] = 2;
        expanded++;
        for (int k = 0; k < need_n; k++) if (need[k] == cur) { remaining--; break; }

        int cx = cur % MAP.rw, cz = cur / MAP.rw;
        for (int e = 0; e < 8; e++) {
            int nx = cx + DX8[e], nz = cz + DZ8[e];
            if (nx < 0 || nz < 0 || nx >= MAP.rw || nz >= MAP.rh) continue;
            int nb = nz * MAP.rw + nx;
            if (DST[nb] == 2) continue;
            if (!rt_region_edge_ok(&MAP, cur, nb, cls)) continue;
            float step = (e >= 4) ? 1.41421356f : 1.0f;
            float ng = DG[cur] + step;
            if (ng + 1e-6f >= DG[nb]) continue;
            DG[nb] = ng;
            DPAR[nb] = cur;
            DST[nb] = 1;
            dheap_push(nb);
        }
    }
    return expanded;
}

/* ------------------------------------------------------------------ 地图 */
static void build_map(int w, int noise_permille)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_grid_init(&G, w, w, 1.0f);
    g_state = 0xC0FFEEull + (uint64_t)w;
    for (int z = 0; z < w; z++)
        for (int x = 0; x < w; x++)
            if ((nu() >> 40) % 1000 < (uint64_t)noise_permille)
                rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int z = 0; z < w; z++)
        if (z != w / 2) rt_grid_set_terrain(&G, w / 2, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int dz = -1; dz <= 1; dz++) {
        rt_grid_set_terrain(&G, w / 2 - 1, w / 2 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, w / 2,     w / 2 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, w / 2 + 1, w / 2 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
    }
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
}

/* 选源区域：保证 passable + 与 goal 同分量 + A* 真能成功 */
static int collect_sources(int goal_region, int cls, int mode,
                           int32_t *out, int max_out, float cx, float cz, float rad)
{
    int n = 0;
    int nn = MAP.rw * MAP.rh;
    int32_t goal_comp = MAP.comp[goal_region];

    if (mode == 0) {
        /* cluster：按到 (cx,cz) 的距离升序，取最近的若干个 */
        RtVec2 c = rt_v2(cx, cz);
        int best[64]; float bestd[64]; int bn = 0;
        for (int r = 0; r < nn && bn < 64; r++) {
            if (!rt_region_passable(&MAP, r, cls)) continue;
            if (MAP.comp[r] != goal_comp) continue;
            RtVec2 rc = rt_region_center(&MAP, r);
            float d = (rc.x - c.x) * (rc.x - c.x) + (rc.z - c.z) * (rc.z - c.z);
            if (d > rad * rad) continue;
            best[bn] = r; bestd[bn] = d; bn++;
        }
        for (int i = 0; i < bn; i++)
            for (int j = i + 1; j < bn; j++)
                if (bestd[j] < bestd[i]) {
                    float td = bestd[i]; bestd[i] = bestd[j]; bestd[j] = td;
                    int tr = best[i]; best[i] = best[j]; best[j] = tr;
                }
        for (int i = 0; i < bn && n < max_out; i++) out[n++] = best[i];
    } else {
        /* spread：全图等距抽样 */
        int stride = 7;
        for (int r = 0; r < nn && n < max_out; r += stride) {
            if (!rt_region_passable(&MAP, r, cls)) continue;
            if (MAP.comp[r] != goal_comp) continue;
            out[n++] = r;
        }
    }
    return n;
}

int main(void)
{
    t_init();
    printf("=== probe: goal-tree vs N x A*  (design gate for M4.2) ===\n");
    printf("grid 256x256, 10%% noise, wall + 3-cell gate, region px=8\n");
    printf("region graph = %d x %d\n\n", 256 / 8, 256 / 8);

    build_map(256, 100);
    int nn = MAP.rw * MAP.rh;
    rt_route_solver_init(&S, nn);
    DG = (float *)malloc((size_t)nn * sizeof(float));
    DPAR = (int32_t *)malloc((size_t)nn * sizeof(int32_t));
    DST = (uint8_t *)malloc((size_t)nn);
    DHEAP = (int32_t *)malloc((size_t)nn * 16 * sizeof(int32_t));
    DCAP = nn * 16;

    int cls = RT_CLS_SMALL;
    int goal = rt_region_of_world(&MAP, 210.5f, 190.5f);
    printf("goal region = %d (%d,%d) passable=%d comp=%d\n\n",
           goal, goal % MAP.rw, goal / MAP.rw,
           rt_region_passable(&MAP, goal, cls), MAP.comp[goal]);

    int32_t src[64];
    int nsrc_cluster = collect_sources(goal, cls, 0, src, 64, 50.f, 60.f, 30.f);
    printf("cluster sources = %d (12~30 m disc around 50,60)\n", nsrc_cluster);

    int32_t src2[64];
    int nsrc_spread = collect_sources(goal, cls, 1, src2, 64, 0, 0, 0);
    printf("spread  sources = %d\n\n", nsrc_spread);

    int counts[] = { 1, 2, 4, 8, 16, 32, 50 };
    int ncase = 7;

    for (int mode = 0; mode < 2; mode++) {
        const int32_t *pool = (mode == 0) ? src : src2;
        int pool_n = (mode == 0) ? nsrc_cluster : nsrc_spread;
        printf("-- %s --\n", mode == 0 ? "cluster (framed selection)" : "spread (many groups)");
        printf("  %-5s %-10s %-12s %-10s %-12s %-10s %-9s\n",
               "N", "Astars_ms", "A_expanded", "tree_ms", "tree_expanded", "speedup", "verdict");

        for (int c = 0; c < ncase; c++) {
            int N = counts[c];
            if (N > pool_n) { printf("  %-5d (pool too small)\n", N); continue; }

            /* A) N 次独立 A* */
            RtRoute tmp; memset(&tmp, 0, sizeof(tmp));
            int exp_a = 0;
            double a0 = now_ms();
            int okA = 1;
            for (int i = 0; i < N; i++) {
                int rc = rt_route_build(&tmp, &S, &MAP, pool[i], goal, cls, 0);
                if (rc != RT_OK) { okA = 0; break; }
                exp_a += tmp.expanded;
            }
            double a1 = now_ms();
            rt_route_free(&tmp);
            if (!okA) { printf("  %-5d (A* failed)\n", N); continue; }

            /* B) 一次有界目标树 */
            int exp_b = goal_tree(goal, cls, pool, N);
            double b0 = now_ms();
            for (int rep = 0; rep < 5; rep++) goal_tree(goal, cls, pool, N);
            double b1 = now_ms();
            double tree_ms = (b1 - b0) / 5.0;

            /* A 侧同样重复 5 次取均值（build 会复用 solver 数组，成本结构一致） */
            double a0b = now_ms();
            for (int rep = 0; rep < 5; rep++)
                for (int i = 0; i < N; i++) rt_route_build(&tmp, &S, &MAP, pool[i], goal, cls, 0);
            double a1b = now_ms();
            rt_route_free(&tmp);
            double astar_ms = (a1b - a0b) / 5.0;

            printf("  %-5d %-10.4f %-12d %-10.4f %-12d %-10.2fx %s\n",
                   N, astar_ms, exp_a, tree_ms, exp_b,
                   tree_ms > 1e-9 ? astar_ms / tree_ms : 0.0,
                   (astar_ms > tree_ms) ? "tree wins" : "A* wins");
            (void)a0; (void)a1;
        }
        printf("\n");
    }

    free(DHEAP); free(DST); free(DPAR); free(DG);
    rt_route_solver_destroy(&S);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return 0;
}

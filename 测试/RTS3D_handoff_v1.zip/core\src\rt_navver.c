/* ============================================================================
 * rt_navver.c -- M3.5 版本判定实现
 * ==========================================================================*/
#include "rt_navver.h"
#include <string.h>

void rt_pathdep_capture(RtPathDep *dep, const RtGrid *g, const uint32_t *mask)
{
    if (!dep) return;
    memset(dep, 0, sizeof(*dep));
    if (!g || !mask) { dep->overflow = 1; return; }

    dep->nav_epoch = g->nav_epoch;
    dep->label_epoch = g->label_epoch;

    for (int c = 0; c < RT_CHUNK_N; c++) {
        if (!(mask[c >> 5] & (1u << (c & 31)))) continue;
        if (dep->n >= RT_PATH_DEP_MAX) { dep->overflow = 1; return; }
        dep->chunks[dep->n] = (uint32_t)c;
        dep->vers[dep->n] = g->chunk_ver[c];
        dep->n++;
    }
}

int rt_pathdep_valid(const RtPathDep *dep, const RtGrid *g)
{
    if (!dep || !g) return 0;
    /* 压缩过 id 空间：所有依赖 component_id 的结论一律作废（ABA 防护）。 */
    if (dep->label_epoch != g->label_epoch) return 0;
    if (dep->overflow) return 0;              /* 依赖太多 -> 保守失效 */
    for (uint32_t i = 0; i < dep->n; i++) {
        uint32_t c = dep->chunks[i];
        if (c >= RT_CHUNK_N) return 0;
        if (g->chunk_ver[c] != dep->vers[i]) return 0;
    }
    return 1;
}

RtPathVerdict rt_path_result_check(const RtPathDep *dep, const RtGrid *g,
                                   uint32_t req_command_version,
                                   uint32_t cur_command_version,
                                   int32_t dep_component)
{
    /* 第一关：命令。玩家连点 Move A..E 时，A~D 的结果必须在这里被丢掉。 */
    if (req_command_version != cur_command_version) return RT_PATH_DISCARD_COMMAND;

    /* 第二关：依赖区域是否正在重建（M3.4 的 PENDING 语义） */
    if (g && dep_component >= 0 && dep_component == g->pending_comp)
        return RT_PATH_PENDING_NAV;

    /* 第三关：导航几何是否已变 */
    if (!rt_pathdep_valid(dep, g)) return RT_PATH_STALE_NAV;

    return RT_PATH_ACCEPT;
}

const char *rt_path_verdict_name(RtPathVerdict v)
{
    switch (v) {
    case RT_PATH_ACCEPT:          return "ACCEPT";
    case RT_PATH_DISCARD_COMMAND: return "DISCARD_COMMAND";
    case RT_PATH_STALE_NAV:       return "STALE_NAV";
    case RT_PATH_PENDING_NAV:     return "PENDING_NAV";
    }
    return "?";
}

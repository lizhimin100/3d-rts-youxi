/* ============================================================================
 * bench_m4.c -- M4.1 基准：共享 Global Route vs 每单位独立 A*
 *
 * A. 单位数扩展（1/10/50/100/300/500/1000，同一目标）
 * B. 10 groups × 100 units（10 目标）
 * C. 50 groups × 20 units（50 目标）
 * D. 同目标复用（同源区域 -> 1 次 build，其余 reuse）
 * E. Sampling 成本（1000 单位一帧）
 * F. Naive baseline：每单位一次 cell-level A*（对照）
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c bench/bench_m4.c -o bench_m4
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void t_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void t_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static uint64_t g_state = 0xC0FFEEull;
static uint64_t nu(void)
{
    uint64_t z = (g_state += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
}

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;

/* ------------------------------------------------------------------ 地图 */
static void build_map(int w, int noise_permille)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_grid_init(&G, w, w, 1.0f);
    g_state = 0xC0FFEEull + (uint64_t)w;
    for (int z = 0; z < w; z++)
        for (int x = 0; x < w; x++)
            if ((nu() >> 40) % 1000 < (uint64_t)noise_permille)
                rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    /* 竖墙 + 3 格门（让路线不是一条直线） */
    for (int z = 0; z < w; z++)
        if (z != w / 2) rt_grid_set_terrain(&G, w / 2, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int dz = -1; dz <= 1; dz++) {
        rt_grid_set_terrain(&G, w / 2 - 1, w / 2 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, w / 2,     w / 2 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, w / 2 + 1, w / 2 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
    }
    rt_grid_rebuild_all(&G);
    rt_gw_destroy(&W);
    rt_region_build(&MAP, &G, 8);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
}

static int spawn_disc(RtUnitId *ids, int n, float cx, float cz, float r)
{
    int k = 0;
    for (int i = 0; i < n * 3 && k < n; i++) {
        float rad = r * sqrtf((float)i / (float)(n * 3));
        float ang = (float)i * 2.39996323f;
        int x = rt_grid_cell_x(&G, cx + cosf(ang) * rad);
        int z = rt_grid_cell_z(&G, cz + sinf(ang) * rad);
        if (!rt_grid_walkable(&G, x, z)) continue;
        RtUnitId id = rt_units_spawn(&US, rt_v3(x + 0.5f, 0.f, z + 0.5f), RT_FP_SMALL);
        if (id != RT_UNIT_ID_NONE) ids[k++] = id;
    }
    return k;
}

/* ------------------------------------------------------- naive：cell A* */
typedef struct {
    float   *g;
    int32_t *parent;
    uint8_t *state;
    int32_t *heap;
    int32_t *hpos;
    int      cap, hn;
    int      gw, gx, gz;
} CellAstar;

static CellAstar AST;

static void astar_init(int maxn)
{
    AST.g = (float *)malloc((size_t)maxn * sizeof(float));
    AST.parent = (int32_t *)malloc((size_t)maxn * sizeof(int32_t));
    AST.state = (uint8_t *)malloc((size_t)maxn);
    AST.heap = (int32_t *)malloc((size_t)maxn * sizeof(int32_t));
    AST.hpos = (int32_t *)malloc((size_t)maxn * sizeof(int32_t));
    AST.cap = maxn;
    AST.hn = 0;
}

static inline float c_octile(float dx, float dz)
{
    float ax = fabsf(dx), az = fabsf(dz);
    return (ax > az) ? (ax + 0.41421356f * az) : (az + 0.41421356f * ax);
}
static inline float c_f(int node)
{
    return AST.g[node] + c_octile((float)(node % AST.gw - AST.gx), (float)(node / AST.gw - AST.gz));
}
static int c_better(int u, int v) {
    float fu = c_f(u), fv = c_f(v);
    if (fu < fv - 1e-6f) return 1;
    if (fu > fv + 1e-6f) return 0;
    return u < v;
}
static void c_swap(int i, int j) { int t = AST.heap[i]; AST.heap[i] = AST.heap[j]; AST.heap[j] = t;
                                   AST.hpos[AST.heap[i]] = i; AST.hpos[AST.heap[j]] = j; }
static void c_up(int i) { while (i > 0) { int p = (i - 1) >> 1; if (!c_better(AST.heap[i], AST.heap[p])) break; c_swap(i, p); i = p; } }
static void c_down(int i) {
    for (;;) {
        int l = 2 * i + 1, r = l + 1, b = i;
        if (l < AST.hn && c_better(AST.heap[l], AST.heap[b])) b = l;
        if (r < AST.hn && c_better(AST.heap[r], AST.heap[b])) b = r;
        if (b == i) break;
        c_swap(i, b); i = b;
    }
}
static void c_push(int node) { AST.heap[AST.hn] = node; AST.hpos[node] = AST.hn; c_up(AST.hn); AST.hn++; }
static int c_pop(void) {
    if (AST.hn <= 0) return -1;
    int top = AST.heap[0]; AST.hpos[top] = -1; AST.hn--;
    if (AST.hn > 0) { AST.heap[0] = AST.heap[AST.hn]; AST.hpos[AST.heap[0]] = 0; c_down(0); }
    return top;
}

static const int DX8[8] = { 1, -1, 0, 0, 1, 1, -1, -1 };
static const int DZ8[8] = { 0, 0, 1, -1, -1, 1, 1, -1 };

/* 单单位 cell-level A*（baseline，不是产品代码） */
static int naive_astar(int sx, int sz, int gx, int gz, float need)
{
    int w = G.w;
    int nn = w * G.h;
    int start = sz * w + sx, goal = gz * w + gx;
    AST.gw = w; AST.gx = gx; AST.gz = gz; AST.hn = 0;
    for (int i = 0; i < nn; i++) { AST.g[i] = 1e30f; AST.parent[i] = -1; AST.state[i] = 0; AST.hpos[i] = -1; }
    AST.g[start] = 0.f; AST.state[start] = 1; c_push(start);
    int expanded = 0;
    while (AST.hn > 0) {
        int cur = c_pop();
        if (AST.state[cur] == 2) continue;
        AST.state[cur] = 2;
        expanded++;
        if (cur == goal) break;
        int cx = cur % w, cz = cur / w;
        for (int e = 0; e < 8; e++) {
            int nx = cx + DX8[e], nz = cz + DZ8[e];
            if (!rt_grid_in_bounds(&G, nx, nz)) continue;
            if (!rt_grid_walkable(&G, nx, nz)) continue;
            if (rt_grid_clearance_m(&G, nx, nz) + 1e-4f < need) continue;
            if (e >= 4) {
                if (!rt_grid_walkable(&G, cx + DX8[e], cz)) continue;
                if (!rt_grid_walkable(&G, cx, cz + DZ8[e])) continue;
            }
            int nb = nz * w + nx;
            if (AST.state[nb] == 2) continue;
            float ng = AST.g[cur] + ((e >= 4) ? 1.41421356f : 1.0f);
            if (ng + 1e-6f >= AST.g[nb]) continue;
            AST.g[nb] = ng; AST.parent[nb] = cur;
            if (AST.state[nb] == 0) { AST.state[nb] = 1; c_push(nb); }
            else { int p = AST.hpos[nb]; if (p >= 0) c_up(p); }
        }
    }
    return expanded;
}

/* ========================================================================== */
typedef struct {
    int    units, groups;
    double cmd_ms, sample_ms;
    uint32_t builds, reuses;
    size_t   bytes;
} Row;

static void run_scaling(void)
{
    printf("\n-- A. unit scaling (same destination, compact spawn) --\n");
    printf("  %-6s %-7s %-8s %-9s %-10s %-11s %-9s\n",
           "units", "groups", "builds", "reuses", "cmd_ms", "sample_ms", "mem_KB");
    int counts[] = { 1, 10, 50, 100, 300, 500, 1000 };
    for (int c = 0; c < 7; c++) {
        int n = counts[c];
        build_map(256, 100);
        static RtUnitId ids[1024];
        int got = spawn_disc(ids, n, 50.f, 60.f, 12.f);
        double t0 = now_ms();
        rt_gw_command(&W, &US, ids, got, rt_v2(210.5f, 190.5f), 0, RT_CLS_SMALL, 1);
        double t1 = now_ms();

        /* sampling：所有单位各采一次，重复 10 次取平均 */
        double ts = 0;
        for (int rep = 0; rep < 10; rep++) {
            double a = now_ms();
            for (int i = 0; i < got; i++) {
                RtVec3 p = rt_units_pos(&US, ids[i]);
                RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[i]);
                int gi = (int)ch->group[rt_unit_slot_index(ids[i])] - 1;
                RtVec2 tgt;
                if (gi >= 0) rt_gw_sample(&W, gi, rt_v2(p.x, p.z), &tgt);
            }
            ts += now_ms() - a;
        }
        ts /= 10.0;

        size_t bytes = MAP.bytes;
        for (int i = 0; i < W.group_count; i++)
            for (int k = 0; k < W.groups[i].route_count; k++)
                bytes += (size_t)W.groups[i].routes[k].route.cap * (sizeof(int32_t) + sizeof(RtVec2));

        printf("  %-6d %-7d %-8u %-9u %-10.3f %-11.4f %-9.1f\n",
               got, W.group_count, W.stats.route_builds, W.stats.route_reuses,
               t1 - t0, ts, (double)bytes / 1024.0);
    }
}

static void run_multi_group(int groups, int per)
{
    printf("\n-- %s: %d groups x %d units --\n", groups == 10 ? "B" : "C", groups, per);
    build_map(256, 60);
    static RtUnitId ids[1024];
    double t_cmd = 0, t_samp = 0;
    uint32_t builds = 0, reuses = 0;
    int total_groups = 0;

    for (int g = 0; g < groups; g++) {
        rt_units_init(&US);
        /* 每个组一个起点 + 一个目标（目标沿对角落分布） */
        float sx = 30.f + (float)(g % 5) * 40.f;
        float sz = 30.f + (float)(g / 5) * 40.f;
        float gx = 220.f - (float)(g % 5) * 30.f;
        float gz = 220.f - (float)(g / 5) * 30.f;
        int got = spawn_disc(ids, per, sx, sz, 5.f);
        double t0 = now_ms();
        rt_gw_command(&W, &US, ids, got, rt_v2(gx, gz), 0, RT_CLS_SMALL, (uint32_t)(g + 1));
        double t1 = now_ms();
        t_cmd += t1 - t0;
        builds += W.stats.route_builds;
        reuses += W.stats.route_reuses;
        total_groups += W.group_count;

        double a = now_ms();
        for (int i = 0; i < got; i++) {
            RtVec3 p = rt_units_pos(&US, ids[i]);
            RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[i]);
            int gi = (int)ch->group[rt_unit_slot_index(ids[i])] - 1;
            RtVec2 tgt;
            if (gi >= 0) rt_gw_sample(&W, gi, rt_v2(p.x, p.z), &tgt);
        }
        t_samp += now_ms() - a;
    }
    printf("  units=%d groups=%d builds=%u reuses=%u cmd_ms=%.3f sample_ms=%.4f\n",
           groups * per, total_groups, builds, reuses, t_cmd, t_samp);
    printf("  per-group cmd = %.3f ms, per-unit sample = %.2f us\n",
           t_cmd / groups, t_samp / (groups * per) * 1000.0);
}

static void run_reuse(void)
{
    printf("\n-- D. same goal from the same source region -> reuse --\n");
    build_map(256, 0);
    RtUnitId a = rt_units_spawn(&US, rt_v3(50.5f, 0.f, 60.5f), RT_FP_SMALL);
    RtUnitId one[1] = { a };
    rt_gw_command(&W, &US, one, 1, rt_v2(210.5f, 190.5f), 0, RT_CLS_SMALL, 1);
    uint32_t b1 = W.stats.route_builds;
    /* 第二个组：另一个单位、同一源区域、同一目标 */
    RtUnitId b = rt_units_spawn(&US, rt_v3(52.5f, 0.f, 61.5f), RT_FP_SMALL);
    RtUnitId one2[1] = { b };
    rt_gw_command(&W, &US, one2, 1, rt_v2(211.5f, 191.5f), 0, RT_CLS_SMALL, 2);
    printf("  first call builds=%u, second call builds=%u reuses=%u\n",
           b1, W.stats.route_builds, W.stats.route_reuses);
}

static void run_naive(void)
{
    printf("\n-- F. naive baseline: one cell-level A* per unit --\n");
    printf("  %-6s %-10s %-12s %-12s %-9s\n", "units", "astar_ms", "per_unit_ms", "expanded", "speedup_vs_shared");
    int counts[] = { 1, 50, 300, 1000 };
    for (int c = 0; c < 4; c++) {
        int n = counts[c];
        build_map(256, 100);
        static RtUnitId ids[1024];
        int got = spawn_disc(ids, n, 50.f, 60.f, 12.f);

        /* 共享方案的时间（同一次命令） */
        double s0 = now_ms();
        rt_gw_command(&W, &US, ids, got, rt_v2(210.5f, 190.5f), 0, RT_CLS_SMALL, 1);
        double s1 = now_ms();
        double shared_ms = s1 - s0;

        int gx = rt_grid_cell_x(&G, 210.5f), gz = rt_grid_cell_z(&G, 190.5f);
        long expanded = 0;
        double t0 = now_ms();
        for (int i = 0; i < got; i++) {
            RtVec3 p = rt_units_pos(&US, ids[i]);
            int sx = rt_grid_cell_x(&G, p.x), sz = rt_grid_cell_z(&G, p.z);
            expanded += naive_astar(sx, sz, gx, gz, rt_clear_radius_m(RT_CLS_SMALL));
        }
        double t1 = now_ms();
        printf("  %-6d %-10.2f %-12.4f %-12ld %-9.1fx\n",
               got, t1 - t0, (t1 - t0) / got, expanded / got,
               (t1 - t0) > 1e-6 ? (t1 - t0) / shared_ms : 0.0);
    }
}

int main(void)
{
    t_init();
    printf("=== M4.1 bench: shared Global Route vs per-unit A* ===\n");
    printf("grid 256x256, 10%% terrain noise, wall + 3-cell gate\n");

    astar_init(256 * 256);
    run_scaling();
    run_multi_group(10, 100);
    run_multi_group(50, 20);
    run_reuse();
    run_naive();

    printf("\n-- notes --\n");
    printf("  builds = 去重后的 (源区域, 目标区域, clearance) 组合数\n");
    printf("  M4.3 的 goal-centric flow 会把 builds 压到 1；本期未做\n");
    printf("  区域 = 8 cell (8 m)，版本 chunk = 32 cell (32 m)\n");
    return 0;
}

/* ============================================================================
 * bench_m5.c -- LocalAvoidance（ORCA）成本扫描
 *
 * 三段：
 *   A. N 扫描（100 / 300 / 1000 / 2000），k=12
 *   B. k 扫描（4 / 8 / 12），N=1000
 *   C. 邻居搜索半径的影响（3 / 4.5 / 6 / 8），N=1000
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c bench/bench_m5.c -o bench_m5
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_local.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

#define MAXA 2100
static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;

static void setup(int n, float spacing, float speed)
{
    int cols = (int)ceilf(sqrtf((float)n));
    for (int i = 0; i < n; i++) {
        memset(&AG[i], 0, sizeof(AG[i]));
        AG[i].pos = rt_v2(33.f + (float)(i % cols) * spacing,
                          33.f + (float)(i / cols) * spacing);
        AG[i].pref_vel = rt_v2(speed, 0.f);
        AG[i].vel = rt_v2(0.f, 0.f);
        AG[i].radius = 0.5f;
        AG[i].max_speed = speed;
        AG[i].fp = 1.f;
        AG[i].share = 0.5f;
        AG[i].inv_mass = 1.f;
    }
}

static void measure(const char *tag, int n, int steps, double *out_best, double *out_mean)
{
    double best = 1e30, sum = 0;
    for (int s = 0; s < steps; s++) {
        double t0 = now_ms();
        (void)rt_local_step(&LC, AG, n, NULL, 1.f / 30.f);
        double dt = now_ms() - t0;
        if (dt < best) best = dt;
        sum += dt;
    }
    *out_best = best;
    *out_mean = sum / steps;
    printf("  %-26s n=%4d  best=%7.3f ms  mean=%7.3f ms\n", tag, n, best, sum / steps);
}

int main(void)
{
    timer_init();
    printf("=== M5 bench: ORCA local avoidance ===\n");

    printf("\n-- A. N sweep (k=12, neighbor_dist=4.5) --\n");
    int ns[4] = { 100, 300, 1000, 2000 };
    for (int i = 0; i < 4; i++) {
        int n = ns[i];
        rt_local_init(&LC, 512.f, 512.f, MAXA, 4.5f);
        rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);
        setup(n, 1.4f, 1.5f);
        double b, m;
        measure("dense lattice", n, 60, &b, &m);
        rt_local_destroy(&LC);
    }

    printf("\n-- B. k sweep (n=1000, neighbor_dist=4.5) --\n");
    int ks[3] = { 4, 8, 12 };
    for (int i = 0; i < 3; i++) {
        rt_local_init(&LC, 512.f, 512.f, MAXA, 4.5f);
        rt_local_set_params(&LC, 2.0f, ks[i], 1, 0.f);
        setup(1000, 1.4f, 1.5f);
        double b, m;
        char tag[32];
        snprintf(tag, sizeof(tag), "k=%d", ks[i]);
        measure(tag, 1000, 60, &b, &m);
        rt_local_destroy(&LC);
    }

    printf("\n-- C. neighbor radius (n=1000, k=12) --\n");
    float rs[4] = { 3.0f, 4.5f, 6.0f, 8.0f };
    for (int i = 0; i < 4; i++) {
        rt_local_init(&LC, 512.f, 512.f, MAXA, rs[i]);
        rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);
        setup(1000, 1.4f, 1.5f);
        double b, m;
        char tag[32];
        snprintf(tag, sizeof(tag), "radius=%.1f", rs[i]);
        measure(tag, 1000, 60, &b, &m);
        rt_local_destroy(&LC);
    }

    printf("\n  说明：这是纯局部层（不含导航采样）。1000 人 30Hz 的预算是 33 ms/帧；\n");
    printf("  8 ms 逻辑帧预算下 ORCA 约占 10%%。01 的 S6 探针是 0.25 ms（邻居已给定、\n");
    printf("  只算数学），这里多出来的部分是**邻居搜索**（每步重建栅格 + 3x3 桶扫描）。\n");
    return 0;
}

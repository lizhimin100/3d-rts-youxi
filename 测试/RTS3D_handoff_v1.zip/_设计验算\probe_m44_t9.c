/* 临时：复刻 test_m4 T9，打印重算后的走廊与步行轨迹（定位 M4.4 回归）。跑完即删。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;

static int segment_clear(RtVec2 a, RtVec2 b)
{
    float dx = b.x - a.x, dz = b.z - a.z;
    float len = sqrtf(dx * dx + dz * dz);
    int steps = (int)(len / 0.25f) + 1;
    for (int i = 0; i <= steps; i++) {
        float t = (float)i / (float)steps;
        int cx = rt_grid_cell_x(&G, a.x + dx * t), cz = rt_grid_cell_z(&G, a.z + dz * t);
        if (!rt_grid_walkable(&G, cx, cz)) return 0;
    }
    return 1;
}

int main(void)
{
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int z = 0; z < 256; z++)
        if (z != 128) rt_grid_set_terrain(&G, 128, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int dz = -1; dz <= 1; dz++) {
        rt_grid_set_terrain(&G, 127, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, 128, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, 129, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
    }
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);

    RtUnitId id = rt_units_spawn(&US, rt_v3(60.5f, 0.f, 128.5f), RT_FP_SMALL);
    RtUnitId one[1] = { id };
    rt_gw_command(&W, &US, one, 1, rt_v2(210.5f, 128.5f), 0, RT_CLS_SMALL, 1);

    RtGridDirty d;
    rt_grid_add_building_dirty(&G, 140, 125, 8, 8, &d);
    rt_grid_apply_dirty(&G, &d);
    rt_region_refresh(&MAP);
    int rebuilt = rt_gw_update(&W);
    printf("rebuilt=%d new_n=%d blocked=%u/%u fine_builds=%u\n", rebuilt,
           W.groups[0].routes[0].route.n, W.stats.corridor_blocked,
           W.stats.corridor_segments, W.stats.fine_builds);

    RtRoute *rt = &W.groups[0].routes[0].route;
    for (int i = 0; i < rt->n; i++) {
        RtVec2 q = (i == rt->n - 1) ? W.groups[0].goal_pos : rt->portal[i];
        printf("  Q[%2d] (%6.1f,%6.1f) seg_block=%d\n", i, q.x, q.z,
               W.groups[0].routes[0].seg_block ? W.groups[0].routes[0].seg_block[i] : -1);
    }

    RtVec2 p = rt_v2(60.5f, 128.5f);
    RtVec2 hist[16]; int hn = 0;
    for (int i = 0; i < 4000; i++) {
        RtVec2 tgt;
        if (rt_gw_sample(&W, 0, p, &tgt) != RT_OK) { printf("ERR\n"); break; }
        RtVec2 dd = rt_v2_sub(tgt, p);
        float len = rt_v2_len(dd);
        hist[hn % 16] = p; hn++;
        if (len < 1e-4f) { printf("  STOP tgt==pos at step %d pos=(%.2f,%.2f)\n", i, p.x, p.z); break; }
        float step = 6.0f / 30.0f;
        if (step > len) step = len;
        RtVec2 np = rt_v2_add(p, rt_v2_mul(dd, step / len));
        if (!segment_clear(p, np)) {
            printf("  PENETRATION at step %d pos=(%.2f,%.2f) -> (%.2f,%.2f) tgt=(%.2f,%.2f)\n",
                   i, p.x, p.z, np.x, np.z, tgt.x, tgt.z);
            int bx = rt_grid_cell_x(&G, np.x), bz = rt_grid_cell_z(&G, np.z);
            printf("  blocked cell=(%d,%d)\n", bx, bz);
            break;
        }
        p = np;
        if (rt_gw_is_arrived(&W, 0, p, 1.5f)) { printf("  ARRIVED at step %d\n", i); break; }
        if (i % 200 == 199) printf("  ...step%d pos=(%.1f,%.1f)\n", i, p.x, p.z);
    }
    printf("  final pos=(%.2f,%.2f) fine chk=%u builds=%u used=%u out=%u\n",
           p.x, p.z, W.stats.fine_checks, W.stats.fine_builds, W.stats.fine_used, W.stats.fine_outside);
    return 0;
}

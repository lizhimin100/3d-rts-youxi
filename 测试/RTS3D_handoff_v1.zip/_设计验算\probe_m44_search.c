/* 临时：随机搜索「区域走廊的段直线被挡」的几何（M4.4-B 触发条件）。跑完即删。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static uint64_t g_state = 0x12345678ull;

static uint64_t nu(void)
{
    uint64_t z = (g_state += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
}

/* 场景：8x8 区域内一条对角阶梯墙 + 区域内柱子 —— 逼出「进出门户不同边」 */
static void build_stair(int rx, int rz, int thick)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_grid_init(&G, 256, 256, 1.0f);
    int x0 = rx * 8, z0 = rz * 8;
    for (int i = 0; i < 8; i++)
        for (int t = 0; t < thick; t++)
            rt_grid_set_terrain(&G, x0 + i, z0 + i + t, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
}

int main(void)
{
    printf("=== search: which geometry blocks a corridor segment? ===\n");

    /* A. 对角阶梯墙（1..3 格厚），跨一个区域 */
    for (int thick = 1; thick <= 3; thick++) {
        for (int rz = 6; rz <= 14; rz += 4) {
            build_stair(8, rz, thick);
            RtUnitId id = rt_units_spawn(&US, rt_v3(20.5f, 0.f, (float)(rz * 8) + 3.5f), RT_FP_SMALL);
            RtUnitId ids[1] = { id };
            rt_gw_command(&W, &US, ids, 1, rt_v2(230.5f, (float)(rz * 8) + 3.5f), 0, RT_CLS_SMALL, 1);
            printf("  stair thick=%d rz=%2d : route_n=%2d segs=%2u blocked=%2u\n",
                   thick, rz, W.groups[0].routes[0].route.n,
                   W.stats.corridor_segments, W.stats.corridor_blocked);
        }
    }

    /* B. 随机 blob 场 + 随机目标，统计 blocked > 0 的比例 */
    int hits = 0, total = 0, maxb = 0;
    for (int trial = 0; trial < 40; trial++) {
        rt_grid_destroy(&G);
        rt_region_destroy(&MAP);
        rt_gw_destroy(&W);
        rt_grid_init(&G, 256, 256, 1.0f);
        g_state = 0xABCD0000ull + (uint64_t)trial;
        for (int b = 0; b < 60; b++) {
            int bx = 10 + (int)(nu() % 230), bz = 10 + (int)(nu() % 230);
            int bw = 1 + (int)(nu() % 4), bh = 1 + (int)(nu() % 4);
            for (int z = bz; z < bz + bh; z++)
                for (int x = bx; x < bx + bw; x++)
                    rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
        rt_grid_rebuild_all(&G);
        rt_region_build(&MAP, &G, 8);
        rt_gw_init(&W, &G, &MAP);
        rt_units_init(&US);

        int ok_any = 0;
        for (int src = 0; src < 6; src++) {
            float sx = 20.5f + (float)(nu() % 200), sz = 20.5f + (float)(nu() % 200);
            int cx = rt_grid_cell_x(&G, sx), cz = rt_grid_cell_z(&G, sz);
            if (!rt_grid_walkable(&G, cx, cz)) continue;
            RtUnitId id = rt_units_spawn(&US, rt_v3(sx, 0.f, sz), RT_FP_SMALL);
            RtUnitId ids[1] = { id };
            float gx = 20.5f + (float)(nu() % 200), gz = 20.5f + (float)(nu() % 200);
            if (rt_gw_command(&W, &US, ids, 1, rt_v2(gx, gz), 0, RT_CLS_SMALL, 1) != RT_OK) continue;
            if (W.group_count <= 0 || W.groups[0].route_count <= 0) continue;
            total++;
            int b = (int)W.stats.corridor_blocked;
            if (b > 0) { ok_any = 1; if (b > maxb) maxb = b; }
        }
        if (ok_any) hits++;
    }
    printf("  random blobs: trials with blocked>0 = %d/40, max blocked segs = %d, cmds=%d\n",
           hits, maxb, total);

    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return 0;
}

/* ============================================================================
 * rt_grid.h -- 导航网格（单层）+ clearance 场 + 连通分量
 *
 * M2（区域增量）引入的三处关键变化：
 *   1. **持久化 8SSEDT 的距离向量 (dx,dy)**，而不只存标量 clearance。
 *      理由：增量重算某个矩形时，需要从 halo 的 (dx,dy) 把「区域外最近障碍」
 *      的方向传播进来；只存标量无法恢复方向，区域重算必然与全量不一致。
 *   2. **Dirty Region 分数据独立 padding**：walkability 的 padding = 0，
 *      clearance 的 padding = f(区域内最大 clearance)，连通域的 padding 由
 *      split/merge 检测决定。禁止「所有派生数据共用一个固定 padding」。
 *   3. **Connectivity 增量**：add 可能 split（局部 BFS 证明连通则可早退），
 *      remove 可能 merge（把较小分量重标号，O(小分量)）。
 *
 * 多层：本文件是**单层**。层间通过 RtPortal 连接（M3）。
 * ==========================================================================*/
#ifndef RT_GRID_H
#define RT_GRID_H

#include "rt_types.h"
#include "rt_math.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ---- chunk 网格（用于版本掩码 / 流场缓存失效粒度） ---- */
#define RT_CHUNK_PX   32
#define RT_CHUNKC_W   (RT_GRID_MAX_DIM / RT_CHUNK_PX)          /* 32 */
#define RT_CHUNKC_H   (RT_GRID_MAX_DIM / RT_CHUNK_PX)          /* 32 */
#define RT_CHUNK_N    (RT_CHUNKC_W * RT_CHUNKC_H)              /* 1024 */
#define RT_CHUNK_MASK_WORDS ((RT_CHUNK_N + 31) / 32)           /* 32 */

typedef struct {
    int      w, h;
    float    cell;
    uint8_t *base;            /* 静态 flags（地形） */
    uint16_t *overlay;        /* 动态建筑覆盖计数 */
    uint8_t *flags;           /* 派生：base | (overlay>0 ? BUILDING : 0) */
    uint16_t *clearance;      /* 到最近阻挡格中心的距离，0.01 m */
    int16_t *ssd_x, *ssd_y;   /* 8SSEDT 距离向量（持久，增量必需） */
    int32_t *component;       /* 连通分量 id（-1 = 不可走） */
    int32_t *component_size;  /* 每个分量的格子数（merge 时选小的改名） */
    int32_t *component_rep;   /* 每个分量的一个代表格（merge 重标时做 BFS 起点） */
    int32_t  component_count;   /* id 空间大小（数组容量索引，只增不减） */
    int32_t  component_cap;
    int32_t  active_components; /* 活跃分量数（split 分配 / merge 释放） */
    int32_t *bfs_queue;       /* w*h，复用，避免每次编辑 malloc */
    int32_t *job_queue;       /* M3.4：分帧 Job 的 BFS 队列（grid 拥有，惰性分配，跨编辑复用） */
    uint8_t *job_label;       /* M3.4：分帧 Job 的分组标记（同上；commit/cancel 负责清零已用部分） */
    uint8_t *split_label;     /* w*h，split 重标时的分组标记（0 = 未访问） */
    uint16_t clearance_max;   /* 全图 clearance 最大值（0.01m）：增量 pad 的依据 */
    uint8_t  clearance_valid; /* 0 = clearance 相对 flags 已过期（编辑后未重算）。
                               * 安全规则：**过期时禁止用 clearance 快路径判定「可通行」**，
                               * 必须退回精确 flags 检测（M3.4 §十四 Safety > progress）。 */
    uint32_t version;         /* 全局导航版本：任何影响导航的编辑 +1 */
    uint32_t revision;        /* 编辑次数 */
    /* 统计（M2/M3 报告用） */
    uint32_t full_rebuild_count;   /* 因增量不可靠而降级全量的次数 */
    uint32_t split_detected_count;
    uint32_t merge_detected_count;
    uint32_t split_relabel_cells;  /* M3：split 重标累计影响的格子数 */
    uint32_t split_multiway_count; /* M3：一次切成 >=3 组的次数 */
    uint32_t id_compaction_count;  /* M3：id 空间压缩（GC）次数 */
    /* M4.6-P3 归因：split 检测为什么放弃增量（全 0 = 从未发生）。
     * 这四条以前是**静默**的：返回 -1 就降级全量，调用方只知道「慢了」，
     * 不知道是 ring 里分量太多、还是单个分量 seed 太多、还是重标失败。 */
    uint32_t split_fail_ring;      /* ring 内「受影响且掉了格子」的分量 > 16 */
    uint32_t split_fail_seeds;     /* 单个分量的 ring seed > 256 */
    uint32_t split_fail_relabel;   /* component_split_relabel 失败（组数/内存） */
    uint32_t split_ring_single_at_fail; /* 最近一次 ring 失败时，n==1（不可能 split）的组数 */
    uint32_t detach_lost_overflow; /* 丢格子的分量 > 16 —— lost[] 被截断（以前是静默的） */
    /* M4.6-P4：大移除不再 100% 降级 —— 解锁区按连通块（patch）分别归属。
     * 下面三个是这条路径的常驻观测点：多块被正确处理是**正常**，只有 Fallback 非 0
     * 才说明又退回了「无法增量」。 */
    uint32_t merge_multipatch_count;     /* 一次移除切出 >1 块、且全部按块处理成功的次数 */
    uint32_t merge_multipatch_fallbacks; /* 单块邻接 >16 个分量 / 重标失败 -> 降级全量（安全网） */
    uint32_t relabel_rep_rescan;         /* component_rep 失效（rep 格被建筑压掉）后重扫的次数 */
    /* M4.6-P4：clearance 区域重算的边界校验（B5 的 clear_diffs 根因：
     * remove 后 rect 外一圈的向量指向了刚被清掉的障碍）。 */
    uint32_t clearance_stale_vectors;    /* 边界环上「向量指向已可走格」且标量已 clamp 的格子数 */
    uint32_t clearance_ring_fallbacks;   /* 陈旧向量的标量未 clamp -> pad 不够，降级全量 */
    int32_t  pending_comp;         /* M3.4：正在被 Job 重建的分量（-1 = 无）；查询遇到它返回 PENDING */

    /* ---- M3.5 版本体系 ----
     * 三个粒度，缺一不可：
     *   nav_epoch   : 每次**提交**（commit）成功 +1；用于诊断与大范围判定，不用于细粒度失效。
     *   chunk_ver[] : 只给本次提交真正影响的 chunk +1；路径/流场按依赖 chunk 校验。
     *   label_epoch : component id 空间被压缩（全量重编号）时 +1；
     *                 任何持有 component_id 的缓存都必须同时校验它，否则 ABA。
     */
    uint32_t nav_epoch;
    uint32_t label_epoch;
    uint32_t chunk_ver[RT_CHUNK_N];   /* 提交版本：只反映「已提交的导航几何」 */
    uint32_t edit_ver[RT_CHUNK_N];    /* 编辑版本：每次**编辑**就 +1，用于 Job 的依赖级 stale 判定 */
} RtGrid;

/* ---- Dirty 描述：每种派生数据的范围**分别**给出 ---- */
typedef struct {
    /* 直接编辑范围（格坐标，含端点） */
    int x0, z0, x1, z1;
    /* clearance/SSEDT 的重算范围（外扩 pad） */
    int cx0, cz0, cx1, cz1;
    int pad;
    /* 连通域需要检查 */
    int may_split;          /* 有格子从 free -> blocked */
    int may_merge;          /* 有格子从 blocked -> free */
    /* 受影响的 chunk 掩码（流场缓存失效用） */
    uint32_t chunk_mask[RT_CHUNK_MASK_WORDS];
    int      chunk_mask_any;
} RtGridDirty;

/* ---- 生命周期 ---- */
int  rt_grid_init(RtGrid *g, int w, int h, float cell);
void rt_grid_destroy(RtGrid *g);
void rt_grid_clear(RtGrid *g);

/* ---- 坐标换算 ---- */
int  rt_grid_cell_x(const RtGrid *g, float world_x);
int  rt_grid_cell_z(const RtGrid *g, float world_z);
static inline int rt_grid_in_bounds(const RtGrid *g, int x, int z)
{
    return (unsigned)x < (unsigned)g->w && (unsigned)z < (unsigned)g->h;
}

/* ---- 编辑（不触发派生数据更新，只改 base/overlay/flags + 记录 dirty） ---- */
void rt_grid_set_terrain(RtGrid *g, int x, int z, uint8_t flag_bits, int on);
/* 返回 RT_OK / RT_ERR_INVALID；dirty 可为 NULL（此时只改数据，不记录） */
int  rt_grid_add_building_dirty(RtGrid *g, int x0, int z0, int bw, int bh, RtGridDirty *dirty);
int  rt_grid_remove_building_dirty(RtGrid *g, int x0, int z0, int bw, int bh, RtGridDirty *dirty);
void rt_grid_clear_buildings(RtGrid *g);

/* 兼容旧接口（内部 = dirty 版本 + 立即 apply） */
int  rt_grid_add_building(RtGrid *g, int x0, int z0, int bw, int bh);
int  rt_grid_remove_building(RtGrid *g, int x0, int z0, int bw, int bh);

/* ---- 派生数据 ---- */
void rt_grid_rebuild_all(RtGrid *g);                  /* 全量（参考实现 / 降级） */
int  rt_grid_apply_dirty(RtGrid *g, RtGridDirty *d);  /* 增量 */

/* 单独暴露，便于差分测试逐项对比 */
void rt_grid_rebuild_clearance_full(RtGrid *g);
/* 返回 1 = 边界向量表明影响半径超出重算范围（调用方必须降级全量）；0 = 成功 */
int  rt_grid_rebuild_clearance_region(RtGrid *g, int x0, int z0, int x1, int z1);
void rt_grid_rebuild_components_full(RtGrid *g);

/* ---- 查询 ---- */
static inline int rt_grid_walkable(const RtGrid *g, int x, int z)
{
    if (!rt_grid_in_bounds(g, x, z)) return 0;
    uint8_t f = g->flags[z * g->w + x];
    return (f & (RT_CELL_BLOCKED_TERRAIN | RT_CELL_BLOCKED_BUILDING)) == 0;
}

float rt_grid_clearance_m(const RtGrid *g, int x, int z);
float rt_grid_clearance_world(const RtGrid *g, float wx, float wz);

int   rt_grid_obb_blocked(const RtGrid *g, const RtObb2 *o);
int   rt_grid_obb_clear_fast(const RtGrid *g, const RtObb2 *o);

int32_t rt_grid_component_at(const RtGrid *g, int x, int z);
int     rt_grid_same_component(const RtGrid *g, int x0, int z0, int x1, int z1);

/*
 * ⚠ Component ID 的语义（M3 明确定义，避免上层误用）：
 *
 *   `component[]` 是 **current connectivity label（当前连通标签）**，
 *   **不是** persistent navigation region identity（持久区域身份）。
 *
 *   - 同一片区域在 split/merge 后可能拿到不同 ID；
 *   - ID 只保证「当前这一帧内，同 ID ⟺ 连通」；
 *   - 上层（Gameplay / 存档 / 网络）**不得**把它当永久 ID 存储或比较；
 *   - null 语义：<0 表示不可走（-1）或临时状态（-2/-3）。
 *
 *   如果将来需要稳定身份，应另建 RegionID 层（M4+），而不是复用 component[]。
 */

/* ---- 统计 ---- */
typedef struct {
    int  walkable_cells;
    int  blocked_cells;
    int  component_count;
    int  largest_component_cells;
    float clearance_max_m;
    float clearance_mean_m;
} RtGridStats;
void rt_grid_stats(const RtGrid *g, RtGridStats *out);

/* ---- M3.4：Job 支持 ---- */
/* 取（必要时分配）分帧 Job 的复用 scratch。所有权归 grid；
 * 同一时刻只能有一个 Job 使用 —— 单线程调度下成立，多 Worker 化需要 per-job 缓冲。 */
int rt_grid_job_scratch(RtGrid *g, int32_t **queue, uint8_t **label);

/* 分配一个新的分量 id（只扩数组/增计数，不修改任何格子） */
int32_t rt_grid_alloc_component_id(RtGrid *g);
/* 暴露给 Job commit 使用 */
void    rt_grid_set_component_sizes(RtGrid *g, int32_t id, int32_t size, int32_t rep);

/* 查询状态：UNKNOWN 必须是合法状态（任务书 §十五） */
typedef enum {
    RT_QUERY_VALID = 0,
    RT_QUERY_UNREACHABLE = 1,
    RT_QUERY_PENDING = 2      /* 依赖正在重建的分量，调用方应稍后重试 */
} RtQueryState;

struct RtNavJob;
/* 异步入口（M3.4）：大分量的 split 交给可暂停的 Job；*job_out != NULL 表示未完成，
 * 需要调用方循环 rt_navjob_step() 然后 rt_navjob_commit()。
 * 注意：Live Obstacle（flags）在调用前已经生效，Job 期间物理上绝不穿墙。 */
int rt_grid_apply_dirty_async(RtGrid *g, RtGridDirty *d, struct RtNavJob **job_out);

/* 带状态的连通查询：任一格属于 pending 分量 -> PENDING（不返回错误的"可达"） */
int rt_grid_same_component_q(const RtGrid *g, int x0, int z0, int x1, int z1,
                             RtQueryState *st);

/* ---- M3.5：版本 ---- */
/* 提交一次导航变更：nav_epoch++，mask 覆盖的 chunk 各自 +1（其余不动）。 */
void rt_grid_note_commit(RtGrid *g, const uint32_t *chunk_mask);
/* 全量重建后的提交：所有 chunk 都视为变更（罕见，允许全失效）。 */
void rt_grid_note_commit_all(RtGrid *g);
/* 一次**编辑**（flags 已改）：只 bump 受影响 chunk 的 edit_ver。
 * Job 用它做「依赖级」stale 判定 —— 无关区域的编辑不应取消正在跑的任务。 */
void rt_grid_note_edit(RtGrid *g, const uint32_t *chunk_mask);

/* 合并两个 dirty（取 bbox，掩码/标志取并集）。用于 M3.7 编辑合并。 */
void rt_grid_dirty_merge(RtGrid *g, RtGridDirty *out,
                         const RtGridDirty *a, const RtGridDirty *b);

/* ---- chunk 掩码工具 ---- */
int  rt_grid_chunk_of_cell(const RtGrid *g, int x, int z);
void rt_grid_mask_set(uint32_t *mask, int chunk);
int  rt_grid_mask_test(const uint32_t *mask, int chunk);
int  rt_grid_mask_intersect(const uint32_t *a, const uint32_t *b);
void rt_grid_mask_clear(uint32_t *mask);
void rt_grid_mask_or(uint32_t *dst, const uint32_t *src);
int  rt_grid_mask_count(const uint32_t *mask);

#ifdef __cplusplus
}
#endif

#endif /* RT_GRID_H */

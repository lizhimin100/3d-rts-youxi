/* ============================================================================
 * test_m4.c -- M4.1 正确性测试（Global Route / MovementGroup / 共享）
 *
 * T1 单单位绕墙过门并抵达
 * T2 100 单位同目标：Global Route build 次数 <= 2
 * T3 1000 单位同目标：build 次数 <= 4（且 != N）
 * T4 clearance 类别：小单位走 2 m 捷径，大单位走 6 m 绕行
 * T5 非法目标（建筑内 / 地图外）-> nearest reachable
 * T6 目标在另一个连通分量（岛）-> 修正到本岛最近点，不是 UNREACHABLE
 * T7 多源区域：单位分散时不强制回中心点，build 数 = 去重源区域数
 * T8 连续 Move：旧命令的结果不能覆盖新命令
 * T9 动态建筑堵住走廊 -> route 失效并重建，且新路不穿墙
 * T10 无关区域编辑 -> route 不失效
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m4.c -o test_m4
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", m); } } while (0)

static uint64_t g_state = 0x4D34ull;
static uint64_t nu(void) {
    uint64_t z = (g_state += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
}

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;

/* ---- 地图构造 ---- */
static void map_init(int w, int noise_permille)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_grid_init(&G, w, w, 1.0f);
    g_state = 0xBEEF0000ull + (uint64_t)w;
    for (int z = 0; z < w; z++)
        for (int x = 0; x < w; x++)
            if ((nu() >> 40) % 1000 < (uint64_t)noise_permille)
                rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);
}

/* 竖墙 + 3 格门 */
static void map_wall_gate(int w)
{
    for (int z = 0; z < w; z++)
        if (z != w / 2) rt_grid_set_terrain(&G, w / 2, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int dz = -1; dz <= 1; dz++) {
        rt_grid_set_terrain(&G, w / 2 - 1, w / 2 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, w / 2,     w / 2 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, w / 2 + 1, w / 2 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
    }
    rt_grid_rebuild_all(&G);
}

static int world_build(void)
{
    rt_region_destroy(&MAP);
    int rc = rt_region_build(&MAP, &G, 8);
    if (rc != RT_OK) return rc;
    rt_gw_destroy(&W);
    rc = rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
    return rc;
}

/* 采样点是否可走（采样质量的最低要求） */
static int sample_walkable(RtVec2 p, int cls)
{
    int cx = rt_grid_cell_x(&G, p.x), cz = rt_grid_cell_z(&G, p.z);
    if (!rt_grid_walkable(&G, cx, cz)) return 0;
    return rt_grid_clearance_m(&G, cx, cz) + 1e-4f >= rt_clear_radius_m(cls);
}

/* 线段不穿墙：以 0.25 m 步长采样 */
static int segment_clear(RtVec2 a, RtVec2 b)
{
    float dx = b.x - a.x, dz = b.z - a.z;
    float len = sqrtf(dx * dx + dz * dz);
    int steps = (int)(len / 0.25f) + 1;
    for (int i = 0; i <= steps; i++) {
        float t = (float)i / (float)steps;
        int cx = rt_grid_cell_x(&G, a.x + dx * t);
        int cz = rt_grid_cell_z(&G, a.z + dz * t);
        if (!rt_grid_walkable(&G, cx, cz)) return 0;
    }
    return 1;
}

/* 用导航层驱动单位前进（无碰撞、无避障，只验证「方向对不对」） */
typedef struct { RtVec2 p; int group; float speed; int steps; int arrived; int penetrations; } Walker;

static void walk_step(Walker *wk)
{
    RtVec2 tgt;
    if (rt_gw_sample(&W, wk->group, wk->p, &tgt) != RT_OK) return;
    RtVec2 d = rt_v2_sub(tgt, wk->p);
    float len = rt_v2_len(d);
    if (len < 1e-4f) return;
    float step = wk->speed * (1.0f / 30.0f);
    if (step > len) step = len;
    RtVec2 np = rt_v2_add(wk->p, rt_v2_mul(d, step / len));
    if (!segment_clear(wk->p, np)) { wk->penetrations++; return; }
    wk->p = np;
    wk->steps++;
    if (rt_gw_is_arrived(&W, wk->group, wk->p, 1.5f)) wk->arrived = 1;
}

/* ========================================================================== */
static void t1_single_unit(void)
{
    printf("\n[T1] single unit around a wall through a 3-cell gate\n");
    map_init(256, 0);
    map_wall_gate(256);
    world_build();

    RtUnitId id = rt_units_spawn(&US, rt_v3(40.5f, 0.f, 128.5f), RT_FP_SMALL);
    OK(id != RT_UNIT_ID_NONE, "T1 spawn");
    RtUnitId ids[1] = { id };
    int rc = rt_gw_command(&W, &US, ids, 1, rt_v2(215.5f, 128.5f), 0, RT_CLS_SMALL, 1);
    OK(rc == RT_OK, "T1 command");
    OK(W.group_count == 1, "T1 one group");
    printf("  groups=%d builds=%u reuses=%u route_len=%d expanded=%d\n",
           W.group_count, W.stats.route_builds, W.stats.route_reuses,
           W.groups[0].routes[0].route.n, W.groups[0].routes[0].route.expanded);
    OK(W.stats.route_builds == 1, "T1 exactly one global route");
    OK(W.groups[0].state == RT_GROUP_NAV_READY, "T1 group ready");

    Walker wk = { rt_v2(40.5f, 128.5f), 0, 6.0f, 0, 0, 0 };
    for (int i = 0; i < 3000 && !wk.arrived; i++) walk_step(&wk);
    printf("  arrived=%d steps=%d penetrations=%d pos=(%.1f, %.1f)\n",
           wk.arrived, wk.steps, wk.penetrations, wk.p.x, wk.p.z);
    OK(wk.arrived, "T1 arrives");
    OK(wk.penetrations == 0, "T1 no wall penetration");
}

static void spawn_disc(RtUnitId *ids, int *n, int maxn, float cx, float cz, float r)
{
    *n = 0;
    for (int i = 0; i < maxn; i++) {
        /* 螺旋撒点，保证都落在可走格上 */
        float rad = r * sqrtf((float)i / (float)maxn);
        float ang = (float)i * 2.39996323f;
        int x = rt_grid_cell_x(&G, cx + cosf(ang) * rad);
        int z = rt_grid_cell_z(&G, cz + sinf(ang) * rad);
        if (!rt_grid_walkable(&G, x, z)) continue;
        RtUnitId id = rt_units_spawn(&US, rt_v3(((float)x) + 0.5f, 0.f, ((float)z) + 0.5f), RT_FP_SMALL);
        if (id != RT_UNIT_ID_NONE) ids[(*n)++] = id;
    }
}

static void t2_t3_scaling(void)
{
    static RtUnitId ids[1024];
    int counts[3] = { 100, 300, 1000 };
    printf("\n[T2/T3] same destination, compact spawn\n");
    for (int k = 0; k < 3; k++) {
        int n = counts[k];
        map_init(256, 0);
        map_wall_gate(256);
        world_build();
        spawn_disc(ids, &n, n, 50.f, 60.f, 12.f);
        int rc = rt_gw_command(&W, &US, ids, n, rt_v2(210.5f, 190.5f), 0, RT_CLS_SMALL, 1);
        printf("  units=%4d  groups=%d  builds=%u  reuses=%u  src_regions<=%d  rc=%d\n",
               n, W.group_count, W.stats.route_builds, W.stats.route_reuses,
               RT_GROUP_ROUTES_MAX, rc);
        OK(rc == RT_OK, "scaling command ok");
        OK(W.stats.route_builds + W.stats.route_reuses >= 1, "at least one route");
        /* M4.1 的口径：build 数 = **去重后的源区域数**（一个源区域一条共享 route），
         * 不是 1，也不是 N。12 m 半径的一簇大约跨 10 个 8 m 区域。
         * M4.3 的 goal-centric flow 会把它压到 1，本期不做。 */
        OK(W.stats.route_builds <= 16, "builds bounded by source regions");
        OK(W.stats.route_builds * 4 < (uint32_t)n, "builds << unit count");
    }
}

/* T4：2 m 捷径 vs 6 m 绕行 */
static void t4_clearance(void)
{
    printf("\n[T4] clearance classes take different corridors\n");
    const int Wsz = 256;
    map_init(Wsz, 0);

    /* 水平墙 z=128，中间开 2 m 宽的门（x 120..121）；右边远处开 6 m 的绕行门（x 200..205） */
    for (int x = 0; x < Wsz; x++) rt_grid_set_terrain(&G, x, 128, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int x = 120; x <= 121; x++) rt_grid_set_terrain(&G, x, 128, RT_CELL_BLOCKED_TERRAIN, 0);
    for (int x = 200; x <= 205; x++) {
        rt_grid_set_terrain(&G, x, 128, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, x, 127, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, x, 129, RT_CELL_BLOCKED_TERRAIN, 0);
    }
    rt_grid_rebuild_all(&G);
    world_build();

    struct { int cls; const char *name; } cases[3] = {
        { RT_CLS_SMALL,  "small(1m)" },
        { RT_CLS_MEDIUM, "medium(2m)" },
        { RT_CLS_LARGE,  "large(4m)"  },
    };
    int built_x[3];
    for (int c = 0; c < 3; c++) {
        rt_units_init(&US);
        RtUnitId id = rt_units_spawn(&US, rt_v3(40.5f, 0.f, 60.5f), RT_FP_SMALL);
        RtUnitId one[1] = { id };
        int rc = rt_gw_command(&W, &US, one, 1, rt_v2(40.5f, 200.5f), 0, (uint8_t)cases[c].cls, 1);
        int rlen = (rc == RT_OK && W.group_count > 0 && W.groups[0].route_count > 0)
                   ? W.groups[0].routes[0].route.n : -1;
        /* 穿越 z=128（region row 16）时的 x：判断走的是 2 m 门还是 6 m 绕行 */
        int cross_x = -1;
        if (rlen > 0) {
            RtRoute *r = &W.groups[0].routes[0].route;
            for (int i = 0; i < r->n; i++) {
                int rz = r->regions[i] / MAP.rw;
                if (rz >= 16) { cross_x = (r->regions[i] % MAP.rw) * 8; break; }
            }
        }
        built_x[c] = cross_x;
        printf("  %-10s rc=%d route_len=%d cross_x=%d\n",
               cases[c].name, rc, rlen, cross_x);
        OK(rc == RT_OK && rlen > 0, "T4 route built");
    }
    /* 小/中单位应走 x≈15 的捷径（120/8=15），大单位只能走 x≈25 的绕行（200/8=25） */
    OK(built_x[0] >= 112 && built_x[0] <= 128, "T4 small uses the 2m shortcut");
    OK(built_x[1] >= 112 && built_x[1] <= 128, "T4 medium uses the 2m shortcut");
    OK(built_x[2] >= 192, "T4 large detours to the 6m opening");
}

static void t5_invalid_dest(void)
{
    printf("\n[T5] invalid destination -> nearest reachable\n");
    map_init(256, 0);
    world_build();
    /* 在 (150..160) 放一栋楼，点它内部 */
    RtGridDirty d;
    rt_grid_add_building_dirty(&G, 150, 150, 10, 10, &d);
    rt_grid_apply_dirty(&G, &d);
    rt_region_refresh(&MAP);

    rt_units_init(&US);
    RtUnitId id = rt_units_spawn(&US, rt_v3(60.5f, 0.f, 60.5f), RT_FP_SMALL);
    RtUnitId one[1] = { id };
    int rc = rt_gw_command(&W, &US, one, 1, rt_v2(155.5f, 155.5f), 0, RT_CLS_SMALL, 1);
    RtMoveGroup *g = &W.groups[0];
    printf("  rc=%d state=%s goal=(%.1f, %.1f) corrections=%u\n",
           rc, rt_group_state_name(g->state), g->goal_pos.x, g->goal_pos.z, W.stats.goal_corrections);
    OK(rc == RT_OK, "T5 command accepted");
    OK(W.stats.goal_corrections >= 1, "T5 corrected to nearest reachable");
    OK(sample_walkable(g->goal_pos, RT_CLS_SMALL), "T5 goal is walkable");
    int gx = rt_grid_cell_x(&G, 155), gz = rt_grid_cell_z(&G, 155);
    OK(rt_grid_walkable(&G, gx, gz) == 0, "T5 original click was inside the building");
    /* 地图外 */
    rc = rt_gw_command(&W, &US, one, 1, rt_v2(-50.f, 900.f), 0, RT_CLS_SMALL, 2);
    printf("  outside: rc=%d goal=(%.1f, %.1f)\n", rc, W.groups[0].goal_pos.x, W.groups[0].goal_pos.z);
    OK(rc == RT_OK, "T5 outside click accepted");
    OK(sample_walkable(W.groups[0].goal_pos, RT_CLS_SMALL), "T5 outside -> walkable goal");
}

static void t6_island(void)
{
    printf("\n[T6] target on another island -> nearest point on own island\n");
    map_init(256, 0);
    /* 用一圈墙把 (180..220) 围成孤岛 */
    for (int i = 178; i <= 222; i++) {
        rt_grid_set_terrain(&G, i, 178, RT_CELL_BLOCKED_TERRAIN, 1);
        rt_grid_set_terrain(&G, i, 222, RT_CELL_BLOCKED_TERRAIN, 1);
        rt_grid_set_terrain(&G, 178, i, RT_CELL_BLOCKED_TERRAIN, 1);
        rt_grid_set_terrain(&G, 222, i, RT_CELL_BLOCKED_TERRAIN, 1);
    }
    rt_grid_rebuild_all(&G);
    world_build();

    rt_units_init(&US);
    RtUnitId id = rt_units_spawn(&US, rt_v3(60.5f, 0.f, 60.5f), RT_FP_SMALL);
    RtUnitId one[1] = { id };
    int rc = rt_gw_command(&W, &US, one, 1, rt_v2(200.5f, 200.5f), 0, RT_CLS_SMALL, 1);
    RtMoveGroup *g = &W.groups[0];
    int32_t goal_comp = rt_grid_component_at(&G,
        rt_grid_cell_x(&G, g->goal_pos.x), rt_grid_cell_z(&G, g->goal_pos.z));
    int32_t unit_comp = rt_grid_component_at(&G, 60, 60);
    printf("  rc=%d state=%s goal=(%.1f, %.1f) comp %d vs unit comp %d\n",
           rc, rt_group_state_name(g->state), g->goal_pos.x, g->goal_pos.z, goal_comp, unit_comp);
    OK(rc == RT_OK, "T6 accepted");
    OK(goal_comp == unit_comp, "T6 goal is on the unit's own component");
    OK(g->state != RT_GROUP_UNREACHABLE, "T6 movable (not marked unreachable)");
}

static void t7_multisource(void)
{
    printf("\n[T7] multi-source group: no gather point, builds = distinct source regions\n");
    map_init(256, 0);
    world_build();
    static RtUnitId ids[300];
    int n = 0;
    /* 三簇：左上、左下、右下 */
    float cx[3] = { 40.f, 40.f, 200.f }, cz[3] = { 40.f, 200.f, 200.f };
    for (int c = 0; c < 3; c++) {
        for (int i = 0; i < 100; i++) {
            float ang = (float)i * 2.39996323f;
            float rad = 6.f * sqrtf((float)i / 100.f);
            int x = rt_grid_cell_x(&G, cx[c] + cosf(ang) * rad);
            int z = rt_grid_cell_z(&G, cz[c] + sinf(ang) * rad);
            if (!rt_grid_walkable(&G, x, z)) continue;
            RtUnitId id = rt_units_spawn(&US, rt_v3(x + 0.5f, 0.f, z + 0.5f), RT_FP_SMALL);
            if (id != RT_UNIT_ID_NONE) ids[n++] = id;
        }
    }
    int rc = rt_gw_command(&W, &US, ids, n, rt_v2(128.5f, 128.5f), 0, RT_CLS_SMALL, 1);
    printf("  units=%d groups=%d builds=%u reuses=%u routes_in_group0=%d\n",
           n, W.group_count, W.stats.route_builds, W.stats.route_reuses,
           W.group_count > 0 ? W.groups[0].route_count : -1);
    OK(rc == RT_OK, "T7 command");
    /* 每个组最多 4 个源区域，超了就再开一组（同类别同分量）。
     * 关键是 build 数 ≈ 源区域数，远小于单位数。 */
    OK(W.group_count >= 1 && W.group_count <= 6, "T7 groups bounded by source regions");
    OK(W.stats.route_builds <= 12, "T7 builds bounded by route slots, not by units");

    /* 判据不是「第一步必须指向目标」（绕角时第一步可以垂直），而是
     * 「下一步必须是**局部**的，不能是把人拉向某个集合点的长跳」。
     * 注意：每个单位要用**自己所属的组**去采样（group 字段由 command 写入）。 */
    int toward = 0, total = 0, max_jump = 0;
    for (int i = 0; i < n; i += 7) {
        RtVec3 p = rt_units_pos(&US, ids[i]);
        RtVec2 pos = rt_v2(p.x, p.z), tgt;
        RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[i]);
        int gi = (int)ch->group[rt_unit_slot_index(ids[i])] - 1;
        if (gi < 0 || gi >= W.group_count) continue;
        if (rt_gw_sample(&W, gi, pos, &tgt) != RT_OK) continue;
        total++;
        float d = rt_v2_len(rt_v2_sub(tgt, pos));
        if (d > max_jump) max_jump = (int)d;
        RtVec2 a = rt_v2_sub(tgt, pos);
        RtVec2 b = rt_v2_sub(W.groups[0].goal_pos, pos);
        if (rt_v2_dot(a, b) > 0.f) toward++;
    }
    printf("  sampled=%d toward_goal=%d max_step=%.1f m\n", total, toward, (float)max_jump);
    OK(total > 0, "T7 sampled");
    OK(max_jump <= 20, "T7 next step is local (no gather point)");
    OK(toward * 5 >= total * 4, "T7 >=80% of samples point toward the goal");
}

static void t8_command_version(void)
{
    printf("\n[T8] new Move command supersedes the old one\n");
    map_init(256, 0);
    world_build();
    rt_units_init(&US);
    RtUnitId id = rt_units_spawn(&US, rt_v3(60.5f, 0.f, 60.5f), RT_FP_SMALL);
    RtUnitId one[1] = { id };

    rt_gw_command(&W, &US, one, 1, rt_v2(100.5f, 60.5f), 0, RT_CLS_SMALL, 1);
    RtVec2 goal_a = W.groups[0].goal_pos;
    rt_gw_command(&W, &US, one, 1, rt_v2(60.5f, 200.5f), 0, RT_CLS_SMALL, 2);
    RtVec2 goal_b = W.groups[0].goal_pos;
    printf("  version=%u goalA=(%.1f,%.1f) goalB=(%.1f,%.1f)\n",
           W.groups[0].command_version, goal_a.x, goal_a.z, goal_b.x, goal_b.z);
    OK(W.groups[0].command_version == 2, "T8 command_version updated");
    OK(fabsf(goal_b.z - goal_a.z) > 100.f, "T8 goal replaced by the new command");
    OK(W.stats.route_builds >= 1, "T8 new route built for the new goal");
}

static void t9_dynamic_block(void)
{
    printf("\n[T9] dynamic building blocks the corridor -> rebuild, no penetration\n");
    map_init(256, 0);
    map_wall_gate(256);
    world_build();
    rt_units_init(&US);
    RtUnitId id = rt_units_spawn(&US, rt_v3(60.5f, 0.f, 128.5f), RT_FP_SMALL);
    RtUnitId one[1] = { id };
    rt_gw_command(&W, &US, one, 1, rt_v2(210.5f, 128.5f), 0, RT_CLS_SMALL, 1);
    int n0 = W.groups[0].routes[0].route.n;
    OK(rt_route_valid(&W.groups[0].routes[0].route, &G), "T9 route initially valid");

    /* 在门后 10 米处建一栋 6x6 的楼，正好压在走廊上 */
    RtGridDirty d;
    rt_grid_add_building_dirty(&G, 140, 125, 8, 8, &d);
    rt_grid_apply_dirty(&G, &d);
    rt_region_refresh(&MAP);
    printf("  invalid after edit = %d\n", rt_route_valid(&W.groups[0].routes[0].route, &G));
    OK(rt_route_valid(&W.groups[0].routes[0].route, &G) == 0, "T9 route became invalid");

    int rebuilt = rt_gw_update(&W);
    printf("  rebuilt=%d stale=%u builds=%u new_len=%d\n",
           rebuilt, W.stats.route_stale, W.stats.route_builds, W.groups[0].routes[0].route.n);
    OK(rebuilt == 1, "T9 group rebased");
    OK(W.stats.route_stale >= 1, "T9 stale counted");
    OK(rt_route_valid(&W.groups[0].routes[0].route, &G), "T9 new route valid");

    /* 沿新路走，不许穿墙；楼在 z=125..132，路应绕到 z<125 或 z>132 */
    Walker wk = { rt_v2(60.5f, 128.5f), 0, 6.0f, 0, 0, 0 };
    for (int i = 0; i < 4000 && !wk.arrived; i++) walk_step(&wk);
    printf("  arrived=%d steps=%d penetrations=%d pos=(%.1f,%.1f) old_len=%d\n",
           wk.arrived, wk.steps, wk.penetrations, wk.p.x, wk.p.z, n0);
    OK(wk.penetrations == 0, "T9 no wall penetration after rebuild");
    OK(wk.arrived, "T9 arrives through the new route");
}

static void t10_unrelated_edit(void)
{
    printf("\n[T10] edit far from the corridor must not invalidate the route\n");
    map_init(256, 0);
    map_wall_gate(256);
    world_build();
    rt_units_init(&US);
    RtUnitId id = rt_units_spawn(&US, rt_v3(60.5f, 0.f, 128.5f), RT_FP_SMALL);
    RtUnitId one[1] = { id };
    rt_gw_command(&W, &US, one, 1, rt_v2(200.5f, 128.5f), 0, RT_CLS_SMALL, 1);
    OK(rt_route_valid(&W.groups[0].routes[0].route, &G), "T10 valid before");

    /* 在地图上方（y≈10，走廊在 z≈128）建一栋楼，离走廊 10 个 chunk */
    RtGridDirty d;
    rt_grid_add_building_dirty(&G, 60, 10, 6, 6, &d);
    rt_grid_apply_dirty(&G, &d);
    int still_valid = rt_route_valid(&W.groups[0].routes[0].route, &G);
    int rebuilt = rt_gw_update(&W);
    printf("  valid after unrelated edit = %d, rebuilt=%d\n", still_valid, rebuilt);
    OK(still_valid == 1, "T10 unrelated edit keeps route valid");
    OK(rebuilt == 0, "T10 no rebuild");
}

int main(void)
{
    timer_init();
    printf("=== M4.1 tests: Global Route / MovementGroup / sharing ===\n");

    t1_single_unit();
    t2_t3_scaling();
    t4_clearance();
    t5_invalid_dest();
    t6_island();
    t7_multisource();
    t8_command_version();
    t9_dynamic_block();
    t10_unrelated_edit();

    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}

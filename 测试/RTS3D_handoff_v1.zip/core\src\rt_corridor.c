/* ============================================================================
 * rt_corridor.c -- 窄通道所有权（FR-STK-3，M10 / M11）
 * 设计口径见 rt_corridor.h 顶部。
 * ==========================================================================*/
#include "rt_corridor.h"
#include "rt_math.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

int rt_corr_init(RtCorrCtx *ctx, int max_corridors, float hold_ttl, float max_hold)
{
    if (!ctx || max_corridors <= 0) return RT_ERR_INVALID;
    memset(ctx, 0, sizeof(*ctx));
    ctx->c = (RtCorridor *)calloc((size_t)max_corridors, sizeof(RtCorridor));
    if (!ctx->c) return RT_ERR_CAPACITY;
    ctx->cap = max_corridors;
    ctx->hold_ttl = (hold_ttl > 0.f) ? hold_ttl : 4.0f;
    ctx->max_hold = (max_hold > 0.f) ? max_hold : 30.0f;
    ctx->gate_radius = 28.0f;
    ctx->staging_slack = 1.2f;
    ctx->stall_limit = 20.0f;
    for (int i = 0; i < max_corridors; i++) {
        ctx->c[i].owner = -1;
        for (int k = 0; k < RT_CORR_MAX_TEAMS; k++) ctx->c[i].want[k] = -1.f;
    }
    return RT_OK;
}

void rt_corr_destroy(RtCorrCtx *ctx)
{
    if (!ctx) return;
    free(ctx->c);
    ctx->c = NULL;
    ctx->cap = ctx->n = 0;
}

/* 清空所有通道（保留缓冲区）。用于「关卡编辑后重新注册」：
 * 通道几何变了，旧的所有权与等待区都不再有意义，重新排队是唯一正确的语义。
 * 统计计数（grants/expires/...）属于旧的通道，一并清零 —— 调用方要留档请先读。 */
void rt_corr_clear_all(RtCorrCtx *ctx)
{
    if (!ctx || !ctx->c) return;
    for (int i = 0; i < ctx->cap; i++) {
        memset(&ctx->c[i], 0, sizeof(RtCorridor));
        ctx->c[i].owner = -1;
        for (int k = 0; k < RT_CORR_MAX_TEAMS; k++) ctx->c[i].want[k] = -1.f;
    }
    ctx->n = 0;
}

int rt_corr_add(RtCorrCtx *ctx, float x0, float z0, float x1, float z1, int axis){
    if (!ctx || ctx->n >= ctx->cap) return -1;
    RtCorridor *c = &ctx->c[ctx->n];
    memset(c, 0, sizeof(*c));
    c->x0 = (x0 < x1) ? x0 : x1;
    c->x1 = (x0 < x1) ? x1 : x0;
    c->z0 = (z0 < z1) ? z0 : z1;
    c->z1 = (z0 < z1) ? z1 : z0;
    c->axis = axis;
    c->owner = -1;
    for (int k = 0; k < RT_CORR_MAX_TEAMS; k++) c->want[k] = -1.f;
    return ctx->n++;
}

void rt_corr_set_staging(RtCorrCtx *ctx, int cid, int side,
                         float x0, float z0, float x1, float z1)
{
    if (!ctx || cid < 0 || cid >= ctx->n || side < 0 || side > 1) return;
    RtCorridor *c = &ctx->c[cid];
    c->stg[side][0] = (x0 < x1) ? x0 : x1;
    c->stg[side][1] = (z0 < z1) ? z0 : z1;
    c->stg[side][2] = (x0 < x1) ? x1 : x0;
    c->stg[side][3] = (z0 < z1) ? z1 : z0;
    c->has_stg[side] = 1;
}

void rt_corr_set_gate_params(RtCorrCtx *ctx, float gate_radius, float staging_slack){
    if (!ctx) return;
    if (gate_radius > 0.f) ctx->gate_radius = gate_radius;
    if (staging_slack > 0.f) ctx->staging_slack = staging_slack;
}

void rt_corr_set_stall_limit(RtCorrCtx *ctx, float seconds)
{
    if (!ctx) return;
    ctx->stall_limit = (seconds > 0.f) ? seconds : 0.f;
}

int rt_corr_contains(const RtCorridor *c, RtVec2 p)
{
    if (!c) return 0;
    return p.x >= c->x0 && p.x <= c->x1 && p.z >= c->z0 && p.z <= c->z1;
}

int rt_corr_side(const RtCorridor *c, RtVec2 p)
{
    if (!c) return 0;
    if (c->axis == 0) {
        if (p.x < c->x0) return 0;
        if (p.x > c->x1) return 1;
        return -1;
    }
    if (p.z < c->z0) return 0;
    if (p.z > c->z1) return 1;
    return -1;
}

RtVec2 rt_corr_staging_point(const RtCorrCtx *ctx, int cid, int side,
                             int slot, int nslots)
{
    if (!ctx || cid < 0 || cid >= ctx->n) return rt_v2(0.f, 0.f);
    const RtCorridor *c = &ctx->c[cid];
    side = (side == 1) ? 1 : 0;
    if (!c->has_stg[side]) {
        /* 没注册等待区：退化为入口外 6 m 的中心点（显式的兜底，不是随便走）。 */
        if (c->axis == 0) {
            float x = (side == 0) ? (c->x0 - 6.f) : (c->x1 + 6.f);
            return rt_v2(x, (c->z0 + c->z1) * 0.5f);
        }
        float z = (side == 0) ? (c->z0 - 6.f) : (c->z1 + 6.f);
        return rt_v2((c->x0 + c->x1) * 0.5f, z);
    }
    if (nslots < 1) nslots = 1;
    if (slot < 0) slot = 0;
    if (slot >= nslots) slot %= nslots;

    int cols = (int)ceilf(sqrtf((float)nslots));
    if (cols < 1) cols = 1;
    int rows = (nslots + cols - 1) / cols;
    if (rows < 1) rows = 1;
    int cx = slot % cols;
    int cz = slot / cols;
    float u = (cols > 1) ? (float)cx / (float)(cols - 1) : 0.5f;
    float v = (rows > 1) ? (float)cz / (float)(rows - 1) : 0.5f;
    return rt_v2(c->stg[side][0] + u * (c->stg[side][2] - c->stg[side][0]),
                 c->stg[side][1] + v * (c->stg[side][3] - c->stg[side][1]));
}

int rt_corr_request(RtCorrCtx *ctx, int cid, int team)
{
    if (!ctx || cid < 0 || cid >= ctx->n) return 0;
    RtCorridor *c = &ctx->c[cid];
    if (c->owner < 0) {
        c->owner = team;
        c->ttl = ctx->max_hold;
        c->held = 0.f;
        c->idle_t = 0.f;
        c->last_passed = -1;
        c->stall_t = 0.f;
        c->grants++;
        return 1;
    }
    if (c->owner == team) return 1;
    c->denials++;
    return 0;
}

int rt_corr_allowed(const RtCorrCtx *ctx, int cid, int team)
{
    if (!ctx || cid < 0 || cid >= ctx->n) return 1;   /* 没注册 = 不限制 */
    return ctx->c[cid].owner == team;
}

void rt_corr_release(RtCorrCtx *ctx, int cid, int team)
{
    if (!ctx || cid < 0 || cid >= ctx->n) return;
    RtCorridor *c = &ctx->c[cid];
    if (c->owner != team) return;
    c->owner = -1;
    c->ttl = 0.f;
    c->held = c->idle_t = 0.f;
    c->inside = 0;
    c->last_passed = -1;
    c->stall_t = 0.f;
}

/* ---- FCFS ---- */

void rt_corr_want(RtCorrCtx *ctx, int cid, int team, float t)
{
    if (!ctx || cid < 0 || cid >= ctx->n) return;
    if (team < 0 || team >= RT_CORR_MAX_TEAMS) return;
    RtCorridor *c = &ctx->c[cid];
    if (c->want[team] < 0.f) c->want[team] = t;
}

void rt_corr_unwant(RtCorrCtx *ctx, int cid, int team)
{
    if (!ctx || cid < 0 || cid >= ctx->n) return;
    if (team < 0 || team >= RT_CORR_MAX_TEAMS) return;
    ctx->c[cid].want[team] = -1.f;
}

int rt_corr_acquire(RtCorrCtx *ctx, int cid)
{
    if (!ctx || cid < 0 || cid >= ctx->n) return -1;
    RtCorridor *c = &ctx->c[cid];
    if (c->owner >= 0) return c->owner;

    int best = -1;
    float best_t = 0.f;
    for (int k = 0; k < RT_CORR_MAX_TEAMS; k++) {
        if (c->want[k] < 0.f) continue;
        if (best < 0 || c->want[k] < best_t) { best = k; best_t = c->want[k]; }
    }
    if (best < 0) return -1;

    c->owner = best;
    c->ttl = ctx->max_hold;
    c->held = 0.f;
    c->idle_t = 0.f;
    c->inside = 0;
    c->last_passed = -1;
    c->stall_t = 0.f;
    c->grants++;
    c->handoffs++;
    c->want[best] = -1.f;        /* 已授予，退出排队 */
    return best;
}

/* ---- 门控 ---- */

RtVec2 rt_corr_gate(const RtCorrCtx *ctx, int cid, int team,
                    RtVec2 pos, RtVec2 pref, RtVec2 wait_pt)
{
    if (!ctx || cid < 0 || cid >= ctx->n) return pref;
    const RtCorridor *c = &ctx->c[cid];
    if (c->owner < 0 || c->owner == team) return pref;

    float sp = rt_v2_len(pref);
    int side = rt_corr_side(c, pos);

    if (side < 0) {
        /* 已在通道内却不是 owner（极少：上一轮 owner 的最后一人）。
         * 推向**最近的一端**出去，绝不逆着 owner 的车流走。 */
        float to0 = (c->axis == 0) ? (pos.x - c->x0) : (pos.z - c->z0);
        float to1 = (c->axis == 0) ? (c->x1 - pos.x) : (c->z1 - pos.z);
        float dir = (to0 < to1) ? -1.f : 1.f;
        if (sp <= 1e-4f) return pref;
        return (c->axis == 0) ? rt_v2(dir * sp, 0.f) : rt_v2(0.f, dir * sp);
    }

    /* 是否正朝门里走 + 离入口多远 */
    float along, at, entry;
    if (c->axis == 0) {
        along = (side == 0) ? pref.x : -pref.x;
        at = pos.x;
        entry = (side == 0) ? c->x0 : c->x1;
    } else {
        along = (side == 0) ? pref.z : -pref.z;
        at = pos.z;
        entry = (side == 0) ? c->z0 : c->z1;
    }
    float d_entry = fabsf(at - entry);
    if (d_entry > ctx->gate_radius) return pref;
    if (along <= 0.f) return pref;      /* 不是在往门里走 */

    RtVec2 d = rt_v2_sub(wait_pt, pos);
    float l = rt_v2_len(d);
    if (l < ctx->staging_slack) return rt_v2(0.f, 0.f);
    if (sp <= 1e-4f) return pref;
    return rt_v2_mul(d, sp / l);
}

void rt_corr_note_pending(RtCorrCtx *ctx, int cid, int owner_units_pending)
{
    if (!ctx || cid < 0 || cid >= ctx->n) return;
    RtCorridor *c = &ctx->c[cid];
    if (owner_units_pending < 0) owner_units_pending = 0;
    /* 单参数接口没有进度信息：`passed = -1` 显式表示「未知」，stall 判定退出。
     * 不能靠「总数下降」推：管道饱和时「走一个、来一个」，总数恒定，
     * 会被误判成占着不走（M10 的脚本场景因此从 12/12 掉到 0/12）。 */
    c->passed = -1;
    c->inside = owner_units_pending;
    c->near = owner_units_pending;
}

void rt_corr_note_pending2(RtCorrCtx *ctx, int cid, int total, int near)
{
    if (!ctx || cid < 0 || cid >= ctx->n) return;
    if (total < 0) total = 0;
    if (near < 0) near = 0;
    if (near > total) near = total;
    ctx->c[cid].inside = total;
    ctx->c[cid].near = near;
}

void rt_corr_note_state(RtCorrCtx *ctx, int cid, int total, int near, int passed)
{
    if (!ctx || cid < 0 || cid >= ctx->n) return;
    if (total < 0) total = 0;
    if (near < 0) near = 0;
    if (near > total) near = total;
    if (passed < 0) passed = 0;
    RtCorridor *c = &ctx->c[cid];
    c->inside = total;
    c->near = near;
    c->passed = passed;
}

void rt_corr_tick(RtCorrCtx *ctx, float dt)
{
    if (!ctx || dt <= 0.f) return;
    for (int i = 0; i < ctx->n; i++) {
        RtCorridor *c = &ctx->c[i];
        if (c->owner < 0) continue;
        c->held += dt;
        c->ttl = (ctx->max_hold > c->held) ? (ctx->max_hold - c->held) : 0.f;

        if (c->inside <= 0) {
            /* 队伍已全部离开：0.3 s 后释放，给尾巴留一点余量，
             * 避免「最后一个刚出门，对面就冲进来」把它堵回去。 */
            c->idle_t += dt;
            c->stall_t = 0.f;
            c->last_passed = c->passed;
            if (c->idle_t >= 0.3f) {
                c->owner = -1;
                c->ttl = 0.f;
                c->held = c->idle_t = 0.f;
                c->last_passed = -1;
            }
        } else {
            c->idle_t = 0.f;

            /* 「占着不走」= 门口有人在等（near>0）但**一个人都没通过**（passed 不涨）。
             * 不能用 pending 总数（队伍还在 100 m 外走过来，20 s 不降 -> 假警报），
             * 也不能用 near（管道饱和时「走一个、来一个」计数恒定 -> 假警报）。
             * passed < 0 表示调用方没提供进度（旧接口），此时不做 stall 判定。 */
            int has_progress = (c->passed >= 0);
            if (!has_progress) {
                c->stall_t = 0.f;
                c->last_passed = -1;
            } else if (c->last_passed < 0) {
                c->last_passed = c->passed;
                c->stall_t = 0.f;
            } else if (c->near <= 0) {
                c->stall_t = 0.f;
                c->last_passed = c->passed;
            } else if (c->passed > c->last_passed) {
                c->last_passed = c->passed;
                c->stall_t = 0.f;
            } else {
                c->stall_t += dt;
            }

            int stalled = has_progress && (ctx->stall_limit > 0.f) &&
                          (c->near > 0) &&
                          (c->stall_t >= ctx->stall_limit);
            if (stalled || (c->held > ctx->max_hold)) {
                if (stalled) c->stalls++; else c->expires++;
                c->owner = -1;
                c->ttl = 0.f;
                c->held = c->idle_t = 0.f;
                c->inside = 0;
                c->last_passed = -1;
                c->stall_t = 0.f;
            }
        }
    }
}

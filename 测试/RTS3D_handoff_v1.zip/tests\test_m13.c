/* ============================================================================
 * test_m13.c -- 局部规划器（地形绕行 / wall-following）
 *
 * 要回答的问题（M11b §6 留下的第 1 条）：
 *   凹角处的极限环没有局部解 —— 「往左还是往右」在几何对称时任何局部指标都分不出来，
 *   所以只能沿墙跟随。本文件用**同一个台架跑两遍**（接/不接 rt_plan_step）来证明：
 *
 *   T1 墙 + 2 m 缺口，单位斜对着墙（M11 掉队单位的最小化）  -> 对照组卡在墙前，规划组穿过
 *   T2 同一道墙、8 人小队，偏移 12 m                          -> 整队都找得到缺口
 *   T3 封闭房间（目标在别的连通分量）                          -> 规划层必须**拒绝**绕行，
 *                                                              且 give-up 仍在 10~30 s
 *   T4 开阔地 200 人                                          -> 规划层完全不介入
 *   T5 1000 人 + 12 格门（真导航流水线）                       -> 不拖慢、不减少到达
 *   T6 确定性
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_stuck.h"
#include "rt_yield.h"
#include "rt_plan.h"
#include "rt_region.h"
#include "rt_group.h"
#include "rt_unit.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", (m)); } } while (0)

#define MAXA 1100
#define GW 256
#define GH 256

static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;
static RtStuckCtx SC;
static RtStuckHooks HK;
static RtYieldCtx YC;
static RtPlanCtx PL;
static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static RtUnitId IDS[MAXA];
static RtVec2 AIM[MAXA];
static RtVec2 GOAL[MAXA];
static uint8_t DONE[MAXA];
static int N = 0;

static int cmp_double(const void *a, const void *b)
{
    double x = *(const double *)a, y = *(const double *)b;
    return (x < y) ? -1 : (x > y) ? 1 : 0;
}

typedef struct {
    int    arrived;
    int    engaged;
    int    finished;
    int    exhausted;
    int    no_exit;
    int    unreachable;
    int    active_max;
    double frames;
    double plan_ms, plan_max_ms, nav_ms;
    double plan_p99_ms;      /* M16：P99 比 max 稳，比 mean 诚实（见 M9 的结论） */
    int    plan_over8;       /* 单帧 plan 超过 8 ms 预算的帧数 */
    int    gave_up_frame;
    double t_stuck_s;
    uint32_t perm;
    uint32_t lvl_fires[7];
    float  min_dist;
} Metrics;

/* ---------------------------------------------------------------------------
 * 世界
 * -------------------------------------------------------------------------*/
static void world_reset(void)
{
    rt_grid_destroy(&G);
    rt_grid_init(&G, GW, GH, 1.0f);
    rt_grid_rebuild_all(&G);
    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
    rt_local_destroy(&LC);
    rt_local_init(&LC, (float)GW, (float)GH, MAXA, 4.5f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);
    rt_stuck_destroy(&SC);
    rt_stuck_init(&SC, MAXA, NULL);
    rt_yield_destroy(&YC);
    rt_yield_init(&YC, MAXA, NULL, &G);
    rt_plan_destroy(&PL);
    rt_plan_init(&PL, MAXA, NULL);
    memset(&HK, 0, sizeof(HK));
    HK.local_repath = rt_plan_hook;
    HK.ud = &PL;
    N = 0;
}

/* 一道竖墙 x=wx，z 方向除 [gap_z0, gap_z1] 之外全部阻塞 */
static void wall_vertical(int wx, int gap_z0, int gap_z1)
{
    for (int z = 0; z < GH; z++) {
        if (z >= gap_z0 && z <= gap_z1) continue;
        rt_grid_set_terrain(&G, wx, z, RT_CELL_BLOCKED_TERRAIN, 1);
    }
}

/* 封闭房间：四面墙，内部 x0..x1 / z0..z1 */
static void wall_room(int x0, int z0, int x1, int z1)
{
    for (int x = x0; x <= x1; x++) {
        rt_grid_set_terrain(&G, x, z0, RT_CELL_BLOCKED_TERRAIN, 1);
        rt_grid_set_terrain(&G, x, z1, RT_CELL_BLOCKED_TERRAIN, 1);
    }
    for (int z = z0; z <= z1; z++) {
        rt_grid_set_terrain(&G, x0, z, RT_CELL_BLOCKED_TERRAIN, 1);
        rt_grid_set_terrain(&G, x1, z, RT_CELL_BLOCKED_TERRAIN, 1);
    }
}

static void spawn(int n, float x0, float z0, int cols, float pitch)
{
    N = 0;
    for (int i = 0; i < n; i++) {
        float x = x0 + (float)(i % cols) * pitch;
        float z = z0 + (float)(i / cols) * pitch;
        RtUnitId id = rt_units_spawn(&US, rt_v3(x, 0.f, z), RT_FP_SMALL);
        if (id == RT_UNIT_ID_NONE) break;
        IDS[N] = id;
        DONE[N] = 0;
        memset(&AG[N], 0, sizeof(AG[N]));
        AG[N].pos = rt_v2(x, z);
        AG[N].radius = 0.5f;
        AG[N].max_speed = 2.0f;
        AG[N].fp = 1.0f;
        AG[N].share = 0.5f;
        AG[N].inv_mass = 1.f;
        N++;
    }
}

/* ---------------------------------------------------------------------------
 * 一个场景跑一遍
 *   use_nav = 1：aim 来自 rt_gw_sample（真流水线）
 *   use_nav = 0：aim = 朝目标 8 m 的前瞻点（隔离局部层）
 * -------------------------------------------------------------------------*/
static Metrics run(const char *name, int use_plan, int use_nav, RtVec2 goal,
                   int frames_max, float arrive_r, int verbose)
{
    Metrics m;
    memset(&m, 0, sizeof(m));
    const float dt = 1.f / 30.f;
    const float LOOKAHEAD = 8.0f;

    for (int i = 0; i < N; i++) {
        AIM[i] = goal;
        GOAL[i] = goal;
        rt_plan_reset(&PL, i);
        rt_stuck_reset(&SC, i);
    }
    if (use_nav) {
        (void)rt_gw_command(&W, &US, IDS, N, goal, 0, RT_CLS_SMALL, 1);
    }

    double nav = 0, plan = 0, plan_max = 0;
    int frames = 0;
    m.gave_up_frame = -1;

    /* 单帧 plan 耗时的样本（只用于 P99；T5 最长 5565 帧，16384 够） */
    static double PSAMP[16384];
    int NSAMP = 0;
    int over8 = 0;

    for (int s = 0; s < frames_max; s++) {
        frames = s;

        for (int i = 0; i < N; i++) {
            if (DONE[i]) { AG[i].pref_vel = rt_v2(0.f, 0.f); continue; }

            RtVec2 aim = goal;
            if (use_nav) {
                RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, IDS[i]);
                int gi = (int)ch->group[rt_unit_slot_index(IDS[i])] - 1;
                if (gi >= 0) {
                    RtVec2 tgt;
                    if (rt_gw_sample(&W, gi, AG[i].pos, &tgt) == RT_OK) aim = tgt;
                }
            } else {
                RtVec2 d = rt_v2_sub(goal, AG[i].pos);
                float l = rt_v2_len(d);
                if (l > LOOKAHEAD) aim = rt_v2_add(AG[i].pos, rt_v2_mul(d, LOOKAHEAD / l));
            }
            AIM[i] = aim;

            RtVec2 d = rt_v2_sub(aim, AG[i].pos);
            float l = rt_v2_len(d);
            AG[i].pref_vel = (l > 1e-3f) ? rt_v2_mul(d, 2.0f / l) : rt_v2(0.f, 0.f);
        }

        double p0 = now_ms();
        int active = 0;
        if (use_plan) active = rt_plan_step(&PL, AG, N, AIM, GOAL, &G, dt);
        double p1 = now_ms();
        plan += p1 - p0;
        if (p1 - p0 > plan_max) plan_max = p1 - p0;
        if (use_plan) {
            if (NSAMP < (int)(sizeof(PSAMP) / sizeof(PSAMP[0]))) PSAMP[NSAMP++] = p1 - p0;
            if (p1 - p0 > 8.0) over8++;
        }
        if (active > m.active_max) m.active_max = active;

        rt_stuck_step(&SC, AG, N, &G, dt, use_plan ? &HK : NULL);
        rt_yield_step(&YC, AG, N, &G, dt, NULL, NULL);

        double l0 = now_ms();
        (void)rt_local_step(&LC, AG, N, &G, dt);
        nav += now_ms() - l0;
        if (use_nav) (void)rt_gw_update(&W);

        /* 到达即停（真实游戏语义；台架不再让已到达的人继续挤） */
        for (int i = 0; i < N; i++)
            if (!DONE[i] && rt_v2_dist(AG[i].pos, goal) < arrive_r) DONE[i] = 1;

        int done = 0;
        for (int i = 0; i < N; i++) if (DONE[i]) done++;
        if (m.gave_up_frame < 0 && SC.st.permanent_stuck > 0) m.gave_up_frame = s;
        if (done == N) break;
    }

    m.frames = frames;
    m.plan_ms = plan / (double)(frames + 1);
    m.plan_max_ms = plan_max;
    m.nav_ms = nav / (double)(frames + 1);
    m.plan_over8 = over8;
    /* P99：排序前先复制，PSAMP 还要留给下一场景（run 会被调用多次） */
    if (NSAMP > 0) {
        static double SORTED[16384];
        memcpy(SORTED, PSAMP, (size_t)NSAMP * sizeof(double));
        qsort(SORTED, (size_t)NSAMP, sizeof(double), cmp_double);
        int idx = (int)((double)(NSAMP - 1) * 0.99);
        m.plan_p99_ms = SORTED[idx];
    }
    m.engaged = (int)PL.st.engaged;
    m.finished = (int)PL.st.finished;
    m.exhausted = (int)PL.st.exhausted;
    m.no_exit = (int)PL.st.no_exit;
    m.unreachable = (int)PL.st.unreachable;
    m.perm = SC.st.permanent_stuck;
    for (int i = 0; i < 7; i++) m.lvl_fires[i] = SC.st.level_fires[i];
    for (int i = 0; i < N; i++) if (DONE[i]) m.arrived++;

    m.min_dist = 1e30f;
    for (int i = 0; i < N; i++) {
        float d = rt_v2_dist(AG[i].pos, goal);
        if (d < m.min_dist) m.min_dist = d;
    }

    if (verbose) {
        printf("  %-22s n=%d frames=%d(%.1f s) arrived=%d  min_dist=%.2f"
               "  plan(eng=%d fin=%d exh=%d noexit=%d unreach=%d max_act=%d)  perm=%u\n",
               name, N, frames, frames * dt, m.arrived, m.min_dist,
               m.engaged, m.finished, m.exhausted, m.no_exit, m.unreachable,
               m.active_max, m.perm);
        printf("  %-22s plan %.3f ms (P99 %.3f max %.3f over8=%d)  local %.3f ms  stuck L1..L6=%u/%u/%u/%u/%u/%u\n",
               "", m.plan_ms, m.plan_p99_ms, m.plan_max_ms, m.plan_over8, m.nav_ms,
               m.lvl_fires[1], m.lvl_fires[2], m.lvl_fires[3],
               m.lvl_fires[4], m.lvl_fires[5], m.lvl_fires[6]);
    }
    return m;
}

/* ============================================================================
 * 场景
 * ==========================================================================*/

/* T1：墙 + 2 m 缺口，单位在墙前 4 m、缺口南侧 11.5 m（M11 掉队单位的最小化） */
static Metrics t1(int use_plan, int verbose)
{
    world_reset();
    wall_vertical(128, 127, 128);
    rt_grid_rebuild_all(&G);
    spawn(1, 124.f, 116.f, 1, 1.6f);
    return run(use_plan ? "T1 gap+planner" : "T1 gap+control", use_plan, 0,
               rt_v2(200.f, 128.f), 3000, 1.0f, verbose);
}

/* T2：同一道墙，4 人小队（2×2），偏移 15 m —— 每个人都得自己找到缺口。
 * 不用 8 人：8 个 1 m 单位挤 2 m 缺口时，限制因素变成通道吞吐（M11 的课题），
 * 会把「规划器找不找得到缺口」这个信号淹掉。 */
static Metrics t2(int use_plan, int verbose)
{
    world_reset();
    wall_vertical(128, 127, 128);
    rt_grid_rebuild_all(&G);
    spawn(4, 120.f, 110.f, 2, 1.6f);
    return run(use_plan ? "T2 squad+planner" : "T2 squad+control", use_plan, 0,
               rt_v2(200.f, 128.f), 4000, 1.2f, verbose);
}

/* T3：封闭房间 —— 目标在别的连通分量。规划层必须拒绝，give-up 仍在 10~30 s。
 * 单位起点离墙 3 m、目标在墙外 8 m，这样 give-up 时刻可以直接和 M6 的 T2（22.4 s）
 * 对照；起点放房间正中会先走 10 s 才碰到墙，数字不可比。 */
static Metrics t3(int use_plan, int verbose)
{
    world_reset();
    wall_room(60, 60, 100, 100);
    rt_grid_rebuild_all(&G);
    spawn(1, 63.f, 80.f, 1, 1.6f);
    Metrics m = run(use_plan ? "T3 room+planner" : "T3 room+control", use_plan, 0,
                    rt_v2(52.f, 80.f), 1600, 1.0f, verbose);
    m.t_stuck_s = (m.gave_up_frame >= 0) ? (double)m.gave_up_frame / 30.0 : -1.0;
    if (verbose) printf("  %-22s give-up at %.1f s\n", "", m.t_stuck_s);
    return m;
}

/* T4：开阔地 200 人 —— 规划层必须完全不介入 */
static Metrics t4(int verbose)
{
    world_reset();
    rt_grid_rebuild_all(&G);
    spawn(200, 40.f, 100.f, 20, 1.6f);
    return run("T4 open 200", 1, 0, rt_v2(200.f, 128.f), 6000, 20.0f, verbose);
}

/* T5：1000 人 + 12 格门，**真导航流水线**（aim 来自 rt_gw_sample） */
static Metrics t5(int use_plan, int verbose)
{
    world_reset();
    wall_vertical(128, 122, 133);
    rt_grid_rebuild_all(&G);
    spawn(1000, 30.f, 90.f, 25, 1.6f);
    return run(use_plan ? "T5 gate+planner" : "T5 gate+control", use_plan, 1,
               rt_v2(210.f, 128.f), 6000, 25.0f, verbose);
}

int main(void)
{
    timer_init();
    printf("=== M13 tests: local planner (wall-following) ===\n\n");

    Metrics c1 = t1(0, 1);
    Metrics p1 = t1(1, 1);
    printf("\n");
    Metrics c2 = t2(0, 1);
    Metrics p2 = t2(1, 1);
    printf("\n");
    Metrics c3 = t3(0, 1);
    Metrics p3 = t3(1, 1);
    (void)c3;   /* 对照组的到达数没有判据：T3 关心的是「拒绝 + 仍给出 GAVE_UP」 */
    printf("\n");
    Metrics o = t4(1);
    printf("\n");
    Metrics gc = t5(0, 1);
    Metrics gp = t5(1, 1);
    printf("\n");

    printf("-- assertions --\n");
    OK(c1.arrived == 0, "T1 control (no planner) stays stuck in front of the wall");
    OK(p1.arrived == 1, "T1 planner squeezes through the 2 m gap");
    OK(p1.engaged >= 1 && p1.engaged <= 8, "T1 planner engages a handful of times, not every frame");

    OK(c2.arrived <= 1, "T2 control squad mostly stuck at the wall");
    OK(p2.arrived >= 3, "T2 planner gets >=3/4 of the squad through the gap");

    OK(p3.engaged == 0 && p3.unreachable >= 1,
       "T3 planner refuses: goal is in another component");
    OK(p3.perm == 1, "T3 unreachable still ends in PermanentStuck (contract kept)");
    OK(p3.t_stuck_s >= 10.0 && p3.t_stuck_s <= 30.0,
       "T3 give-up still inside the 10~30 s window");
    OK(p3.lvl_fires[1] && p3.lvl_fires[2] && p3.lvl_fires[3] &&
       p3.lvl_fires[4] && p3.lvl_fires[5] && p3.lvl_fires[6],
       "T3 all six recovery levels still fire");

    OK(o.engaged == 0 && o.active_max == 0, "T4 open field: planner never engages (no op)");
    OK(o.arrived == 200, "T4 open field: all 200 arrive");
    OK(o.plan_ms < 0.10, "T4 planner cost is negligible on an open field");

    OK(gp.arrived + 20 >= gc.arrived, "T5 nav pipeline: planner does not reduce arrivals");
    /* M16 修订：判据从「mean < 0.6 && max < 8」改成「P99 < 3 && 超预算帧 < 0.5%」。
     * 原因有实测：同一二进制在这台机器上 mean 会从 0.364 漂到 1.174（频率墙 +
     * OS 抢占），max 会在 1.8~48 ms 乱跳 —— 旧判据在**没有任何改动**的情况下
     * 一天里红过三次（其中一次是两条门禁并发跑）。而 P99 稳定在 0.91~1.02 ms。
     * 这条与 M9 的结论一致：帧预算用 P99 + 超预算占比，不用 max，也不要用 mean 当主判据。 */
    OK(gp.plan_p99_ms < 3.0, "T5 planner P99 stays well under the 8 ms frame budget");
    OK(gp.plan_over8 * 200 <= (int)gp.frames, "T5 over-budget frames stay under 0.5%");
    OK(gp.nav_ms + gp.plan_ms < 8.0, "T5 local+plan mean frame < 8 ms");

    /* T6 确定性：同一输入跑两遍，逐字节相同 */
    {
        static RtLocalAgent snap[MAXA];
        (void)t1(1, 0);
        memcpy(snap, AG, sizeof(RtLocalAgent) * (size_t)N);
        int n1 = N;
        (void)t1(1, 0);
        OK(n1 == N && memcmp(snap, AG, sizeof(RtLocalAgent) * (size_t)N) == 0,
           "T6 determinism: identical run -> identical agents");
    }

    printf("\n  对照组: T1 %d/1 到达（最近 %.1f m）/ T2 %d/4 到达\n",
           c1.arrived, c1.min_dist, c2.arrived);
    printf("  规划组: T1 %d/1（%.1f s）/ T2 %d/4（%.1f s）/ T3 %.1f s GAVE_UP\n",
           p1.arrived, p1.frames / 30.0, p2.arrived, p2.frames / 30.0, p3.t_stuck_s);
    printf("  成本:   T4 %.3f ms / T5 plan %.3f ms (max %.2f) + local %.3f ms\n",
           o.plan_ms, gp.plan_ms, gp.plan_max_ms, gp.nav_ms);
    printf("  门场景: 对照组到达 %d（%.1f s）/ 规划组到达 %d（%.1f s）\n",
           gc.arrived, gc.frames / 30.0, gp.arrived, gp.frames / 30.0);

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    if (g_fail == 0) printf("ALL PASS (%d asserts)\n", g_pass);

    rt_plan_destroy(&PL);
    rt_stuck_destroy(&SC);
    rt_yield_destroy(&YC);
    rt_local_destroy(&LC);
    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return g_fail == 0 ? 0 : 1;
}

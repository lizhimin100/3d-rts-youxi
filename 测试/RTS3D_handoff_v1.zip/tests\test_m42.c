/* ============================================================================
 * test_m42.c -- M4.2：目标维度 Route Cache + 精确失效
 *
 * 断言重点不是「单位最终走到了」，而是**内部成本模型**：
 *   T1 完全重复命令        -> 第二次 0 builds，全部 cache hit
 *   T2 1000 单位同目标      -> 首次 builds 不随单位数增长；重复命令 0 builds
 *   T3 无关 topology edit   -> route_invalidated = 0，下一次 command 0 builds
 *   T4 单 route 相关 edit   -> 只失效 1 条；1 invalid 不再触发 N rebuild
 *   T5 goal 附近 edit       -> Goal Cache：远端编辑命中，目标处编辑重解析
 *   T6 缓存容量压力 50/300  -> 不崩溃、不错误复用、eviction 可统计、淘汰后重建正确
 *   T7 clearance key 隔离   -> 2 m / 4 m 不共享同一条走廊
 *   T8 component 隔离       -> 同 region 不同分量不得错误 cache hit
 *   T9 动态障碍连续变化      -> 插入/删除建筑：无 stale、无穿墙、无整表 flush
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m42.c -o test_m42
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", m); } } while (0)

static uint64_t g_state = 0x4D42ull;
static uint64_t nu(void)
{
    uint64_t z = (g_state += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
}

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static uint32_t g_cmd_ver = 0;

/* ------------------------------------------------------------------ 地图 */
static void map_init(int w, int noise_permille)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_grid_init(&G, w, w, 1.0f);
    g_state = 0xBEEF0000ull + (uint64_t)w;
    for (int z = 0; z < w; z++)
        for (int x = 0; x < w; x++)
            if ((nu() >> 40) % 1000 < (uint64_t)noise_permille)
                rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);
}

static void map_wall_gate(int w)
{
    for (int z = 0; z < w; z++)
        if (z != w / 2) rt_grid_set_terrain(&G, w / 2, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int dz = -1; dz <= 1; dz++) {
        rt_grid_set_terrain(&G, w / 2 - 1, w / 2 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, w / 2,     w / 2 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, w / 2 + 1, w / 2 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
    }
    rt_grid_rebuild_all(&G);
}

static int world_build(void)
{
    rt_region_destroy(&MAP);
    int rc = rt_region_build(&MAP, &G, 8);
    if (rc != RT_OK) return rc;
    rt_gw_destroy(&W);
    rc = rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
    g_cmd_ver = 0;
    return rc;
}

static void spawn_disc(RtUnitId *ids, int *n, int maxn, float cx, float cz, float r)
{
    *n = 0;
    for (int i = 0; i < maxn; i++) {
        float rad = r * sqrtf((float)i / (float)maxn);
        float ang = (float)i * 2.39996323f;
        int x = rt_grid_cell_x(&G, cx + cosf(ang) * rad);
        int z = rt_grid_cell_z(&G, cz + sinf(ang) * rad);
        if (!rt_grid_walkable(&G, x, z)) continue;
        RtUnitId id = rt_units_spawn(&US, rt_v3((float)x + 0.5f, 0.f, (float)z + 0.5f), RT_FP_SMALL);
        if (id != RT_UNIT_ID_NONE) ids[(*n)++] = id;
    }
}

static int sample_walkable(RtVec2 p, int cls)
{
    int cx = rt_grid_cell_x(&G, p.x), cz = rt_grid_cell_z(&G, p.z);
    if (!rt_grid_walkable(&G, cx, cz)) return 0;
    return rt_grid_clearance_m(&G, cx, cz) + 1e-4f >= rt_clear_radius_m(cls);
}

static int segment_clear(RtVec2 a, RtVec2 b)
{
    float dx = b.x - a.x, dz = b.z - a.z;
    float len = sqrtf(dx * dx + dz * dz);
    int steps = (int)(len / 0.25f) + 1;
    for (int i = 0; i <= steps; i++) {
        float t = (float)i / (float)steps;
        int cx = rt_grid_cell_x(&G, a.x + dx * t);
        int cz = rt_grid_cell_z(&G, a.z + dz * t);
        if (!rt_grid_walkable(&G, cx, cz)) return 0;
    }
    return 1;
}

/* --------------------------------------------------------------- 命令记录 */
typedef struct {
    uint32_t builds, hits, misses, invalidated, evicted, reuses;
    uint32_t goal_hits, goal_misses, goal_resolves;
    int groups, routes;
    double ms;
} Rec;

static Rec run_cmd(const RtUnitId *ids, int n, RtVec2 dest, int cls)
{
    double t0 = now_ms();
    rt_gw_command(&W, &US, ids, n, dest, 0, (uint8_t)cls, ++g_cmd_ver);
    double t1 = now_ms();
    Rec r;
    memset(&r, 0, sizeof(r));
    r.builds = W.stats.route_builds;
    r.hits = W.stats.route_cache_hits;
    r.misses = W.stats.route_cache_misses;
    r.invalidated = W.stats.route_invalidated;
    r.evicted = W.stats.route_evicted;
    r.reuses = W.stats.route_reuses;
    r.goal_hits = W.stats.goal_cache_hits;
    r.goal_misses = W.stats.goal_cache_misses;
    r.goal_resolves = W.stats.goal_resolves;
    r.groups = W.group_count;
    r.routes = 0;
    for (int i = 0; i < W.group_count; i++) r.routes += W.groups[i].route_count;
    r.ms = t1 - t0;
    return r;
}

static void print_rec(const char *tag, Rec r)
{
    printf("  %-18s groups=%d routes=%d builds=%u hits=%u miss=%u inval=%u evict=%u "
           "goal(h/m)=%u/%u %.3f ms\n",
           tag, r.groups, r.routes, r.builds, r.hits, r.misses, r.invalidated,
           r.evicted, r.goal_hits, r.goal_misses, r.ms);
}

/* 诊断：route 为什么失效（label / overflow / 具体 chunk） */
static void route_why(const RtRoute *r, const char *tag)
{
    int why = 0;
    uint32_t bad = 0;
    if (r->label_epoch != G.label_epoch) why = 1;
    else if (r->dep_overflow) why = 2;
    else for (int i = 0; i < r->dep_n; i++)
        if (G.chunk_ver[r->dep_chunks[i]] != r->dep_vers[i]) { why = 3; bad = r->dep_chunks[i]; break; }
    printf("    [why] %-6s n=%d dep_n=%d overflow=%d label=%u/%u why=%d chunk=%u\n",
           tag, r->n, r->dep_n, (int)r->dep_overflow, r->label_epoch, G.label_epoch, why, bad);
}

/* 找一块「离所有 route 依赖 chunk 至少 pad 格」的空地：用于「无关编辑」用例。
 * 不能随手选角落 —— clearance 重建的 pad 会把脏区扩到相邻 chunk。 */
static int find_isolated_spot(int pad, int *out_x, int *out_z)
{
    static uint8_t used[RT_CHUNK_N];
    memset(used, 0, sizeof(used));
    for (int i = 0; i < W.group_count; i++)
        for (int k = 0; k < W.groups[i].route_count; k++) {
            RtRoute *r = &W.groups[i].routes[k].route;
            for (int j = 0; j < r->dep_n; j++)
                if (r->dep_chunks[j] < RT_CHUNK_N) used[r->dep_chunks[j]] = 1;
        }
    for (int z = pad; z + pad < G.h; z += 4)
        for (int x = pad; x + pad < G.w; x += 4) {
            int ok = 1;
            for (int dz = -pad; dz <= pad && ok; dz += 4)
                for (int dx = -pad; dx <= pad; dx += 4) {
                    int c = rt_grid_chunk_of_cell(&G, x + dx, z + dz);
                    if (c >= 0 && c < RT_CHUNK_N && used[c]) { ok = 0; break; }
                }
            if (ok) { *out_x = x; *out_z = z; return 1; }
        }
    return 0;
}

/* ============================================================== T1 重复命令 */
static void t1_repeat_command(void)
{
    printf("\n[T1] identical command twice\n");
    map_init(256, 100);
    map_wall_gate(256);
    world_build();

    RtUnitId ids[256];
    int n = 0;
    spawn_disc(ids, &n, 200, 50.f, 60.f, 12.f);
    RtVec2 dest = rt_v2(210.5f, 190.5f);

    Rec a = run_cmd(ids, n, dest, RT_CLS_SMALL);
    Rec b = run_cmd(ids, n, dest, RT_CLS_SMALL);
    print_rec("first", a);
    print_rec("repeat", b);

    OK(a.builds >= 1, "T1 first command builds");
    OK(a.builds <= 16, "T1 first builds bounded by source regions");
    OK(b.builds == 0, "T1 repeat builds == 0");
    OK(b.hits == (uint32_t)a.routes, "T1 repeat: every route is a cache hit");
    OK(b.goal_misses == 0, "T1 repeat: goal resolved from cache");
    OK(b.goal_hits >= 1, "T1 repeat: goal cache hit");
    OK(rt_gw_route_cache_count(&W) >= a.builds, "T1 cache populated");
}

/* ============================================================== T2 1000 单位 */
static void t2_1000_units(void)
{
    printf("\n[T2] 1000 units, same destination\n");
    map_init(256, 100);
    map_wall_gate(256);
    world_build();

    static RtUnitId ids[1024];
    int n = 0;
    spawn_disc(ids, &n, 1000, 50.f, 60.f, 12.f);
    RtVec2 dest = rt_v2(210.5f, 190.5f);

    Rec a = run_cmd(ids, n, dest, RT_CLS_SMALL);
    Rec b = run_cmd(ids, n, dest, RT_CLS_SMALL);
    print_rec("first", a);
    print_rec("repeat", b);

    OK(a.builds <= 16, "T2 cold builds still bounded by source regions (not units)");
    OK(a.builds * 8 < (uint32_t)n, "T2 cold builds << unit count");
    OK(b.builds == 0, "T2 warm builds == 0 (M4.2 core value)");

    /* 采样仍然可用，且目标可站立 */
    int sampled = 0, walkable = 0;
    for (int i = 0; i < n && i < 200; i++) {
        RtVec3 p = rt_units_pos(&US, ids[i]);
        RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[i]);
        int gi = (int)ch->group[rt_unit_slot_index(ids[i])] - 1;
        if (gi < 0) continue;
        RtVec2 tgt;
        if (rt_gw_sample(&W, gi, rt_v2(p.x, p.z), &tgt) == RT_OK) {
            sampled++;
            if (sample_walkable(tgt, RT_CLS_SMALL)) walkable++;
        }
    }
    printf("  sampled=%d walkable=%d\n", sampled, walkable);
    OK(sampled > 0, "T2 sampling works after cache hit");
    OK(walkable == sampled, "T2 sampled targets are walkable");
}

/* ========================================================= T3 无关 topology */
static void t3_unrelated_edit(void)
{
    printf("\n[T3] unrelated topology edit -> no invalidation\n");
    map_init(256, 100);
    map_wall_gate(256);
    world_build();

    RtUnitId ids[256];
    int n = 0;
    spawn_disc(ids, &n, 200, 50.f, 60.f, 12.f);
    RtVec2 dest = rt_v2(210.5f, 190.5f);

    Rec a = run_cmd(ids, n, dest, RT_CLS_SMALL);
    Rec b = run_cmd(ids, n, dest, RT_CLS_SMALL);
    print_rec("cold", a);
    print_rec("warm", b);
    OK(b.builds == 0, "T3 warm before edit");

    /* 找一块「离所有 route 依赖 chunk ≥ 26 格」的空地建楼：真正的无关编辑 */
    int ix = 0, iz = 0;
    int found = find_isolated_spot(26, &ix, &iz);
    OK(found == 1, "T3 found an isolated spot for the unrelated edit");
    RtGridDirty d;
    rt_grid_add_building_dirty(&G, ix, iz, 6, 6, &d);
    rt_grid_apply_dirty(&G, &d);
    printf("  unrelated building at (%d,%d)\n", ix, iz);

    Rec c = run_cmd(ids, n, dest, RT_CLS_SMALL);
    print_rec("after unrelated", c);
    OK(c.invalidated == 0, "T3 unrelated edit invalidates nothing");
    OK(c.builds == 0, "T3 unrelated edit: builds == 0");
    OK(c.hits == (uint32_t)c.routes, "T3 all routes still cache hits");
    OK(c.goal_misses == 0, "T3 goal cache survives unrelated edit");
}

/* =========================================================== T4 单条失效 */
static void t4_single_route_invalidation(void)
{
    printf("\n[T4] localized edit -> only one route invalidated/rebuilt\n");
    map_init(256, 0);
    map_wall_gate(256);
    world_build();

    RtUnitId a = rt_units_spawn(&US, rt_v3(40.5f, 0.f, 40.5f), RT_FP_SMALL);
    RtUnitId b = rt_units_spawn(&US, rt_v3(40.5f, 0.f, 200.5f), RT_FP_SMALL);
    RtUnitId ids[2] = { a, b };
    RtVec2 dest = rt_v2(220.5f, 120.5f);

    Rec r0 = run_cmd(ids, 2, dest, RT_CLS_SMALL);
    print_rec("cold", r0);
    OK(W.group_count == 1, "T4 both units share one group");
    OK(W.groups[0].route_count == 2, "T4 two source regions -> two routes");

    RtGroupRoute *rA = &W.groups[0].routes[0];
    RtGroupRoute *rB = &W.groups[0].routes[1];
    int lenA = rA->route.n, lenB = rB->route.n;
    float costB = rB->route.cost;
    printf("  route A start=%d len=%d | route B start=%d len=%d\n",
           rA->start_region, lenA, rB->start_region, lenB);

    /* 只压 A 的**起点附近**（z≈40 那一侧）；B 的起点在 z≈200，整条走廊不重叠 */
    RtGridDirty d;
    rt_grid_add_building_dirty(&G, 46, 46, 8, 8, &d);
    rt_grid_apply_dirty(&G, &d);

    int invA = !rt_route_valid(&rA->route, &G);
    int invB = !rt_route_valid(&rB->route, &G);
    printf("  after edit: A invalid=%d B invalid=%d\n", invA, invB);
    route_why(&rA->route, "routeA");
    route_why(&rB->route, "routeB");
    OK(invA == 1, "T4 the affected route is invalid");
    OK(invB == 0, "T4 the untouched route stays valid");

    uint32_t b0 = W.stats.route_builds, i0 = W.stats.route_invalidated;
    int rebuilt = rt_gw_update(&W);
    uint32_t d_build = W.stats.route_builds - b0;
    uint32_t d_inval = W.stats.route_invalidated - i0;
    printf("  update: rebuilt=%d d_build=%u d_inval=%u\n", rebuilt, d_build, d_inval);
    OK(rebuilt == 1, "T4 exactly one route rebuilt (not the whole group)");
    OK(d_inval == 1, "T4 invalidated == 1");
    OK(d_build == 1, "T4 builds == 1");
    OK(rB->route.cost == costB && rB->route.n == lenB, "T4 untouched route not rebuilt");
    OK(rt_route_valid(&rA->route, &G), "T4 rebuilt route valid");
}

/* =========================================================== T5 goal 附近 */
static void t5_goal_cache(void)
{
    printf("\n[T5] goal resolution cache\n");
    map_init(256, 0);
    world_build();

    RtUnitId id = rt_units_spawn(&US, rt_v3(40.5f, 0.f, 40.5f), RT_FP_SMALL);
    RtUnitId ids[1] = { id };
    RtVec2 dest = rt_v2(200.5f, 120.5f);

    Rec a = run_cmd(ids, 1, dest, RT_CLS_SMALL);
    Rec b = run_cmd(ids, 1, dest, RT_CLS_SMALL);
    print_rec("cold", a);
    print_rec("repeat", b);
    OK(a.goal_misses == 1 && a.goal_resolves == 1, "T5 first resolve is a miss");
    OK(b.goal_misses == 0 && b.goal_hits >= 1, "T5 repeat is a hit");

    /* 目标格上盖楼 -> 必须重新解析 */
    RtVec2 old_goal = W.groups[0].goal_pos;
    RtGridDirty d;
    int gx = rt_grid_cell_x(&G, dest.x), gz = rt_grid_cell_z(&G, dest.z);
    rt_grid_add_building_dirty(&G, gx - 2, gz - 2, 5, 5, &d);
    rt_grid_apply_dirty(&G, &d);

    Rec c = run_cmd(ids, 1, dest, RT_CLS_SMALL);
    print_rec("goal blocked", c);
    OK(c.goal_misses >= 1, "T5 goal cache invalidated when the goal area changes");
    OK(sample_walkable(W.groups[0].goal_pos, RT_CLS_SMALL), "T5 new goal is walkable");

    /* 远端编辑 -> 仍然命中 */
    rt_grid_add_building_dirty(&G, 20, 200, 6, 6, &d);
    rt_grid_apply_dirty(&G, &d);
    RtVec2 keep = W.groups[0].goal_pos;
    Rec e = run_cmd(ids, 1, dest, RT_CLS_SMALL);
    print_rec("far edit", e);
    OK(e.goal_misses == 0, "T5 far edit does not flush the goal cache");
    OK(e.goal_hits >= 1, "T5 far edit still hits");
    OK(fabsf(keep.x - W.groups[0].goal_pos.x) < 1e-3f &&
       fabsf(keep.z - W.groups[0].goal_pos.z) < 1e-3f, "T5 cached goal reused after far edit");
    (void)old_goal;
}

/* ============================================================== T6 容量压力 */
static void t6_capacity_pressure(void)
{
    printf("\n[T6] cache capacity pressure (50 / 300 distinct goals)\n");
    map_init(256, 0);
    world_build();

    RtUnitId id = rt_units_spawn(&US, rt_v3(20.5f, 0.f, 20.5f), RT_FP_SMALL);
    RtUnitId ids[1] = { id };

    int built50 = 0, evict50 = 0;
    for (int i = 0; i < 50; i++) {
        float gx = 40.f + (float)(i % 10) * 18.f;
        float gz = 40.f + (float)(i / 10) * 30.f;
        Rec r = run_cmd(ids, 1, rt_v2(gx, gz), RT_CLS_SMALL);
        built50 += (int)r.builds;
        evict50 += (int)r.evicted;
    }
    printf("  50 goals: builds=%d evict=%d cache_count=%d\n",
           built50, evict50, rt_gw_route_cache_count(&W));
    OK(rt_gw_route_cache_count(&W) >= 40, "T6 50 distinct goals cached");
    OK(evict50 == 0, "T6 50 entries fit without eviction");

    int built300 = 0, evict300 = 0;
    for (int i = 0; i < 300; i++) {
        float gx = 40.f + (float)(i % 20) * 9.f;
        float gz = 30.f + (float)(i / 20) * 15.f;
        Rec r = run_cmd(ids, 1, rt_v2(gx, gz), RT_CLS_SMALL);
        built300 += (int)r.builds;
        evict300 += (int)r.evicted;
    }
    printf("  300 goals: builds=%d evict=%d cache_count=%d\n",
           built300, evict300, rt_gw_route_cache_count(&W));
    OK(rt_gw_route_cache_count(&W) <= RT_ROUTE_CACHE_CAP, "T6 cache respects capacity");
    OK(evict300 > 0, "T6 eviction happened and is counted");
    OK(built300 > 0, "T6 cache pressure still builds");

    /* 被淘汰的 key 再次请求：必须正确重建，且命中/未命中计数自洽 */
    Rec again = run_cmd(ids, 1, rt_v2(40.f, 30.f), RT_CLS_SMALL);
    print_rec("re-request evicted", again);
    OK(again.builds + again.hits + again.invalidated >= 1, "T6 re-request accounted");
    OK(rt_route_valid(&W.groups[0].routes[0].route, &G), "T6 re-request route valid");
}

/* =========================================================== T7 clearance 隔离 */
static void t7_clearance_isolation(void)
{
    printf("\n[T7] clearance class must not share a cached route\n");
    int Wsz = 256;
    map_init(Wsz, 0);
    /* 水平墙 z=128：2 m 门在 x=120..121，6 m 绕行门在 x=200..205 */
    for (int x = 0; x < Wsz; x++) rt_grid_set_terrain(&G, x, 128, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int x = 120; x <= 121; x++) rt_grid_set_terrain(&G, x, 128, RT_CELL_BLOCKED_TERRAIN, 0);
    for (int x = 200; x <= 205; x++) {
        rt_grid_set_terrain(&G, x, 128, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, x, 127, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, x, 129, RT_CELL_BLOCKED_TERRAIN, 0);
    }
    rt_grid_rebuild_all(&G);
    world_build();

    RtUnitId id = rt_units_spawn(&US, rt_v3(40.5f, 0.f, 60.5f), RT_FP_SMALL);
    RtUnitId ids[1] = { id };
    RtVec2 dest = rt_v2(40.5f, 200.5f);

    Rec s = run_cmd(ids, 1, dest, RT_CLS_SMALL);
    int cross_small = -1;
    if (W.groups[0].route_count > 0) {
        RtRoute *r = &W.groups[0].routes[0].route;
        for (int i = 0; i < r->n; i++) {
            if (r->regions[i] / MAP.rw >= 16) { cross_small = (r->regions[i] % MAP.rw) * 8; break; }
        }
    }
    Rec l = run_cmd(ids, 1, dest, RT_CLS_LARGE);
    int cross_large = -1;
    if (W.groups[0].route_count > 0) {
        RtRoute *r = &W.groups[0].routes[0].route;
        for (int i = 0; i < r->n; i++) {
            if (r->regions[i] / MAP.rw >= 16) { cross_large = (r->regions[i] % MAP.rw) * 8; break; }
        }
    }
    printf("  small cross_x=%d (builds=%u) | large cross_x=%d (builds=%u hits=%u miss=%u)\n",
           cross_small, s.builds, cross_large, l.builds, l.hits, l.misses);
    OK(cross_small >= 112 && cross_small <= 128, "T7 small uses the 2m gate");
    OK(cross_large >= 192, "T7 large detours to the 6m opening");
    OK(l.builds == 1 && l.hits == 0, "T7 different clearance => no cache sharing");
}

/* =========================================================== T8 component 隔离 */
static void t8_component_isolation(void)
{
    printf("\n[T8] same region, different components must not share a route\n");
    map_init(256, 0);
    /* 在 x=124 立一道贯通墙：region 15 (x=120..127) 被切成两个连通分量 */
    for (int z = 0; z < 256; z++) rt_grid_set_terrain(&G, 124, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);
    world_build();

    int ra = rt_region_of_world(&MAP, 121.5f, 60.5f);
    int rb = rt_region_of_world(&MAP, 126.5f, 60.5f);
    int ca = rt_grid_component_at(&G, 121, 60);
    int cb = rt_grid_component_at(&G, 126, 60);
    printf("  region A=%d comp=%d | region B=%d comp=%d | mixed(regionA)=%d\n",
           ra, ca, rb, cb, MAP.mixed[ra]);
    OK(ra == rb, "T8 both units sit in the same region id");
    OK(ca != cb, "T8 but in different connected components");

    RtUnitId ua = rt_units_spawn(&US, rt_v3(121.5f, 0.f, 60.5f), RT_FP_SMALL);
    RtUnitId ub = rt_units_spawn(&US, rt_v3(126.5f, 0.f, 60.5f), RT_FP_SMALL);
    RtUnitId ids[2] = { ua, ub };

    Rec r = run_cmd(ids, 2, rt_v2(180.5f, 60.5f), RT_CLS_SMALL);
    print_rec("two comps", r);
    OK(W.group_count == 2, "T8 two components => two groups");
    OK(r.hits == 0, "T8 no false cache hit across components");
    OK(rt_gw_route_cache_count(&W) == 2, "T8 two distinct cache entries");

    int same_start = 1;
    for (int i = 1; i < W.group_count; i++)
        if (W.groups[i].routes[0].start_region != W.groups[0].routes[0].start_region) same_start = 0;
    OK(same_start, "T8 entries really share the same start region (component is the separator)");
}

/* ============================================================= T9 连续变化 */
static void t9_dynamic_toggle(void)
{
    printf("\n[T9] insert / remove building across ticks\n");
    map_init(256, 0);
    map_wall_gate(256);
    world_build();

    RtUnitId id = rt_units_spawn(&US, rt_v3(60.5f, 0.f, 128.5f), RT_FP_SMALL);
    RtUnitId ids[1] = { id };
    RtVec2 dest = rt_v2(210.5f, 128.5f);

    Rec a = run_cmd(ids, 1, dest, RT_CLS_SMALL);
    Rec b = run_cmd(ids, 1, dest, RT_CLS_SMALL);
    int cache_before = rt_gw_route_cache_count(&W);
    print_rec("cold", a);
    print_rec("warm", b);
    OK(b.builds == 0, "T9 warm command stable");

    RtGridDirty d;
    rt_grid_add_building_dirty(&G, 140, 125, 8, 8, &d);
    rt_grid_apply_dirty(&G, &d);

    int rebuilt = rt_gw_update(&W);
    printf("  insert: rebuilt=%d invalidated=%u cache_count=%d\n",
           rebuilt, W.stats.route_invalidated, rt_gw_route_cache_count(&W));
    OK(rebuilt >= 1, "T9 insert rebuilds affected route");
    OK(rt_gw_route_cache_count(&W) > 0, "T9 no whole-cache flush on insert");
    OK(rt_route_valid(&W.groups[0].routes[0].route, &G), "T9 no stale route after insert");

    /* 沿新路走：不穿墙、能到 */
    RtVec2 p = rt_v2(60.5f, 128.5f);
    int steps = 0, pen = 0, arrived = 0;
    for (int i = 0; i < 5000 && !arrived; i++) {
        RtVec2 tgt;
        if (rt_gw_sample(&W, 0, p, &tgt) != RT_OK) break;
        RtVec2 dd = rt_v2_sub(tgt, p);
        float len = rt_v2_len(dd);
        if (len < 1e-4f) break;
        float step = 6.0f * (1.0f / 30.0f);
        if (step > len) step = len;
        RtVec2 np = rt_v2_add(p, rt_v2_mul(dd, step / len));
        if (!segment_clear(p, np)) { pen++; break; }
        p = np; steps++;
        if (rt_gw_is_arrived(&W, 0, p, 1.5f)) arrived = 1;
    }
    printf("  walk after insert: arrived=%d steps=%d penetrations=%d\n", arrived, steps, pen);
    OK(pen == 0, "T9 no wall penetration after insert");
    OK(arrived == 1, "T9 arrives after insert");

    /* 删掉建筑：再次请求应恢复 */
    rt_grid_remove_building_dirty(&G, 140, 125, 8, 8, &d);
    rt_grid_apply_dirty(&G, &d);
    Rec c = run_cmd(ids, 1, dest, RT_CLS_SMALL);
    print_rec("after remove", c);
    OK(rt_gw_route_cache_count(&W) >= 1, "T9 cache still alive after toggle");
    OK(rt_route_valid(&W.groups[0].routes[0].route, &G), "T9 route valid after remove");
    OK(c.builds + c.hits >= 1, "T9 request accounted after remove");
    (void)cache_before;
}

/* ==================================================================== main */
int main(void)
{
    timer_init();
    printf("=== M4.2 tests: goal-dimension route cache + precise invalidation ===\n");
    printf("cache: route=%d slots, goal=%d slots, max route len=%d\n",
           RT_ROUTE_CACHE_CAP, RT_GOAL_CACHE_CAP, RT_ROUTE_CACHE_MAX_LEN);

    t1_repeat_command();
    t2_1000_units();
    t3_unrelated_edit();
    t4_single_route_invalidation();
    t5_goal_cache();
    t6_capacity_pressure();
    t7_clearance_isolation();
    t8_component_isolation();
    t9_dynamic_toggle();

    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}

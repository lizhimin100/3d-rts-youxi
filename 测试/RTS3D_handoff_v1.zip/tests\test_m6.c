/* ============================================================================
 * test_m6.c -- 卡死检测与分级恢复（FR-STK）
 *
 * 门禁：
 *   T1 单格宽走廊双向死锁：不恢复 = 谁都过不去；恢复后全部通过
 *   T2 目标不可达（封闭房间）：走完 L1~L6 -> GAVE_UP，>=10 s，且没有传送
 *   T3 合法排队（前车在走）：不是 STUCK
 *   T4 静止单位堵门口（QUEUED != STUCK）：不误判永久卡死；移开障碍后全部通过
 *   T5 1000 人每帧成本
 *   T6 确定性
 *   T7 全程无传送：单帧位移 <= max_speed*dt
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_stuck.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", (m)); } } while (0)

#define MAXA 1200
static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;
static RtStuckCtx SC;
static RtGrid G;

static void agent_set(int i, float x, float z, float r, float speed, float px, float pz)
{
    memset(&AG[i], 0, sizeof(AG[i]));
    AG[i].pos = rt_v2(x, z);
    AG[i].vel = rt_v2(0.f, 0.f);
    AG[i].pref_vel = rt_v2(px, pz);
    AG[i].radius = r;
    AG[i].max_speed = speed;
    AG[i].fp = r * 2.f;
    AG[i].share = 0.5f;
    AG[i].inv_mass = 1.f;
}

static float worst_overlap(int n, int *out_pairs)
{
    float worst = 0.f;
    int pairs = 0;
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++) {
            float d = rt_v2_dist(AG[i].pos, AG[j].pos);
            float pen = (AG[i].radius + AG[j].radius) - d;
            if (pen > 0.f) { pairs++; if (pen > worst) worst = pen; }
        }
    if (out_pairs) *out_pairs = pairs;
    return worst;
}

static void room_walls(int x0, int z0, int x1, int z1)
{
    for (int x = x0; x <= x1; x++) {
        rt_grid_set_terrain(&G, x, z0, RT_CELL_BLOCKED_TERRAIN, 1);
        rt_grid_set_terrain(&G, x, z1, RT_CELL_BLOCKED_TERRAIN, 1);
    }
    for (int z = z0; z <= z1; z++) {
        rt_grid_set_terrain(&G, x0, z, RT_CELL_BLOCKED_TERRAIN, 1);
        rt_grid_set_terrain(&G, x1, z, RT_CELL_BLOCKED_TERRAIN, 1);
    }
}

/* ----------------------------------------------------------------------------
 * T1：单格宽走廊里的双向死锁（2 人对穿）
 * 走廊 x∈[120,132]、z=127，两端开阔；让行方退 ~8 m 就能让出通道。
 * --------------------------------------------------------------------------*/
static void t1_corridor(int use_recovery, int *out_crossed, int *out_frames,
                        float *out_maxstep, int verbose)
{
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int z = 0; z < 256; z++)
        for (int x = 120; x <= 132; x++)
            if (z != 127) rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);

    rt_local_destroy(&LC);
    rt_local_init(&LC, 256.f, 256.f, 64, 4.5f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);

    rt_stuck_destroy(&SC);
    rt_stuck_init(&SC, MAXA, NULL);

    const int n = 2;
    const float dt = 1.f / 30.f;
    const float sp = 1.5f;
    agent_set(0, 124.f, 127.5f, 0.45f, sp, sp, 0.f);
    agent_set(1, 128.f, 127.5f, 0.45f, sp, -sp, 0.f);

    RtVec2 goal[2];
    goal[0] = rt_v2(150.f, 127.5f);
    goal[1] = rt_v2(100.f, 127.5f);

    float maxstep = 0.f;
    int frames = 0;
    for (int s = 0; s < 3600; s++) {
        frames = s;
        for (int i = 0; i < n; i++) {
            RtVec2 d = rt_v2_sub(goal[i], AG[i].pos);
            float l = rt_v2_len(d);
            AG[i].pref_vel = (l > 0.5f) ? rt_v2_mul(d, sp / l) : rt_v2(0.f, 0.f);
        }

        RtVec2 before[2];
        for (int i = 0; i < n; i++) before[i] = AG[i].pos;

        if (use_recovery) (void)rt_stuck_step(&SC, AG, n, &G, dt, NULL);
        (void)rt_local_step(&LC, AG, n, &G, dt);

        for (int i = 0; i < n; i++) {
            float d = rt_v2_dist(before[i], AG[i].pos);
            if (d > maxstep) maxstep = d;
        }

        int crossed = 0;
        if (AG[0].pos.x > 136.f) crossed++;
        if (AG[1].pos.x < 116.f) crossed++;
        if (crossed == n) break;
    }

    int crossed = 0;
    if (AG[0].pos.x > 136.f) crossed++;
    if (AG[1].pos.x < 116.f) crossed++;
    int pairs = 0;
    float pen = worst_overlap(n, &pairs);

    if (verbose) {
        printf("  %s: crossed=%d/%d frames=%d overlap=%.3f  final x = %.1f / %.1f\n",
               use_recovery ? "recovery" : "control ", crossed, n, frames, pen,
               AG[0].pos.x, AG[1].pos.x);
        printf("         states:");
        for (int i = 0; i < n; i++)
            printf(" %s/L%d", rt_stuck_state_name((int)SC.u[i].state), (int)SC.u[i].level);
        printf("\n");
        printf("         episodes=%u resolved=%u permanent=%u fires L1..L6=%u/%u/%u/%u/%u/%u"
               " bay=%u/%u hook_missing=%u max_recover=%.1fs\n",
               SC.st.episodes, SC.st.resolved, SC.st.permanent_stuck,
               SC.st.level_fires[1], SC.st.level_fires[2], SC.st.level_fires[3],
               SC.st.level_fires[4], SC.st.level_fires[5], SC.st.level_fires[6],
               SC.st.bay_found, SC.st.bay_none, SC.st.hook_missing, SC.st.max_recover_s);
    }

    if (out_crossed) *out_crossed = crossed;
    if (out_frames) *out_frames = frames;
    if (out_maxstep) *out_maxstep = maxstep;
}

static void t1(void)
{
    printf("\n[T1] 单格宽走廊：2 人对穿\n");
    int c0 = 0, c1 = 0, f0 = 0, f1 = 0;
    float ms0 = 0.f, ms1 = 0.f;
    t1_corridor(0, &c0, &f0, &ms0, 1);
    t1_corridor(1, &c1, &f1, &ms1, 1);
    printf("  control %d/2 in %d frames | recovery %d/2 in %d frames | max_step %.3f / %.3f m\n",
           c0, f0, c1, f1, ms0, ms1);
    OK(c0 == 0, "T1 without recovery the corridor really deadlocks");
    OK(c1 == 2, "T1 with graded recovery both units get through");
    OK(ms1 <= 1.5f / 30.f + 1e-3f, "T1 recovery never teleports (step <= v*dt)");
}

/* ----------------------------------------------------------------------------
 * T2：目标不可达 -> 走完 6 级 -> GAVE_UP
 * --------------------------------------------------------------------------*/
static void t2_unreachable(void)
{
    printf("\n[T2] 目标不可达（封闭房间）\n");
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    room_walls(100, 100, 104, 104);
    rt_grid_rebuild_all(&G);

    rt_local_destroy(&LC);
    rt_local_init(&LC, 256.f, 256.f, 8, 4.5f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);

    rt_stuck_destroy(&SC);
    rt_stuck_init(&SC, 8, NULL);

    const int n = 1;
    const float dt = 1.f / 30.f;
    agent_set(0, 102.5f, 102.5f, 0.4f, 1.2f, 1.2f, 0.f);

    const RtVec2 goal = rt_v2(120.f, 102.5f);
    float maxstep = 0.f;
    int gave_up_frame = -1;
    for (int s = 0; s < 1200; s++) {
        RtVec2 d = rt_v2_sub(goal, AG[0].pos);
        float l = rt_v2_len(d);
        AG[0].pref_vel = (l > 0.5f) ? rt_v2_mul(d, 1.2f / l) : rt_v2(0.f, 0.f);

        RtVec2 before = AG[0].pos;
        (void)rt_stuck_step(&SC, AG, n, &G, dt, NULL);
        (void)rt_local_step(&LC, AG, n, &G, dt);
        float step = rt_v2_dist(before, AG[0].pos);
        if (step > maxstep) maxstep = step;
        if (SC.st.permanent_stuck > 0 && gave_up_frame < 0) gave_up_frame = s;
    }

    float t_giveup = gave_up_frame >= 0 ? (float)gave_up_frame * dt : -1.f;
    printf("  state=%s level=%d stuck_time=%.1fs gave_up_at=%.1fs permanent=%u"
           " fires=%u/%u/%u/%u/%u/%u bay=%u/%u\n",
           rt_stuck_state_name((int)SC.u[0].state), (int)SC.u[0].level, SC.u[0].stuck_time,
           t_giveup, SC.st.permanent_stuck,
           SC.st.level_fires[1], SC.st.level_fires[2], SC.st.level_fires[3],
           SC.st.level_fires[4], SC.st.level_fires[5], SC.st.level_fires[6],
           SC.st.bay_found, SC.st.bay_none);
    printf("  max_step=%.4f m (bound %.4f)\n", maxstep, 1.2f * dt);
    OK(SC.st.permanent_stuck == 1, "T2 unreachable goal ends in exactly one PermanentStuck");
    OK(t_giveup >= 10.0f && t_giveup <= 30.0f, "T2 gave up between 10 s and 30 s");
    OK(SC.st.level_fires[1] > 0 && SC.st.level_fires[6] > 0, "T2 went through the whole L1..L6 ladder");
    OK(maxstep <= 1.2f * dt + 1e-3f, "T2 never teleports");
}

/* ----------------------------------------------------------------------------
 * T3：合法排队（前车在走）不应被当成 STUCK
 * --------------------------------------------------------------------------*/
static void t3_legit_queue(void)
{
    printf("\n[T3] 合法排队：前车在走\n");
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    rt_grid_rebuild_all(&G);

    rt_local_destroy(&LC);
    rt_local_init(&LC, 256.f, 256.f, 16, 4.5f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);

    rt_stuck_destroy(&SC);
    rt_stuck_init(&SC, 16, NULL);

    const int n = 6;
    const float dt = 1.f / 30.f;
    for (int i = 0; i < n; i++) agent_set(i, 60.f + (float)i * 1.8f, 128.f, 0.5f, 1.2f, 1.2f, 0.f);

    const RtVec2 goal = rt_v2(400.f, 128.f);
    for (int s = 0; s < 600; s++) {
        for (int i = 0; i < n; i++) {
            RtVec2 d = rt_v2_sub(goal, AG[i].pos);
            float l = rt_v2_len(d);
            AG[i].pref_vel = rt_v2_mul(d, 1.2f / l);
        }
        (void)rt_stuck_step(&SC, AG, n, &G, dt, NULL);
        (void)rt_local_step(&LC, AG, n, &G, dt);
    }
    printf("  episodes=%u permanent=%u  states:", SC.st.episodes, SC.st.permanent_stuck);
    for (int i = 0; i < n; i++) printf(" %s", rt_stuck_state_name((int)SC.u[i].state));
    printf("  x=%.1f..%.1f\n", AG[0].pos.x, AG[5].pos.x);
    OK(SC.st.episodes == 0, "T3 a moving column is never flagged STUCK");
    OK(SC.st.permanent_stuck == 0, "T3 no PermanentStuck in a legitimate queue");
    OK(AG[5].pos.x - 60.f > 15.f, "T3 the whole column actually advanced");
}

/* ----------------------------------------------------------------------------
 * T4：静止单位堵在单格走廊 —— QUEUED != STUCK；移开后全部通过
 * --------------------------------------------------------------------------*/
static void t4_idle_blocker(void)
{
    printf("\n[T4] 静止单位堵走廊（QUEUED != STUCK）\n");
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int z = 0; z < 256; z++)
        for (int x = 0; x < 256; x++)
            if (!(z == 127 && x >= 80 && x <= 140))
                rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);

    rt_local_destroy(&LC);
    rt_local_init(&LC, 256.f, 256.f, 16, 4.5f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);

    rt_stuck_destroy(&SC);
    rt_stuck_init(&SC, 16, NULL);

    const int n = 6;
    const float dt = 1.f / 30.f;
    /* 0 = 静止障碍；1..5 排队 */
    agent_set(0, 100.f, 127.5f, 0.45f, 0.f, 0.f, 0.f);
    AG[0].inv_mass = 0.f;
    AG[0].share = 0.f;
    AG[0].fp = 0.9f;
    for (int i = 1; i < n; i++)
        agent_set(i, 88.f + (float)(i - 1) * 1.6f, 127.5f, 0.45f, 1.2f, 1.2f, 0.f);

    const RtVec2 goal = rt_v2(120.f, 127.5f);
    int max_stuck = 0;
    for (int s = 0; s < 900; s++) {
        for (int i = 1; i < n; i++) {
            RtVec2 d = rt_v2_sub(goal, AG[i].pos);
            float l = rt_v2_len(d);
            AG[i].pref_vel = (l > 0.5f) ? rt_v2_mul(d, 1.2f / l) : rt_v2(0.f, 0.f);
        }
        (void)rt_stuck_step(&SC, AG, n, &G, dt, NULL);
        (void)rt_local_step(&LC, AG, n, &G, dt);
        int stuck_now = 0;
        for (int i = 1; i < n; i++) if (SC.u[i].state == RT_STUCK_STUCK) stuck_now++;
        if (stuck_now > max_stuck) max_stuck = stuck_now;
    }
    int blocked = 0, queued = 0;
    for (int i = 1; i < n; i++) {
        if (SC.u[i].state == RT_STUCK_BLOCKED) blocked++;
        if (SC.u[i].state == RT_STUCK_QUEUED) queued++;
    }
    printf("  after 30 s: blocked=%d queued=%d max_stuck_seen=%d permanent=%u episodes=%u\n",
           blocked, queued, max_stuck, SC.st.permanent_stuck, SC.st.episodes);
    OK(SC.st.permanent_stuck == 0, "T4 an idle blocker never produces PermanentStuck");
    OK(SC.st.episodes == 0, "T4 waiting behind an idle unit is not STUCK");
    OK(blocked + queued == n - 1, "T4 everyone is classified BLOCKED/QUEUED");

    /* 移开障碍：整队应当走完 */
    AG[0].inv_mass = 1.f;
    AG[0].max_speed = 1.2f;
    for (int s = 0; s < 900; s++) {
        for (int i = 0; i < n; i++) {
            RtVec2 d = rt_v2_sub(goal, AG[i].pos);
            float l = rt_v2_len(d);
            AG[i].pref_vel = (l > 0.5f) ? rt_v2_mul(d, 1.2f / l) : rt_v2(0.f, 0.f);
        }
        (void)rt_stuck_step(&SC, AG, n, &G, dt, NULL);
        (void)rt_local_step(&LC, AG, n, &G, dt);
    }
    int arrived = 0;
    for (int i = 0; i < n; i++) if (AG[i].pos.x > 112.f) arrived++;
    printf("  after the blocker moved away: arrived=%d/%d (x=%.1f..%.1f)\n",
           arrived, n, AG[0].pos.x, AG[5].pos.x);
    OK(arrived == n, "T4 the queue clears once the blocker leaves");
}

/* ----------------------------------------------------------------------------
 * T5：1000 人的成本
 * --------------------------------------------------------------------------*/
static void t5_cost(void)
{
    printf("\n[T5] 1000 人每帧成本（含 4 Hz 采样）\n");
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    rt_grid_rebuild_all(&G);

    rt_local_destroy(&LC);
    rt_local_init(&LC, 256.f, 256.f, MAXA, 4.5f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);

    rt_stuck_destroy(&SC);
    rt_stuck_init(&SC, MAXA, NULL);

    const int n = 1000;
    const float dt = 1.f / 30.f;
    for (int i = 0; i < n; i++) {
        float x = 30.f + (float)(i % 40) * 1.5f + (float)(i % 3) * 0.1f;
        float z = 30.f + (float)(i / 40) * 1.5f + (float)(i % 5) * 0.1f;
        agent_set(i, x, z, 0.5f, 1.5f, 1.5f, 0.f);
    }

    double best = 1e30, sum = 0, worst = 0;
    const int steps = 300;
    for (int s = 0; s < steps; s++) {
        for (int i = 0; i < n; i++) AG[i].pref_vel = rt_v2(1.5f, 0.f);
        double t0 = now_ms();
        rt_stuck_step(&SC, AG, n, &G, dt, NULL);
        double d = now_ms() - t0;
        if (d < best) best = d;
        if (d > worst) worst = d;
        sum += d;
        (void)rt_local_step(&LC, AG, n, &G, dt);
    }
    printf("  n=1000: best=%.4f ms  mean=%.4f ms  worst(采样帧)=%.4f ms  samples=%u episodes=%u\n",
           best, sum / steps, worst, SC.st.samples, SC.st.episodes);
    OK(best < 0.50, "T5 stuck detection costs < 0.5 ms for 1000 units");
    OK(worst < 1.00, "T5 even the 4 Hz sampling frame stays under 1 ms");
    OK(sum / steps < 0.60, "T5 mean stays < 0.6 ms");
}

/* ----------------------------------------------------------------------------
 * T6：确定性
 * --------------------------------------------------------------------------*/
static void t6_determinism(void)
{
    printf("\n[T6] 确定性\n");
    static RtLocalAgent A1[MAXA];
    static RtStuckUnit U1[MAXA];

    int c = 0, f = 0;
    float ms = 0.f;
    t1_corridor(1, &c, &f, &ms, 0);
    memcpy(A1, AG, sizeof(RtLocalAgent) * 6);
    memcpy(U1, SC.u, sizeof(RtStuckUnit) * 6);
    uint32_t ep1 = SC.st.episodes;

    t1_corridor(1, &c, &f, &ms, 0);
    int d1 = memcmp(A1, AG, sizeof(RtLocalAgent) * 6) != 0;
    int d2 = memcmp(U1, SC.u, sizeof(RtStuckUnit) * 6) != 0;
    printf("  agent memcmp=%s  unit memcmp=%s  episodes=%u/%u\n",
           d1 ? "DIFF" : "same", d2 ? "DIFF" : "same", ep1, SC.st.episodes);
    OK(!d1, "T6 agent state is bit-identical across runs");
    OK(!d2, "T6 stuck state machine is bit-identical across runs");
}

int main(void)
{
    timer_init();
    printf("=== M6 tests: stall detection + graded recovery (FR-STK) ===\n");
    t1();
    t2_unreachable();
    t3_legit_queue();
    t4_idle_blocker();
    t5_cost();
    t6_determinism();

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    if (g_fail == 0) printf("ALL PASS (%d asserts)\n", g_pass);
    rt_stuck_destroy(&SC);
    rt_local_destroy(&LC);
    rt_grid_destroy(&G);
    return g_fail == 0 ? 0 : 1;
}

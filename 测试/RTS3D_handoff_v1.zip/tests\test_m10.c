/* ============================================================================
 * test_m10.c -- 窄通道所有权（FR-STK-3）
 *
 * 场景：一条 2 格宽、40 m 长的走廊，两端开阔。
 *   A 队 6 人从左边去右边，B 队 6 人从右边去左边。
 *   没有仲裁 -> 在中间对顶，谁也过不去（脚本行人流，不会侧移）。
 *   有仲裁   -> A 先拿所有权，B 在入口外等；A 全部通过并清空后释放，B 再过。
 *
 * 这条测试只验证**仲裁策略**：给谁过、什么时候换手、非 owner 会不会偷偷进去。
 * 与 ORCA 的耦合在 M9 的 gate 场景里。
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_corridor.h"

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", (m)); } } while (0)

#define MAXU 64

typedef struct {
    RtVec2 pos;
    int    team;      /* 0 = A（向左走 -> 右），1 = B */
    int    arrived;
} Unit;

static Unit U[MAXU];
static int  NU;
static RtGrid G;
static RtCorrCtx CC;

static void build_corridor(void)
{
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    /* 2 格宽走廊：x∈[100,140]，z=127/128；其余区域全开放 */
    for (int z = 0; z < 256; z++)
        for (int x = 100; x <= 140; x++)
            if (z != 127 && z != 128)
                rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);
}

static void spawn(void)
{
    NU = 0;
    for (int i = 0; i < 6; i++) {          /* A：左边，向 +x */
        U[NU].pos = rt_v2(92.f + (float)(i / 2) * 1.6f, 127.5f + (float)(i % 2) * 1.0f);
        U[NU].team = 0; U[NU].arrived = 0; NU++;
    }
    for (int i = 0; i < 6; i++) {          /* B：右边，向 -x */
        U[NU].pos = rt_v2(152.f - (float)(i / 2) * 1.6f, 127.5f + (float)(i % 2) * 1.0f);
        U[NU].team = 1; U[NU].arrived = 0; NU++;
    }
}

/* 前方同车道是否有人（不会侧移） */
static int blocked_ahead(int i, float dir)
{
    for (int j = 0; j < NU; j++) {
        if (j == i || U[j].arrived) continue;
        if (fabsf(U[j].pos.z - U[i].pos.z) > 0.8f) continue;
        float dx = (U[j].pos.x - U[i].pos.x) * dir;
        if (dx > 0.f && dx < 1.05f) return 1;
    }
    return 0;
}

/* use_owner = 0 对照；= 1 开仲裁。返回通过人数，*viol 记非 owner 闯入次数 */
static int run(int use_owner, int *out_viol, int *out_grants, int *out_frames)
{
    build_corridor();
    spawn();
    rt_corr_destroy(&CC);
    rt_corr_init(&CC, 4, 4.0f, 40.0f);
    int cid = rt_corr_add(&CC, 100.f, 127.f, 141.f, 129.f, 0);

    const float dt = 1.f / 30.f;
    const float sp = 1.5f;
    int viol = 0, frames = 0;

    for (int s = 0; s < 3600; s++) {
        frames = s;

        if (use_owner) {
            /* 申请：某队有人在入口附近、且通道空闲 -> 申请 */
            for (int t = 0; t < 2; t++) {
                int lead_near = 0;
                for (int i = 0; i < NU; i++) {
                    if (U[i].team != t || U[i].arrived) continue;
                    if (t == 0 && U[i].pos.x < 99.f && U[i].pos.x > 93.f) lead_near = 1;
                    if (t == 1 && U[i].pos.x > 143.f && U[i].pos.x < 150.f) lead_near = 1;
                }
                if (lead_near) (void)rt_corr_request(&CC, cid, t);
            }
        }

        for (int i = 0; i < NU; i++) {
            if (U[i].arrived) continue;
            float dir = (U[i].team == 0) ? 1.f : -1.f;
            float next = U[i].pos.x + dir * sp * dt;

            /* 非 owner：停在**入口外**（不是出口边上），否则会堵住对方出门 */
            if (use_owner && !rt_corr_allowed(&CC, cid, U[i].team)) {
                float hold = (U[i].team == 0) ? 97.f : 147.f;
                int would_enter = (U[i].team == 0) ? (next > hold) : (next < hold);
                if (would_enter) { viol++; continue; }
            }
            if (blocked_ahead(i, dir)) continue;
            U[i].pos.x = next;

            /* 「通过」= 走出走廊另一端（141/100），不是走到对方的老家 */
            if ((U[i].team == 0 && U[i].pos.x > 143.f) ||
                (U[i].team == 1 && U[i].pos.x < 98.f)) {
                U[i].arrived = 1;
            }
        }

        if (use_owner) {
            /* 报告 owner「还要用通道」的人数：通道内 + 入口附近排队。
             * 只报 inside 会让「队伍还没进门」被当成「用完了」，0.3 s 就释放，
             * 于是两队每帧互相抢（实测 grants=302、谁也没过去）。 */
            int owner = CC.c[cid].owner;
            int pending = 0;
            for (int i = 0; i < NU; i++) {
                if (U[i].arrived || U[i].team != owner) continue;
                if (rt_corr_contains(&CC.c[cid], U[i].pos) ||
                    (U[i].pos.x > 94.f && U[i].pos.x < 147.f))
                    pending++;
            }
            rt_corr_note_pending(&CC, cid, pending);
            rt_corr_tick(&CC, dt);
        }

        int done = 0;
        for (int i = 0; i < NU; i++) if (U[i].arrived) done++;
        if (done == NU) break;
    }

    int done = 0;
    for (int i = 0; i < NU; i++) if (U[i].arrived) done++;
    if (out_viol) *out_viol = viol;
    if (out_grants) *out_grants = (int)CC.c[cid].grants;
    if (out_frames) *out_frames = frames;
    return done;
}

int main(void)
{
    printf("=== M10 tests: corridor ownership (FR-STK-3) ===\n");

    int v0 = 0, g0 = 0, f0 = 0, v1 = 0, g1 = 0, f1 = 0;
    printf("\n[T1] 2 格宽走廊，6 人对穿\n");
    int a0 = run(0, &v0, &g0, &f0);
    printf("  control: crossed=%d/12 frames=%d\n", a0, f0);
    int a1 = run(1, &v1, &g1, &f1);
    printf("  owner  : crossed=%d/12 frames=%d grants=%d（非 owner 在入口外等待 %d 次）\n",
           a1, f1, g1, v1);

    OK(a0 <= 2, "T1 without ownership the corridor deadlocks");
    OK(a1 == 12, "T1 with ownership all twelve get through");
    OK(g1 >= 2, "T1 ownership handed over at least once");
    OK(f1 < f0, "T1 ownership is faster than mutual blocking");

    printf("\n[T2] TTL / 释放语义\n");
    rt_corr_destroy(&CC);
    rt_corr_init(&CC, 4, 4.0f, 10.0f);
    int cid = rt_corr_add(&CC, 0.f, 0.f, 10.f, 10.f, 0);
    int r1 = rt_corr_request(&CC, cid, 0);
    int r2 = rt_corr_request(&CC, cid, 1);
    int al0 = rt_corr_allowed(&CC, cid, 0);
    int al1 = rt_corr_allowed(&CC, cid, 1);
    rt_corr_note_pending(&CC, cid, 2);
    for (int i = 0; i < 30; i++) rt_corr_tick(&CC, 1.f / 30.f);   /* 1 s，队伍还在 */
    int still = (CC.c[cid].owner == 0);
    rt_corr_note_pending(&CC, cid, 0);
    for (int i = 0; i < 30; i++) rt_corr_tick(&CC, 1.f / 30.f);   /* 清空 1 s -> 释放 */
    int freed = (CC.c[cid].owner < 0);
    int r3 = rt_corr_request(&CC, cid, 1);

    printf("  A request=%d B request=%d allowed(A/B)=%d/%d still_owned_1s=%d freed=%d B_later=%d\n",
           r1, r2, al0, al1, still, freed, r3);
    OK(r1 == 1 && r2 == 0, "T2 second team is refused while the first owns it");
    OK(al0 == 1 && al1 == 0, "T2 only the owner is allowed in");
    OK(still == 1, "T2 ownership is not dropped while the team is still inside");
    OK(freed == 1, "T2 corridor is released after the team clears out");
    OK(r3 == 1, "T2 the waiting team can take over afterwards");

    printf("\n[T3] 强制释放（owner 卡死在通道里）\n");
    rt_corr_destroy(&CC);
    rt_corr_init(&CC, 2, 4.0f, 2.0f);
    cid = rt_corr_add(&CC, 0.f, 0.f, 10.f, 10.f, 0);
    (void)rt_corr_request(&CC, cid, 0);
    rt_corr_note_pending(&CC, cid, 1);
    for (int i = 0; i < 90; i++) rt_corr_tick(&CC, 1.f / 30.f);   /* 3 s > max_hold 2 s */
    printf("  after 3 s with max_hold=2: owner=%d expires=%u\n", CC.c[cid].owner, CC.c[cid].expires);
    OK(CC.c[cid].owner < 0, "T3 a stuck owner is force-released at max_hold");
    OK(CC.c[cid].expires == 1, "T3 the forced release is counted");

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    if (g_fail == 0) printf("ALL PASS (%d asserts)\n", g_pass);
    rt_corr_destroy(&CC);
    rt_grid_destroy(&G);
    return g_fail == 0 ? 0 : 1;
}

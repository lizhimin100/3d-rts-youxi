/* ============================================================================
 * rt_spatial.h -- 多分辨率均匀网格空间索引（计数排序分桶）
 *
 * 关键约束（**探针实测发现的坑，不是理论担忧**）：
 *   3x3 桶查询要求 `cell_size >= 2 * query_radius`。
 *   否则查询半径超出 3x3 覆盖范围，会**静默漏检**邻居。
 *
 *   实测证据（design_probe.py S2）：
 *     4x4 单位、合并邻域半径 5.66m、桶 2m 时，
 *     「粗筛候选/单位 = 0.9」而「真邻居/单位 = 2.4」——
 *     候选数小于真邻居数，这不可能，正是漏检的直接证据。
 *     桶 8m（>= 5.66m）时两者回到 13.2 : 2.4，比例合理。
 *
 *   因此 build 时把 query_radius 作为**必填**参数并断言；
 *   不同 footprint 走不同桶尺寸（1x1 用 2m，4x4 用 8m），
 *   这就是题面要求的「多分辨率」的真实动机。
 * ==========================================================================*/
#ifndef RT_SPATIAL_H
#define RT_SPATIAL_H

#include "rt_types.h"
#include "rt_unit.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    float    cell;            /* 桶边长（米） */
    float    declared_radius; /* 构建时声明的最大查询半径 */
    int      gw, gh;
    int     *start;           /* gw*gh+1 */
    uint16_t *items;          /* RT_MAX_UNITS */
    uint16_t *cell_of;        /* RT_MAX_UNITS（临时，构建用） */
    int     *wr;              /* gw*gh（临时，前缀和写指针） */
    int      n;
    int      cap_cells;
} RtSpatialGrid;

/* 给定查询半径，返回满足不漏检的最小桶尺寸 */
float rt_spatial_required_cell(float query_radius);

int  rt_spatial_init(RtSpatialGrid *sg, float world_w, float world_h, float cell_size);
void rt_spatial_destroy(RtSpatialGrid *sg);

/* 构建索引。query_radius = 调用方将要使用的最大查询半径。
 * 返回 RT_ERR_INVALID 表示 cell_size 不足（调用方应改用更大的桶）。 */
int rt_spatial_build(RtSpatialGrid *sg, const RtUnitStore *units,
                     const RtUnitId *ids, int n, float query_radius);

/* 圆查询：返回写入 out 的个数（受 max_out 截断）。
 *
 * `exclude` 语义必须显式给定（不要靠调用方记得减 1）：
 *   传 RT_UNIT_ID_NONE  -> 结果包含查询者自己（通用空间查询）
 *   传某个 id           -> 结果排除该 id（避障/邻居查询的常见用法）
 *
 * 首版没有这个参数，测试里 grid 结果恒比 brute 多 1（1000 单位多 1000），
 * 定位后才发现是「包含自己」——这类口径不明确比算法错更隐蔽。
 */
int rt_spatial_query_circle(const RtSpatialGrid *sg, const RtUnitStore *units,
                            RtVec2 center, float radius, RtUnitId exclude,
                            RtUnitId *out, int max_out);

/* 矩形查询（框选/统计，FR-SPA-3） */
int rt_spatial_query_rect(const RtSpatialGrid *sg, const RtUnitStore *units,
                          RtAabb2 rect, RtUnitId *out, int max_out);

/* 上一次查询是否被 max_out 截断（1 = 是）。截断必须被计数，否则统计会偏低。 */
int rt_spatial_last_truncated(void);

#ifdef __cplusplus
}
#endif

#endif /* RT_SPATIAL_H */

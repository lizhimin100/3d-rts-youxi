/* ============================================================================
 * test_m14.c -- 窄通道自动检测 + 自动仲裁注册（FR-STK-3 收尾）
 *
 * M10/M11 的通道矩形是手工 `rt_corr_add(128,126,139,128,0)` 摆的。
 * 本文件要证明：**同一张图，零手工配置**，检测出来的矩形和手工那条逐字段相同，
 * 而且仲裁效果一样。
 *
 *   T1 几何：11 m 长 × 2 m 宽的隧道 -> 一个 portal，rect/axis/len/width 全对
 *   T2 假阳性：开阔地必须 0 个
 *   T3 编辑：把隧道拓宽到 6 m -> portal 还在但不再算窄，注册数为 0
 *   T4 复现 M11：自动注册后跑 60v60，A 队 95% 通过 vs 不仲裁的对照组
 *   T5 宽通道不仲裁（3 m 与 6 m 两个洞）
 *   T6 成本 / T7 确定性
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_stuck.h"
#include "rt_yield.h"
#include "rt_corridor.h"
#include "rt_portal.h"
#include "rt_region.h"
#include "rt_group.h"
#include "rt_unit.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", (m)); } } while (0)

#define MAXA 1024
#define WALL_X0 128
#define WALL_X1 138          /* 墙体占据 cell x ∈ [128,138] */
#define TUN_Z0  126          /* 隧道 cell z ∈ [126,127] = 2 m 宽 */
#define TUN_Z1  127

static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;
static RtStuckCtx SC;
static RtYieldCtx YC;
static RtCorrCtx CC;
static RtPortalMap PM;
static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static RtUnitId IDS[MAXA];
static int TEAM[MAXA];
static int ARRIVED[MAXA];
static uint8_t HELD[MAXA];
static int N = 0;

/* ---------------------------------------------------------------------------
 * 世界
 * -------------------------------------------------------------------------*/
static void map_clear(void)
{
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
}

/* 一道 11 格厚的墙 + 一条隧洞（z 宽度可调） */
static void map_tunnel(int z0, int z1)
{
    for (int x = WALL_X0; x <= WALL_X1; x++)
        for (int z = 0; z < 256; z++) {
            if (z >= z0 && z <= z1) continue;
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
}

static void world_build(void)
{
    rt_grid_rebuild_all(&G);
    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
    rt_local_destroy(&LC);
    rt_local_init(&LC, 256.f, 256.f, MAXA, 4.5f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);
    rt_yield_destroy(&YC);
    rt_yield_init(&YC, MAXA, NULL, &G);
    rt_corr_destroy(&CC);
    rt_corr_init(&CC, 8, 60.f, 600.f);
    rt_corr_set_gate_params(&CC, 28.f, 1.2f);
    rt_corr_set_stall_limit(&CC, 20.f);
    N = 0;
}

/* ---------------------------------------------------------------------------
 * T1 / T2 / T3 / T5 / T6 / T7：检测本身
 * -------------------------------------------------------------------------*/
static void t1_geometry(void)
{
    printf("\n[T1] geometry: 11 m x 2 m tunnel\n");
    map_clear();
    map_tunnel(TUN_Z0, TUN_Z1);
    world_build();

    rt_portal_destroy(&PM);
    rt_portal_init(&PM, RT_PORTAL_MAX, NULL);
    int n = rt_portal_scan(&PM, &G);
    if (n > 0) {
        const RtPortal *p = &PM.p[0];
        printf("      portal0 rect=[%.1f,%.1f]x[%.1f,%.1f] axis=%d len=%.1f width=%.1f"
               " cells=%d clr=[%.2f,%.2f]\n",
               p->x0, p->x1, p->z0, p->z1, p->axis, p->len_m, p->width_m,
               p->cells, p->min_clear, p->max_clear);
    }
    printf("      blobs=%u accepted=%u small=%u huge=%u walkable=%d\n",
           PM.st.blobs, PM.st.accepted, PM.st.rejected_small,
           PM.st.rejected_huge, PM.st.walkable_cells);

    OK(n == 1, "T1 exactly one portal in the map");
    if (n == 1) {
        const RtPortal *p = &PM.p[0];
        OK(fabsf(p->x0 - 128.f) < 0.01f && fabsf(p->x1 - 139.f) < 0.01f,
           "T1 portal x range == hand-registered [128,139]");
        OK(fabsf(p->z0 - 126.f) < 0.01f && fabsf(p->z1 - 128.f) < 0.01f,
           "T1 portal z range == hand-registered [126,128]");
        OK(p->axis == 0, "T1 axis = 0 (pass along x)");
        OK(fabsf(p->len_m - 11.f) < 0.01f && fabsf(p->width_m - 2.f) < 0.01f,
           "T1 len 11 m / width 2 m");
        OK(p->cells == 22, "T1 22 cells (11 x 2)");
    } else {
        OK(0, "T1 x range"); OK(0, "T1 z range"); OK(0, "T1 axis");
        OK(0, "T1 len/width"); OK(0, "T1 cells");
    }

    /* 注册：窄 -> 注册 1 条，矩形与手工一致 */
    int reg = rt_portal_register(&PM, &CC);
    OK(reg == 1 && CC.n == 1, "T1 auto-registered exactly one corridor");
    if (CC.n == 1) {
        OK(fabsf(CC.c[0].x0 - 128.f) < 0.01f && fabsf(CC.c[0].x1 - 139.f) < 0.01f &&
           fabsf(CC.c[0].z0 - 126.f) < 0.01f && fabsf(CC.c[0].z1 - 128.f) < 0.01f,
           "T1 corridor rect identical to rt_corr_add(128,126,139,128)");
        OK(CC.c[0].axis == 0, "T1 corridor axis 0");
        /* 等待区：两侧都要在通道外，且不压在通道上 */
        int ok0 = CC.c[0].has_stg[0] && CC.c[0].has_stg[1];
        float ax0 = CC.c[0].stg[0][0], az0 = CC.c[0].stg[0][1];
        float ax1 = CC.c[0].stg[0][2], az1 = CC.c[0].stg[0][3];
        int outside0 = (ax1 <= 128.f + 0.01f) || (ax0 >= 139.f - 0.01f) ||
                       (az1 <= 126.f + 0.01f) || (az0 >= 128.f - 0.01f);
        float bx0 = CC.c[0].stg[1][0], bz0 = CC.c[0].stg[1][1];
        float bx1 = CC.c[0].stg[1][2], bz1 = CC.c[0].stg[1][3];
        int outside1 = (bx1 <= 128.f + 0.01f) || (bx0 >= 139.f - 0.01f) ||
                       (bz1 <= 126.f + 0.01f) || (bz0 >= 128.f - 0.01f);
        printf("      staging0=[%.1f,%.1f]x[%.1f,%.1f] staging1=[%.1f,%.1f]x[%.1f,%.1f]\n",
               ax0, ax1, az0, az1, bx0, bx1, bz0, bz1);
        OK(ok0, "T1 both staging rects registered");
        OK(outside0 && outside1, "T1 staging rects do not overlap the corridor");
    } else {
        OK(0, "T1 corridor rect"); OK(0, "T1 corridor axis");
        OK(0, "T1 staging registered"); OK(0, "T1 staging outside");
    }
}

static void t2_open_field(void)
{
    printf("\n[T2] no false positives on an open field\n");
    map_clear();
    world_build();
    rt_portal_destroy(&PM);
    rt_portal_init(&PM, RT_PORTAL_MAX, NULL);
    int n = rt_portal_scan(&PM, &G);
    printf("      portals=%d blobs=%u walkable=%d\n", n, PM.st.blobs, PM.st.walkable_cells);
    OK(n == 0 && PM.st.blobs == 0, "T2 open field has zero portals");
    OK(rt_portal_register(&PM, &CC) == 0 && CC.n == 0, "T2 nothing registered");
}

static void t3_edit(void)
{
    printf("\n[T3] edit: widen the tunnel from 2 m to 6 m\n");
    map_clear();
    map_tunnel(TUN_Z0, TUN_Z1);
    world_build();
    rt_portal_destroy(&PM);
    rt_portal_init(&PM, RT_PORTAL_MAX, NULL);
    int n0 = rt_portal_scan(&PM, &G);

    /* 拓宽：z=124..129 全开 -> 6 m 宽 */
    for (int x = WALL_X0; x <= WALL_X1; x++)
        for (int z = 124; z <= 129; z++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 0);
    rt_grid_rebuild_all(&G);

    int n1 = rt_portal_scan(&PM, &G);
    int reg = rt_portal_register(&PM, &CC);
    printf("      before: %d portal(s) | after: %d portal(s), width=%.1f, registered=%d\n",
           n0, n1, (n1 > 0) ? PM.p[0].width_m : 0.f, reg);
    OK(n0 == 1, "T3 one portal before the edit");
    OK(n1 == 0 || PM.p[0].width_m > 2.5f,
       "T3 after widening: portal is gone or no longer narrow");
    OK(reg == 0 && CC.n == 0, "T3 widened portal is not registered for arbitration");
}

static void t5_wide(void)
{
    printf("\n[T5] wide gap must not be arbitrated (3 m and 6 m)\n");
    /* 3 m */
    map_clear();
    map_tunnel(126, 128);
    world_build();
    rt_portal_destroy(&PM);
    rt_portal_init(&PM, RT_PORTAL_MAX, NULL);
    int n3 = rt_portal_scan(&PM, &G);
    int r3 = rt_portal_register(&PM, &CC);
    printf("      3 m gap: portals=%d width=%.1f registered=%d\n",
           n3, (n3 > 0) ? PM.p[0].width_m : 0.f, r3);
    OK(n3 == 0 || PM.p[0].width_m > 2.5f, "T5 3 m gap is not classified as a lane");
    OK(r3 == 0, "T5 3 m gap is not arbitrated");

    /* 6 m */
    map_clear();
    map_tunnel(124, 129);
    world_build();
    rt_portal_destroy(&PM);
    rt_portal_init(&PM, RT_PORTAL_MAX, NULL);
    int n6 = rt_portal_scan(&PM, &G);
    int r6 = rt_portal_register(&PM, &CC);
    printf("      6 m gap: portals=%d registered=%d\n", n6, r6);
    OK(n6 == 0, "T5 6 m gap produces no portal at all");
    OK(r6 == 0, "T5 6 m gap is not arbitrated");
}

static void t6_cost(void)
{
    printf("\n[T6] cost\n");
    map_clear();
    map_tunnel(TUN_Z0, TUN_Z1);
    world_build();
    rt_portal_destroy(&PM);
    rt_portal_init(&PM, RT_PORTAL_MAX, NULL);

    /* 中位数而不是均值：第一次扫描要付 realloc 的页错误（实测 20 ms 量级），
     * 混进均值会把稳态成本说得大 2 倍 —— 和 M3.4 的「看中位数」是同一个理由。 */
    double best = 1e30, med;
    const int R = 20;
    double v[32];
    for (int k = 0; k < R; k++) {
        double t0 = now_ms();
        (void)rt_portal_scan(&PM, &G);
        v[k] = now_ms() - t0;
        if (v[k] < best) best = v[k];
    }
    for (int a = 1; a < R; a++) {          /* 插入排序，R 很小 */
        double key = v[a]; int b = a - 1;
        while (b >= 0 && v[b] > key) { v[b + 1] = v[b]; b--; }
        v[b + 1] = key;
    }
    med = v[R / 2];
    printf("      256x256 scan: best=%.3f ms median=%.3f ms cold=%.3f ms (65 536 cells)\n",
           best, med, v[R - 1]);
    OK(med < 2.0, "T6 full scan of 256x256 < 2 ms (median)");

    /* 确定性 */
    static RtPortal snap[RT_PORTAL_MAX];
    int n1 = rt_portal_scan(&PM, &G);
    memcpy(snap, PM.p, sizeof(RtPortal) * (size_t)n1);
    int n2 = rt_portal_scan(&PM, &G);
    printf("      determinism: n=%d/%d memcmp=%s\n", n1, n2,
           (n1 == n2 && memcmp(snap, PM.p, sizeof(RtPortal) * (size_t)n1) == 0) ? "same" : "DIFF");
    OK(n1 == n2 && memcmp(snap, PM.p, sizeof(RtPortal) * (size_t)n1) == 0,
       "T7 determinism: identical scan -> identical portals");
}

/* ---------------------------------------------------------------------------
 * T4：自动注册后跑 M11 的 60v60 隧道场景
 * -------------------------------------------------------------------------*/
typedef struct {
    int crossA, crossB;
    int frames;
    double t95A;
    float  max_pen;
    uint32_t perm, grants, handoffs, stalls;
    double t_mean;
} Tun;

static void spawn_team(int team, int n, float x0, float z0, int cols)
{
    for (int k = 0; k < n && N < MAXA; k++) {
        float x = x0 + (float)(k % cols) * 1.6f;
        float z = z0 + (float)(k / cols) * 1.6f;
        RtUnitId id = rt_units_spawn(&US, rt_v3(x, 0.f, z), RT_FP_SMALL);
        if (id == RT_UNIT_ID_NONE) break;
        IDS[N] = id;
        TEAM[N] = team;
        ARRIVED[N] = 0;
        HELD[N] = 0;
        memset(&AG[N], 0, sizeof(AG[N]));
        AG[N].pos = rt_v2(x, z);
        AG[N].radius = 0.5f;
        AG[N].max_speed = 2.0f;
        AG[N].fp = 1.0f;
        AG[N].share = 0.5f;
        AG[N].inv_mass = 1.f;
        N++;
    }
}

static int may_yield_cb(void *ud, int idx) { (void)ud; return !HELD[idx]; }

static Tun run_tunnel(int use_arb, int frames_max, int nA, int nB)
{
    Tun m;
    memset(&m, 0, sizeof(m));

    map_clear();
    map_tunnel(TUN_Z0, TUN_Z1);
    world_build();

    /* —— 零手工配置：扫 -> 自动注册 —— */
    rt_portal_destroy(&PM);
    rt_portal_init(&PM, RT_PORTAL_MAX, NULL);
    (void)rt_portal_scan(&PM, &G);
    (void)rt_portal_register(&PM, &CC);
    const int cid = (PM.n > 0) ? PM.p[0].cid : -1;
    const float cor_x0 = (PM.n > 0) ? PM.p[0].x0 : 128.f;
    const float cor_x1 = (PM.n > 0) ? PM.p[0].x1 : 139.f;
    const float cor_cz = (PM.n > 0) ? (PM.p[0].z0 + PM.p[0].z1) * 0.5f : 127.f;

    {
        RtStuckConfig cfg;
        rt_stuck_config_default(&cfg);
        cfg.permanent_time = 60.f;   /* 2 m 隧道里正常排队就会超 20 s（M11 §5） */
        rt_stuck_destroy(&SC);
        rt_stuck_init(&SC, MAXA, &cfg);
    }

    spawn_team(0, nA, 28.f, 118.f, 10);
    spawn_team(1, nB, 206.f, 118.f, 10);

    const float dt = 1.f / 30.f;
    const RtVec2 goalA = rt_v2(206.f, 190.f);
    const RtVec2 goalB = rt_v2(28.f, 62.f);
    {
        RtUnitId a[MAXA], b[MAXA];
        int na = 0, nb = 0;
        for (int i = 0; i < N; i++) { if (TEAM[i] == 0) a[na++] = IDS[i]; else b[nb++] = IDS[i]; }
        if (na) (void)rt_gw_command(&W, &US, a, na, goalA, 0, RT_CLS_SMALL, 1);
        if (nb) (void)rt_gw_command(&W, &US, b, nb, goalB, 0, RT_CLS_SMALL, 2);
    }

    double sum = 0;
    int frames = 0;
    for (int s = 0; s < frames_max; s++) {
        frames = s;
        const float now = (float)s * dt;
        double t0 = now_ms();

        if (use_arb && cid >= 0) {
            int needA = 0, needB = 0, pendA = 0, pendB = 0, nearA = 0, nearB = 0;
            int passA = 0, passB = 0;
            for (int i = 0; i < N; i++) {
                int passed = (TEAM[i] == 0) ? (AG[i].pos.x > cor_x1 + 2.f)
                                            : (AG[i].pos.x < cor_x0 - 2.f);
                if (TEAM[i] == 0) { if (passed) passA++; }
                else              { if (passed) passB++; }
                int needs = !ARRIVED[i] &&
                            ((TEAM[i] == 0) ? (AG[i].pos.x < cor_x1 + 2.f)
                                            : (AG[i].pos.x > cor_x0 - 2.f));
                if (!needs) continue;
                float dz = AG[i].pos.z - cor_cz;
                float ex = (TEAM[i] == 0) ? cor_x0 : cor_x1;
                float dx = AG[i].pos.x - ex;
                int is_near = rt_corr_contains(&CC.c[cid], AG[i].pos) ||
                              sqrtf(dx * dx + dz * dz) < 12.f;
                if (TEAM[i] == 0) { needA = 1; pendA++; if (is_near) nearA++; }
                else              { needB = 1; pendB++; if (is_near) nearB++; }
            }
            if (needA) rt_corr_want(&CC, cid, 0, now); else rt_corr_unwant(&CC, cid, 0);
            if (needB) rt_corr_want(&CC, cid, 1, now); else rt_corr_unwant(&CC, cid, 1);
            (void)rt_corr_acquire(&CC, cid);
            int owner = CC.c[cid].owner;
            rt_corr_note_state(&CC, cid,
                               (owner == 0) ? pendA : (owner == 1 ? pendB : 0),
                               (owner == 0) ? nearA : (owner == 1 ? nearB : 0),
                               (owner == 0) ? passA : (owner == 1 ? passB : 0));
            rt_corr_tick(&CC, dt);
        }

        for (int i = 0; i < N; i++) {
            RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, IDS[i]);
            int gi = (int)ch->group[rt_unit_slot_index(IDS[i])] - 1;
            RtVec2 pref = rt_v2(0.f, 0.f);
            if (gi >= 0) {
                RtVec2 tgt;
                if (rt_gw_sample(&W, gi, AG[i].pos, &tgt) == RT_OK) {
                    RtVec2 d = rt_v2_sub(tgt, AG[i].pos);
                    float l = rt_v2_len(d);
                    if (l > 1e-3f) pref = rt_v2_mul(d, 2.0f / l);
                }
            }
            HELD[i] = 0;
            if (use_arb && cid >= 0 && CC.c[cid].owner >= 0 && CC.c[cid].owner != TEAM[i]) {
                int needs = !ARRIVED[i] &&
                            ((TEAM[i] == 0) ? (AG[i].pos.x < cor_x1 + 2.f)
                                            : (AG[i].pos.x > cor_x0 - 2.f));
                if (needs) {
                    HELD[i] = 1;
                    float dz = AG[i].pos.z - cor_cz;
                    float ex = (TEAM[i] == 0) ? cor_x0 : cor_x1;
                    float dx = AG[i].pos.x - ex;
                    if (sqrtf(dx * dx + dz * dz) < 28.f) {
                        int side = rt_corr_side(&CC.c[cid], AG[i].pos);
                        if (side >= 0) {
                            RtVec2 wp = rt_corr_staging_point(&CC, cid, side, i % 64, 64);
                            pref = rt_corr_gate(&CC, cid, TEAM[i], AG[i].pos, pref, wp);
                        }
                    }
                }
            }
            AG[i].pref_vel = pref;
            rt_stuck_set_hold(&SC, i, HELD[i]);
        }

        rt_stuck_step(&SC, AG, N, &G, dt, NULL);
        rt_yield_step(&YC, AG, N, &G, dt, may_yield_cb, NULL);
        (void)rt_local_step(&LC, AG, N, &G, dt);
        (void)rt_gw_update(&W);

        sum += now_ms() - t0;

        int ca = 0, cb = 0;
        for (int i = 0; i < N; i++) {
            if (TEAM[i] == 0) { if (AG[i].pos.x > cor_x1 + 2.f) ca++; }
            else              { if (AG[i].pos.x < cor_x0 - 2.f) cb++; }
        }
        m.crossA = ca; m.crossB = cb;
        int needA = (nA * 95 + 99) / 100, needB = (nB * 95 + 99) / 100;
        if (m.t95A <= 0.0 && ca >= needA) m.t95A = (double)s * dt;
        if (ca >= needA && cb >= needB) break;
    }

    m.frames = frames;
    m.t_mean = sum / (double)(frames + 1);
    m.perm = SC.st.permanent_stuck;
    for (int i = 0; i < N; i++) {
        for (int j = i + 1; j < N; j++) {
            float d = rt_v2_dist(AG[i].pos, AG[j].pos);
            float pen = (AG[i].radius + AG[j].radius) - d;
            if (pen > m.max_pen) m.max_pen = pen;
        }
    }
    if (cid >= 0) {
        m.grants = CC.c[cid].grants;
        m.handoffs = CC.c[cid].handoffs;
        m.stalls = CC.c[cid].stalls;
    }
    return m;
}

static void t4_m11_replay(void)
{
    printf("\n[T4] replay M11: 60 v 60 through the 2 m tunnel (auto-registered)\n");
    const int FR = 160 * 30;   /* 160 s：对照组 95% 在 212 s，仲裁组 108 s */
    Tun off = run_tunnel(0, FR, 60, 60);
    printf("      no arbitration : crossed A=%d B=%d  t95A=%s  perm=%u  %.2f ms/frame\n",
           off.crossA, off.crossB, (off.t95A > 0 ? "ok" : "never"), off.perm, off.t_mean);
    Tun on = run_tunnel(1, FR, 60, 60);
    printf("      auto arbitration: crossed A=%d B=%d  t95A=%.1f s  perm=%u"
           "  grants=%u handoffs=%u stalls=%u  %.2f ms/frame\n",
           on.crossA, on.crossB, on.t95A, on.perm, on.grants, on.handoffs, on.stalls, on.t_mean);

    /* liveness：仲裁不能让某一队永远过不去（M11 的 B 队 95% 在 321 s） */
    Tun live = run_tunnel(1, 380 * 30, 60, 60);
    printf("      liveness (380 s): A=%d B=%d  grants=%u handoffs=%u stalls=%u\n",
           live.crossA, live.crossB, live.grants, live.handoffs, live.stalls);

    OK(on.crossA >= 57, "T4 with auto arbitration 95% of team A is through");
    OK(on.crossA > off.crossA, "T4 arbitration is faster than the control at the same time");
    OK(on.grants >= 2, "T4 ownership was actually handed over (grants >= 2)");
    OK(on.perm == 0, "T4 no PermanentStuck with auto arbitration");
    OK(on.max_pen < 0.60f, "T4 penetration < 0.6 m");
    OK(live.crossA >= 57 && live.crossB >= 57,
       "T4 liveness: both teams get through given 380 s (no starvation)");
}

/* 两条隧道（z=60..61 与 z=190..191），检查多通道同时注册 */
static void map_two_tunnels(void)
{
    for (int x = WALL_X0; x <= WALL_X1; x++)
        for (int z = 0; z < 256; z++) {
            if ((z >= 60 && z <= 61) || (z >= 190 && z <= 191)) continue;
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
}

/* L 形窄通道（2 m 宽、拐直角）：一个矩形描述不了 */
static void map_bent(void)
{
    for (int x = 120; x <= 160; x++)
        for (int z = 120; z <= 160; z++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int x = 120; x <= 158; x++)          /* 西向的横臂，z 两层 */
        for (int z = 140; z <= 141; z++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 0);
    for (int x = 157; x <= 158; x++)          /* 向北的竖臂 */
        for (int z = 120; z <= 141; z++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 0);
}

static void t8_two_tunnels(void)
{
    printf("\n[T8] two tunnels in one map\n");
    map_clear();
    map_two_tunnels();
    world_build();
    rt_portal_destroy(&PM);
    rt_portal_init(&PM, RT_PORTAL_MAX, NULL);
    int n = rt_portal_scan(&PM, &G);
    int reg = rt_portal_register(&PM, &CC);
    printf("      portals=%d registered=%d\n", n, reg);
    for (int i = 0; i < n; i++)
        printf("        p%d z=[%.0f,%.0f] width=%.1f cells=%d cid=%d\n",
               i, PM.p[i].z0, PM.p[i].z1, PM.p[i].width_m, PM.p[i].cells, PM.p[i].cid);
    OK(n == 2, "T8 two portals detected");
    OK(reg == 2 && CC.n == 2, "T8 both registered");
    if (n == 2) {
        /* 扫描按 z 行推进，顺序确定：低 z 的先出 */
        OK(fabsf(PM.p[0].z0 - 60.f) < 0.01f && fabsf(PM.p[1].z0 - 190.f) < 0.01f,
           "T8 portal order is deterministic (by z)");
        OK(fabsf(PM.p[0].width_m - 2.f) < 0.01f && fabsf(PM.p[1].width_m - 2.f) < 0.01f,
           "T8 both are 2 m wide");
        OK(PM.p[0].cid == 0 && PM.p[1].cid == 1, "T8 corridor ids are 0 and 1");
    } else {
        OK(0, "T8 order"); OK(0, "T8 widths"); OK(0, "T8 cids");
    }
}

static void t9_bent(void)
{
    printf("\n[T9] L-shaped corridor: split into 2 straight segments -> must NOT be arbitrated\n");
    map_clear();
    map_bent();
    world_build();
    rt_portal_destroy(&PM);
    rt_portal_init(&PM, RT_PORTAL_MAX, NULL);
    int n = rt_portal_scan(&PM, &G);
    int reg = rt_portal_register(&PM, &CC);
    printf("      portals=%d registered=%d chained=%u bent=%u\n",
           n, reg, PM.st.rejected_chained, PM.st.rejected_bent);
    for (int i = 0; i < n; i++)
        printf("        p%d rect=[%.0f,%.0f]x[%.0f,%.0f] w=%.1f fill=%.2f chained=%d\n",
               i, PM.p[i].x0, PM.p[i].x1, PM.p[i].z0, PM.p[i].z1,
               PM.p[i].width_m, PM.p[i].fill, PM.p[i].chained);
    /* L 形的拐角格 min(span) 很大、本身不算窄，所以它天然被切成两段直走廊。
     * 两段各自注册会在拐角形成两个 owner 互锁（跨通道协调是下一轮的事），
     * 所以本轮：**只要相接就不仲裁**，显式计数。 */
    OK(n >= 1, "T9 the L corridor is decomposed into straight segments");
    OK(PM.st.rejected_chained >= 1, "T9 touching segments are marked chained");
    OK(reg == 0 && CC.n == 0, "T9 chained segments are not arbitrated (no cross-corridor deadlock)");
}

int main(void)
{
    timer_init();
    printf("=== M14 tests: portal detection + auto arbitration ===\n");

    t1_geometry();
    t2_open_field();
    t3_edit();
    t5_wide();
    t8_two_tunnels();
    t9_bent();
    t6_cost();
    t4_m11_replay();

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    if (g_fail == 0) printf("ALL PASS (%d asserts)\n", g_pass);

    rt_portal_destroy(&PM);
    rt_corr_destroy(&CC);
    rt_stuck_destroy(&SC);
    rt_yield_destroy(&YC);
    rt_local_destroy(&LC);
    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return g_fail == 0 ? 0 : 1;
}

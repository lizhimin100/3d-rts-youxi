/* ============================================================================
 * rt_chain.c -- 通道链：多段共享一个 owner（M15）
 * 设计口径见 rt_chain.h 顶部。
 * ==========================================================================*/
#include "rt_chain.h"

#include <stdlib.h>
#include <string.h>

int rt_chain_init(RtChainCtx *x, RtCorrCtx *cc, int max_chains, float max_hold)
{
    if (!x) return RT_ERR_INVALID;
    memset(x, 0, sizeof(*x));
    if (max_chains <= 0) max_chains = 1;
    if (max_chains > RT_CHAIN_MAX) max_chains = RT_CHAIN_MAX;
    x->cap = max_chains;
    x->cc = cc;
    x->max_hold = (max_hold > 0.f) ? max_hold : 0.f;
    for (int i = 0; i < x->cap; i++) {
        x->c[i].owner = -1;
        for (int k = 0; k < RT_CORR_MAX_TEAMS; k++) x->c[i].want[k] = -1.f;
    }
    return RT_OK;
}

void rt_chain_destroy(RtChainCtx *x)
{
    if (!x) return;
    x->n = x->cap = 0;
    x->cc = NULL;
}

void rt_chain_clear_all(RtChainCtx *x)
{
    if (!x) return;
    x->n = 0;
    for (int i = 0; i < x->cap; i++) {
        memset(&x->c[i], 0, sizeof(RtChain));
        x->c[i].owner = -1;
        x->c[i].last_team = -1;
        for (int k = 0; k < RT_CORR_MAX_TEAMS; k++) x->c[i].want[k] = -1.f;
    }
}

int rt_chain_new(RtChainCtx *x){
    if (!x || x->n >= x->cap) return -1;
    RtChain *c = &x->c[x->n];
    memset(c, 0, sizeof(*c));
    c->owner = -1;
    c->last_team = -1;
    for (int k = 0; k < RT_CORR_MAX_TEAMS; k++) c->want[k] = -1.f;
    return x->n++;
}

int rt_chain_add_seg(RtChainCtx *x, int ch, int cid)
{
    if (!x || ch < 0 || ch >= x->n || cid < 0) return 0;
    RtChain *c = &x->c[ch];
    if (c->nseg >= RT_CHAIN_MAX_SEGS) return 0;
    for (int i = 0; i < c->nseg; i++) if (c->seg[i] == cid) return c->nseg;
    c->seg[c->nseg++] = cid;
    if (x->st.max_segs < (uint32_t)c->nseg) x->st.max_segs = (uint32_t)c->nseg;
    return c->nseg;
}

int rt_chain_of_seg(const RtChainCtx *x, int cid)
{
    if (!x || cid < 0) return -1;
    for (int i = 0; i < x->n; i++) {
        for (int k = 0; k < x->c[i].nseg; k++)
            if (x->c[i].seg[k] == cid) return i;
    }
    return -1;
}

void rt_chain_want(RtChainCtx *x, int ch, int team, float t)
{
    if (!x || ch < 0 || ch >= x->n) return;
    if (team < 0 || team >= RT_CORR_MAX_TEAMS) return;
    RtChain *c = &x->c[ch];
    if (c->want[team] < 0.f) c->want[team] = t;
}

void rt_chain_unwant(RtChainCtx *x, int ch, int team)
{
    if (!x || ch < 0 || ch >= x->n) return;
    if (team < 0 || team >= RT_CORR_MAX_TEAMS) return;
    x->c[ch].want[team] = -1.f;
}

int rt_chain_allowed(const RtChainCtx *x, int ch, int team)
{
    if (!x || ch < 0 || ch >= x->n) return 1;
    return x->c[ch].owner < 0 || x->c[ch].owner == team;
}

int rt_chain_acquire(RtChainCtx *x, int ch)
{
    if (!x || !x->cc || ch < 0 || ch >= x->n) return -1;
    RtChain *c = &x->c[ch];
    if (c->owner >= 0) return c->owner;

    x->st.acquire_calls++;

    /* FCFS：最早开始等的那一队先拿。没有人在等就不动。 */
    int team = -1;
    float best = 1e30f;
    for (int t = 0; t < RT_CORR_MAX_TEAMS; t++) {
        if (c->want[t] < 0.f) continue;
        if (c->want[t] < best) { best = c->want[t]; team = t; }
    }
    if (team < 0) return -1;

    /* 原子：先把能拿的都拿下来；任何一段拿不到就整条退回。
     * 「半个链在 A 手里」这个中间态必须不可达，否则死锁只是被推迟。 */
    int got[RT_CHAIN_MAX_SEGS];
    int ngot = 0;
    for (int i = 0; i < c->nseg; i++) {
        int cid = c->seg[i];
        if (cid < 0 || cid >= x->cc->n) continue;
        if (rt_corr_request(x->cc, cid, team)) { got[ngot++] = cid; }
        else {
            for (int k = 0; k < ngot; k++) rt_corr_release(x->cc, got[k], team);
            x->st.partial_fail++;
            return -1;
        }
    }
    if (ngot == 0) return -1;

    /* handoff = 所有权真正**换了队伍**（同一队连续拿两次不算）。
     * 不能写成「上一帧 owner >= 0」—— 授予的前提就是 owner < 0，
     * 那样 handoffs 永远为 0（M15 第一版就是这么错的）。 */
    if (c->last_team >= 0 && c->last_team != team) c->handoffs++;
    c->last_team = team;
    c->owner = team;
    c->grants++;
    c->held = 0.f;
    x->st.grants++;
    return team;
}

void rt_chain_release(RtChainCtx *x, int ch, int team)
{
    if (!x || !x->cc || ch < 0 || ch >= x->n) return;
    RtChain *c = &x->c[ch];
    if (c->owner < 0) return;
    if (team >= 0 && c->owner != team) return;
    for (int i = 0; i < c->nseg; i++) {
        int cid = c->seg[i];
        if (cid < 0 || cid >= x->cc->n) continue;
        rt_corr_release(x->cc, cid, c->owner);
    }
    c->owner = -1;
    c->held = 0.f;
}

void rt_chain_tick(RtChainCtx *x, float dt)
{
    if (!x || !x->cc || dt <= 0.f) return;
    for (int i = 0; i < x->n; i++) {
        RtChain *c = &x->c[i];
        if (c->owner < 0) continue;
        c->held += dt;

        /* 段被 rt_corridor 强制释放（stall / TTL）-> 整条收回。
         * 不整条收回的话，链以为自己还持有，而某一段已经空了：
         * 下一队会从那个缺口钻进去，又回到「半条链两个人」的互锁。 */
        int lost = 0;
        for (int k = 0; k < c->nseg; k++) {
            int cid = c->seg[k];
            if (cid < 0 || cid >= x->cc->n) continue;
            if (x->cc->c[cid].owner != c->owner) { lost = 1; break; }
        }
        if (lost) {
            for (int k = 0; k < c->nseg; k++) {
                int cid = c->seg[k];
                if (cid < 0 || cid >= x->cc->n) continue;
                if (x->cc->c[cid].owner == c->owner)
                    rt_corr_release(x->cc, cid, c->owner);
            }
            c->owner = -1;
            c->held = 0.f;
            c->stalls++;
            x->st.seg_lost++;
            continue;
        }

        if (x->max_hold > 0.f && c->held > x->max_hold) {
            rt_chain_release(x, i, -1);
            x->st.max_hold_release++;
        }
    }
}

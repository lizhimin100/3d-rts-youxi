/* ============================================================================
 * rt_form.h -- 队形（FR-FOR，M8）
 *
 * 设计（01 §10 / §11）：
 *   anchor + 局部 slot。slot 只是「相对 anchor 的一个点」，成员各自朝自己的
 *   slot 走（成员不各自寻路，FR-NAV-2）；朝向由 yaw 给出并平滑。
 *
 * 本层做四件事：
 *   1. 生成 slot（矩形 / 纵队）；
 *   2. 分配 slot（Hilbert 排序 + 贪心 + 2-opt 交换，目标是减少**严重交叉**）；
 *   3. 窄通道自动降级：矩形放不下就变纵队；
 *   4. **落脚点五级搜索**（M16 / FR-FOR-5）：带障碍的落点修正，见文件末尾。
 *
 * 不做：成员增删的增量修复（11.3）、队形与 ORCA 的集成。接口留着，但本层只保证
 * 「生成 / 分配 / 降级 / 落脚」正确。
 * ==========================================================================*/
#ifndef RT_FORM_H
#define RT_FORM_H

#include "rt_types.h"
#include "rt_math.h"   /* RtObb2：落脚搜索的探测形状（M16） */

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    RT_FORM_RECT = 0,     /* 方阵：cols × rows */
    RT_FORM_COLUMN = 1    /* 纵队：单列，沿 -x（朝向的反方向）排开 */
} RtFormKind;

typedef struct {
    RtVec2  local;        /* 相对 anchor 的局部坐标 */
    int32_t row, col;
    int32_t valid;        /* 0 = 不可用（被挡/没落到 lattice，见 M16 的 L5） */
    uint8_t queued;       /* M16：valid=0 时，该 local 是否是**可用**的环绕队列点 */
} RtFormSlot;

typedef struct {
    RtFormKind kind;
    int   cols, rows;
    float pitch_x, pitch_z;   /* slot 间距 = fp + gap */
    RtVec2 anchor;
    float yaw;                /* 朝向（弧度，0 = +x） */
    float yaw_target;
    RtFormSlot *slots;
    int   slot_count;
    int   capacity;
    uint32_t rebuilds;        /* 生成次数 */
} RtFormation;

typedef struct {
    float gap;            /* slot 间距增量（默认 1.0 m，见 01 §10） */
    float fp;             /* 单位 footprint（窄道降级用） */
    float yaw_rate;       /* 朝向平滑（rad/s，默认 90°/s） */
    float turn_in_place;  /* yaw 变化超过此值 -> 建议先原地转（30°） */
} RtFormConfig;

void rt_form_config_default(RtFormConfig *c);

int  rt_form_init(RtFormation *f, int capacity);
void rt_form_destroy(RtFormation *f);

/* 生成 slot。count 个成员，pitch = fp + gap。布局以 anchor 为中心。 */
int  rt_form_build(RtFormation *f, RtFormKind kind, int count,
                   float fp, float gap);

/* 窄通道降级：可用宽度 < 矩形所需宽度 -> 纵队（FR-FOR-4）。
 * 返回最终使用的 kind。 */
RtFormKind rt_form_degrade_for_width(RtFormation *f, float width_m);

/* anchor / 朝向。yaw 变化超过 turn_in_place 时只转不走（见 01 §10）。 */
void rt_form_set_anchor(RtFormation *f, RtVec2 anchor);
void rt_form_set_yaw(RtFormation *f, float yaw, float dt, const RtFormConfig *cfg);
int  rt_form_needs_turn_in_place(const RtFormation *f, const RtFormConfig *cfg);

/* slot 的世界坐标 */
RtVec2 rt_form_slot_world(const RtFormation *f, int slot);

/* 分配：out_slot[i] = 单位 i 分到的 slot 编号。
 * 单位位置 pos[i]；n <= f->slot_count。返回分配数。 */
int rt_form_assign(RtFormation *f, const RtVec2 *pos, int n, int *out_slot);

/* 队形凝聚度：1 - mean(|pos - slot_world|) / R（01 §11.4） */
float rt_form_cohesion(const RtFormation *f, const RtVec2 *pos,
                       const int *slot_of, int n, float radius);

/* ----------------------------------------------------------------------------
 * 落脚策略（M12）
 *
 * 为什么不能「进容差就停」：台架最初的写法是「距 slot < 1.2 m 就 pref=0 并锁存」。
 * 实测（probe_m12_pair）144 人里有 88 人停在**刚好 1.13~1.19 m** 处、再也不动，
 * 最近邻距离中位数 1.0~1.5 m —— 整个方阵被压扁成 1.0 m 的接触堆，
 * 队形看上去跟「挤一个点」没什么区别（只是覆盖了 141/144 个 slot）。
 *
 * 根因有两层：
 *   1. 容差被当成**目标**：1.2 m 处就停，永远不会真的站到 slot 上；
 *   2. `ON_SLOT` 是**永久锁存**：一旦置位，被后来的人挤出去 5~11 m 也不回来
 *      （实测 #63：75 s 时 gap=0.62，78 s 被挤到 5.12，87 s 到 11.06，之后卡在 5.35）。
 *
 * 正确的做法是**滞回**：
 *   gap <= arrive_eps      -> 到位（pref = 0），并且只有 gap > reengage_eps 才重新接管；
 *   arrive_eps < gap       -> 一直朝 slot 走，接近时线性减速（不爬到天荒地老）。
 *   arrive_eps < reengage 之间的这段是**死区**，不许来回抖。
 * 这样「到位」是收敛到点上，而不是收敛到容差边缘；被挤开也能自己回来。
 * --------------------------------------------------------------------------*/
typedef struct {
    float arrive_eps;      /* 0.35 m：进这个圈算到位 */
    float reengage_eps;    /* 0.90 m：被挤出去这么远才重新接管（死区） */
    float slow_radius;     /* 2.00 m：进这个圈开始线性减速 */
    float min_speed_frac;  /* 0.25：减速下界（相对 max_speed），不许爬 */
    float creep_frac;      /* 0.12：已就位但被推开时的回位爬行速度 */
} RtFormSettle;

typedef struct {
    uint8_t  arrived;      /* 已就位（带滞回） */
    float    settle_t;     /* 连续在 arrive_eps 内的时间（抖动诊断） */
    uint32_t reengages;    /* 被挤出去之后重新接管的次数 */
} RtFormMember;

void   rt_form_settle_default(RtFormSettle *s);
void   rt_form_member_reset(RtFormMember *m);

/* 落脚策略的**本体**：朝任意目标点 aim 收敛（slot 只是 aim 的一种）。
 * 「到点就停」的对照实验（点目标 vs 槽位）用的是同一个函数，只换 aim，
 * 这样两组数字的差异只可能来自「去哪」，不来自「怎么停」。 */
RtVec2 rt_form_steer_point(RtVec2 aim, RtVec2 pos, RtFormMember *m,
                           const RtFormSettle *cfg, float max_speed, float dt);

/* 本帧期望速度（世界系，长度 <= max_speed）；已就位返回 0。
 * 无内部状态转移之外的副作用；同一输入同一输出（CON-8）。 */
RtVec2 rt_form_member_steer(const RtFormation *f, int slot, RtVec2 pos,
                            RtFormMember *m, const RtFormSettle *cfg,
                            float max_speed, float dt);

int    rt_form_member_arrived(const RtFormMember *m);

/* ============================================================================
 * M16 · 落脚点五级搜索（FR-FOR-5 / 01 §11.1）
 *
 * 问题：命令下达时只有一个「点击的 anchor」。它在墙里、在走廊里、在 45° 的
 * 斜带上、或者根本放不下整个方阵。M8 的 `rt_form_degrade_for_width()` 只能回答
 * 「够不够宽」，回答不了「往哪挪、转多少度、改成几乘几、压缩多少」。
 *
 * 做法：**逐级放宽，先便宜后贵**，每一级都是上一级的超集：
 *
 *   L0  原样落：anchor + yaw + 默认形状，零冲突 → 直接返回（绝大多数命令走这条）
 *   L1  平移  ：8 方向 × 40 步（步长 1 m = 1 格）的环形搜索，**按半径递增**，
 *               第一个零冲突的候选就是位移最小的那个（不需要算 cost 比较）
 *   L2  转向  ：加上 yaw 偏置（0/±45/±90/±135/180，受 `max_yaw_dev` 限制，
 *               默认只到 ±90°），仍在半径递增序里
 *   L3  变形  ：加 3 种形状（宽扁 / 高瘦 / 纵队）；纵队沿**朝向反方向**排开
 *   L4  压缩  ：pitch 压到 `fp + compress`（默认 0.2 m），同样的形状/朝向再搜
 *   L5  部分落：前面全失败 → 在 L1 的候选集里挑「冲突最少」的落点，
 *               每个坏槽先试 3×3 格内的空位（FR-FOR-10 的局部调整），
 *               仍不行的进**环绕队列**（`valid = 0`，位置是队列点，不是 lattice）
 *
 * 为什么 L1~L4 只看「是否零冲突」而不算 cost：
 *   设计文档里的 cost = 冲突槽×100 + 越界×1000 + 距离，是用来在**都放不下**时
 *   挑一个最不坏的（那是 L5）。只要能放下，半径递增序的第一个解已经是最小位移，
 *   再算 cost 只是多花时间。这条让 L1 的典型成本从「320 次全扫描」降到
 *   「320 次，坏候选在第 1~2 个槽就短路」。
 *
 * probe 只读、由调用方注入（本层不认识 RtGrid，和 rt_local 同一条纪律）：
 *   `rt_form_probe_grid()` 是现成的适配器（`rt_form_grid.c`）。
 *
 * 两条**调用约定**（写在这里是因为它们不能用断言保证，只能靠调用方）：
 *   1. 本层只查「这个位置放不放得下」，**不查连通性**。如果 anchor 在一个封闭
 *      小室里、而 6 m 外是另一个房间，L1 完全可能把队形挪过去。跨房间的落点
 *      要由 probe 或调用方按连通分量挡掉（例如 probe 对「不属于本分量」的格返回 1）。
 *   2. `rt_form_place()` 是**命令时**的落点决策：它会直接写 f->anchor / f->yaw
 *      （不走 rt_form_set_yaw 的 90°/s 平滑），并且内部有一次 malloc。
 *      进 tick 的路径应该只读 slot，不要再调它。
 * ==========================================================================*/

typedef struct {
    void *ud;
    /* 0 = 该 OBB 可用；1 = 被地形/建筑挡住；2 = 越界（权重更高）。
     * 必须**只读**：搜索会对同一个位置问很多次。 */
    int (*obb_state)(void *ud, const RtObb2 *o);
} RtFormProbe;

typedef struct {
    float step;        /* L1/L2 环形搜索步长（默认 1.0 m） */
    int   rings;       /* 每个方向最多几步（默认 40 → 半径 40 m） */
    float compress;    /* L4 的间距增量（默认 0.2 m → pitch = fp + 0.2） */
    float nudge;       /* L5 单槽兜底步长（默认 1.0 m，即 3×3 格） */
    int   orbit_rings; /* L5 环绕队列最多外扩几圈（0/未设置 = 12；负数 = 关闭，只给 A/B 用） */
    float max_yaw_dev; /* 为了放下最多允许转多少（默认 90° = π/2）
                        * 为什么不是「8 个 yaw 全试」：180° 会让队列朝后、
                        * 单位倒着走 —— 实测 3 m 隧道里 r=0 的 180° 纵队
                        * 会击败 r=28 的 0° 纵队（省 28 m，但整个队形反了）。
                        * 需要任意朝向（斜房间）时把它设成 π。 */
    int   max_evals;   /* 候选预算（默认 24000；0 = 不限）。撞上会置 truncated。 */
} RtFormPlaceCfg;

typedef struct {
    int   level;          /* 0 原样 / 1 平移 / 2 转向 / 3 变形 / 4 压缩 / 5 部分 */
    int   evals;          /* 评估过的候选数（成本代理，不是时间） */
    int   truncated;      /* 1 = 撞上 max_evals，搜索不全（禁止静默） */
    int   conflicts;      /* 选定候选**兜底前**被地形挡住的槽数（L5 才有非零） */
    int   oob;            /* 选定候选**兜底前**越界的槽数 */
    int   nudged_slots;   /* L5 用 3×3 兜底挪回 lattice 的槽数 */
    int   invalid_slots;  /* 没能落到 lattice 的槽数（本应进环绕队列，见 queued_slots） */
    int   queued_slots;   /* 其中环绕队列位置**可用**的槽数 */
    float cost;           /* 100*conflicts + 1000*oob + 位移（仅 L5 用于挑落点） */
    int   cols, rows;     /* 最终布局（纵队：cols=1, rows=n） */
    float pitch_x, pitch_z;
    RtVec2 anchor;
    float  yaw;
} RtFormPlaceStat;

void rt_form_place_default(RtFormPlaceCfg *c);

/* 计算落点并**写回** f（slots 的 local/row/col/valid、anchor、yaw、pitch、kind）。
 * count <= f->capacity。probe == NULL 或 count <= 0 返回 RT_ERR_INVALID。
 * 返回 RT_OK 表示「已给出布局」——L5 也算成功，但要检查 stat.invalid_slots。 */
int rt_form_place(RtFormation *f, int count, float fp, float gap,
                  RtVec2 anchor, float yaw,
                  const RtFormProbe *probe, const RtFormPlaceCfg *cfg,
                  RtFormPlaceStat *out);

/* 现成适配器：`grid` 实际类型是 `const RtGrid *`（RtGrid 是匿名 struct 的 typedef，
 * 没法前向声明，所以这里用 void*）。调用方：`rt_form_probe_grid(&p, &G);` */
void rt_form_probe_grid(RtFormProbe *p, const void *grid);

#ifdef __cplusplus
}
#endif

#endif /* RT_FORM_H */

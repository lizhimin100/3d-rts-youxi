/* ============================================================================
 * rt_route.c -- 区域级 A* + 版本依赖 + 走廊查询
 *
 * 实现纪律：
 *   - 邻接顺序固定（E,W,N,S,NE,NW,SE,SW），tie-break 固定（小 index 优先）
 *     -> 同一输入必得同一路径（题面 §八十二 的确定性要求）。
 *   - 所有数组由 solver 持有并复用，build 里不 malloc（§七十六）。
 *   - 依赖按 32-cell chunk 记录版本，与 M3 的 chunk_ver 对接（§四十四）。
 * ==========================================================================*/
#include "rt_route.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

int rt_route_solver_init(RtRouteSolver *s, int max_nodes)
{
    if (!s || max_nodes <= 0) return RT_ERR_INVALID;
    memset(s, 0, sizeof(*s));
    s->gscore = (float *)malloc((size_t)max_nodes * sizeof(float));
    s->parent = (int32_t *)malloc((size_t)max_nodes * sizeof(int32_t));
    s->state  = (uint8_t *)malloc((size_t)max_nodes);
    s->heap   = (int32_t *)malloc((size_t)max_nodes * sizeof(int32_t));
    s->hpos   = (int32_t *)malloc((size_t)max_nodes * sizeof(int32_t));
    if (!s->gscore || !s->parent || !s->state || !s->heap || !s->hpos) {
        rt_route_solver_destroy(s);
        return RT_ERR_CAPACITY;
    }
    s->cap = max_nodes;
    return RT_OK;
}

void rt_route_solver_destroy(RtRouteSolver *s)
{
    if (!s) return;
    free(s->gscore); s->gscore = NULL;
    free(s->parent); s->parent = NULL;
    free(s->state);  s->state = NULL;
    free(s->heap);   s->heap = NULL;
    free(s->hpos);   s->hpos = NULL;
    s->cap = 0;
}

/* 八邻域固定顺序（确定性） */
static const int DX8[8] = { 1, -1, 0, 0, 1, 1, -1, -1 };
static const int DZ8[8] = { 0, 0, 1, -1, -1, 1, 1, -1 };

static inline float octile(float dx, float dz)
{
    float ax = fabsf(dx), az = fabsf(dz);
    return (ax > az) ? (ax + 0.41421356f * az) : (az + 0.41421356f * ax);
}

/* ---- A* 的堆：decrease-key（每个节点在堆里最多一次，堆容量 = 节点数） ----
 * 不能用「重复入堆」的简化写法：那会让 heap 数组超过 cap，
 * 而 cap 恰好等于区域数（实测会写坏内存）。 */
typedef struct {
    RtRouteSolver *s;
    int gw, gx, gz;
    int hn;
} AStar;

static inline float f_of(const AStar *a, int node)
{
    float dx = (float)(node % a->gw - a->gx);
    float dz = (float)(node / a->gw - a->gz);
    return a->s->gscore[node] + octile(dx, dz);
}

static inline int better(const AStar *a, int u, int v)
{
    float fu = f_of(a, u), fv = f_of(a, v);
    if (fu < fv - 1e-6f) return 1;
    if (fu > fv + 1e-6f) return 0;
    return u < v;    /* 固定 tie-break，保证同输入同输出 */
}

static void heap_swap(AStar *a, int i, int j)
{
    int32_t *h = a->s->heap;
    int t = h[i]; h[i] = h[j]; h[j] = t;
    a->s->hpos[h[i]] = i;
    a->s->hpos[h[j]] = j;
}

static void sift_up(AStar *a, int i)
{
    while (i > 0) {
        int p = (i - 1) >> 1;
        if (!better(a, a->s->heap[i], a->s->heap[p])) break;
        heap_swap(a, i, p);
        i = p;
    }
}

static void sift_down(AStar *a, int i)
{
    for (;;) {
        int l = 2 * i + 1, r = l + 1, best = i;
        if (l < a->hn && better(a, a->s->heap[l], a->s->heap[best])) best = l;
        if (r < a->hn && better(a, a->s->heap[r], a->s->heap[best])) best = r;
        if (best == i) break;
        heap_swap(a, i, best);
        i = best;
    }
}

static void heap_push(AStar *a, int node)
{
    if (a->hn >= a->s->cap) return;      /* 只可能发生在参数配错时 */
    a->s->heap[a->hn] = node;
    a->s->hpos[node] = a->hn;
    sift_up(a, a->hn);
    a->hn++;
}

static void heap_decrease(AStar *a, int node)
{
    int pos = a->s->hpos[node];
    if (pos >= 0) sift_up(a, pos);
}

static int heap_pop(AStar *a)
{
    if (a->hn <= 0) return -1;
    int top = a->s->heap[0];
    a->s->hpos[top] = -1;
    a->hn--;
    if (a->hn > 0) {
        a->s->heap[0] = a->s->heap[a->hn];
        a->s->hpos[a->s->heap[0]] = 0;
        sift_down(a, 0);
    }
    return top;
}

static void route_push_dep(RtRoute *r, const RtGrid *g, int region, int px)
{
    int rw = (g->w + px - 1) / px;
    int rx = region % rw;
    int rz = region / rw;
    /* 必须走 grid 的编码（chunk 宽度 = ceil(w/32)，256 的地图是 8 而不是 32）。
     * 这里手写 cz*RT_CHUNKC_W 会让依赖指向完全不相干的 chunk（T9 抓到的 bug）。 */
    int ch = rt_grid_chunk_of_cell(g, rx * px + px / 2, rz * px + px / 2);
    for (int i = 0; i < r->dep_n; i++) if ((int)r->dep_chunks[i] == ch) return;
    if (r->dep_n >= RT_ROUTE_DEP_MAX) { r->dep_overflow = 1; return; }
    r->dep_chunks[r->dep_n] = (uint32_t)ch;
    r->dep_vers[r->dep_n] = g->chunk_ver[ch];
    r->dep_n++;
}

int rt_route_build(RtRoute *r, RtRouteSolver *s, const RtRegionMap *m,
                   int start_region, int goal_region, int clearance_class,
                   int movement_class)
{
    if (!r || !s || !m || !m->g) return RT_ERR_INVALID;
    if (start_region < 0 || goal_region < 0) return RT_ERR_INVALID;
    int nn = m->rw * m->rh;
    if (nn > s->cap) return RT_ERR_CAPACITY;

    r->n = 0;
    r->expanded = 0;
    r->cost = 0.f;
    r->dep_n = 0;
    r->dep_overflow = 0;
    r->start_region = start_region;
    r->goal_region = goal_region;
    r->clearance_class = (uint8_t)clearance_class;
    r->movement_class = (uint8_t)movement_class;
    r->radius_m = rt_clear_radius_m(clearance_class);
    r->label_epoch = m->g->label_epoch;

    if (!rt_region_passable(m, start_region, clearance_class)) return RT_ERR_NOT_FOUND;
    if (!rt_region_passable(m, goal_region, clearance_class)) return RT_ERR_NOT_FOUND;
    if (start_region == goal_region) {
        if (!r->regions || r->cap < 1) {
            free(r->regions); free(r->portal);
            r->regions = (int32_t *)malloc(sizeof(int32_t));
            r->portal  = (RtVec2 *)malloc(sizeof(RtVec2));
            r->cap = (r->regions && r->portal) ? 1 : 0;
            if (!r->regions || !r->portal) return RT_ERR_CAPACITY;
        }
        r->regions[0] = start_region;
        r->portal[0] = rt_region_anchor(m, start_region);
        r->n = 1;
        route_push_dep(r, m->g, start_region, m->px);
        return RT_OK;
    }

    for (int i = 0; i < nn; i++) {
        s->gscore[i] = 1e30f;
        s->parent[i] = -1;
        s->state[i] = 0;
        s->hpos[i] = -1;
    }

    AStar a;
    a.s = s;
    a.gw = m->rw;
    a.gx = goal_region % m->rw;
    a.gz = goal_region / m->rw;
    a.hn = 0;

    s->gscore[start_region] = 0.f;
    s->state[start_region] = 1;
    heap_push(&a, start_region);

    int found = 0;
    while (a.hn > 0) {
        int cur = heap_pop(&a);
        if (cur < 0) break;
        if (s->state[cur] == 2) continue;
        s->state[cur] = 2;
        r->expanded++;
        if (cur == goal_region) { found = 1; break; }

        int cx = cur % a.gw, cz = cur / a.gw;
        for (int e = 0; e < 8; e++) {
            int nx = cx + DX8[e], nz = cz + DZ8[e];
            if (nx < 0 || nz < 0 || nx >= a.gw || nz >= m->rh) continue;
            int nb = nz * a.gw + nx;
            if (s->state[nb] == 2) continue;
            if (!rt_region_edge_ok(m, cur, nb, clearance_class)) continue;

            float step = (e >= 4) ? 1.41421356f : 1.0f;
            float ng = s->gscore[cur] + step;
            if (ng + 1e-6f >= s->gscore[nb]) continue;
            s->gscore[nb] = ng;
            s->parent[nb] = cur;
            if (s->state[nb] == 0) {
                s->state[nb] = 1;
                heap_push(&a, nb);
            } else {
                heap_decrease(&a, nb);
            }
        }
    }

    if (!found) return RT_ERR_NOT_FOUND;

    int len = 0;
    for (int c = goal_region; c != -1; c = s->parent[c]) {
        len++;
        if (len > nn) return RT_ERR_NOT_FOUND;
    }
    if (!r->regions || !r->portal || r->cap < len) {
        free(r->regions); free(r->portal);
        r->regions = (int32_t *)malloc((size_t)len * sizeof(int32_t));
        r->portal  = (RtVec2 *)malloc((size_t)len * sizeof(RtVec2));
        r->cap = (r->regions && r->portal) ? len : 0;
        if (!r->regions || !r->portal) return RT_ERR_CAPACITY;
    }
    int i = len - 1;
    for (int c = goal_region; c != -1; c = s->parent[c]) r->regions[i--] = c;
    r->n = len;
    r->cost = s->gscore[goal_region];

    /* 门户点：走廊的每个出口。用真实跨界格对的中点，而不是区域中心 ——
     * 区域中心可能落在障碍旁，沿它走会切墙角。 */
    for (int k = 0; k + 1 < r->n; k++) {
        if (!rt_region_portal(m, r->regions[k], r->regions[k + 1], clearance_class, &r->portal[k]))
            r->portal[k] = rt_region_center(m, r->regions[k + 1]);
    }
    if (r->n > 0) r->portal[r->n - 1] = rt_region_center(m, r->regions[r->n - 1]);

    for (int k = 0; k < r->n; k++) route_push_dep(r, m->g, r->regions[k], m->px);
    return RT_OK;
}

void rt_route_free(RtRoute *r)
{
    if (!r) return;
    free(r->regions);
    free(r->portal);
    r->regions = NULL;
    r->portal = NULL;
    r->n = r->cap = 0;
    r->dep_n = 0;
}

int rt_route_valid(const RtRoute *r, const RtGrid *g)
{
    if (!r || !g || r->n <= 0) return 0;
    if (r->label_epoch != g->label_epoch) return 0;
    if (r->dep_overflow) return 0;    /* 依赖太多 -> 保守失效 */
    for (int i = 0; i < r->dep_n; i++) {
        uint32_t c = r->dep_chunks[i];
        if (c >= RT_CHUNK_N) return 0;
        if (g->chunk_ver[c] != r->dep_vers[i]) return 0;
    }
    return 1;
}

int rt_route_next_region(const RtRoute *r, const RtRegionMap *m, int cur_region)
{
    if (!r || r->n <= 0) return -1;
    int best = -1, best_d = 1 << 30;
    for (int i = 0; i < r->n; i++) {
        int d = abs(r->regions[i] - cur_region);
        /* 用区域坐标算曼哈顿距离，避免 index 差在跨行时失真 */
        int ax = r->regions[i] % m->rw, az = r->regions[i] / m->rw;
        int bx = cur_region % m->rw, bz = cur_region / m->rw;
        d = abs(ax - bx) + abs(az - bz);
        if (d < best_d) { best_d = d; best = i; }
    }
    if (best < 0) return -1;
    if (best + 1 >= r->n) return -1;          /* 已经在最后一个区域 */
    return r->regions[best + 1];
}

int rt_route_next_portal(const RtRoute *r, const RtRegionMap *m, int cur_region, RtVec2 *out)
{
    if (!r || !m || !out || r->n <= 0) return 0;
    int best = 0, best_d = 1 << 30;
    int bx = (cur_region >= 0) ? (cur_region % m->rw) : 0;
    int bz = (cur_region >= 0) ? (cur_region / m->rw) : 0;
    for (int i = 0; i < r->n; i++) {
        int ax = r->regions[i] % m->rw, az = r->regions[i] / m->rw;
        int d = abs(ax - bx) + abs(az - bz);
        if (d < best_d) { best_d = d; best = i; }
    }
    if (best + 1 >= r->n) return 0;         /* 已在最后一个区域 */
    *out = r->portal[best];
    return 1;
}

int rt_route_polyline(const RtRoute *r, const RtRegionMap *m, RtVec2 *out, int max_out)
{
    if (!r || !m || !out) return 0;
    int k = 0;
    for (int i = 0; i < r->n && k < max_out; i++)
        out[k++] = rt_region_center(m, r->regions[i]);
    return k;
}

/* ============================================================================
 * M4.3 Goal-centric Coarse Flow（反向 Dijkstra）
 * ==========================================================================*/

int rt_goalflow_solver_init(RtGoalFlowSolver *s, int max_nodes)
{
    if (!s || max_nodes <= 0) return RT_ERR_INVALID;
    memset(s, 0, sizeof(*s));
    s->heap  = (int32_t *)malloc((size_t)max_nodes * sizeof(int32_t));
    s->hpos  = (int32_t *)malloc((size_t)max_nodes * sizeof(int32_t));
    s->state = (uint8_t *)malloc((size_t)max_nodes);
    s->need  = (uint8_t *)malloc((size_t)max_nodes);
    if (!s->heap || !s->hpos || !s->state || !s->need) {
        rt_goalflow_solver_destroy(s);
        return RT_ERR_CAPACITY;
    }
    s->cap = max_nodes;
    return RT_OK;
}

void rt_goalflow_solver_destroy(RtGoalFlowSolver *s)
{
    if (!s) return;
    free(s->heap);  s->heap = NULL;
    free(s->hpos);  s->hpos = NULL;
    free(s->state); s->state = NULL;
    free(s->need);  s->need = NULL;
    s->cap = s->hn = 0;
}

void rt_goalflow_free(RtGoalFlow *f)
{
    if (!f) return;
    free(f->dist);   f->dist = NULL;
    free(f->parent); f->parent = NULL;
    f->state = 0;
    f->nregions = 0;
    f->dep_n = 0;
}

static void gf_swap(RtGoalFlowSolver *s, int i, int j)
{
    int32_t t = s->heap[i]; s->heap[i] = s->heap[j]; s->heap[j] = t;
    s->hpos[s->heap[i]] = i;
    s->hpos[s->heap[j]] = j;
}

static int gf_less(const float *dist, int a, int b)
{
    if (dist[a] < dist[b] - 1e-6f) return 1;
    if (dist[a] > dist[b] + 1e-6f) return 0;
    return a < b;                       /* 固定 tie-break：小 index 优先 */
}

static void gf_sift_up(RtGoalFlowSolver *s, const float *dist, int i)
{
    while (i > 0) {
        int p = (i - 1) >> 1;
        if (!gf_less(dist, s->heap[i], s->heap[p])) break;
        gf_swap(s, i, p);
        i = p;
    }
}

static void gf_sift_down(RtGoalFlowSolver *s, const float *dist, int i)
{
    for (;;) {
        int l = 2 * i + 1, r = l + 1, b = i;
        if (l < s->hn && gf_less(dist, s->heap[l], s->heap[b])) b = l;
        if (r < s->hn && gf_less(dist, s->heap[r], s->heap[b])) b = r;
        if (b == i) break;
        gf_swap(s, i, b);
        i = b;
    }
}

static void gf_push(RtGoalFlowSolver *s, const float *dist, int node)
{
    if (s->hn >= s->cap) return;
    s->heap[s->hn] = node;
    s->hpos[node] = s->hn;
    gf_sift_up(s, dist, s->hn);
    s->hn++;
}

static int gf_pop(RtGoalFlowSolver *s, const float *dist)
{
    if (s->hn <= 0) return -1;
    int top = s->heap[0];
    s->hpos[top] = -1;
    s->hn--;
    if (s->hn > 0) {
        s->heap[0] = s->heap[s->hn];
        s->hpos[s->heap[0]] = 0;
        gf_sift_down(s, dist, 0);
    }
    return top;
}

static void gf_init(RtGoalFlow *f, int nn, int goal, int comp, int cls, int mcls,
                    uint32_t label_epoch)
{
    f->state = 1;
    f->goal = goal;
    f->comp = comp;
    f->cls = (uint8_t)cls;
    f->mcls = (uint8_t)mcls;
    f->label_epoch = label_epoch;
    f->nregions = nn;
    f->dep_n = 0;
    f->dep_overflow = 0;
    f->expanded = 0;
    f->source_n = 0;
    memset(f->dep_mask, 0, sizeof(f->dep_mask));
}

int rt_goalflow_build(RtGoalFlow *f, RtGoalFlowSolver *s, const RtRegionMap *m,
                      int goal, int comp, int cls, int mcls,
                      const int32_t *srcs, int nsrcs)
{
    if (!f || !s || !m || !m->g) return RT_ERR_INVALID;
    int nn = m->rw * m->rh;
    if (nn <= 0 || nn > s->cap) return RT_ERR_CAPACITY;
    if (!rt_region_passable(m, goal, cls)) return RT_ERR_NOT_FOUND;

    if (!f->dist || f->nregions != nn) {
        free(f->dist); free(f->parent);
        f->dist = (float *)malloc((size_t)nn * sizeof(float));
        f->parent = (int32_t *)malloc((size_t)nn * sizeof(int32_t));
        f->nregions = nn;
        if (!f->dist || !f->parent) { rt_goalflow_free(f); return RT_ERR_CAPACITY; }
    }
    gf_init(f, nn, goal, comp, cls, mcls, m->g->label_epoch);

    for (int i = 0; i < nn; i++) {
        f->dist[i] = 1e30f;
        f->parent[i] = -1;
        s->state[i] = 0;
        s->hpos[i] = -1;
        s->need[i] = 0;
    }
    int remaining = 0;
    for (int k = 0; k < nsrcs; k++) {
        int r = srcs[k];
        if (r < 0 || r >= nn) continue;
        if (!rt_region_passable(m, r, cls)) continue;   /* 交给调用方走 A* 兜底 */
        if (!s->need[r]) { s->need[r] = 1; remaining++; }
    }
    f->source_n = nsrcs;
    if (remaining == 0) return RT_OK;                    /* 只建了 goal 本身 */

    s->hn = 0;
    f->dist[goal] = 0.f;
    s->state[goal] = 1;
    gf_push(s, f->dist, goal);

    int rw = m->rw;
    while (s->hn > 0 && remaining > 0) {
        int cur = gf_pop(s, f->dist);
        if (cur < 0) break;
        if (s->state[cur] == 2) continue;
        s->state[cur] = 2;
        f->expanded++;

        /* dependency：树访问过的 chunk + 当时的版本 */
        {
            int ch = rt_grid_chunk_of_cell(m->g, (cur % rw) * m->px + m->px / 2,
                                           (cur / rw) * m->px + m->px / 2);
            if (ch >= 0 && ch < RT_CHUNK_N) {
                int wi = ch >> 6, bi = ch & 63;
                if (!(f->dep_mask[wi] & (1ull << bi))) {
                    f->dep_mask[wi] |= (1ull << bi);
                    f->dep_ver[ch] = m->g->chunk_ver[ch];
                    f->dep_n++;
                }
            } else {
                f->dep_overflow = 1;
            }
        }

        if (s->need[cur]) {
            s->need[cur] = 0;
            if (--remaining == 0) break;                /* 有界：source 全部 settle 即停 */
        }

        int cx = cur % rw, cz = cur / rw;
        for (int e = 0; e < 8; e++) {
            int nx = cx + DX8[e], nz = cz + DZ8[e];
            if (nx < 0 || nz < 0 || nx >= rw || nz >= m->rh) continue;
            int nb = nz * rw + nx;
            if (s->state[nb] == 2) continue;
            if (!rt_region_edge_ok(m, cur, nb, cls)) continue;
            float step = (e >= 4) ? 1.41421356f : 1.0f;
            float nd = f->dist[cur] + step;
            if (nd + 1e-6f >= f->dist[nb]) continue;
            f->dist[nb] = nd;
            f->parent[nb] = cur;
            if (s->state[nb] == 0) {
                s->state[nb] = 1;
                gf_push(s, f->dist, nb);
            } else {
                int pos = s->hpos[nb];
                if (pos >= 0) gf_sift_up(s, f->dist, pos);
            }
        }
    }
    return RT_OK;
}

int rt_goalflow_valid(const RtGoalFlow *f, const RtGrid *g)
{
    if (!f || !g || f->state != 1 || !f->dist) return 0;
    if (f->dep_overflow) return 0;
    if (f->label_epoch != g->label_epoch) return 0;
    for (int wd = 0; wd < RT_GOALFLOW_DEP_WORDS; wd++) {
        uint64_t bits = f->dep_mask[wd];
        while (bits) {
            int b = 0;
            while (!((bits >> b) & 1ull)) b++;
            bits &= ~(1ull << b);
            int ch = wd * 64 + b;
            if (ch >= RT_CHUNK_N) return 0;
            if (g->chunk_ver[ch] != f->dep_ver[ch]) return 0;
        }
    }
    return 1;
}

int rt_goalflow_path(const RtGoalFlow *f, int src, int32_t *out, int max_out)
{
    if (!f || f->state != 1 || !f->dist || !out || max_out <= 0) return 0;
    if (src < 0 || src >= f->nregions) return 0;
    if (f->dist[src] >= 1e29f) return 0;
    int k = 0, cur = src;
    while (k < max_out) {
        out[k++] = cur;
        if (cur == f->goal) return k;
        cur = f->parent[cur];
        if (cur < 0) return 0;
    }
    return 0;
}

int rt_route_from_path(RtRoute *r, const RtRegionMap *m, const int32_t *regions,
                       int n, int cls, int mcls, float cost)
{
    if (!r || !m || !regions || n <= 0) return RT_ERR_INVALID;
    if (!r->regions || !r->portal || r->cap < n) {
        free(r->regions); free(r->portal);
        r->regions = (int32_t *)malloc((size_t)n * sizeof(int32_t));
        r->portal  = (RtVec2  *)malloc((size_t)n * sizeof(RtVec2));
        r->cap = (r->regions && r->portal) ? n : 0;
        if (!r->regions || !r->portal) return RT_ERR_CAPACITY;
    }
    memcpy(r->regions, regions, (size_t)n * sizeof(int32_t));
    r->n = n;
    r->start_region = regions[0];
    r->goal_region = regions[n - 1];
    r->clearance_class = (uint8_t)cls;
    r->movement_class = (uint8_t)mcls;
    r->radius_m = rt_clear_radius_m(cls);
    r->label_epoch = m->g->label_epoch;
    r->dep_n = 0;
    r->dep_overflow = 0;
    r->expanded = 0;
    r->cost = cost;

    for (int k = 0; k + 1 < n; k++) {
        if (!rt_region_portal(m, regions[k], regions[k + 1], cls, &r->portal[k]))
            r->portal[k] = rt_region_center(m, regions[k + 1]);
        route_push_dep(r, m->g, regions[k], m->px);
    }
    r->portal[n - 1] = rt_region_center(m, regions[n - 1]);
    route_push_dep(r, m->g, regions[n - 1], m->px);
    return RT_OK;
}

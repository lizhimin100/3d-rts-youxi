/* ============================================================================
 * test_core.c -- V0 核心数据结构与算法断言
 *
 * 纪律（来自 2D 工程题的实战教训）：
 *   1. 每个自动检查类工具必须配**负例**：本文件的 spatial 部分显式断言
 *      「桶太小时必须报错」，否则「永远通过」等于没有检查。
 *   2. 断言数量必须与 EXPECTED_ASSERTS **恰好相等**：
 *      否则「断言被静默跳过」与「新增断言忘了同步」都不会被发现。
 *   3. RNG 用 Python 独立算出的参考值做**跨语言硬比对**，
 *      这是唯一能证明「实现没抄歪」的断言。
 *
 * 编译（dmc，本机验证用；注意 dmc 的 64 位乘法有 bug，只能做语法检查）：
 *   dmc -Icore\include core\src\rt_core.c core\src\rt_unit.c core\src\rt_grid.c core\src\rt_spatial.c tests\test_core.c -o test_core.exe
 * 编译（zig cc，本机已实测通过）：
 *   zig cc -O2 -std=c11 -Wall -Wextra -Icore/include core/src/rt_*.c tests/test_core.c -o test_core
 * 编译（GCC，标准路径）：
 *   gcc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_core.c -o test_core -lm
 * ==========================================================================*/
#include <stdio.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_spatial.h"

/* ---------------------------------------------------------------- 断言框架 */
static int g_pass = 0;
static int g_fail = 0;

#define EXPECTED_ASSERTS 79

static void report_fail(const char *file, int line, const char *msg)
{
    g_fail++;
    printf("FAIL %s:%d  %s\n", file, line, msg);
}

#define OK(cond, msg)                                                       \
    do {                                                                    \
        if (cond) { g_pass++; }                                             \
        else { report_fail(__FILE__, __LINE__, msg); }                       \
    } while (0)

#define EQ_INT(a, b, msg)                                                   \
    do {                                                                    \
        long long _a = (long long)(a), _b = (long long)(b);                  \
        if (_a == _b) { g_pass++; }                                          \
        else {                                                               \
            printf("FAIL %s:%d  %s  (got %lld want %lld)\n",                 \
                   __FILE__, __LINE__, msg, _a, _b);                         \
            g_fail++;                                                        \
        }                                                                    \
    } while (0)

#define NEAR(a, b, tol, msg)                                                \
    do {                                                                    \
        double _a = (double)(a), _b = (double)(b), _t = (double)(tol);       \
        if (fabs(_a - _b) <= _t) { g_pass++; }                               \
        else {                                                               \
            printf("FAIL %s:%d  %s  (got %.4f want %.4f +-%.4f)\n",          \
                   __FILE__, __LINE__, msg, _a, _b, _t);                     \
            g_fail++;                                                        \
        }                                                                    \
    } while (0)

/* ==========================================================================
 * T1 RNG：跨语言硬比对（参考值由 Python 独立算出）
 * ========================================================================*/
static void test_rng(void)
{
    RtRng r;

    rt_rng_seed(&r, 0);
    OK(rt_rng_u64(&r) == 0xE220A8397B1DCDAFull, "rng seed0 #1");
    OK(rt_rng_u64(&r) == 0x6E789E6AA1B965F4ull, "rng seed0 #2");
    OK(rt_rng_u64(&r) == 0x06C45D188009454Full, "rng seed0 #3");
    OK(rt_rng_u64(&r) == 0xF88BB8A8724C81ECull, "rng seed0 #4");

    rt_rng_seed(&r, 12345);
    OK(rt_rng_u64(&r) == 0x22118258A9D111A0ull, "rng seed12345 #1");
    OK(rt_rng_u64(&r) == 0x346EDCE5F713F8EDull, "rng seed12345 #2");

    /* f32 路径也必须一致（取高 24 位） */
    rt_rng_seed(&r, 0);
    NEAR(rt_rng_f32(&r), 0.883310795, 1e-6, "rng_f32 seed0 #1");
    NEAR(rt_rng_f32(&r), 0.431527972, 1e-6, "rng_f32 seed0 #2");
    NEAR(rt_rng_f32(&r), 0.026433766, 1e-6, "rng_f32 seed0 #3");

    /* 负例：不同种子的第一个值必须不同（否则种子没接进去） */
    RtRng a, b;
    rt_rng_seed(&a, 1);
    rt_rng_seed(&b, 2);
    OK(rt_rng_u64(&a) != rt_rng_u64(&b), "rng seed must matter");

    /* 区间函数 */
    rt_rng_seed(&r, 777);
    int in_range = 1;
    for (int i = 0; i < 1000; i++) {
        int v = rt_rng_range(&r, -5, 5);
        if (v < -5 || v >= 5) in_range = 0;
    }
    OK(in_range, "rng_range bounds");
}

/* ==========================================================================
 * T2 Arena
 * ========================================================================*/
static void test_arena(void)
{
    RtArena a;
    EQ_INT(rt_arena_init(&a, 1024), RT_OK, "arena init");

    void *p1 = rt_arena_alloc(&a, 100, 8);
    OK(p1 != NULL, "arena alloc 100");

    /* 对齐检查 */
    OK(((size_t)p1 % 8) == 0, "arena 8-byte aligned");

    /* 申请超过剩余容量 -> NULL + overflow 计数（不 abort） */
    void *p2 = rt_arena_alloc(&a, 2048, 8);
    OK(p2 == NULL, "arena overflow returns NULL");
    EQ_INT(a.overflow, 1, "arena overflow counted");

    rt_arena_reset(&a);
    EQ_INT(rt_arena_used(&a), 0, "arena reset");

    /* reset 后可以重新分配 */
    OK(rt_arena_alloc(&a, 1000, 16) != NULL, "arena alloc after reset");

    /* 负例：非法对齐（非 2 的幂）必须拒绝 */
    OK(rt_arena_alloc(&a, 16, 3) == NULL, "arena rejects non-pow2 align");

    rt_arena_destroy(&a);
}

/* ==========================================================================
 * T3 Grid：clearance / 覆盖计数 / 连通分量 / OBB
 * ========================================================================*/
static RtGrid G;

static void grid_build_wall(void)
{
    /* 竖墙：x = 256，z 贯穿全高（含边界）。
     * 注意：若两端留缝，地图仍然连通 —— 首版就写成了 z=1..510，
     * 被「wall splits into 2 components」这条断言抓出来。 */
    for (int z = 0; z < 512; z++)
        rt_grid_set_terrain(&G, 256, z, RT_CELL_BLOCKED_TERRAIN, 1);
}

static void test_grid_clearance(void)
{
    memset(&G, 0, sizeof(G));
    EQ_INT(rt_grid_init(&G, 512, 512, 1.0f), RT_OK, "grid init 512");

    rt_grid_rebuild_all(&G);
    /* 全空图：clearance 被 clamp 到 RT_SSEDT_CLAMP = 16 m = 1600（0.01 m 单位）。
     * 为什么必须 clamp（而不是留 65535）：增量重算的 pad 必须 >= 全图 max clearance，
     * 开放地图上 max = 半张图（512² -> 256 m = 25600），pad 会直接撞上 64 的上限，
     * 于是**每次编辑都降级全量**。16 m 对半径 <= 4 m 的单位与 OBB 快路径都足够。 */
    EQ_INT(G.clearance[100 * 512 + 100], 1600, "empty grid clearance clamp (16 m)");

    grid_build_wall();
    rt_grid_rebuild_all(&G);

    /* 墙左侧一格：到墙格中心距离 1.0m -> 100 (0.01m) */
    NEAR(rt_grid_clearance_m(&G, 255, 100), 1.0f, 0.05f, "clearance 1 cell from wall");
    NEAR(rt_grid_clearance_m(&G, 250, 100), 6.0f, 0.30f, "clearance 6 cells from wall");
    /* 墙上本身 = 0 */
    NEAR(rt_grid_clearance_m(&G, 256, 100), 0.0f, 0.01f, "clearance on blocked cell");

    /* 斜向：45 度角，距离应为 sqrt(2) 倍 */
    NEAR(rt_grid_clearance_m(&G, 255, 99), 1.0f, 0.30f, "clearance diagonal adjacent");

    /* 负例：越界查询返回 0 而不是越界读 */
    NEAR(rt_grid_clearance_m(&G, -1, 100), 0.0f, 1e-6, "clearance out of bounds");
}

static void test_grid_components(void)
{
    /* 上面的墙把地图分成左右两半：应得到 2 个分量 */
    RtGridStats st;
    rt_grid_stats(&G, &st);
    EQ_INT(st.component_count, 2, "wall splits into 2 components");

    OK(!rt_grid_same_component(&G, 100, 100, 400, 100), "left/right disconnected");

    /* 在墙上开一个门 -> 恢复为 1 个分量 */
    rt_grid_set_terrain(&G, 256, 256, RT_CELL_BLOCKED_TERRAIN, 0);
    rt_grid_rebuild_all(&G);
    rt_grid_stats(&G, &st);
    EQ_INT(st.component_count, 1, "door merges components");
    OK(rt_grid_same_component(&G, 100, 100, 400, 100), "left/right connected via door");

    /* 修复：把门重新堵上，供后续用例使用 */
    rt_grid_set_terrain(&G, 256, 256, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);
}

static void test_grid_building_overlay(void)
{
    RtGrid *g = &G;

    /* 两个建筑重叠：先 A(10..13,10..13)，再 B(12..15,12..15) */
    EQ_INT(rt_grid_add_building(g, 10, 10, 4, 4), RT_OK, "add building A");
    EQ_INT(rt_grid_add_building(g, 12, 12, 4, 4), RT_OK, "add building B");

    OK(!rt_grid_walkable(g, 10, 10), "A-only cell blocked");
    OK(!rt_grid_walkable(g, 12, 12), "overlap cell blocked");
    EQ_INT(g->overlay[12 * 512 + 12], 2, "overlap count == 2");

    /* 拆掉 A：重叠区必须**仍然** blocked（覆盖计数语义） */
    EQ_INT(rt_grid_remove_building(g, 10, 10, 4, 4), RT_OK, "remove building A");
    OK(rt_grid_walkable(g, 10, 10), "A-only cell freed");
    OK(!rt_grid_walkable(g, 12, 12), "overlap cell STILL blocked (overlay=1)");
    EQ_INT(g->overlay[12 * 512 + 12], 1, "overlay decremented to 1");

    /* 拆掉 B：全部释放 */
    rt_grid_remove_building(g, 12, 12, 4, 4);
    OK(rt_grid_walkable(g, 12, 12), "overlap cell freed after both removed");
    EQ_INT(g->overlay[12 * 512 + 12], 0, "overlay back to 0");

    /* 负例：越界的建筑必须被拒绝，且不能部分写入 */
    EQ_INT(rt_grid_add_building(g, 510, 510, 10, 10), RT_ERR_INVALID, "out-of-bounds building rejected");
}

static void test_grid_obb(void)
{
    RtObb2 o;

    /* 空旷处（远离墙）：不阻挡 */
    o = rt_obb_make(rt_v2(100.5f, 100.5f), 4.0f, 0.0f);
    EQ_INT(rt_grid_obb_blocked(&G, &o), 0, "OBB in open space not blocked");

    /* 快速判定应命中（clearance 足够） */
    EQ_INT(rt_grid_obb_clear_fast(&G, &o), 1, "OBB fast clear in open space");

    /* 压在墙上：阻挡 */
    o = rt_obb_make(rt_v2(256.5f, 100.5f), 4.0f, 0.0f);
    EQ_INT(rt_grid_obb_blocked(&G, &o), 1, "OBB on wall blocked");

    /* 贴墙但不重叠：4x4 单位中心在 x=253.5（半宽 2），右边到 255.5，墙从 256 开始 ->
     * 不阻挡。这是「内切半径 vs 外接圆」的关键区别：外接圆半径 2.83 会误判为阻挡。 */
    o = rt_obb_make(rt_v2(253.5f, 100.5f), 4.0f, 0.0f);
    EQ_INT(rt_grid_obb_blocked(&G, &o), 0, "OBB touching-but-not-overlapping wall");

    /* 超出地图边界：阻挡 */
    o = rt_obb_make(rt_v2(0.5f, 100.5f), 4.0f, 0.0f);
    EQ_INT(rt_grid_obb_blocked(&G, &o), 1, "OBB outside map blocked");

    /* 负例：旋转 45 度后外接圆变大，同一位置可能碰到墙 —— 验证 SAT 真的考虑了朝向 */
    o = rt_obb_make(rt_v2(253.5f, 100.5f), 4.0f, 0.7853981f);
    EQ_INT(rt_grid_obb_blocked(&G, &o), 1, "45-deg OBB at same pos hits wall");
}

/* ==========================================================================
 * T4 Unit store
 * ========================================================================*/
static void test_units(void)
{
    RtUnitStore s;
    rt_units_init(&s);
    EQ_INT(s.count, 0, "units init empty");

    RtUnitId a = rt_units_spawn(&s, rt_v3(10.f, 0.f, 20.f), RT_FP_SMALL);
    RtUnitId b = rt_units_spawn(&s, rt_v3(30.f, 0.f, 40.f), RT_FP_LARGE);
    OK(a != RT_UNIT_ID_NONE, "spawn small");
    OK(b != RT_UNIT_ID_NONE, "spawn large");
    OK(a != b, "ids distinct");
    EQ_INT(s.count, 2, "count after 2 spawn");

    NEAR(rt_units_fp(&s, b), 4.0f, 1e-6, "fp large stored");
    NEAR(rt_units_pos(&s, a).x, 10.f, 1e-6, "pos x");
    NEAR(rt_units_pos(&s, a).z, 20.f, 1e-6, "pos z");

    /* 非法 footprint 必须被拒绝（不是悄悄当成 1） */
    EQ_INT(rt_units_spawn(&s, rt_v3(0, 0, 0), 3), RT_UNIT_ID_NONE, "invalid fp rejected");

    /* despawn 后可复用，且 alive 立即为假 */
    EQ_INT(rt_units_despawn(&s, a), RT_OK, "despawn a");
    OK(!rt_units_alive(&s, a), "a not alive after despawn");
    EQ_INT(rt_units_despawn(&s, a), RT_ERR_NOT_FOUND, "double despawn rejected");

    RtUnitId c = rt_units_spawn(&s, rt_v3(1.f, 0.f, 1.f), RT_FP_MEDIUM);
    OK(c != RT_UNIT_ID_NONE, "respawn after despawn");
    EQ_INT(s.count, 2, "count stable after reuse");

    /* 容量上界：填满到 4096 后必须报 RT_UNIT_ID_NONE 并计数 */
    rt_units_init(&s);
    int spawned = 0;
    for (int i = 0; i < RT_MAX_UNITS; i++) {
        if (rt_units_spawn(&s, rt_v3((float)i, 0.f, 0.f), RT_FP_SMALL) != RT_UNIT_ID_NONE)
            spawned++;
    }
    EQ_INT(spawned, RT_MAX_UNITS, "spawn up to capacity");
    EQ_INT(rt_units_spawn(&s, rt_v3(0, 0, 0), RT_FP_SMALL), RT_UNIT_ID_NONE, "capacity overflow rejected");
    EQ_INT(s.overflow.unit_overflow, 1, "capacity overflow counted");
}

/* ==========================================================================
 * T5 Spatial：与暴力 O(N^2) 对比 + 负例（桶太小必须报错）
 * ========================================================================*/
#define T5_N 1000
static RtUnitId g_t5_ids[T5_N];

static int brute_neighbors(const RtUnitStore *s, RtUnitId id, float r, RtUnitId *out, int max)
{
    RtVec3 p = rt_units_pos(s, id);
    int n = 0;
    for (int i = 0; i < T5_N; i++) {
        if (g_t5_ids[i] == id) continue;
        RtVec3 q = rt_units_pos(s, g_t5_ids[i]);
        float dx = q.x - p.x, dz = q.z - p.z;
        if (dx * dx + dz * dz <= r * r) {
            if (n < max) out[n] = g_t5_ids[i];
            n++;
        }
    }
    return n;
}

static void test_spatial(void)
{
    RtUnitStore s;
    rt_units_init(&s);
    RtRng rng;
    rt_rng_seed(&rng, 0xBEEF);

    for (int i = 0; i < T5_N; i++) {
        float x = rt_rng_f32_range(&rng, 10.f, 500.f);
        float z = rt_rng_f32_range(&rng, 10.f, 500.f);
        g_t5_ids[i] = rt_units_spawn(&s, rt_v3(x, 0.f, z), RT_FP_LARGE);
    }
    EQ_INT(s.count, T5_N, "spatial test spawned 1000");

    const float query_r = 5.657f;   /* 两个 4x4 单位的合并半径 */

    /* ★ 负例：桶 2m < 2*5.657m，必须返回 RT_ERR_INVALID（拒绝静默漏检） */
    RtSpatialGrid bad;
    EQ_INT(rt_spatial_init(&bad, 512.f, 512.f, 2.0f), RT_OK, "bad spatial init");
    EQ_INT(rt_spatial_build(&bad, &s, g_t5_ids, T5_N, query_r), RT_ERR_INVALID,
           "NEGATIVE: too-small bucket must be rejected");
    rt_spatial_destroy(&bad);

    /* 正例：桶 8m >= 2*5.657m */
    RtSpatialGrid sg;
    EQ_INT(rt_spatial_init(&sg, 512.f, 512.f, 8.0f), RT_OK, "spatial init 8m");
    EQ_INT(rt_spatial_build(&sg, &s, g_t5_ids, T5_N, query_r), RT_OK, "spatial build");

    /* 与暴力对比：总邻居对数必须**完全一致**（浮点比较同源，可以要求相等）
     * exclude 显式传自己 —— 首版没这个参数，导致 grid 恒比 brute 多 1000。 */
    int total_grid = 0, total_brute = 0;
    RtUnitId tmp[256];
    for (int i = 0; i < T5_N; i++) {
        int nb = brute_neighbors(&s, g_t5_ids[i], query_r, tmp, 256);
        int ng = rt_spatial_query_circle(&sg, &s,
                                         rt_v2(rt_units_pos(&s, g_t5_ids[i]).x,
                                               rt_units_pos(&s, g_t5_ids[i]).z),
                                         query_r, g_t5_ids[i], tmp, 256);
        total_brute += nb;
        total_grid += ng;
    }
    /* 每条边被两个端点各数一次，所以是 2 * 对数；这里只要求两边相等 */
    EQ_INT(total_grid, total_brute, "grid neighbor count == brute force");

    /* 稀疏处查询必须返回 0 而不是错误值 */
    int n0 = rt_spatial_query_circle(&sg, &s, rt_v2(-100.f, -100.f), query_r,
                                     RT_UNIT_ID_NONE, tmp, 256);
    EQ_INT(n0, 0, "query outside map returns 0");

    /* 截断必须被显式报告：单独构造密集场景（均匀分布下不会截断） */
    {
        RtUnitStore ds;
        rt_units_init(&ds);
        RtUnitId dids[4];
        dids[0] = rt_units_spawn(&ds, rt_v3(100.0f, 0.f, 100.0f), RT_FP_SMALL);
        dids[1] = rt_units_spawn(&ds, rt_v3(100.5f, 0.f, 100.0f), RT_FP_SMALL);
        dids[2] = rt_units_spawn(&ds, rt_v3(100.0f, 0.f, 100.5f), RT_FP_SMALL);
        dids[3] = rt_units_spawn(&ds, rt_v3(100.5f, 0.f, 100.5f), RT_FP_SMALL);

        RtSpatialGrid dsg;
        EQ_INT(rt_spatial_init(&dsg, 256.f, 256.f, 8.f), RT_OK, "dense spatial init");
        EQ_INT(rt_spatial_build(&dsg, &ds, dids, 4, 2.0f), RT_OK, "dense spatial build");

        int nt = rt_spatial_query_circle(&dsg, &ds, rt_v2(100.2f, 100.2f), 2.0f,
                                         RT_UNIT_ID_NONE, tmp, 2);
        EQ_INT(nt, 2, "truncated query returns max_out");
        EQ_INT(rt_spatial_last_truncated(), 1, "truncation reported");
        rt_spatial_destroy(&dsg);
    }

    /* 查询半径超过声明值：必须报告不完整（而不是悄悄少返回） */
    (void)rt_spatial_query_circle(&sg, &s, rt_v2(256.f, 256.f), query_r + 2.f,
                                  RT_UNIT_ID_NONE, tmp, 256);
    EQ_INT(rt_spatial_last_truncated(), 1, "over-radius query reported");

    rt_spatial_destroy(&sg);
}

/* ==========================================================================
 * T6 确定性：同输入两次得到同结果
 * ========================================================================*/
static void test_determinism(void)
{
    uint64_t h1 = 0, h2 = 0;
    for (int round = 0; round < 2; round++) {
        RtRng rng;
        rt_rng_seed(&rng, 42);
        uint64_t h = 1469598103934665603ull;
        for (int i = 0; i < 1000; i++) {
            uint64_t v = rt_rng_u64(&rng);
            h = (h ^ v) * 1099511628211ull;
        }
        if (round == 0) h1 = h; else h2 = h;
    }
    OK(h1 == h2, "same seed -> same stream");

    /* 负例：不同种子必须不同（否则上面的断言恒真） */
    RtRng a, b;
    rt_rng_seed(&a, 42);
    rt_rng_seed(&b, 43);
    OK(rt_rng_u64(&a) != rt_rng_u64(&b), "different seed -> different first value");
}

/* ==========================================================================*/
int main(void)
{
    printf("=== rt_core V0 tests ===\n");

    test_rng();
    test_arena();
    test_grid_clearance();
    test_grid_components();
    test_grid_building_overlay();
    test_grid_obb();
    test_units();
    test_spatial();
    test_determinism();

    rt_grid_destroy(&G);

    int total = g_pass + g_fail;
    printf("\n%d/%d passed, %d failed\n", g_pass, total, g_fail);

    /* 断言数量本身也要被断言：静默跳过 / 忘记同步都会在这里被抓住 */
    if (total != EXPECTED_ASSERTS) {
        printf("ASSERT COUNT MISMATCH: ran %d, expected %d "
               "(更新 EXPECTED_ASSERTS 或检查是否有断言被跳过)\n",
               total, EXPECTED_ASSERTS);
        return 2;
    }
    if (g_fail) return 1;
    printf("ALL PASS (%d asserts)\n", total);
    return 0;
}

/* ============================================================================
 * rt_route.h -- Global Route（区域级 A*，带 clearance 与版本依赖）
 *
 * M4.1 的目标只有一个：**同一目标的一群单位共用一条 Global Route**，
 * 而不是每人一条。所以 Route 是**被共享的只读对象**，按
 *   (start_region, goal_region, clearance_class, movement_class)
 * 做 key 缓存。
 *
 * 为什么先做「按起点区域缓存」而不是立刻做 goal-centric field：
 *   - 一次框选 1000 个单位通常集中在几个区域里（RTS 的框选形状决定），
 *     所以 build 次数 ≈ 源区域数，已经比 N 小两三个数量级；
 *   - goal-centric 的 coarse flow 是 M4.3 的任务，两者可以共存
 *     （Policy 在 M4 报告里给数据依据，见题面 §九十六）。
 * ==========================================================================*/
#ifndef RT_ROUTE_H
#define RT_ROUTE_H

#include "rt_types.h"
#include "rt_grid.h"
#include "rt_region.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 依赖 chunk 的上限：一条走廊如果跨超过 24 个 32-cell chunk，
 * 就不再逐 chunk 记版本，退化为「任一提交即失效」（保守但正确）。 */
#define RT_ROUTE_DEP_MAX 24

typedef struct {
    int32_t *regions;        /* 走廊：从 start 到 goal 的区域序列 */
    RtVec2  *portal;         /* 门户点：portal[i] = 从 regions[i] 出去的跨界点 */
    int      n, cap;
    int32_t  start_region, goal_region;
    uint8_t  clearance_class, movement_class;
    float    radius_m;

    /* 版本依赖（M3 的 chunk_ver / label_epoch） */
    uint32_t dep_chunks[RT_ROUTE_DEP_MAX];
    uint32_t dep_vers[RT_ROUTE_DEP_MAX];
    int      dep_n;
    uint8_t  dep_overflow;
    uint32_t label_epoch;

    /* 诊断 */
    int      expanded;       /* A* 展开节点数 */
    float    cost;           /* 路径代价（区域步长） */
    uint32_t build_seq;      /* 用于 benchmark 归因 */
} RtRoute;

/* 可复用的 A* 工作区（避免每次 build malloc；由 owner 持有） */
typedef struct {
    float   *gscore;
    int32_t *parent;
    uint8_t *state;          /* 0 = 未访问, 1 = open, 2 = closed */
    int32_t *heap;           /* 堆里存 node */
    int32_t *hpos;           /* node 在堆中的位置（-1 = 不在） */
    int      cap;
} RtRouteSolver;

int  rt_route_solver_init(RtRouteSolver *s, int max_nodes);
void rt_route_solver_destroy(RtRouteSolver *s);

/* 建一条 route。成功返回 RT_OK，并把 n 置为走廊长度。
 * 失败：RT_ERR_NOT_FOUND（无路）、RT_ERR_CAPACITY、RT_ERR_INVALID。 */
int rt_route_build(RtRoute *r, RtRouteSolver *s, const RtRegionMap *m,
                   int start_region, int goal_region, int clearance_class,
                   int movement_class);

void rt_route_free(RtRoute *r);

/* 依赖校验：label_epoch 相同 + 每个依赖 chunk 的版本未变 */
int rt_route_valid(const RtRoute *r, const RtGrid *g);

/* 单位沿走廊前进：返回它当前应该前往的门户点。
 * 返回 1 = 有门户（写 out）；0 = 已在走廊末端，调用方应转向最终目标。 */
int rt_route_next_portal(const RtRoute *r, const RtRegionMap *m, int cur_region, RtVec2 *out);

/* 单位沿走廊前进：给定当前区域，返回「下一个该去的区域」（-1 = 已到末端）。
 * 若当前区域不在走廊上（被推离），返回走廊上与当前区域最近的点的下一个。 */
int rt_route_next_region(const RtRoute *r, const RtRegionMap *m, int cur_region);

/* 把走廊压成一条折线（区域中心），用于 debug 绘制 / 局部目标 */
int rt_route_polyline(const RtRoute *r, const RtRegionMap *m, RtVec2 *out, int max_out);

/* ============================================================================
 * M4.3 Goal-centric Coarse Flow
 *
 * 定位：**route 的搜索后端**。当同一个 (goal, comp, cls, mcls) 被多个 source
 * 区域请求时，从 goal 侧做一次反向 Dijkstra，多个 source 共用这棵树。
 *   - 仍然产出 per-source 的 RtRoute（下游 rt_gw_sample / portal / group 不变）
 *   - 树只展开到「本次请求的 source 全部 settle」为止（有界，不扫全图）
 *   - 依赖 = 树访问过的 chunk 集合 + label_epoch；任一变化 => 整棵树失效（不做局部修复）
 * ==========================================================================*/
#define RT_GOALFLOW_MAX          4      /* 同时缓存的 flow 数 */
#define RT_GOALFLOW_DEP_WORDS    16     /* RT_CHUNK_N = 1024 位 */

typedef struct {
    uint8_t  state;         /* 0 = 空, 1 = ready, 2 = 作废但槽位保留 */
    uint8_t  cls, mcls;
    int32_t  goal, comp;
    uint32_t label_epoch;
    uint32_t last_used;
    uint32_t hits, builds;

    float   *dist;          /* [nregions] 到 goal 的代价，>=1e29 表示未 settle */
    int32_t *parent;        /* [nregions] 指向 goal 的下一跳 */
    int      nregions;
    uint64_t dep_mask[RT_GOALFLOW_DEP_WORDS];
    uint32_t dep_ver[RT_CHUNK_N];
    int      dep_n, dep_overflow;
    int      expanded;      /* settle 的区域数（成本归因） */
    int      source_n;      /* 建树时请求的 source 数 */
} RtGoalFlow;

typedef struct {
    int32_t *heap;
    int32_t *hpos;
    uint8_t *state;         /* 0 未访问 / 1 open / 2 closed */
    uint8_t *need;          /* 1 = 本次请求的 source */
    int      cap, hn;
} RtGoalFlowSolver;

int  rt_goalflow_solver_init(RtGoalFlowSolver *s, int max_nodes);
void rt_goalflow_solver_destroy(RtGoalFlowSolver *s);
void rt_goalflow_free(RtGoalFlow *f);

/* 从 goal 反向建树，直到 srcs 全部 settle（或连通域耗尽）。 */
int rt_goalflow_build(RtGoalFlow *f, RtGoalFlowSolver *s, const RtRegionMap *m,
                      int goal, int comp, int cls, int mcls,
                      const int32_t *srcs, int nsrcs);

int rt_goalflow_valid(const RtGoalFlow *f, const RtGrid *g);

/* 沿 parent 摘出 source -> goal 的区域序列；返回长度（0 = 不可达） */
int rt_goalflow_path(const RtGoalFlow *f, int src, int32_t *out, int max_out);

/* 用一条区域序列填充 RtRoute（门户 / 依赖 / label_epoch 与 A* 版完全一致）。
 * cost 由调用方给（= flow 的 dist[src]），避免重复累加。 */
int rt_route_from_path(RtRoute *r, const RtRegionMap *m, const int32_t *regions,
                       int n, int cls, int mcls, float cost);

#ifdef __cplusplus
}
#endif

#endif /* RT_ROUTE_H */

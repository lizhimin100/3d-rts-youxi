/* 临时：拆解 1000 单位采样里 fine 层到底花了多少（LOS / 查表 / 建场）。跑完即删。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void t_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#endif

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static uint64_t g_state = 0xC0FFEEull;

static uint64_t nu(void)
{
    uint64_t z = (g_state += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
}

static int spawn_disc(RtUnitId *ids, int n, float cx, float cz, float r)
{
    int k = 0;
    for (int i = 0; i < n * 3 && k < n; i++) {
        float rad = r * sqrtf((float)i / (float)(n * 3));
        float ang = (float)i * 2.39996323f;
        int x = rt_grid_cell_x(&G, cx + cosf(ang) * rad);
        int z = rt_grid_cell_z(&G, cz + sinf(ang) * rad);
        if (!rt_grid_walkable(&G, x, z)) continue;
        RtUnitId id = rt_units_spawn(&US, rt_v3((float)x + 0.5f, 0.f, (float)z + 0.5f), RT_FP_SMALL);
        if (id != RT_UNIT_ID_NONE) ids[k++] = id;
    }
    return k;
}

int main(void)
{
    t_init();
    rt_grid_init(&G, 256, 256, 1.0f);
    g_state = 0xC0FFEEull + 256u + 1u;
    for (int z = 0; z < 256; z++)
        for (int x = 0; x < 256; x++)
            if ((nu() >> 40) % 1000 < 100) rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int z = 0; z < 256; z++)
        if (z != 128) rt_grid_set_terrain(&G, 128, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int dz = -1; dz <= 1; dz++) {
        rt_grid_set_terrain(&G, 127, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, 128, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, 129, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
    }
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);

    static RtUnitId ids[1024];
    int n = spawn_disc(ids, 1000, 50.f, 60.f, 12.f);
    rt_gw_command(&W, &US, ids, n, rt_v2(210.5f, 190.5f), 0, RT_CLS_SMALL, 1);

    for (int mode = 0; mode < 2; mode++) {
        rt_gw_set_fine_enabled(&W, mode);
        double best = 1e30;
        volatile float acc = 0.f;
        printf("-- fine=%d --\n", mode);
        for (int rep = 0; rep < 7; rep++) {
            uint32_t b0 = W.stats.fine_builds;
            double t0 = now_ms();
            for (int i = 0; i < n; i++) {
                RtVec3 p = rt_units_pos(&US, ids[i]);
                RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[i]);
                int gi = (int)ch->group[rt_unit_slot_index(ids[i])] - 1;
                RtVec2 tgt;
                if (gi >= 0 && rt_gw_sample(&W, gi, rt_v2(p.x, p.z), &tgt) == RT_OK) acc += tgt.x;
            }
            double dt = now_ms() - t0;
            if (dt < best) best = dt;
            printf("   rep%d %.4f ms (builds +%u)\n", rep, dt, W.stats.fine_builds - b0);
        }
        printf("fine=%d : sample best=%.4f ms | checks=%u builds=%u hits=%u invalid=%u used=%u out=%u rej=%u fail=%u segs=%u blocked=%u\n",
               mode, best, W.stats.fine_checks, W.stats.fine_builds, W.stats.fine_hits,
               W.stats.fine_invalid, W.stats.fine_used,
               W.stats.fine_outside, W.stats.fine_rejected, W.stats.fine_failed,
               W.stats.corridor_segments, W.stats.corridor_blocked);
    }

    /* 单独测 LOS：从每个单位到它当前的目标节点 */
    double best = 1e30;
    int acc2 = 0;
    for (int rep = 0; rep < 7; rep++) {
        double t0 = now_ms();
        for (int i = 0; i < n; i++) {
            RtVec3 p = rt_units_pos(&US, ids[i]);
            RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[i]);
            int gi = (int)ch->group[rt_unit_slot_index(ids[i])] - 1;
            RtVec2 tgt;
            if (gi < 0 || rt_gw_sample(&W, gi, rt_v2(p.x, p.z), &tgt) != RT_OK) continue;
            acc2 += rt_los_clear(&G, rt_v2(p.x, p.z), tgt);
        }
        double dt = now_ms() - t0;
        if (dt < best) best = dt;
    }
    printf("sample + LOS : best=%.4f ms (LOS acc=%d)\n", best, acc2);

    /* 单独测一次 fine flow 建场 */
    {
        RtFineSolver fs; rt_fine_solver_init(&fs, RT_FINE_CELLS);
        RtFineFlow ff; memset(&ff, 0, sizeof(ff));
        int okn = 0;
        double t0 = now_ms();
        for (int i = 0; i < 2000; i++) {
            int x = 40 + (i * 7) % 160, z = 40 + (i * 13) % 160;
            if (rt_fineflow_build(&ff, &fs, &G, x, z, RT_CLS_SMALL) == RT_OK) okn++;
        }
        double dt = now_ms() - t0;
        printf("fine build: %.2f us/build (%d ok / 2000), reached=%d\n", dt * 1000.0 / 2000.0, okn, ff.reached);
        rt_fine_free(&ff);
        rt_fine_solver_destroy(&fs);
    }

    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return 0;
}

/* ============================================================================
 * rt_plan.h -- LocalPlanner：地形绕行（wall-following，M13）
 *
 * 为什么需要这一层（M11b §6 根因 3 的结论）：
 *   凹角处的极限环**没有局部解**。L3 的侧移 `perp = (-dir.z, dir.x)` 与期望方向
 *   严格垂直，左右两边「离目标更近」的一阶项恒为 0 —— clearance、距离、可走性
 *   全都分不出来，所以按索引奇偶选边，选错就把人推离洞口。
 *   唯一能分辨的是**墙往哪边拐**，那需要沿墙跟随，也就是本层。
 *
 * 本层做什么：
 *   给每个单位一个**本地目标** aim（导航采样出来的 11 m 前瞻点，或调用方给的任何点）。
 *   1. 直线 pos->aim 被**地形**挡住 -> 接管 pref_vel，按「从朝目标方向起、朝某一侧
 *      旋转扫描」找第一个可走的候选方向（12° 一步，最多 300°）。
 *   2. 扫描的旋向 `side` 在进入绕行时**只决定一次**并持久化 —— 这就是 Bug 类算法的
 *      终止性来源：旋转方向固定，墙再凹也会被绕完；每帧重算会原地打转。
 *   3. 一旦直线重新可通 -> 立刻交还（不接管），并且要求「比进入时更近」才计入 finished。
 *   4. 绕行预算（14 m / 6 s）用完 -> BLOCKED，**不再接管**，把决定权交回上层
 *      （卡死恢复会继续升级）。这条是 M6 T2「不可达必须给 GAVE_UP」的护栏：
 *      没有预算，封闭房间里的单位会沿着墙永远转圈，永远到不了 give-up。
 *
 * 只处理**地形**，不处理单位：
 *   单位之间的拥堵是 ORCA + FR-STK 的事（它们有 inv_mass / 优先权 / 队列语义）。
 *   所以本层在「只有人挡路」时完全不动 pref —— 不会和 L1/L2/L3 抢。
 *
 * 层级契约（CON-5）：本文件只 include rt_grid.h / rt_local.h，不认识 Navigation。
 *
 * 与 rt_stuck 的接法：本层先跑（写 pref），再把 `rt_plan_hook` 挂到
 * RtStuckHooks.local_repath 上 —— L3 会问本层「你是不是已经在绕了」，
 * 在绕就返回 1（rt_stuck 不动 pref），不在绕才退回它自己的侧移。
 * ==========================================================================*/
#ifndef RT_PLAN_H
#define RT_PLAN_H

#include "rt_types.h"
#include "rt_grid.h"
#include "rt_local.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 扫描候选数上限：12° × 25 = 300°，够绕过一个凹角 */
#define RT_PLAN_SWEEP_MAX 25

typedef enum {
    RT_PLAN_IDLE = 0,     /* 直线可通 / 无目标：本层不接管 */
    RT_PLAN_FOLLOW = 1,   /* 地形挡住：沿墙绕行（本层接管 pref_vel） */
    RT_PLAN_BLOCKED = 2,  /* 预算用完：放弃绕行（不接管，交回上层） */
    RT_PLAN_STATE_COUNT
} RtPlanState;

typedef struct {
    float los_step;         /* 直线采样步长（m），默认 0.30 */
    float probe_dist;       /* 候选方向探测长度（m），默认 1.40 */
    float sweep_step_deg;   /* 角扫步长（度），默认 12 */
    float follow_max_dist;  /* 绕行位移预算（m），默认 15 */
    float follow_max_time;  /* 绕行时间预算（s），默认 6 */
    float rejoin_margin;    /* 退出绕行时要求「比进入时近」多少（m），默认 0.30 */
    float rearm_delay;      /* 放弃后至少隔多久才允许重新接管（s），默认 2 */
    float arrive_dist;      /* 到目标这么近就不管了（m），默认 0.60 */
    float cooldown;         /* 绕行结束后多久不再进入（s），默认 0.40 */
} RtPlanConfig;

typedef struct {
    int32_t  state;        /* RtPlanState */
    int32_t  side;         /* +1 / -1：本次绕行的旋向（持久，禁止每帧翻） */
    float    follow_t;
    float    follow_d;
    float    cooldown_t;
    float    rearm_t;
    uint32_t fail_epoch;   /* 放弃时的 nav_epoch：地图没变就别再试 */
    float    hit_goal_d;   /* 进入绕行时到目标的距离 */
    RtVec2   hit_pos;
    RtVec2   fail_pos;
    uint32_t episodes;
    uint8_t  unl;          /* 已计入 unreachable（只数事件，不数帧） */
    RtVec2   dir;          /* 本帧给出的方向（诊断） */
} RtPlanUnit;

typedef struct {
    uint32_t engaged;      /* 进入绕行的次数 */
    uint32_t finished;     /* 绕行后重新看到目标的次数 */
    uint32_t exhausted;    /* 预算用完 */
    uint32_t no_exit;      /* 300° 扫完没有可走方向 */
    uint32_t rearm;        /* 放弃后重新接管（地图变了） */
    uint32_t unreachable;  /* 目标在别的连通分量 -> 本层直接不接管 */
    uint32_t active;       /* 当前在绕行的人数 */
    uint32_t los_fast;     /* 走快路径（clearance 已证明直线可通）的次数 */
    uint32_t los_check;    /* 精确直线检测次数 */
    uint64_t los_samples;  /* 精确检测里采样的格子数（成本核算） */
} RtPlanStats;

typedef struct {
    RtPlanConfig cfg;
    RtPlanUnit  *u;
    int          cap;
    RtPlanStats  st;
} RtPlanCtx;

void rt_plan_config_default(RtPlanConfig *c);

int  rt_plan_init(RtPlanCtx *c, int max_units, const RtPlanConfig *cfg);
void rt_plan_destroy(RtPlanCtx *c);
void rt_plan_reset(RtPlanCtx *c, int idx);
void rt_plan_reset_all(RtPlanCtx *c);

int  rt_plan_state(const RtPlanCtx *c, int idx);   /* RtPlanState */
int  rt_plan_active(const RtPlanCtx *c, int idx);  /* 1 = 本层正在接管 pref */

/* 每帧一次，在「调用方填好 pref_vel」之后、rt_stuck_step 之前。
 *   aim[i]  : 本地目标（world）——真流水线里是 rt_gw_sample 的 11 m 前瞻点。
 *   goal[i] : 这条命令的最终目标。
 * 两个都要：aim 决定「现在往哪走」，goal 决定「值不值得绕」。
 * 只给 aim 的话，封闭房间里的前瞻点还在房间内（同一个连通分量），
 * 本层就会以为「绕一绕能到」，在墙上白耗 6 s，把 M6 的 10~30 s give-up 顶到 32.9 s。
 * goal[i] 与 aim[i] 相同也没问题（单点命令）。
 * g 为 NULL 时本层整体不工作（返回 0，全部放行）。
 * 返回本帧接管的单位数。 */
int rt_plan_step(RtPlanCtx *c, RtLocalAgent *ag, int n,
                 const RtVec2 *aim, const RtVec2 *goal,
                 const RtGrid *g, float dt);

/* 给 RtStuckHooks.local_repath 用（ud 传 RtPlanCtx*）。 */
int rt_plan_hook(void *ud, int idx, RtVec2 dir);

const char *rt_plan_state_name(int s);

#ifdef __cplusplus
}
#endif

#endif /* RT_PLAN_H */

/* ============================================================================
 * test_m7.c -- 静止单位让路（FR-YLD）
 *
 * 这一层是**决策逻辑**：谁该让、让到哪、什么时候回去。
 * 为了不被 ORCA 在单格走廊里的「冻结」行为掩盖（M5 已知边界），
 * 主场景用**脚本行人流**：mover 以恒定速度朝 +x 走，前面有人就停（不会侧移）。
 * 这正是「一条窄路 + 一个站着的人」的抽象，逻辑层要解决的就是它。
 *
 *   T1 主场景：8 人要通过，中间站着一个单位（control / yield 对照）
 *   T2 没有交通时不许乱动
 *   T3 滞回：连续多批交通下不许反复横跳
 *   T4 1000 人（500 mover + 500 idle）成本
 *   T5 确定性
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_yield.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", (m)); } } while (0)

#define MAXA 1200
static RtLocalAgent AG[MAXA];
static RtYieldCtx YC;
static RtGrid G;

static void agent_set(int i, float x, float z, float r, float speed, int inv_mass)
{
    memset(&AG[i], 0, sizeof(AG[i]));
    AG[i].pos = rt_v2(x, z);
    AG[i].pref_vel = rt_v2(0.f, 0.f);
    AG[i].radius = r;
    AG[i].max_speed = speed;
    AG[i].fp = r * 2.f;
    AG[i].share = 0.5f;
    AG[i].inv_mass = (float)inv_mass;
}

/* 单格走廊 x∈[90,132] z=127；壁龛 x∈[106,110] z∈[125,126] */
static void build_corridor(void)
{
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int z = 0; z < 256; z++)
        for (int x = 0; x < 256; x++) {
            int corridor = (z == 127 && x >= 90 && x <= 132);
            int alcove = (x >= 106 && x <= 111 && z >= 124 && z <= 126);
            if (!corridor && !alcove)
                rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
    rt_grid_rebuild_all(&G);
}

/* 让路单位自己走一步：按 pref 积分，撞墙按轴分解（与 rt_local 的墙约束同义）。
 * 只给静止单位用，所以不需要 ORCA。返回实际位移。 */
static float integrate_one(RtLocalAgent *a, const RtGrid *g, float dt)
{
    RtVec2 before = a->pos;
    RtVec2 v = a->pref_vel;
    if (rt_v2_len2(v) < 1e-8f) { a->vel = rt_v2(0.f, 0.f); return 0.f; }
    RtVec2 np = rt_v2(before.x + v.x * dt, before.z + v.z * dt);
    RtObb2 o = rt_obb_make(np, a->fp, 0.f);
    if (!g || !rt_grid_obb_blocked(g, &o)) {
        a->pos = np;
        a->vel = v;
        return rt_v2_dist(before, a->pos);
    }
    /* 逐轴滑动 */
    RtVec2 px = rt_v2(before.x + v.x * dt, before.z);
    RtObb2 ox = rt_obb_make(px, a->fp, 0.f);
    if (!g || !rt_grid_obb_blocked(g, &ox)) {
        a->pos = px; a->vel = rt_v2(v.x, 0.f);
        return rt_v2_dist(before, a->pos);
    }
    RtVec2 pz = rt_v2(before.x, before.z + v.z * dt);
    RtObb2 oz = rt_obb_make(pz, a->fp, 0.f);
    if (!g || !rt_grid_obb_blocked(g, &oz)) {
        a->pos = pz; a->vel = rt_v2(0.f, v.z);
        return rt_v2_dist(before, a->pos);
    }
    a->vel = rt_v2(0.f, 0.f);
    return 0.f;
}

typedef struct {
    int   arrived;
    int   frames;
    int   transitions;
    float max_away;
    float home_err;
} CorridorResult;

/* 脚本行人流：mover 以 sp 朝 +x 前进，前面 0.95 m 有人就停（不会侧移）。
 * 让路单位（index 0）由 rt_yield 驱动，用 integrate_one 积分。 */
static CorridorResult run_corridor(int use_yield, int n_movers, int frames_max,
                                   int verbose)
{
    CorridorResult r;
    memset(&r, 0, sizeof(r));

    build_corridor();
    rt_yield_destroy(&YC);
    rt_yield_init(&YC, MAXA, NULL, &G);

    const float dt = 1.f / 30.f;
    const float sp = 1.5f;
    const int idle = 0;
    agent_set(idle, 108.5f, 127.5f, 0.45f, 1.0f, 0);

    for (int i = 1; i <= n_movers; i++)
        agent_set(i, 94.f + (float)(i - 1) * 1.2f, 127.5f, 0.45f, sp, 1);

    const float goal_x = 128.f;
    int prev_state = (int)YC.u[idle].state;
    RtVec2 home = AG[idle].pos;

    int s = 0;
    for (; s < frames_max; s++) {
        int moving = 0;

        /* 1) mover：先按「前面有没有人」决定这一帧走不走 */
        for (int i = 1; i <= n_movers; i++) {
            if (AG[i].max_speed <= 0.f) continue;
            float gap = goal_x - AG[i].pos.x;
            if (gap <= 0.3f) {
                AG[i].max_speed = 0.f;
                AG[i].pref_vel = rt_v2(0.f, 0.f);
                AG[i].vel = rt_v2(0.f, 0.f);
                continue;
            }
            /* 找正前方最近的身体（含让路单位） */
            float block = 1e9f;
            for (int j = 0; j < n_movers + 1; j++) {
                if (j == i) continue;
                if (AG[j].max_speed <= 0.f && j != idle) continue;   /* 已到达的不挡路 */
                float dz = fabsf(AG[j].pos.z - AG[i].pos.z);
                if (dz > AG[i].radius + AG[j].radius) continue;
                float dx = AG[j].pos.x - AG[i].pos.x;
                if (dx <= 0.f) continue;
                float need = AG[i].radius + AG[j].radius + 0.05f;
                if (dx < need && dx < block) block = dx;
            }
            /* 关键：pref_vel 永远是「我想走多快」，被堵只影响 vel。
             * 压力场就是拿 actual/desired 判的，两个都写 0 就测不出拥堵。 */
            AG[i].pref_vel = rt_v2(sp, 0.f);
            if (block < 1e8f) {
                AG[i].vel = rt_v2(0.f, 0.f);
            } else {
                AG[i].vel = rt_v2(sp, 0.f);
                AG[i].pos.x += sp * dt;
                if (AG[i].pos.x > goal_x) AG[i].pos.x = goal_x;
                moving++;
            }
        }

        /* 2) 让路层决策（读的是上面的 pref/vel） */
        if (use_yield) rt_yield_step(&YC, AG, n_movers + 1, &G, dt, NULL, NULL);

        /* 3) 让路单位积分（脚本 mover 已经自己走过了，不要再积分） */
        (void)integrate_one(&AG[idle], &G, dt);

        if (verbose && s % 300 == 0) {
            printf("      [f=%4d] x:", s);
            for (int q = 0; q <= n_movers; q++) printf(" %.1f", AG[q].pos.x);
            printf("  %-4s idle=(%.2f,%.2f) tgt=(%.2f,%.2f) p=%.1f\n",
                   rt_yield_state_name((int)YC.u[0].state),
                   AG[0].pos.x, AG[0].pos.z,
                   YC.u[0].target.x, YC.u[0].target.z,
                   rt_yield_pressure_at(&YC, AG[0].pos));
        }

        float away = rt_v2_dist(home, AG[idle].pos);
        if (away > r.max_away) r.max_away = away;
        int st = (int)YC.u[idle].state;
        if (st != prev_state) { r.transitions++; prev_state = st; }

        if (moving == 0) {
            /* 全部到达或全部堵死：如果没人能动了就结束 */
            if (AG[1].pos.x >= goal_x - 0.3f) break;
        }
    }
    r.frames = s;

    for (int i = 1; i <= n_movers; i++) if (AG[i].pos.x >= goal_x - 0.3f) r.arrived++;

    /* 队伍走完后，再跑 8 s 看它是否回位 */
    for (int k = 0; k < 240; k++) {
        if (use_yield) rt_yield_step(&YC, AG, n_movers + 1, &G, dt, NULL, NULL);
        (void)integrate_one(&AG[idle], &G, dt);
        float away = rt_v2_dist(home, AG[idle].pos);
        if (away > r.max_away) r.max_away = away;
        int st = (int)YC.u[idle].state;
        if (st != prev_state) { r.transitions++; prev_state = st; }
    }
    r.home_err = rt_v2_dist(home, AG[idle].pos);
    return r;
}

static void t1(void)
{
    printf("\n[T1] 单格走廊 + 壁龛：8 人要通过，中间站着一个单位\n");
    CorridorResult a = run_corridor(0, 8, 2400, 1);
    printf("  control: arrived=%d/8 frames=%d  idle moved=%.2f m\n",
           a.arrived, a.frames, a.max_away);

    CorridorResult b = run_corridor(1, 8, 2400, 1);
    printf("  yield  : arrived=%d/8 frames=%d  idle moved=%.2f m (home err %.2f)"
           "  transitions=%d triggers=%u completed=%u no_cand=%u timeouts=%u\n",
           b.arrived, b.frames, b.max_away, b.home_err, b.transitions,
           YC.st.triggers, YC.st.completed, YC.st.no_candidate, YC.st.timeouts);

    OK(a.arrived <= 1, "T1 without yielding the corridor is blocked");
    OK(b.arrived == 8, "T1 with yielding all eight get through");
    OK(b.frames < a.frames, "T1 yielding clears the corridor faster than waiting");
    OK(b.max_away > 1.2f, "T1 the idle unit actually stepped aside");
    OK(b.home_err < 0.8f, "T1 it went back home afterwards");
    OK(YC.st.completed >= 1, "T1 a yield cycle completed");
}

static void t2_no_traffic(void)
{
    printf("\n[T2] 没有交通：不许乱动\n");
    build_corridor();
    rt_yield_destroy(&YC);
    rt_yield_init(&YC, 64, NULL, &G);

    const int n = 4;
    for (int i = 0; i < n; i++) agent_set(i, 100.f + (float)i * 4.f, 127.5f, 0.45f, 1.f, 0);
    RtVec2 home0 = AG[0].pos;

    for (int s = 0; s < 900; s++) {
        rt_yield_step(&YC, AG, n, &G, 1.f / 30.f, NULL, NULL);
        (void)integrate_one(&AG[0], &G, 1.f / 30.f);
    }

    printf("  triggers=%u yields=%u  moved=%.3f m\n",
           YC.st.triggers, YC.u[0].yields, rt_v2_dist(home0, AG[0].pos));
    OK(YC.st.triggers == 0, "T2 no traffic produces no yield trigger");
    OK(rt_v2_dist(home0, AG[0].pos) < 0.05f, "T2 nobody wandered off");
}

/* 连续交通：每 4 s 放一批 4 人反复穿过，看让路单位会不会来回横跳 */
static void t3_hysteresis(void)
{
    printf("\n[T3] 连续交通：不许反复横跳\n");
    build_corridor();
    rt_yield_destroy(&YC);
    rt_yield_init(&YC, MAXA, NULL, &G);

    const float dt = 1.f / 30.f, sp = 1.5f;
    const float goal_x = 128.f;
    agent_set(0, 108.5f, 127.5f, 0.45f, 1.0f, 0);
    RtVec2 home = AG[0].pos;

    const int batch = 4;
    int used[9] = { 0 };
    int transitions = 0, prev = (int)YC.u[0].state, spawned = 0;

    for (int s = 0; s < 1800; s++) {
        if (s % 120 == 0) {
            for (int k = 0; k < batch; k++) {
                int slot = -1;
                for (int q = 1; q <= 8; q++) if (!used[q]) { slot = q; break; }
                if (slot < 0) break;
                used[slot] = 1;
                agent_set(slot, 94.f + (float)k * 1.2f, 127.5f, 0.45f, sp, 1);
                spawned++;
            }
        }
        for (int q = 1; q <= 8; q++) {
            if (!used[q]) continue;
            float block = 1e9f;
            for (int j = 0; j < 9; j++) {
                if (j == q) continue;
                if (AG[j].max_speed <= 0.f && j != 0) continue;
                float dz = fabsf(AG[j].pos.z - AG[q].pos.z);
                if (dz > AG[q].radius + AG[j].radius) continue;
                float dx = AG[j].pos.x - AG[q].pos.x;
                if (dx <= 0.f) continue;
                float need = AG[q].radius + AG[j].radius + 0.05f;
                if (dx < need && dx < block) block = dx;
            }
            AG[q].pref_vel = rt_v2(sp, 0.f);
            if (block < 1e8f) {
                AG[q].vel = rt_v2(0.f, 0.f);
            } else {
                AG[q].vel = rt_v2(sp, 0.f);
                if (AG[q].pos.x < goal_x) AG[q].pos.x += sp * dt;
            }
            if (AG[q].pos.x >= goal_x) { used[q] = 0; AG[q].max_speed = 0.f; }
        }
        rt_yield_step(&YC, AG, 9, &G, dt, NULL, NULL);
        (void)integrate_one(&AG[0], &G, dt);
        int st = (int)YC.u[0].state;
        if (st != prev) { transitions++; prev = st; }
    }
    printf("  batches=%d  triggers=%u completed=%u transitions=%d  home err=%.2f m\n",
           spawned / batch, YC.st.triggers, YC.st.completed, transitions,
           rt_v2_dist(home, AG[0].pos));
    OK(YC.st.triggers <= 6, "T3 at most one yield per burst (5 bursts)");
    OK(transitions <= 12, "T3 no ping-ponging (state changes bounded)");
}

static void t4_cost(void)
{
    printf("\n[T4] 1000 人（500 mover + 500 idle）每帧成本\n");
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    rt_grid_rebuild_all(&G);
    rt_yield_destroy(&YC);
    rt_yield_init(&YC, MAXA, NULL, &G);

    const int n = 1000;
    for (int i = 0; i < n; i++) {
        int mover = (i < 500);
        agent_set(i, 30.f + (float)(i % 40) * 1.5f, 30.f + (float)(i / 40) * 1.5f,
                  0.5f, 1.5f, mover ? 1 : 0);
    }
    double best = 1e30, sum = 0, worst = 0;
    const int steps = 300;
    for (int s = 0; s < steps; s++) {
        for (int i = 0; i < 500; i++) {
            AG[i].pref_vel = rt_v2(1.5f, 0.f);
            AG[i].vel = rt_v2(0.1f, 0.f);        /* 被堵：<0.5*pref，计入压力 */
        }
        double t0 = now_ms();
        rt_yield_step(&YC, AG, n, &G, 1.f / 30.f, NULL, NULL);
        double d = now_ms() - t0;
        if (d < best) best = d;
        if (d > worst) worst = d;
        sum += d;
    }
    printf("  n=1000: best=%.4f ms  mean=%.4f ms  worst=%.4f ms  triggers=%u\n",
           best, sum / steps, worst, YC.st.triggers);
    OK(best < 0.20, "T4 yielding layer costs < 0.2 ms at 1000 units");
    OK(worst < 0.60, "T4 worst frame < 0.6 ms");
}

static void t5_determinism(void)
{
    printf("\n[T5] 确定性\n");
    static RtLocalAgent A1[MAXA];
    CorridorResult a = run_corridor(1, 4, 1800, 0);
    memcpy(A1, AG, sizeof(RtLocalAgent) * 5);
    uint32_t t1s = YC.st.triggers, c1s = YC.st.completed;

    CorridorResult b = run_corridor(1, 4, 1800, 0);
    int d = memcmp(A1, AG, sizeof(RtLocalAgent) * 5) != 0;
    printf("  memcmp=%s transitions=%d/%d triggers=%u/%u completed=%u/%u\n",
           d ? "DIFF" : "same", a.transitions, b.transitions, t1s, YC.st.triggers, c1s, YC.st.completed);
    OK(!d, "T5 agent state is bit-identical across runs");
    OK(t1s == YC.st.triggers && c1s == YC.st.completed, "T5 counters identical");
}

int main(void)
{
    timer_init();
    printf("=== M7 tests: idle-unit yielding (FR-YLD) ===\n");
    t1();
    t2_no_traffic();
    t3_hysteresis();
    t4_cost();
    t5_determinism();

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    if (g_fail == 0) printf("ALL PASS (%d asserts)\n", g_pass);
    rt_yield_destroy(&YC);
    rt_grid_destroy(&G);
    return g_fail == 0 ? 0 : 1;
}

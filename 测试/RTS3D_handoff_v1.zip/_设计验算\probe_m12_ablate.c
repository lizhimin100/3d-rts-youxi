/* ============================================================================
 * probe_m12_ablate.c -- M12 消融：谁把方阵压扁的？
 *
 * 两个候选原因：
 *   A. 落脚策略（老台架：dist<1.2 就 pref=0 并永久锁存）
 *   B. 让路层（rt_yield 把「已就位的队形成员」当闲人挪走，01 §8 本应用
 *      may_yield 锁住，台架传了 NULL）
 *
 * 2 x 2 = 四组，同机同会话，从同一初始状态出发。
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_stuck.h"
#include "rt_yield.h"
#include "rt_form.h"
#include "rt_region.h"
#include "rt_group.h"
#include "rt_unit.h"

#define MAXA 512
#define N_UNITS 144

static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;
static RtStuckCtx SC;
static RtYieldCtx YC;
static RtFormation FM;
static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static RtUnitId IDS[MAXA];
static int SLOT_OF[MAXA];
static RtFormMember MEM[MAXA];
static RtFormSettle SET;
static int N = 0;

/* 老台架的锁存位 */
static uint8_t LATCH[MAXA];
static int      G_FORM_LOCKED = 0;

static int may_yield_cb(void *ud, int idx)
{
    (void)ud;
    if (G_FORM_LOCKED) return 0;          /* 队形成员不让路（01 §8） */
    return 1;
}

static void build_world(void)
{
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    rt_grid_rebuild_all(&G);
    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
    rt_local_destroy(&LC);
    rt_local_init(&LC, 256.f, 256.f, MAXA, 4.0f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);
    rt_stuck_destroy(&SC);
    rt_stuck_init(&SC, MAXA, NULL);
    rt_yield_destroy(&YC);
    rt_yield_init(&YC, MAXA, NULL, &G);
}

static void spawn_block(int n, float x0, float z0, int cols)
{
    N = 0;
    for (int i = 0; i < n; i++) {
        float x = x0 + (float)(i % cols) * 1.6f;
        float z = z0 + (float)(i / cols) * 1.6f;
        RtUnitId id = rt_units_spawn(&US, rt_v3(x, 0.f, z), RT_FP_SMALL);
        if (id == RT_UNIT_ID_NONE) break;
        IDS[N] = id;
        rt_form_member_reset(&MEM[N]);
        LATCH[N] = 0;
        memset(&AG[N], 0, sizeof(AG[N]));
        AG[N].pos = rt_v2(x, z);
        AG[N].radius = 0.5f;
        AG[N].max_speed = 2.0f;
        AG[N].fp = 1.0f;
        AG[N].share = 0.5f;
        AG[N].inv_mass = 1.f;
        N++;
    }
}

static float gap_to_slot(int i)
{
    return rt_v2_dist(AG[i].pos, rt_form_slot_world(&FM, SLOT_OF[i]));
}

static int cmp_float(const void *a, const void *b)
{
    float x = *(const float *)a, y = *(const float *)b;
    return (x < y) ? -1 : (x > y ? 1 : 0);
}

typedef struct {
    int   on_slot, coverage, frames, pairs_lt_140, reengages;
    float mean_gap, cohesion, nn_min, nn_p10, nn_med, spread;
    double t95;
} Row;

static Row run(const char *name, int use_settle, int form_locked, RtVec2 dest)
{
    Row r;
    memset(&r, 0, sizeof(r));
    G_FORM_LOCKED = form_locked;

    build_world();
    spawn_block(N_UNITS, 32.f, 108.f, 12);
    const float dt = 1.f / 30.f;

    rt_form_destroy(&FM);
    rt_form_init(&FM, MAXA);
    rt_form_build(&FM, RT_FORM_RECT, N, 1.0f, 1.2f);
    rt_form_set_anchor(&FM, dest);
    rt_form_set_yaw(&FM, 0.f, dt, NULL);
    {
        RtVec2 ps[MAXA];
        for (int i = 0; i < N; i++) ps[i] = AG[i].pos;
        (void)rt_form_assign(&FM, ps, N, SLOT_OF);
    }
    (void)rt_gw_command(&W, &US, IDS, N, dest, 0, RT_CLS_SMALL, 1);
    rt_form_settle_default(&SET);

    for (int s = 0; s < 3600; s++) {
        r.frames = s;
        for (int i = 0; i < N; i++) {
            RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, IDS[i]);
            int gi = (int)ch->group[rt_unit_slot_index(IDS[i])] - 1;
            RtVec2 pref = rt_v2(0.f, 0.f);
            int on = 0;
            RtVec2 slot = rt_form_slot_world(&FM, SLOT_OF[i]);

            if (rt_v2_dist(AG[i].pos, dest) < 40.f) {
                if (use_settle) {
                    pref = rt_form_member_steer(&FM, SLOT_OF[i], AG[i].pos,
                                                &MEM[i], &SET, 2.0f, dt);
                    on = rt_form_member_arrived(&MEM[i]);
                } else {
                    /* 老逻辑：进 1.2 m 就停，永久锁存 */
                    if (!LATCH[i] && rt_v2_dist(AG[i].pos, slot) < 1.2f) LATCH[i] = 1;
                    if (!LATCH[i]) {
                        RtVec2 d = rt_v2_sub(slot, AG[i].pos);
                        float l = rt_v2_len(d);
                        if (l > 1e-3f) pref = rt_v2_mul(d, 2.0f / l);
                    }
                    on = LATCH[i];
                }
            } else if (gi >= 0) {
                RtVec2 tgt;
                if (rt_gw_sample(&W, gi, AG[i].pos, &tgt) == RT_OK) {
                    RtVec2 d = rt_v2_sub(tgt, AG[i].pos);
                    float l = rt_v2_len(d);
                    if (l > 1e-3f) pref = rt_v2_mul(d, 2.0f / l);
                }
            }
            AG[i].pref_vel = pref;
            rt_stuck_set_hold(&SC, i, on);
        }

        rt_stuck_step(&SC, AG, N, &G, dt, NULL);
        rt_yield_step(&YC, AG, N, &G, dt, may_yield_cb, NULL);
        (void)rt_local_step(&LC, AG, N, &G, dt);
        (void)rt_gw_update(&W);

        if ((s % 30) == 0) {
            int done = 0;
            for (int i = 0; i < N; i++) {
                if (use_settle ? MEM[i].arrived : LATCH[i]) { done++; continue; }
                if (gap_to_slot(i) < 2.0f) done++;
            }
            if (r.t95 <= 0.0 && done >= (N * 95 + 99) / 100) r.t95 = (double)s * dt;
            if (done == N) break;
        }
    }

    /* 终局 */
    RtVec2 c = rt_v2(0.f, 0.f);
    for (int i = 0; i < N; i++) c = rt_v2_add(c, AG[i].pos);
    c = rt_v2_mul(c, 1.f / (float)N);
    for (int i = 0; i < N; i++) r.spread += rt_v2_dist(AG[i].pos, c);
    r.spread /= (float)N;

    float nn[MAXA];
    for (int i = 0; i < N; i++) {
        float bd = 1e30f;
        for (int j = 0; j < N; j++) {
            if (j == i) continue;
            float d = rt_v2_dist(AG[i].pos, AG[j].pos);
            if (d < bd) bd = d;
            if (j > i && d < 1.40f) r.pairs_lt_140++;
        }
        nn[i] = bd;
    }
    qsort(nn, (size_t)N, sizeof(float), cmp_float);
    r.nn_min = nn[0];
    r.nn_p10 = nn[(int)((float)N * 0.10f)];
    r.nn_med = nn[N / 2];

    for (int k = 0; k < FM.slot_count; k++) {
        RtVec2 sp = rt_form_slot_world(&FM, k);
        for (int i = 0; i < N; i++)
            if (rt_v2_dist(AG[i].pos, sp) < 1.5f) { r.coverage++; break; }
    }
    for (int i = 0; i < N; i++) {
        if (use_settle ? MEM[i].arrived : LATCH[i]) r.on_slot++;
        r.reengages += MEM[i].reengages;
        r.mean_gap += gap_to_slot(i);
    }
    r.mean_gap /= (float)N;
    {
        RtVec2 ps[MAXA];
        for (int i = 0; i < N; i++) ps[i] = AG[i].pos;
        r.cohesion = rt_form_cohesion(&FM, ps, SLOT_OF, N, 25.f);
    }

    /* gap 分布 + 逐列的位移（看是不是「整列被推」这种系统性偏差） */
    {
        float gs[MAXA];
        for (int i = 0; i < N; i++) gs[i] = gap_to_slot(i);
        qsort(gs, (size_t)N, sizeof(float), cmp_float);
        printf("  %-22s gap p50/p90/p99 = %.2f / %.2f / %.2f\n",
               name, gs[N / 2], gs[(int)(N * 0.9f)], gs[N - 1]);

        /* 按列（slot % 12）平均位移 */
        float sx[12], sz[12];
        int   cn[12];
        memset(sx, 0, sizeof(sx)); memset(sz, 0, sizeof(sz)); memset(cn, 0, sizeof(cn));
        for (int i = 0; i < N; i++) {
            int col = SLOT_OF[i] % 12;
            RtVec2 sp = rt_form_slot_world(&FM, SLOT_OF[i]);
            sx[col] += AG[i].pos.x - sp.x;
            sz[col] += AG[i].pos.z - sp.z;
            cn[col]++;
        }
        printf("  %-22s mean(pos-slot) by column: ", name);
        for (int c = 0; c < 12; c++)
            printf("%.2f/%.2f%s", sx[c] / (float)(cn[c] ? cn[c] : 1),
                   sz[c] / (float)(cn[c] ? cn[c] : 1), c == 11 ? "\n" : " ");
    }

    printf("  %-22s on_slot=%3d cov=%3d gap=%.2f nn=%.2f/%.2f/%.2f p<1.4=%3d"
           " coh=%.2f reeng=%2d frames=%4d t95=%s\n",
           name, r.on_slot, r.coverage, r.mean_gap,
           r.nn_min, r.nn_p10, r.nn_med, r.pairs_lt_140,
           r.cohesion, r.reengages, r.frames, r.t95 > 0 ? "ok" : "never");
    return r;
}

int main(void)
{
    RtVec2 dest = rt_v2(180.f, 128.f);
    printf("=== probe M12 ablation: settle policy x yield-lock ===\n");
    printf("  (pitch 2.2 m / radius 0.5 -> ORCA 接触距离 1.00 m)\n\n");
    run("old-latch + yield",   0, 0, dest);
    run("old-latch + locked",  0, 1, dest);
    run("settle    + yield",   1, 0, dest);
    run("settle    + locked",  1, 1, dest);
    printf("\nNOTE: gap = 到自己的 slot 的平均距离；nn = 最近邻 min/p10/中位\n");
    return 0;
}

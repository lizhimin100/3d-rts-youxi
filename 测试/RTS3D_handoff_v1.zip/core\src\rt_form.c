/* ============================================================================
 * rt_form.c -- 队形（FR-FOR，M8）
 * 设计口径见 rt_form.h 顶部。
 * ==========================================================================*/
#include "rt_form.h"
#include "rt_math.h"

#include <stdlib.h>
#include <string.h>
#include <math.h>

#define RT_FORM_PI 3.14159265358979f

void rt_form_config_default(RtFormConfig *c)
{
    if (!c) return;
    memset(c, 0, sizeof(*c));
    c->gap = 1.0f;
    c->fp = 1.0f;
    c->yaw_rate = RT_FORM_PI * 0.5f;            /* 90°/s */
    c->turn_in_place = RT_FORM_PI / 6.0f;       /* 30° */
}

int rt_form_init(RtFormation *f, int capacity)
{
    if (!f || capacity <= 0) return RT_ERR_INVALID;
    memset(f, 0, sizeof(*f));
    f->slots = (RtFormSlot *)calloc((size_t)capacity, sizeof(RtFormSlot));
    if (!f->slots) return RT_ERR_CAPACITY;
    f->capacity = capacity;
    return RT_OK;
}

void rt_form_destroy(RtFormation *f)
{
    if (!f) return;
    free(f->slots);
    f->slots = NULL;
    f->capacity = 0;
    f->slot_count = 0;
}

/* 矩形：cols = ceil(sqrt(n))，保证接近正方；最后一列可以不满 */
static int rect_cols(int n)
{
    int c = 1;
    while (c * c < n) c++;
    return c;
}

/* ----------------------------------------------------------------------------
 * 布局的本体（M16 从 rt_form_build 里抽出来的）
 *
 * `nx` = 沿**本地 x 轴**的槽数，`nz` = 沿**本地 z 轴**的槽数。
 *   RECT  ：nx = cols，nz = rows；锚点在方阵中心。
 *   COLUMN：沿 -x 单列排开（anchor 在最前）。这是 M8 的冻结口径
 *           （朝向 = 行进方向，所以队列在身后），M16 的 L3 直接复用。
 * 抽出来只有一个目的：**搜索用的候选布局**和**最终写回 f 的布局**必须是同一段代码。
 * 两份写法一旦分叉，测试会全绿而游戏里差半米。
 * --------------------------------------------------------------------------*/
typedef struct {
    int   kind;
    int   nx, nz;
    float px, pz;
} FormShape;

static void form_local_at(const FormShape *s, int i, float *lx, float *lz)
{
    if (s->kind == RT_FORM_COLUMN) {
        *lx = -(float)i * s->px;
        *lz = 0.f;
        return;
    }
    int ix = i % (s->nx > 0 ? s->nx : 1);
    int iz = i / (s->nx > 0 ? s->nx : 1);
    *lx = ((float)ix - (float)(s->nx - 1) * 0.5f) * s->px;
    *lz = ((float)iz - (float)(s->nz - 1) * 0.5f) * s->pz;
}

int rt_form_build(RtFormation *f, RtFormKind kind, int count,
                  float fp, float gap)
{
    if (!f || count <= 0 || count > f->capacity) return RT_ERR_INVALID;
    if (fp <= 0.f) fp = 1.f;
    if (gap < 0.f) gap = 0.f;

    FormShape s;
    s.kind = (int)kind;
    s.px = fp + gap;
    s.pz = fp + gap;
    if (kind == RT_FORM_COLUMN) {
        s.nx = count;
        s.nz = 1;
    } else {
        s.nx = rect_cols(count);
        s.nz = (count + s.nx - 1) / s.nx;
    }

    f->kind = kind;
    f->pitch_x = s.px;
    f->pitch_z = s.pz;
    f->slot_count = count;
    f->cols = (kind == RT_FORM_COLUMN) ? 1 : s.nx;
    f->rows = (kind == RT_FORM_COLUMN) ? count : s.nz;

    for (int i = 0; i < count; i++) {
        RtFormSlot *sl = &f->slots[i];
        float lx, lz;
        form_local_at(&s, i, &lx, &lz);
        sl->col = (kind == RT_FORM_COLUMN) ? 0 : (i % s.nx);
        sl->row = (kind == RT_FORM_COLUMN) ? i : (i / s.nx);
        sl->local = rt_v2(lx, lz);
        sl->valid = 1;
        sl->queued = 0;
    }
    f->rebuilds++;
    return RT_OK;
}

RtFormKind rt_form_degrade_for_width(RtFormation *f, float width_m)
{
    if (!f || f->slot_count <= 0) return RT_FORM_RECT;
    if (f->kind == RT_FORM_COLUMN) return RT_FORM_COLUMN;

    /* 矩形宽度 = cols * pitch；放不下 -> 纵队（单列只需 1 个 pitch） */
    float need = (float)f->cols * f->pitch_x;
    if (width_m > 0.f && need > width_m) {
        /* 只改布局，不改间距（间距是设计参数，压缩留给 L4） */
        int n = f->slot_count;
        float px = f->pitch_x, pz = f->pitch_z;
        f->kind = RT_FORM_COLUMN;
        f->cols = 1;
        f->rows = n;
        for (int i = 0; i < n; i++) {
            RtFormSlot *s = &f->slots[i];
            s->row = i;
            s->col = 0;
            s->local = rt_v2(-(float)i * px, 0.f);
            s->valid = 1;
            s->queued = 0;
        }
        f->pitch_z = pz;
        f->rebuilds++;
    }
    return f->kind;
}

void rt_form_set_anchor(RtFormation *f, RtVec2 anchor)
{
    if (!f) return;
    f->anchor = anchor;
}

void rt_form_set_yaw(RtFormation *f, float yaw, float dt, const RtFormConfig *cfg)
{
    if (!f) return;
    float rate = (cfg && cfg->yaw_rate > 0.f) ? cfg->yaw_rate : (RT_FORM_PI * 0.5f);
    float d = yaw - f->yaw;
    while (d > RT_FORM_PI) d -= 2.f * RT_FORM_PI;
    while (d < -RT_FORM_PI) d += 2.f * RT_FORM_PI;
    float maxd = rate * (dt > 0.f ? dt : 0.f);
    if (d > maxd) d = maxd;
    if (d < -maxd) d = -maxd;
    f->yaw += d;
    f->yaw_target = yaw;
}

int rt_form_needs_turn_in_place(const RtFormation *f, const RtFormConfig *cfg)
{
    if (!f || !cfg) return 0;
    float d = f->yaw_target - f->yaw;
    while (d > RT_FORM_PI) d -= 2.f * RT_FORM_PI;
    while (d < -RT_FORM_PI) d += 2.f * RT_FORM_PI;
    return (fabsf(d) > cfg->turn_in_place) ? 1 : 0;
}

RtVec2 rt_form_slot_world(const RtFormation *f, int slot)
{
    if (!f || slot < 0 || slot >= f->slot_count) return f ? f->anchor : rt_v2(0.f, 0.f);
    const RtFormSlot *s = &f->slots[slot];
    float c = cosf(f->yaw), sn = sinf(f->yaw);
    return rt_v2(f->anchor.x + s->local.x * c - s->local.z * sn,
                 f->anchor.z + s->local.x * sn + s->local.z * c);
}

/* ----------------------------------------------------------------------------
 * 分配：Hilbert 排序 + 贪心 + 2-opt
 * --------------------------------------------------------------------------*/

/* 2D -> Hilbert 序号（order 5 = 32×32），只用来做「空间局部性」排序 */
static void hilbert_rot(int n, int *x, int *y, int rx, int ry)
{
    if (ry == 0) {
        if (rx == 1) { *x = n - 1 - *x; *y = n - 1 - *y; }
        int t = *x; *x = *y; *y = t;
    }
}

static uint32_t hilbert_d2xy(int order, int x, int y)
{
    int n = 1 << order;
    uint32_t d = 0;
    for (int s = n >> 1; s > 0; s >>= 1) {
        int rx = (x & s) > 0 ? 1 : 0;
        int ry = (y & s) > 0 ? 1 : 0;
        d += (uint32_t)s * (uint32_t)s * (uint32_t)((3 * rx) ^ ry);
        hilbert_rot(s, &x, &y, rx, ry);
    }
    return d;
}

typedef struct { uint32_t key; int idx; } FormSort;

static int cmp_sort(const void *a, const void *b)
{
    const FormSort *x = (const FormSort *)a, *y = (const FormSort *)b;
    if (x->key < y->key) return -1;
    if (x->key > y->key) return 1;
    return (x->idx < y->idx) ? -1 : (x->idx > y->idx) ? 1 : 0;
}

int rt_form_assign(RtFormation *f, const RtVec2 *pos, int n, int *out_slot)
{
    if (!f || !pos || !out_slot || n <= 0) return 0;
    if (n > f->slot_count) n = f->slot_count;

    FormSort *us = (FormSort *)malloc((size_t)n * sizeof(FormSort));
    FormSort *ss = (FormSort *)malloc((size_t)n * sizeof(FormSort));
    RtVec2 *wpos = (RtVec2 *)malloc((size_t)n * sizeof(RtVec2));
    int *taken = (int *)calloc((size_t)f->slot_count, sizeof(int));
    if (!us || !ss || !wpos || !taken) {
        free(us); free(ss); free(wpos); free(taken);
        return 0;
    }

    /* 用世界坐标的包围盒归一化到 32×32 再做 Hilbert */
    float minx = 1e30f, minz = 1e30f, maxx = -1e30f, maxz = -1e30f;
    for (int i = 0; i < n; i++) {
        wpos[i] = rt_form_slot_world(f, i);
        if (pos[i].x < minx) minx = pos[i].x;
        if (pos[i].x > maxx) maxx = pos[i].x;
        if (pos[i].z < minz) minz = pos[i].z;
        if (pos[i].z > maxz) maxz = pos[i].z;
    }
    float sx = (maxx - minx) > 1e-3f ? (maxx - minx) : 1.f;
    float sz = (maxz - minz) > 1e-3f ? (maxz - minz) : 1.f;

    for (int i = 0; i < n; i++) {
        int gx = (int)((pos[i].x - minx) / sx * 31.f);
        int gz = (int)((pos[i].z - minz) / sz * 31.f);
        if (gx < 0) gx = 0; if (gx > 31) gx = 31;
        if (gz < 0) gz = 0; if (gz > 31) gz = 31;
        us[i].key = hilbert_d2xy(5, gx, gz);
        us[i].idx = i;

        int qx = (int)((wpos[i].x - minx) / sx * 31.f);
        int qz = (int)((wpos[i].z - minz) / sz * 31.f);
        if (qx < 0) qx = 0; if (qx > 31) qx = 31;
        if (qz < 0) qz = 0; if (qz > 31) qz = 31;
        ss[i].key = hilbert_d2xy(5, qx, qz);
        ss[i].idx = i;
    }
    qsort(us, (size_t)n, sizeof(FormSort), cmp_sort);
    qsort(ss, (size_t)n, sizeof(FormSort), cmp_sort);

    /* 贪心：按 Hilbert 序，每个单位取最近的未分配 slot */
    for (int k = 0; k < n; k++) {
        int ui = us[k].idx;
        int best = -1;
        float bestd = 1e30f;
        for (int t = 0; t < n; t++) {
            int si = ss[t].idx;
            if (taken[si]) continue;
            float d = rt_v2_dist2(pos[ui], wpos[si]);
            if (d < bestd) { bestd = d; best = si; }
        }
        if (best < 0) break;
        taken[best] = 1;
        out_slot[ui] = best;
    }
    free(taken);

    /* 2-opt：只交换「方向显著相反」的对，且交换后总距离减少 > 1 m（01 §11.2） */
    for (int round = 0; round < 2; round++) {
        int swapped = 0;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                RtVec2 di = rt_v2_sub(wpos[out_slot[i]], pos[i]);
                RtVec2 dj = rt_v2_sub(wpos[out_slot[j]], pos[j]);
                float li = rt_v2_len(di), lj = rt_v2_len(dj);
                if (li < 0.1f || lj < 0.1f) continue;
                if ((di.x * dj.x + di.z * dj.z) / (li * lj) > -0.5f) continue;
                float before = li + lj;
                float after = rt_v2_dist(pos[i], wpos[out_slot[j]]) +
                              rt_v2_dist(pos[j], wpos[out_slot[i]]);
                if (before - after > 1.0f) {
                    int t = out_slot[i]; out_slot[i] = out_slot[j]; out_slot[j] = t;
                    swapped = 1;
                }
            }
        }
        if (!swapped) break;
    }

    free(us);
    free(ss);
    free(wpos);
    return n;
}

float rt_form_cohesion(const RtFormation *f, const RtVec2 *pos,
                       const int *slot_of, int n, float radius)
{
    if (!f || !pos || !slot_of || n <= 0 || radius <= 0.f) return 0.f;
    float sum = 0.f;
    for (int i = 0; i < n; i++) {
        sum += rt_v2_dist(pos[i], rt_form_slot_world(f, slot_of[i]));
    }
    float c = 1.f - (sum / (float)n) / radius;
    if (c < 0.f) c = 0.f;
    if (c > 1.f) c = 1.f;
    return c;
}

/* ----------------------------------------------------------------------------
 * 落脚策略（M12）：见 rt_form.h 的说明
 * --------------------------------------------------------------------------*/
void rt_form_settle_default(RtFormSettle *s)
{
    if (!s) return;
    memset(s, 0, sizeof(*s));
    /* 0.35 不是拍的：pitch 2.2 - 2*eps 才是两人同向贴近时的最坏间距。
     * eps=0.35 -> 1.50；实测收敛到 eps 内的人平均误差 ~0.1 m，所以实际
     * 最近邻中位数仍在 2.1 m 以上（见 30_M12 报告的表）。 */
    s->arrive_eps     = 0.35f;
    s->reengage_eps   = 0.90f;   /* 死区 0.55 m，比一帧位移(0.067 m)大两个量级 */
    s->slow_radius    = 2.00f;
    s->min_speed_frac = 0.25f;
    s->creep_frac     = 0.12f;
}

void rt_form_member_reset(RtFormMember *m)
{
    if (m) memset(m, 0, sizeof(*m));
}

RtVec2 rt_form_steer_point(RtVec2 aim, RtVec2 pos, RtFormMember *m,
                           const RtFormSettle *cfg, float max_speed, float dt)
{
    if (!m) return rt_v2(0.f, 0.f);

    RtFormSettle def;
    if (!cfg) { rt_form_settle_default(&def); cfg = &def; }

    RtVec2 d = rt_v2_sub(aim, pos);
    float g = rt_v2_len(d);

    if (m->arrived) {
        if (g > cfg->reengage_eps) {
            /* 被挤开了：重新接管。这不是抖动 —— 死区 0.9 m 远大于容差 0.35 m。 */
            m->arrived = 0;
            m->settle_t = 0.f;
            m->reengages++;
        } else if (g > cfg->arrive_eps) {
            /* 已就位但被推开一点点（死区内）：**用爬行速度**回位。
             * 不退化成「一直歇到 0.9 m 才管」——那样每个被推的人都会永久停在
             * 死区里（实测 p99 到 4.46 m，相邻两人各偏 0.8 m 就只剩 1.2 m 间距）。
             * 爬行速度足够慢（0.24 m/s），不会对邻居形成压力，也不会跨过 eps 抖动。 */
            m->settle_t = 0.f;
            float sp = max_speed * (cfg->creep_frac > 0.f ? cfg->creep_frac : 0.f);
            if (g < 1e-4f) return rt_v2(0.f, 0.f);
            return rt_v2_mul(d, sp / g);
        } else {
            return rt_v2(0.f, 0.f);
        }
    }

    if (g <= cfg->arrive_eps) {
        m->arrived = 1;
        m->settle_t += (dt > 0.f ? dt : 0.f);
        return rt_v2(0.f, 0.f);
    }

    m->settle_t = 0.f;
    if (g < 1e-4f) return rt_v2(0.f, 0.f);

    float frac = g / (cfg->slow_radius > 1e-3f ? cfg->slow_radius : 1.f);
    if (frac > 1.f) frac = 1.f;
    if (frac < cfg->min_speed_frac) frac = cfg->min_speed_frac;
    float sp = max_speed * frac;
    return rt_v2_mul(d, sp / g);
}

RtVec2 rt_form_member_steer(const RtFormation *f, int slot, RtVec2 pos,
                            RtFormMember *m, const RtFormSettle *cfg,
                            float max_speed, float dt)
{
    if (!f) return rt_v2(0.f, 0.f);
    return rt_form_steer_point(rt_form_slot_world(f, slot), pos, m, cfg,
                               max_speed, dt);
}

int rt_form_member_arrived(const RtFormMember *m)
{
    return (m && m->arrived) ? 1 : 0;
}

/* ============================================================================
 * M16 · 落脚点五级搜索（FR-FOR-5）
 * 设计口径见 rt_form.h 顶部注释块；这里只写实现上的三个要点：
 *
 *   1. **半径递增序**：r 从 0 开始，同一半径内先形状、后朝向、最后方向。
 *      第一个零冲突的候选就是「位移最小」的那个，所以 L1~L4 不需要算 cost 比较。
 *   2. **坏候选短路**：只要一个槽被挡就退出该候选。绝大多数候选只问 1~2 个槽，
 *      这是 L1 能压在 1 ms 级的原因（不是靠更少的候选）。
 *   3. **L5 才需要完整 cost**：都放不下时用 `100*冲突 + 1000*越界 + 位移`
 *      在 L1 的候选集里挑最不坏的一个，再做 3x3 兜底 + 环绕队列。
 * ==========================================================================*/

#define RT_FORM_DIRS 8
#define RT_FORM_PI_F 3.14159265358979f

/* 8 方向，固定顺序（E, NE, N, NW, W, SW, S, SE） */
static const float RT_FORM_DIR_DX[RT_FORM_DIRS] = { 1.f, 1.f, 0.f, -1.f, -1.f, -1.f, 0.f, 1.f };
static const float RT_FORM_DIR_DZ[RT_FORM_DIRS] = { 0.f, 1.f, 1.f, 1.f, 0.f, -1.f, -1.f, -1.f };
/* 8 个 yaw 偏置，按 |dθ| 升序：0, +45, -45, +90, -90, +135, -135, 180 */
static const float RT_FORM_YAW_OFF[RT_FORM_DIRS] = {
    0.f, 0.785398163f, -0.785398163f, 1.570796327f,
    -1.570796327f, 2.356194490f, -2.356194490f, 3.141592654f
};
/* L5 单槽兜底：3×3 格，先四邻后对角 */
static const float RT_FORM_NUDGE_X[9] = { 0.f, 1.f, -1.f, 0.f, 0.f, 1.f, 1.f, -1.f, -1.f };
static const float RT_FORM_NUDGE_Z[9] = { 0.f, 0.f, 0.f, 1.f, -1.f, 1.f, -1.f, 1.f, -1.f };

void rt_form_place_default(RtFormPlaceCfg *c)
{
    if (!c) return;
    memset(c, 0, sizeof(*c));
    c->step = 1.0f;         /* 1 格 */
    c->rings = 40;          /* 半径 40 m */
    c->compress = 0.2f;     /* pitch -> fp + 0.2 */
    c->nudge = 1.0f;        /* 3x3 格 */
    c->orbit_rings = 12;    /* L5 环绕队列最多 12 圈 */
    c->max_yaw_dev = 1.5707963f;  /* 不超过 90°：再大就是「倒着走」，见头文件 */
    c->max_evals = 24000;   /* 上面四个默认值下的完整搜索约 2.05 万候选 */
}

/* ---- 候选评估 ---------------------------------------------------------- */

typedef struct {
    const RtFormProbe *probe;
    int    n;
    float  fp;
    const int *order;   /* 槽的评估顺序（从中心往外），NULL = 按索引 */
} FormEval;

typedef struct {
    FormEval e;
    const RtFormPlaceCfg *cfg;
    int evals;
    int truncated;
} FormSearch;

/* 返回坏槽数；stop_first=1 时遇到第一个坏槽就返回（>0）。
 * states != NULL 时写入每槽状态（0/1/2），此时 stop_first 必须为 0。 */
static int form_eval(const FormEval *e, const FormShape *s, RtVec2 a, float yaw,
                     int stop_first, int *states, int *oob_out)
{
    float c = cosf(yaw), sn = sinf(yaw);
    int bad = 0, oob = 0;
    for (int k = 0; k < e->n; k++) {
        int i = e->order ? e->order[k] : k;
        float lx, lz;
        form_local_at(s, i, &lx, &lz);
        RtObb2 o = rt_obb_make(rt_v2(a.x + lx * c - lz * sn,
                                     a.z + lx * sn + lz * c), e->fp, yaw);
        int st = e->probe->obb_state(e->probe->ud, &o);
        if (states) states[i] = st;
        if (st) {
            bad++;
            if (st == 2) oob++;
            if (stop_first) return bad;
        }
    }
    if (oob_out) *oob_out = oob;
    return bad;
}

/* 一个候选：返回 1 = 零冲突（可用）。撞预算时置 truncated 并返回 0。 */
static int form_try(FormSearch *S, const FormShape *s, RtVec2 a, float yaw)
{
    if (S->cfg->max_evals > 0 && S->evals >= S->cfg->max_evals) {
        S->truncated = 1;
        return 0;
    }
    S->evals++;
    return form_eval(&S->e, s, a, yaw, 1, NULL, NULL) == 0;
}

/* ---- 槽序（中心往外）--------------------------------------------------- */

typedef struct { float key; int idx; } FormOrd;

static int cmp_form_ord(const void *a, const void *b)
{
    const FormOrd *x = (const FormOrd *)a, *y = (const FormOrd *)b;
    if (x->key < y->key) return -1;
    if (x->key > y->key) return 1;
    return (x->idx < y->idx) ? -1 : (x->idx > y->idx) ? 1 : 0;
}

static void form_order_make(const FormShape *s, int n, int *order, FormOrd *tmp)
{
    for (int i = 0; i < n; i++) {
        float lx, lz;
        form_local_at(s, i, &lx, &lz);
        tmp[i].key = lx * lx + lz * lz;
        tmp[i].idx = i;
    }
    qsort(tmp, (size_t)n, sizeof(FormOrd), cmp_form_ord);
    for (int i = 0; i < n; i++) order[i] = tmp[i].idx;
}

/* ---- 半径递增搜索 ------------------------------------------------------ */

/* kmin/kmax 是 yaw 偏置的取用范围：
 *   L1: 0..0（只用原朝向）    L2: 1..7（原朝向已证明不行）    L3/L4: 0..7 */
static int form_search_radius(FormSearch *S,
                              const FormShape *shapes, int nshapes,
                              int *const *orders,
                              RtVec2 anchor, float yaw0,
                              int rings, float step, int kmin, int kmax,
                              FormShape *out_shape, float *out_yaw,
                              RtVec2 *out_anchor)
{
    for (int r = 0; r <= rings; r++) {
        int nd = (r == 0) ? 1 : RT_FORM_DIRS;
        for (int si = 0; si < nshapes; si++) {
            S->e.order = orders[si];
            for (int k = kmin; k <= kmax; k++) {
                float yaw = yaw0 + RT_FORM_YAW_OFF[k];
                for (int d = 0; d < nd; d++) {
                    RtVec2 a = rt_v2(anchor.x + RT_FORM_DIR_DX[d] * (float)r * step,
                                     anchor.z + RT_FORM_DIR_DZ[d] * (float)r * step);
                    if (form_try(S, &shapes[si], a, yaw)) {
                        *out_shape = shapes[si];
                        *out_yaw = yaw;
                        *out_anchor = a;
                        return 1;
                    }
                    if (S->truncated) return 0;
                }
            }
        }
    }
    return 0;
}

static void form_rect_shape(int n, int nx, float px, float pz, FormShape *s)
{
    if (nx < 1) nx = 1;
    if (nx > n) nx = n;
    s->kind = RT_FORM_RECT;
    s->nx = nx;
    s->nz = (n + nx - 1) / nx;
    s->px = px;
    s->pz = pz;
}

static float form_norm_yaw(float y)
{
    while (y > RT_FORM_PI_F) y -= 2.f * RT_FORM_PI_F;
    while (y < -RT_FORM_PI_F) y += 2.f * RT_FORM_PI_F;
    return y;
}

/* 位置是否可用：地形空 + 与已落位的槽保持 min_sep */
static int form_spot_free(const RtFormProbe *p, RtVec2 c, float fp, float yaw,
                          const RtVec2 *w, const int *state, int n, int self,
                          float min_sep)
{
    RtObb2 o = rt_obb_make(c, fp, yaw);
    if (p->obb_state(p->ud, &o) != 0) return 0;
    float min_sep2 = min_sep * min_sep;
    for (int j = 0; j < n; j++) {
        /* 已占位 = 落在 lattice/nudge 上（0）或已经在队列里（3）；
         * 1/2 是「还没处理」的坏槽，位置待定，不参与排斥。 */
        if (j == self || (state[j] != 0 && state[j] != 3)) continue;
        if (rt_v2_dist2(c, w[j]) < min_sep2) return 0;
    }
    return 1;
}

int rt_form_place(RtFormation *f, int count, float fp, float gap,
                  RtVec2 anchor, float yaw,
                  const RtFormProbe *probe, const RtFormPlaceCfg *cfg,
                  RtFormPlaceStat *out)
{
    if (!f || !probe || !probe->obb_state) return RT_ERR_INVALID;
    if (count <= 0) return RT_ERR_INVALID;
    if (count > f->capacity) return RT_ERR_CAPACITY;
    if (fp <= 0.f) fp = 1.f;
    if (gap < 0.f) gap = 0.f;

    RtFormPlaceCfg def;
    if (!cfg) { rt_form_place_default(&def); cfg = &def; }
    float step     = cfg->step > 0.f ? cfg->step : 1.f;
    int   rings    = cfg->rings > 0 ? cfg->rings : 40;
    float compress = cfg->compress >= 0.f ? cfg->compress : 0.2f;
    float nudge    = cfg->nudge > 0.f ? cfg->nudge : 1.f;
    /* 0/未设置 -> 默认 12 圈；负数 -> 关闭（只给 A/B 用） */
    int   orings   = (cfg->orbit_rings < 0) ? 0 : (cfg->orbit_rings > 0 ? cfg->orbit_rings : 12);
    float max_dev  = cfg->max_yaw_dev > 0.f ? cfg->max_yaw_dev : 0.f;
    if (max_dev > RT_FORM_PI_F) max_dev = RT_FORM_PI_F;

    /* 允许的 yaw 偏置上界：偏置表按 |dθ| 升序，取最后一个 <= max_dev 的下标 */
    int kmax = 0;
    for (int k = 1; k < RT_FORM_DIRS; k++)
        if (fabsf(RT_FORM_YAW_OFF[k]) <= max_dev + 1e-4f) kmax = k;
    if (fabsf(RT_FORM_YAW_OFF[0]) > max_dev) kmax = -1;   /* 连原朝向都不许（不会发生） */

    FormOrd *ordtmp = (FormOrd *)malloc((size_t)count * sizeof(FormOrd));
    int     *state  = (int *)malloc((size_t)count * sizeof(int));
    uint8_t *moved  = (uint8_t *)calloc((size_t)count, 1);
    RtVec2  *w      = (RtVec2 *)malloc((size_t)count * sizeof(RtVec2));
    if (!ordtmp || !state || !moved || !w) {
        free(ordtmp); free(state); free(moved); free(w);
        return RT_ERR_CAPACITY;
    }

    float pitch = fp + gap;
    FormShape base;
    form_rect_shape(count, rect_cols(count), pitch, pitch, &base);

    /* L3/L4 的形状集：宽扁 / 高瘦 / 纵队（与 base 相同的跳过） */
    FormShape variants[3];
    int nvar = 0;
    if (count > 1) {
        int wide_nx = (int)ceilf(sqrtf((float)count * 2.f));
        int tall_nx = (int)ceilf(sqrtf((float)count * 0.5f));
        FormShape t;
        form_rect_shape(count, wide_nx, pitch, pitch, &t);
        if (t.nx != base.nx) variants[nvar++] = t;
        form_rect_shape(count, tall_nx, pitch, pitch, &t);
        if (t.nx != base.nx) variants[nvar++] = t;
        FormShape col;
        col.kind = RT_FORM_COLUMN; col.nx = count; col.nz = 1; col.px = pitch; col.pz = pitch;
        variants[nvar++] = col;
    }

    FormEval e;
    e.probe = probe; e.n = count; e.fp = fp; e.order = NULL;
    FormSearch S;
    S.e = e; S.cfg = cfg; S.evals = 0; S.truncated = 0;

    /* 每个形状一份评估序（只在形状变化时重算） */
    int *orders[4] = { NULL, NULL, NULL, NULL };
    FormShape all4[4];
    int nall = 0;
    all4[nall++] = base;
    for (int i = 0; i < nvar; i++) all4[nall++] = variants[i];
    for (int i = 0; i < nall; i++) {
        orders[i] = (int *)malloc((size_t)count * sizeof(int));
        if (!orders[i]) {
            /* 退化：这些形状改成按索引评估（正确，只是短路变慢）。
             * 必须置 NULL —— 否则函数末尾的 free 会二次释放。 */
            for (int k = 0; k < i; k++) { free(orders[k]); orders[k] = NULL; }
            for (int k = i; k < nall; k++) orders[k] = NULL;
            break;
        }
        form_order_make(&all4[i], count, orders[i], ordtmp);
    }

    RtFormPlaceStat st;
    memset(&st, 0, sizeof(st));
    st.anchor = anchor;
    st.yaw = form_norm_yaw(yaw);
    st.cols = (base.kind == RT_FORM_COLUMN) ? 1 : base.nx;
    st.rows = (base.kind == RT_FORM_COLUMN) ? count : base.nz;
    st.pitch_x = base.px;
    st.pitch_z = base.pz;

    FormShape chosen = base;
    RtVec2    chosen_a = anchor;
    float     chosen_yaw = yaw;
    int       level = 5;

    /* ---- L0：原样落 ---- */
    S.e.order = orders[0];
    if (form_try(&S, &base, anchor, yaw)) {
        level = 0;
    }

    int *one0[1] = { NULL };

    /* ---- L1：平移（只用原朝向） ---- */
    if (level == 5) {
        FormShape sh; float y; RtVec2 a;
        one0[0] = orders[0];
        if (form_search_radius(&S, &base, 1, one0, anchor, yaw,
                               rings, step, 0, 0, &sh, &y, &a)) {
            level = 1; chosen = sh; chosen_a = a; chosen_yaw = y;
        }
    }

    /* ---- L2：加朝向（原朝向已证明放不下） ---- */
    if (level == 5) {
        FormShape sh; float y; RtVec2 a;
        one0[0] = orders[0];
        if (form_search_radius(&S, &base, 1, one0, anchor, yaw,
                               rings, step, 1, kmax, &sh, &y, &a)) {
            level = 2; chosen = sh; chosen_a = a; chosen_yaw = y;
        }
    }

    /* ---- L3：加形状 ---- */
    if (level == 5 && nvar > 0) {
        FormShape sh; float y; RtVec2 a;
        if (form_search_radius(&S, variants, nvar, orders + 1, anchor, yaw,
                               rings, step, 0, kmax, &sh, &y, &a)) {
            level = 3; chosen = sh; chosen_a = a; chosen_yaw = y;
        }
    }

    /* ---- L4：压缩间距（pitch -> fp + compress） ---- */
    if (level == 5) {
        float cp = fp + (compress > 0.f ? compress : 0.f);
        if (cp < pitch && cp > fp) {
            FormShape comp[4];
            int ncomp = 0;
            form_rect_shape(count, base.nx, cp, cp, &comp[ncomp++]);
            for (int i = 0; i < nvar; i++) {
                FormShape t = variants[i];
                t.px = cp; t.pz = cp;
                comp[ncomp++] = t;
            }
            int *comp_orders[4] = { NULL, NULL, NULL, NULL };
            for (int i = 0; i < ncomp; i++) {
                comp_orders[i] = (int *)malloc((size_t)count * sizeof(int));
                if (comp_orders[i]) form_order_make(&comp[i], count, comp_orders[i], ordtmp);
            }
            FormShape sh; float y; RtVec2 a;
            if (form_search_radius(&S, comp, ncomp, comp_orders, anchor, yaw,
                                   rings, step, 0, kmax, &sh, &y, &a)) {
                level = 4; chosen = sh; chosen_a = a; chosen_yaw = y;
            }
            for (int i = 0; i < ncomp; i++) free(comp_orders[i]);
        }
    }

    if (level <= 4) {
        /* 零冲突：所有槽都在 lattice 上（chosen 已在上面按级填好） */
        for (int i = 0; i < count; i++) state[i] = 0;
        st.cost = rt_v2_dist(chosen_a, anchor);
    } else {
        /* ---- L5：挑最不坏的落点，逐槽兜底，剩下的进环绕队列 ---- */
        FormEval eb;
        eb.probe = probe; eb.n = count; eb.fp = fp; eb.order = orders[0];
        float best = 1e30f;
        int best_bad = 0, best_oob = 0;
        for (int r = 0; r <= rings; r++) {
            int nd = (r == 0) ? 1 : RT_FORM_DIRS;
            for (int d = 0; d < nd; d++) {
                RtVec2 a = rt_v2(anchor.x + RT_FORM_DIR_DX[d] * (float)r * step,
                                 anchor.z + RT_FORM_DIR_DZ[d] * (float)r * step);
                int oob = 0;
                int bad = form_eval(&eb, &base, a, yaw, 0, NULL, &oob);
                S.evals++;
                float cost = 100.f * (float)bad + 1000.f * (float)oob +
                             (float)r * step;
                if (cost < best - 1e-3f) {
                    best = cost; best_bad = bad; best_oob = oob;
                    chosen_a = a;
                }
            }
        }
        chosen = base;
        chosen_yaw = yaw;
        st.cost = best;
        st.conflicts = best_bad;
        st.oob = best_oob;

        /* 布局的世界坐标 + 每槽状态 */
        float cch = cosf(chosen_yaw), ssh = sinf(chosen_yaw);
        for (int i = 0; i < count; i++) {
            float lx, lz;
            form_local_at(&chosen, i, &lx, &lz);
            w[i] = rt_v2(chosen_a.x + lx * cch - lz * ssh,
                         chosen_a.z + lx * ssh + lz * cch);
            RtObb2 o = rt_obb_make(w[i], fp, chosen_yaw);
            state[i] = probe->obb_state(probe->ud, &o);
        }

        /* 3x3 兜底（FR-FOR-10）：只对坏槽，且不与已落位的槽压在一起。
         * 间距门槛用 fp + 0.2（和 L4 的压缩间距同一个下界）：允许「贴住」会
         * 把 ORCA 直接推到互相顶的状态，而兜底本来就是为了**少一个堵点**。 */
        float min_sep = fp + 0.2f;
        for (int i = 0; i < count; i++) {
            if (state[i] == 0) continue;
            for (int k = 1; k < 9; k++) {
                RtVec2 c = rt_v2(w[i].x + RT_FORM_NUDGE_X[k] * nudge,
                                 w[i].z + RT_FORM_NUDGE_Z[k] * nudge);
                if (form_spot_free(probe, c, fp, chosen_yaw, w, state, count, i, min_sep)) {
                    w[i] = c; state[i] = 0; moved[i] = 1; st.nudged_slots++;
                    break;
                }
            }
        }

        /* 环绕队列：从队形外接圆开始，一圈一圈往外、16 个方向找空位。
         *
         * 为什么不是「每个坏槽推自己的 lattice 点」：那个点在墙里，沿
         * (p0 - anchor) 的方向往外走通常还在墙里（它本来就是从队形外缘出去的）。
         * 真实需求是「在**还有空间的那一侧**排队」—— 长走廊里就是队形前后两端。
         * 所以从 anchor 出发按半径扫，谁先找到谁先站，后面的靠 min_sep 自然外推。 */
        float ex = (chosen.kind == RT_FORM_COLUMN)
                     ? (float)(count - 1) * chosen.px
                     : (float)(chosen.nx - 1) * chosen.px;
        float ez = (chosen.kind == RT_FORM_COLUMN) ? 0.f : (float)(chosen.nz - 1) * chosen.pz;
        float base_r = 0.5f * sqrtf(ex * ex + ez * ez) + fp * 1.5f;
        int q = 0;
        for (int i = 0; i < count; i++) {
            if (state[i] == 0) continue;
            st.invalid_slots++;
            int placed = 0;
            for (int ring = 0; ring < orings && !placed; ring++) {
                float rad = base_r + (float)ring * (fp + 0.5f);
                for (int a = 0; a < 16 && !placed; a++) {
                    float ang = chosen_yaw + (float)((a + q * 3) % 16) * (2.f * RT_FORM_PI_F / 16.f);
                    RtVec2 c = rt_v2(chosen_a.x + cosf(ang) * rad,
                                     chosen_a.z + sinf(ang) * rad);
                    if (form_spot_free(probe, c, fp, chosen_yaw, w, state, count, i, min_sep)) {
                        w[i] = c; state[i] = 3; placed = 1;
                        st.queued_slots++;
                    }
                }
            }
            if (!placed) {
                /* 连队列都放不下：不要把人往墙里指，留在 anchor 上等调用方 hold */
                w[i] = chosen_a;
            }
            q++;
        }
    }

    /* ---- 写回 f ---- */
    f->kind = (RtFormKind)chosen.kind;
    f->cols = (chosen.kind == RT_FORM_COLUMN) ? 1 : chosen.nx;
    f->rows = (chosen.kind == RT_FORM_COLUMN) ? count : chosen.nz;
    f->pitch_x = chosen.px;
    f->pitch_z = chosen.pz;
    f->anchor = chosen_a;
    f->yaw = form_norm_yaw(chosen_yaw);
    f->yaw_target = f->yaw;
    f->slot_count = count;
    f->rebuilds++;

    float cc = cosf(f->yaw), ss = sinf(f->yaw);
    for (int i = 0; i < count; i++) {
        RtFormSlot *sl = &f->slots[i];
        float lx, lz;
        if (moved[i] || state[i] != 0) {
            /* 兜底 / 队列 / 彻底放不下：位置来自世界坐标，反变换回本地系 */
            float dx = w[i].x - chosen_a.x, dz = w[i].z - chosen_a.z;
            lx =  dx * cc + dz * ss;      /* R(-yaw) */
            lz = -dx * ss + dz * cc;
        } else {
            form_local_at(&chosen, i, &lx, &lz);
        }
        sl->local = rt_v2(lx, lz);
        if (chosen.kind == RT_FORM_COLUMN) {
            sl->row = i; sl->col = 0;
        } else {
            sl->row = i / chosen.nx; sl->col = i % chosen.nx;
        }
        sl->valid = (state[i] == 0) ? 1 : 0;
        sl->queued = (state[i] == 3) ? 1 : 0;
    }

    st.level = level;
    st.evals = S.evals;
    st.truncated = S.truncated;
    st.anchor = chosen_a;
    st.yaw = f->yaw;
    st.cols = f->cols;
    st.rows = f->rows;
    st.pitch_x = f->pitch_x;
    st.pitch_z = f->pitch_z;
    if (out) *out = st;

    for (int i = 0; i < nall; i++) free(orders[i]);
    free(ordtmp); free(state); free(moved); free(w);
    return RT_OK;
}

/* ============================================================================
 * test_m43.c -- M4.3：goal-centric coarse flow + 自适应选择
 *
 * T1  1 source     -> 自适应必须仍走 per-source A*
 * T2  4 source     -> 同上
 * T3  8 source     -> 灰区：记录策略，正确性必须成立
 * T4  16 source    -> 1 次 goal-side 搜索，不是 16 次 A*
 * T5  32 source    -> 1 次搜索 + 32 次提取；route cost 与 A* 基线一致
 * T6  50 source    -> 复现 probe 的规模；记录 expanded / 时间比
 * T7  clearance    -> 2 m / 4 m 不共享 flow
 * T8  component    -> 同 region 不同分量不共享 flow
 * T9  topology     -> 无关编辑 flow 仍有效；相关编辑必须失效重建
 * T10 warm cache   -> 第二次命令 0 flow build / 0 A*
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m43.c -o test_m43
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", m); } } while (0)

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static uint32_t g_ver = 0;

static void setup_open(int w)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_grid_init(&G, w, w, 1.0f);
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
    g_ver = 0;
}

/* 在 20 m 网格上取 N 个互不相同的源区域（单位落在格中心） */
static int spawn_spread(RtUnitId *ids, int n, float x0, float z0, float step)
{
    int k = 0, per_row = (int)((240.f - x0) / step);
    if (per_row < 1) per_row = 1;
    for (int i = 0; i < n; i++) {
        float x = x0 + (float)(i % per_row) * step;
        float z = z0 + (float)(i / per_row) * step;
        if (x > 240.f || z > 240.f) break;
        RtUnitId id = rt_units_spawn(&US, rt_v3(x, 0.f, z), RT_FP_SMALL);
        if (id != RT_UNIT_ID_NONE) ids[k++] = id;
    }
    return k;
}

typedef struct {
    uint32_t builds, flow_builds, flow_hits, flow_invalid, extracts, fallback;
    uint32_t expanded, flow_sources, adaptive_flow, adaptive_astar;
    int groups, routes, flows;
    double ms;
} Rec;

static Rec run_cmd(const RtUnitId *ids, int n, RtVec2 dest, int cls)
{
    double t0 = now_ms();
    rt_gw_command(&W, &US, ids, n, dest, 0, (uint8_t)cls, ++g_ver);
    double t1 = now_ms();
    Rec r; memset(&r, 0, sizeof(r));
    r.builds = W.stats.route_builds;
    r.flow_builds = W.stats.goal_flow_builds;
    r.flow_hits = W.stats.goal_flow_hits;
    r.flow_invalid = W.stats.goal_flow_invalid;
    r.extracts = W.stats.flow_route_extracts;
    r.fallback = W.stats.fallback_to_astar;
    r.expanded = W.stats.goal_flow_expanded;
    r.flow_sources = W.stats.goal_flow_sources;
    r.adaptive_flow = W.stats.adaptive_flow;
    r.adaptive_astar = W.stats.adaptive_astar;
    r.groups = W.group_count;
    for (int i = 0; i < W.group_count; i++) r.routes += W.groups[i].route_count;
    r.flows = rt_gw_flow_count(&W);
    r.ms = t1 - t0;
    return r;
}

static void print_rec(const char *tag, Rec r)
{
    printf("  %-10s groups=%d routes=%d flows=%d | astar=%u flow_build=%u hit=%u inval=%u "
           "extract=%u fallback=%u exp=%u ada(f/a)=%u/%u %.3f ms\n",
           tag, r.groups, r.routes, r.flows, r.builds, r.flow_builds, r.flow_hits,
           r.flow_invalid, r.extracts, r.fallback, r.expanded,
           r.adaptive_flow, r.adaptive_astar, r.ms);
}

/* start_region -> cost（用于与 A* 基线对照） */
static float g_cost[RT_MAX_REGIONS];
static int g_has[RT_MAX_REGIONS];

static void collect_costs(void)
{
    for (int i = 0; i < RT_MAX_REGIONS; i++) { g_cost[i] = 0.f; g_has[i] = 0; }
    for (int i = 0; i < W.group_count; i++)
        for (int k = 0; k < W.groups[i].route_count; k++) {
            int sr = W.groups[i].routes[k].start_region;
            if (sr < 0 || sr >= RT_MAX_REGIONS) continue;
            g_cost[sr] = W.groups[i].routes[k].route.cost;
            g_has[sr] = 1;
        }
}

/* =============================================================== T1/T2/T3 */
static void t_small(int n, const char *tag)
{
    setup_open(256);
    static RtUnitId ids[256];
    int k = spawn_spread(ids, n, 20.5f, 20.5f, 20.f);
    Rec r = run_cmd(ids, k, rt_v2(220.5f, 220.5f), RT_CLS_SMALL);
    printf("\n[%s] %d sources (default threshold)\n", tag, n);
    print_rec("default", r);
    OK(k == n, "spawned requested sources");
    OK(r.adaptive_astar >= 1, "small N stays on per-source A*");
    OK(r.flow_builds == 0, "no goal flow built for small N");
    OK(r.builds == (uint32_t)r.routes, "one A* per source route");
}

/* ================================================================ T4/T5/T6 */
static void t_flow(int n, const char *tag, int strict_cost)
{
    /* 基线：强制 per-source A* */
    setup_open(256);
    static RtUnitId ids[256];
    int k = spawn_spread(ids, n, 20.5f, 20.5f, 20.f);
    rt_gw_set_flow_threshold(&W, 1000000);
    Rec base = run_cmd(ids, k, rt_v2(220.5f, 220.5f), RT_CLS_SMALL);
    collect_costs();
    float base_cost[RT_MAX_REGIONS];
    int base_has[RT_MAX_REGIONS];
    memcpy(base_cost, g_cost, sizeof(g_cost));
    memcpy(base_has, g_has, sizeof(g_has));

    /* 强制 goal flow */
    setup_open(256);
    k = spawn_spread(ids, n, 20.5f, 20.5f, 20.f);
    rt_gw_set_flow_threshold(&W, -1);
    Rec r = run_cmd(ids, k, rt_v2(220.5f, 220.5f), RT_CLS_SMALL);
    collect_costs();

    printf("\n[%s] %d sources\n", tag, n);
    print_rec("astar", base);
    print_rec("flow", r);

    OK(r.flow_builds == 1, "exactly one goal-side search");
    OK(r.extracts == (uint32_t)r.routes, "every route extracted from the flow");
    OK(r.fallback == 0, "no A* fallback");
    OK(r.flows == 1, "one cached flow");
    OK(r.ms <= base.ms * 1.05, "flow path not slower than N x A*");

    if (strict_cost) {
        int same = 1, cmp = 0;
        for (int i = 0; i < RT_MAX_REGIONS; i++) {
            if (!base_has[i] || !g_has[i]) continue;
            cmp++;
            if (fabsf(base_cost[i] - g_cost[i]) > 1e-2f) same = 0;
        }
        printf("  cost compared on %d sources, identical=%d\n", cmp, same);
        OK(cmp == r.routes, "cost comparison covered every route");
        OK(same == 1, "flow route cost equals A* baseline");
    }
}

/* =================================================================== T7 */
static void t_clearance_isolation(void)
{
    printf("\n[T7] clearance isolation\n");
    setup_open(256);
    /* 水平墙 + 2 m 门 (x=120..121) + 6 m 绕行 (x=200..205) */
    for (int x = 0; x < 256; x++) rt_grid_set_terrain(&G, x, 128, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int x = 120; x <= 121; x++) rt_grid_set_terrain(&G, x, 128, RT_CELL_BLOCKED_TERRAIN, 0);
    for (int x = 200; x <= 205; x++) {
        rt_grid_set_terrain(&G, x, 128, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, x, 127, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, x, 129, RT_CELL_BLOCKED_TERRAIN, 0);
    }
    rt_grid_rebuild_all(&G);
    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
    rt_gw_set_flow_threshold(&W, -1);

    static RtUnitId ids[4];
    ids[0] = rt_units_spawn(&US, rt_v3(40.5f, 0.f, 60.5f), RT_FP_SMALL);
    ids[1] = rt_units_spawn(&US, rt_v3(60.5f, 0.f, 60.5f), RT_FP_SMALL);
    Rec s = run_cmd(ids, 2, rt_v2(40.5f, 200.5f), RT_CLS_SMALL);
    int cross_small = -1;
    for (int i = 0; i < W.group_count; i++)
        for (int k = 0; k < W.groups[i].route_count; k++) {
            RtRoute *rt = &W.groups[i].routes[k].route;
            for (int q = 0; q < rt->n; q++) {
                if (rt->regions[q] / MAP.rw >= 16) {
                    int x = (rt->regions[q] % MAP.rw) * 8;
                    if (x > cross_small) cross_small = x;
                    break;
                }
            }
        }
    Rec l = run_cmd(ids, 2, rt_v2(40.5f, 200.5f), RT_CLS_LARGE);
    int cross_large = -1;
    for (int i = 0; i < W.group_count; i++)
        for (int k = 0; k < W.groups[i].route_count; k++) {
            RtRoute *rt = &W.groups[i].routes[k].route;
            for (int q = 0; q < rt->n; q++) {
                if (rt->regions[q] / MAP.rw >= 16) {
                    int x = (rt->regions[q] % MAP.rw) * 8;
                    if (x > cross_large) cross_large = x;
                    break;
                }
            }
        }
    printf("  small cross_x=%d flow_builds=%u | large cross_x=%d flow_builds=%u flows=%d\n",
           cross_small, s.flow_builds, cross_large, l.flow_builds, l.flows);
    OK(cross_small > 0 && cross_small <= 128, "small class uses the 2m gate");
    OK(cross_large >= 192, "large class detours to the 6m opening");
    OK(l.flow_builds == 1, "different clearance builds its own flow");
    OK(l.flows == 2, "two flows coexist (not shared)");
}

/* =================================================================== T8 */
static void t_component_isolation(void)
{
    printf("\n[T8] component isolation\n");
    setup_open(256);
    for (int z = 0; z < 256; z++) rt_grid_set_terrain(&G, 124, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);
    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
    rt_gw_set_flow_threshold(&W, -1);

    int ra = rt_region_of_world(&MAP, 121.5f, 60.5f);
    int rb = rt_region_of_world(&MAP, 126.5f, 60.5f);
    static RtUnitId ids[2];
    ids[0] = rt_units_spawn(&US, rt_v3(121.5f, 0.f, 60.5f), RT_FP_SMALL);
    ids[1] = rt_units_spawn(&US, rt_v3(126.5f, 0.f, 60.5f), RT_FP_SMALL);
    Rec r = run_cmd(ids, 2, rt_v2(180.5f, 60.5f), RT_CLS_SMALL);
    printf("  region A=%d B=%d | groups=%d flow_builds=%u flows=%d\n",
           ra, rb, r.groups, r.flow_builds, r.flows);
    OK(ra == rb, "both units share a region id");
    OK(r.groups == 2, "two components -> two groups");
    OK(r.flow_builds == 2, "each component builds its own flow");
    OK(r.flows == 2, "flows are not shared across components");
}

/* =================================================================== T9 */
static void t_topology(void)
{
    printf("\n[T9] topology invalidation\n");
    setup_open(256);
    static RtUnitId ids[256];
    int k = spawn_spread(ids, 24, 20.5f, 20.5f, 20.f);
    rt_gw_set_flow_threshold(&W, 1000000);
    rt_gw_set_flow_threshold(&W, -1);
    Rec r1 = run_cmd(ids, k, rt_v2(220.5f, 220.5f), RT_CLS_SMALL);
    print_rec("cold", r1);
    OK(r1.flow_builds == 1, "flow built");

    Rec r2 = run_cmd(ids, k, rt_v2(220.5f, 220.5f), RT_CLS_SMALL);
    print_rec("warm", r2);
    OK(r2.flow_builds == 0 && r2.builds == 0, "warm command reuses cache (no build, no flow)");

    /* 无关编辑：远端建楼 */
    RtGridDirty d;
    rt_grid_add_building_dirty(&G, 10, 240, 4, 4, &d);
    rt_grid_apply_dirty(&G, &d);
    rt_region_refresh(&MAP);
    Rec r3 = run_cmd(ids, k, rt_v2(220.5f, 220.5f), RT_CLS_SMALL);
    print_rec("unrelated", r3);
    OK(r3.flow_invalid == 0 && r3.flow_builds == 0, "unrelated edit keeps the flow valid");

    /* 相关编辑：压住所有走廊必经的收束区（goal 附近） */
    rt_grid_add_building_dirty(&G, 196, 196, 6, 6, &d);
    rt_grid_apply_dirty(&G, &d);
    rt_region_refresh(&MAP);
    Rec r4 = run_cmd(ids, k, rt_v2(220.5f, 220.5f), RT_CLS_SMALL);
    print_rec("related", r4);
    OK(r4.flow_invalid + r4.flow_builds >= 1, "related edit invalidates or rebuilds the flow");
    OK(r4.flows >= 1, "flow usable after rebuild");
}

/* ================================================================== T10 */
static void t_warm(void)
{
    printf("\n[T10] warm cache with default threshold (32 sources)\n");
    setup_open(256);
    static RtUnitId ids[256];
    int k = spawn_spread(ids, 32, 20.5f, 20.5f, 20.f);
    Rec a = run_cmd(ids, k, rt_v2(220.5f, 220.5f), RT_CLS_SMALL);
    Rec b = run_cmd(ids, k, rt_v2(220.5f, 220.5f), RT_CLS_SMALL);
    print_rec("cold", a);
    print_rec("warm", b);
    OK(a.adaptive_flow >= 1, "default threshold chose flow for 32 sources");
    OK(a.flow_builds == 1, "cold builds flow once");
    OK(b.flow_builds == 0, "warm does not rebuild flow");
    OK(b.builds == 0, "warm does not run A*");
}

int main(void)
{
    timer_init();
    printf("=== M4.3 tests: goal-centric coarse flow + adaptive selection ===\n");
    printf("default threshold = %d unique source regions\n", RT_GOALFLOW_MIN_SOURCES);

    t_small(1, "T1");
    t_small(4, "T2");
    t_small(8, "T3");
    t_flow(16, "T4", 1);
    t_flow(32, "T5", 1);
    t_flow(50, "T6", 1);
    t_clearance_isolation();
    t_component_isolation();
    t_topology();
    t_warm();

    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}

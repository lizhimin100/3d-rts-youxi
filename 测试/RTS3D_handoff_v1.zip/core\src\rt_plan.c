/* ============================================================================
 * rt_plan.c -- LocalPlanner：地形绕行（wall-following，M13）
 * 设计口径见 rt_plan.h 顶部。
 * ==========================================================================*/
#include "rt_plan.h"
#include "rt_math.h"

#include <stdlib.h>
#include <string.h>
#include <math.h>

#define RT_PLAN_PI 3.14159265358979f

void rt_plan_config_default(RtPlanConfig *c)
{
    if (!c) return;
    memset(c, 0, sizeof(*c));
    c->los_step        = 0.30f;
    /* 1.4 m 的探测长度：要大于「两个半径 + 半个格」，否则单位会把自己脚下的格子
     * 判成不可走；又要短到能在凹角处区分「左拐」和「右拐」。 */
    c->probe_dist      = 1.40f;
    c->sweep_step_deg  = 12.f;
    /* 20 m / 10 s：只覆盖**局部**绕行（绕柱子、退回洞口、贴墙找缺口）。
     * 更长的绕路是导航层的责任 —— 硬要本层绕 50 m，等价于把「不可达」判成「可绕」。
     * 不可达的那种情况由上面的连通分量快筛挡掉，所以这个预算再大也不会
     * 拖长 M6 T2 的 give-up。 */
    c->follow_max_dist = 20.f;
    c->follow_max_time = 10.f;
    c->rejoin_margin   = 0.30f;
    c->rearm_delay     = 2.0f;
    c->arrive_dist     = 0.60f;
    c->cooldown        = 0.40f;
}

int rt_plan_init(RtPlanCtx *c, int max_units, const RtPlanConfig *cfg)
{
    if (!c || max_units <= 0) return RT_ERR_INVALID;
    memset(c, 0, sizeof(*c));
    if (cfg) c->cfg = *cfg;
    else     rt_plan_config_default(&c->cfg);
    c->cap = max_units;
    c->u = (RtPlanUnit *)calloc((size_t)max_units, sizeof(RtPlanUnit));
    if (!c->u) { c->cap = 0; return RT_ERR_CAPACITY; }
    for (int i = 0; i < max_units; i++) c->u[i].side = 1;
    return RT_OK;
}

void rt_plan_destroy(RtPlanCtx *c)
{
    if (!c) return;
    free(c->u);
    c->u = NULL;
    c->cap = 0;
}

void rt_plan_reset(RtPlanCtx *c, int idx)
{
    if (!c || !c->u || idx < 0 || idx >= c->cap) return;
    uint32_t ep = c->u[idx].episodes;
    memset(&c->u[idx], 0, sizeof(RtPlanUnit));
    c->u[idx].side = 1;
    c->u[idx].episodes = ep;   /* 统计跨命令保留，和 rt_stuck 一致 */
}

void rt_plan_reset_all(RtPlanCtx *c)
{
    if (!c) return;
    for (int i = 0; i < c->cap; i++) rt_plan_reset(c, i);
}

const char *rt_plan_state_name(int s)
{
    switch (s) {
        case RT_PLAN_IDLE:    return "IDLE";
        case RT_PLAN_FOLLOW:  return "FOLLOW";
        case RT_PLAN_BLOCKED: return "BLOCKED";
        default:              return "?";
    }
}

int rt_plan_state(const RtPlanCtx *c, int idx)
{
    if (!c || !c->u || idx < 0 || idx >= c->cap) return RT_PLAN_IDLE;
    return c->u[idx].state;
}

int rt_plan_active(const RtPlanCtx *c, int idx)
{
    return rt_plan_state(c, idx) == RT_PLAN_FOLLOW;
}

/* ----------------------------------------------------------------------------
 * 直线检测
 * --------------------------------------------------------------------------*/
/* 单条射线：沿线采样，要求每格可走且 clearance >= radius */
static int ray_clear(RtPlanCtx *c, const RtGrid *g, RtVec2 a, RtVec2 b, float radius)
{
    RtVec2 d = rt_v2_sub(b, a);
    float len = rt_v2_len(d);
    if (len < 1e-5f) return 1;

    float step = c->cfg.los_step > 0.05f ? c->cfg.los_step : 0.05f;
    int n = (int)(len / step) + 1;
    if (n > 512) n = 512;               /* 防呆：半个地图的直线不该走到这里 */

    c->st.los_samples += (uint64_t)n;

    for (int k = 1; k <= n; k++) {
        float t = (float)k / (float)n;
        RtVec2 p = rt_v2(a.x + d.x * t, a.z + d.z * t);
        int cx = rt_grid_cell_x(g, p.x);
        int cz = rt_grid_cell_z(g, p.z);
        if (!rt_grid_walkable(g, cx, cz)) return 0;
        /* clearance 是「本格中心到最近阻挡格中心」的距离；用它当半径代理是保守的
         * （宁可判「过不去」也不要让单位擦着墙角走）。 */
        if (rt_grid_clearance_m(g, cx, cz) < radius) return 0;
    }
    return 1;
}

/* 直线检测 = 中心线 + 左右各偏移 radius 的两条线。
 *
 * **只测中心线是不够的**：2 m 缺口（两个格）里，中心射线在 z=127.0 就能穿过去，
 * 但半径 0.5 的单位要 z∈[127.5,128.5] 才塞得下。第一版只测中心线，规划器在
 * z=127.0 就判「通了」交还控制权，单位立刻被墙角卡住 -> 卡死层升级 -> GAVE_UP
 * （实测 probe_m13_t1：t=7.5 s 进 IDLE，之后 |pref|=0 冻了 52 s）。
 * 三条线等价于「单位本体扫过的走廊」，成本只有 3 倍。 */
static int los_clear(RtPlanCtx *c, const RtGrid *g, RtVec2 a, RtVec2 b, float radius)
{
    RtVec2 d = rt_v2_sub(b, a);
    float len = rt_v2_len(d);
    if (len < 1e-5f) return 1;

    c->st.los_check++;

    float ux = d.x / len, uz = d.z / len;
    float px = -uz, pz = ux;
    /* +0.1 m 余量：ORCA 的墙体约束是**精确 OBB**，而这里只能按 1 m 的格子离散判断。
     * 2 m 缺口里单位的可行带是 z∈[127.5,128.5]，如果规划器在 z=127.5 就判「通了」交还，
     * ORCA 会因为「刚好贴住」而每帧都撞墙、只能原地滑，单位就永久卡在缺口边上
     * （实测 probe_m13_t1 第一版：z=127.01 交还，之后冻住 52 s）。
     * 留 0.1 m 让交还那一刻单位**确实有富余**，不是恰好在边界上。 */
    float off = radius + 0.10f;

    if (!ray_clear(c, g, a, b, radius)) return 0;
    if (!ray_clear(c, g,
                   rt_v2(a.x + px * off, a.z + pz * off),
                   rt_v2(b.x + px * off, b.z + pz * off), radius)) return 0;
    if (!ray_clear(c, g,
                   rt_v2(a.x - px * off, a.z - pz * off),
                   rt_v2(b.x - px * off, b.z - pz * off), radius)) return 0;
    return 1;
}

/* 快路径：从起点到目标整段都在 clearance 圈内 -> 一定有直通（含两侧偏移）。
 * 用 2 个 radius + 1 格余量抵消「格中心 vs 格边界」的半个格误差。 */
static int los_clear_fast(RtPlanCtx *c, const RtGrid *g, RtVec2 a, RtVec2 b, float radius)
{
    float gd = rt_v2_dist(a, b);
    int cx = rt_grid_cell_x(g, a.x), cz = rt_grid_cell_z(g, a.z);
    float cl = rt_grid_clearance_m(g, cx, cz);
    if (cl > gd + 2.f * radius + g->cell) {
        c->st.los_fast++;
        return 1;
    }
    return los_clear(c, g, a, b, radius);
}

/* 从 base 角开始、朝 side 方向每次转 step，找第一个「探针可走」的方向。
 * 返回 1 = 找到（out 为单位方向）。 */
static int sweep(RtPlanCtx *c, const RtGrid *g, RtVec2 pos, float base_ang, int side,
                 float radius, RtVec2 *out)
{
    float step = c->cfg.sweep_step_deg * (RT_PLAN_PI / 180.f);
    if (step < 0.01f) step = 0.01f;
    float pd = c->cfg.probe_dist;

    for (int k = 1; k <= RT_PLAN_SWEEP_MAX; k++) {
        float ang = base_ang + (float)k * step * (float)side;
        RtVec2 d = rt_v2(cosf(ang), sinf(ang));
        RtVec2 p = rt_v2(pos.x + d.x * pd, pos.z + d.z * pd);
        if (los_clear(c, g, pos, p, radius)) {
            *out = d;
            return 1;
        }
    }
    return 0;
}

/* 进入绕行时选旋向：两侧各扫一次，取「第一个可走方向偏离目标更小」的一侧。
 * 完全对称时取 +1（确定性的平手规则）。M11b 已经论证过：对称的几何下
 * 任何局部指标都分不出该往哪边走 —— 所以这里**不假装聪明**，
 * 只保证「选定后不再改」；选错了就是绕远路，靠预算兜底，不会原地打转。 */
static int pick_side(RtPlanCtx *c, const RtGrid *g, RtVec2 pos, float base_ang, float radius)
{
    float step = c->cfg.sweep_step_deg * (RT_PLAN_PI / 180.f);
    if (step < 0.01f) step = 0.01f;
    float pd = c->cfg.probe_dist;

    for (int k = 1; k <= RT_PLAN_SWEEP_MAX; k++) {
        int ok_p = 0, ok_m = 0;
        for (int s = 0; s < 2; s++) {
            int side = s ? -1 : 1;
            float ang = base_ang + (float)k * step * (float)side;
            RtVec2 d = rt_v2(cosf(ang), sinf(ang));
            RtVec2 p = rt_v2(pos.x + d.x * pd, pos.z + d.z * pd);
            int ok = los_clear(c, g, pos, p, radius);
            if (side > 0) ok_p = ok; else ok_m = ok;
        }
        if (ok_p && ok_m) return 1;      /* 对称平手 -> +1 */
        if (ok_p) return 1;
        if (ok_m) return -1;
    }
    return 1;
}

/* ----------------------------------------------------------------------------
 * 每帧
 * --------------------------------------------------------------------------*/
int rt_plan_step(RtPlanCtx *c, RtLocalAgent *ag, int n, const RtVec2 *aim,
                 const RtVec2 *goal, const RtGrid *g, float dt)
{
    if (!c || !c->u || !ag || !aim || n <= 0) return 0;
    if (n > c->cap) n = c->cap;
    if (!g) return 0;

    int handled = 0;
    uint32_t active = 0;

    for (int i = 0; i < n; i++) {
        RtPlanUnit *u = &c->u[i];
        RtLocalAgent *a = &ag[i];
        if (a->inv_mass <= 0.f) { u->state = RT_PLAN_IDLE; continue; }

        RtVec2 gv = rt_v2_sub(aim[i], a->pos);
        float gd = rt_v2_len(gv);
        if (gd < c->cfg.arrive_dist || gd < 1e-4f) {
            u->state = RT_PLAN_IDLE;
            continue;
        }

        float radius = a->radius > 0.05f ? a->radius : 0.5f;

        /* 可达性快筛：命令目标在**别的连通分量**里 -> 本层永远绕不过去，直接不接管。
         * 这一条把 M6 T2（封闭房间）的 give-up 留在 22.4 s；
         * 没有它，绕行预算会先吃掉 6 s，实测顶到 32.9 s，越过了 30 s 的契约上界。
         * 只在分量号已提交时判（pending_comp >= 0 是「正在重建」，UNKNOWN 是合法状态）。 */
        if (goal && g->pending_comp < 0) {
            int32_t ca = rt_grid_component_at(g, rt_grid_cell_x(g, a->pos.x),
                                                 rt_grid_cell_z(g, a->pos.z));
            int32_t cb = rt_grid_component_at(g, rt_grid_cell_x(g, goal[i].x),
                                                 rt_grid_cell_z(g, goal[i].z));
            if (ca >= 0 && cb >= 0 && ca != cb) {
                if (!u->unl) { u->unl = 1; c->st.unreachable++; }
                u->state = RT_PLAN_IDLE;
                continue;
            }
            u->unl = 0;
        }

        /* 一直要跑的一步：直线通不通 */
        int clear = los_clear_fast(c, g, a->pos, aim[i], radius);
        if (clear) {
            if (u->state == RT_PLAN_FOLLOW) {
                /* 只把「比进入时更近」记成 finished，绕了一圈还在原地的别算成功 */
                if (gd < u->hit_goal_d - c->cfg.rejoin_margin) c->st.finished++;
                u->cooldown_t = c->cfg.cooldown;
            }
            if (u->state == RT_PLAN_FOLLOW) u->state = RT_PLAN_IDLE;
            if (u->cooldown_t > 0.f) u->cooldown_t -= dt;
            continue;
        }

        /* 直线被地形挡住 */
        if (u->state == RT_PLAN_BLOCKED) {
            u->rearm_t += dt;
            /* 重新接管的条件是**地图变了**（nav_epoch 前进），而不是「等够时间」。
             * 只按时间重试会让「不可达」变成「每 8 s 试一次」：封闭房间里的单位
             * 每次重新接管都能沿墙走 6 s，rt_stuck 的进度被反复清零，
             * 实测 give-up 从 26.5 s 被拖到 55 s，直接破坏 M6 的 10~30 s 契约。
             * 这和 M11b 的 GAVE_UP 重试是同一条原则：放弃只对**当时那个环境**成立，
             * 而这里的环境有显式版本号（nav_epoch），不需要猜。 */
            if (u->rearm_t >= c->cfg.rearm_delay && g->nav_epoch != u->fail_epoch) {
                u->state = RT_PLAN_IDLE;
                u->rearm_t = 0.f;
                c->st.rearm++;
            }
            continue;
        }

        if (u->state != RT_PLAN_FOLLOW) {
            if (u->cooldown_t > 0.f) { u->cooldown_t -= dt; continue; }
            float base = atan2f(gv.z, gv.x);
            u->state = RT_PLAN_FOLLOW;
            u->side = pick_side(c, g, a->pos, base, radius);
            u->follow_t = 0.f;
            u->follow_d = 0.f;
            u->hit_pos = a->pos;
            u->hit_goal_d = gd;
            u->episodes++;
            c->st.engaged++;
        }

        /* 预算：按**实际位移**累计，原地抖不算绕 */
        u->follow_t += dt;
        u->follow_d += rt_v2_len(a->vel) * dt;
        if (u->follow_t > c->cfg.follow_max_time || u->follow_d > c->cfg.follow_max_dist) {
            u->state = RT_PLAN_BLOCKED;
            u->fail_pos = a->pos;
            u->fail_epoch = g->nav_epoch;
            u->rearm_t = 0.f;
            c->st.exhausted++;
            continue;
        }

        float base = atan2f(gv.z, gv.x);
        RtVec2 dir;
        if (!sweep(c, g, a->pos, base, u->side, radius, &dir)) {
            u->state = RT_PLAN_BLOCKED;
            u->fail_pos = a->pos;
            u->fail_epoch = g->nav_epoch;
            u->rearm_t = 0.f;
            c->st.no_exit++;
            continue;
        }

        float sp = a->max_speed > 0.f ? a->max_speed : 1.f;
        a->pref_vel = rt_v2_mul(dir, sp);
        u->dir = dir;
        handled++;
        active++;
    }

    c->st.active = active;
    return handled;
}

int rt_plan_hook(void *ud, int idx, RtVec2 dir)
{
    (void)dir;
    RtPlanCtx *c = (RtPlanCtx *)ud;
    if (!c) return 0;
    /* 在绕行中：pref 已经是本层给的方向，卡死层不要再用奇偶侧移覆盖它。 */
    return rt_plan_active(c, idx);
}

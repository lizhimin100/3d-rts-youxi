/* ============================================================================
 * probe_m46_split_async.c -- 路线 B：同步 split vs 异步 split（同机同会话 A/B）
 *
 * 测什么：
 *   · mode=0 同步：rt_gw_submit_edit 里 async_split=0（等价于 M4.6-P4 的
 *     apply_dirty + note_edit），整块 split 在同一帧完成；
 *   · mode=1 异步：默认路径，split 摊到多帧，记录帧数 / 单帧最坏成本。
 * 每次编辑后都把建筑拆掉还原，保证两个 mode 从同一状态出发。
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c \
 *          _设计验算/probe_m46_split_async.c -o probe_split_async
 * ==========================================================================*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "rt_grid.h"
#include "rt_region.h"
#include "rt_group.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

#define W 256
#define H 256

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld GW;

static void build(void)
{
    rt_grid_init(&G, W, H, 1.0f);
    uint64_t st = 0xB5EEDull;
    for (int z = 0; z < H; z++)
        for (int x = 0; x < W; x++) {
            uint64_t k = (st += 0x9E3779B97F4A7C15ull);
            k = (k ^ (k >> 30)) * 0xBF58476D1CE4E5B9ull;
            k = (k ^ (k >> 27)) * 0x94D049BB133111EBull;
            k ^= k >> 31;
            if ((k >> 40) % 1000 < 100ull) rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
    /* 一堵长墙 + 3 格门：整图一个大分量，建筑压在门上就会 split */
    for (int z = 0; z < H; z++)
        if (z != 128) rt_grid_set_terrain(&G, 128, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int dz = -1; dz <= 1; dz++) {
        rt_grid_set_terrain(&G, 127, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, 128, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        rt_grid_set_terrain(&G, 129, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
    }
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_gw_init(&GW, &G, &MAP);
}

/* 一次编辑（加或删），返回：总耗时 / 帧数 / 单帧最坏 */
typedef struct { double submit_ms; double total_ms; int frames; double worst_ms; int pending_after_submit; } Result;

static Result run_edit(int async, int x, int z, int w, int h, int add)
{
    Result r; memset(&r, 0, sizeof(r));
    RtGridDirty d;
    memset(&d, 0, sizeof(d));
    rt_gw_set_async_split(&GW, async);

    double t0 = now_ms();
    if (add) rt_grid_add_building_dirty(&G, x, z, w, h, &d);
    else     rt_grid_remove_building_dirty(&G, x, z, w, h, &d);
    (void)rt_gw_submit_edit(&GW, &d);
    r.submit_ms = now_ms() - t0;
    r.total_ms = r.submit_ms;
    r.worst_ms = r.submit_ms;
    r.pending_after_submit = rt_gw_split_pending(&GW);

    while (rt_gw_split_pending(&GW) && r.frames < 10000) {
        double u0 = now_ms();
        (void)rt_gw_update(&GW);
        double dt = now_ms() - u0;
        r.total_ms += dt;
        if (dt > r.worst_ms) r.worst_ms = dt;
        r.frames++;
    }
    return r;
}

int main(void)
{
    timer_init();
    build();
    printf("=== M4.6-P5 probe: sync vs async split ===\n");
    printf("map %dx%d, main component=%d cells, threshold=20000, budget=%d\n",
           W, H, G.component_size[G.component[0]], rt_gw_split_budget(&GW));

    printf("\n  %-9s %6s %10s %7s %9s %9s %7s\n",
           "edit", "mode", "submit ms", "frames", "worst ms", "total ms", "defer");
    int sizes[5] = { 8, 16, 24, 32, 64 };
    for (int k = 0; k < 5; k++) {
        int s = sizes[k];
        for (int mode = 0; mode < 2; mode++) {
            Result a = run_edit(mode, 128 - s / 2, 128 - s / 2, s, s, 1);
            /* 拆掉还原（用同一模式，避免把上一 mode 的状态带过来） */
            (void)run_edit(mode, 128 - s / 2, 128 - s / 2, s, s, 0);
            printf("  %2dx%-6d %6s %10.3f %7d %9.3f %9.3f %7d\n",
                   s, s, mode ? "async" : "sync", a.submit_ms, a.frames,
                   a.worst_ms, a.total_ms, a.pending_after_submit);
        }
    }

    printf("\n  split stats: scheduled=%u commits=%u cancels=%u spans(>=2frame)=%u max_frames=%u\n",
           GW.sched.stat_scheduled, GW.sched.stat_commit, GW.sched.stat_cancel,
           GW.split_spans, GW.split_max_frames);

    rt_gw_destroy(&GW);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return 0;
}

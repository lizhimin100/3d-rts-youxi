/* ============================================================================
 * rt_grid.c -- 导航网格 / clearance 场（8SSEDT）/ 连通分量 / OBB 阻挡
 *
 * M2 增量实现的三条硬纪律：
 *   1. 8SSEDT 的 (dx,dy) **持久化**；区域重算靠 halo 传播，不靠标量反推。
 *   2. 每种派生数据**独立**决定 dirty 范围（walkability=0，clearance=区域最大
 *      clearance+2，connectivity 由 split/merge 检测决定）。
 *   3. 增量不可证明正确时**降级全量并计数**（full_rebuild_count），
 *      不允许「看起来差不多」。
 * ==========================================================================*/
#include "rt_grid.h"
#include "rt_navjob.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdio.h>

/* ---------------------------------------------------------------- 常量 */
#define SSDP_BIG        16384
/* clearance 区域重算的外扩上限：超过则放弃精确性，改为全量。
 * 64 m 覆盖 512² 图上 99% 的编辑（实测最大 clearance 5.1 m）。 */
/* clearance 的**数值上限**（16 m）。
 * 为什么必须有：开放地图上「到最近障碍的距离」可以到半张图（256² -> 62 m），
 * 而增量 pad 必须 >= 全图 max clearance，于是每次编辑都撞上 PAD 上限 -> 全量重建。
 * 16 m 对任何单位（半径 <= 4 m）与 OBB 快路径都足够；超出部分视为「无限开阔」。
 * 全量与增量使用同一个 clamp，所以差分一致性不受影响。 */
#define RT_SSEDT_CLAMP   1600.f
#define RT_SSEDT_MAX_PAD 64
/* split 检测的局部 BFS 半径（格）：超出则无法证明「无 split」，降级全量 */
#define RT_SPLIT_LOCAL_RADIUS 96
/* 分量超过这个规模就交给可暂停的 Job（约 1.4 ms @70ns/格）*/
#define RT_JOB_SPLIT_THRESHOLD 20000

/* 8 邻域（2D XZ），全局共用，保证「连通域 / A* / 防穿角」三处语义一致 */
static const int DX8[8] = { 1, -1, 0, 0, 1, 1, -1, -1 };
static const int DZ8[8] = { 0, 0, 1, -1, 1, -1, 1, -1 };

/* ================================================================ 掩码 */
int rt_grid_chunk_of_cell(const RtGrid *g, int x, int z)
{
    int cw = (g->w + RT_CHUNK_PX - 1) / RT_CHUNK_PX;
    int cx = x / RT_CHUNK_PX;
    int cz = z / RT_CHUNK_PX;
    return cz * cw + cx;
}

void rt_grid_mask_set(uint32_t *mask, int chunk)
{
    if (chunk < 0 || chunk >= RT_CHUNK_N) return;
    mask[chunk >> 5] |= (1u << (chunk & 31));
}

int rt_grid_mask_test(const uint32_t *mask, int chunk)
{
    if (chunk < 0 || chunk >= RT_CHUNK_N) return 0;
    return (mask[chunk >> 5] >> (chunk & 31)) & 1u;
}

int rt_grid_mask_intersect(const uint32_t *a, const uint32_t *b)
{
    for (int i = 0; i < RT_CHUNK_MASK_WORDS; i++)
        if (a[i] & b[i]) return 1;
    return 0;
}

void rt_grid_mask_clear(uint32_t *mask)
{
    memset(mask, 0, sizeof(uint32_t) * RT_CHUNK_MASK_WORDS);
}

void rt_grid_mask_or(uint32_t *dst, const uint32_t *src)
{
    for (int i = 0; i < RT_CHUNK_MASK_WORDS; i++) dst[i] |= src[i];
}

int rt_grid_mask_count(const uint32_t *mask)
{
    int n = 0;
    for (int i = 0; i < RT_CHUNK_MASK_WORDS; i++) {
        uint32_t v = mask[i];
        while (v) { v &= (v - 1); n++; }
    }
    return n;
}

/* ================================================================ 生命周期 */
static int alloc_components(RtGrid *g, int32_t cap)
{
    int32_t *c = (int32_t *)realloc(g->component_size, sizeof(int32_t) * (size_t)cap);
    if (!c) return RT_ERR_CAPACITY;
    g->component_size = c;
    int32_t *r = (int32_t *)realloc(g->component_rep, sizeof(int32_t) * (size_t)cap);
    if (!r) return RT_ERR_CAPACITY;
    g->component_rep = r;
    g->component_cap = cap;
    return RT_OK;
}

int rt_grid_init(RtGrid *g, int w, int h, float cell)
{
    if (!g) return RT_ERR_INVALID;
    if (w < RT_GRID_MIN_DIM || h < RT_GRID_MIN_DIM) return RT_ERR_INVALID;
    if (w > RT_GRID_MAX_DIM || h > RT_GRID_MAX_DIM) return RT_ERR_INVALID;

    memset(g, 0, sizeof(*g));
    g->w = w;
    g->h = h;
    g->cell = (cell > 0.f) ? cell : 1.0f;

    size_t n = (size_t)w * (size_t)h;
    g->base      = (uint8_t *)calloc(n, sizeof(uint8_t));
    g->overlay   = (uint16_t *)calloc(n, sizeof(uint16_t));
    g->flags     = (uint8_t *)calloc(n, sizeof(uint8_t));
    g->clearance = (uint16_t *)calloc(n, sizeof(uint16_t));
    g->ssd_x     = (int16_t *)calloc(n, sizeof(int16_t));
    g->ssd_y     = (int16_t *)calloc(n, sizeof(int16_t));
    g->component = (int32_t *)malloc(n * sizeof(int32_t));
    g->bfs_queue = (int32_t *)malloc(n * sizeof(int32_t));
    g->split_label = (uint8_t *)malloc(n * sizeof(uint8_t));
    g->job_queue = NULL;
    g->job_label = NULL;

    if (!g->base || !g->overlay || !g->flags || !g->clearance ||
        !g->ssd_x || !g->ssd_y || !g->component || !g->bfs_queue) {
        rt_grid_destroy(g);
        return RT_ERR_CAPACITY;
    }
    for (size_t i = 0; i < n; i++) {
        g->component[i] = -1;
        g->ssd_x[i] = SSDP_BIG;
        g->ssd_y[i] = 0;
    }
    g->component_count = 0;
    g->component_cap = 0;
    if (alloc_components(g, 1024) != RT_OK) {
        rt_grid_destroy(g);
        return RT_ERR_CAPACITY;
    }
    g->version = 1;
    g->revision = 0;
    g->pending_comp = -1;
    g->nav_epoch = 1;
    g->label_epoch = 1;
    for (int i = 0; i < RT_CHUNK_N; i++) { g->chunk_ver[i] = 1; g->edit_ver[i] = 1; }
    return RT_OK;
}

void rt_grid_destroy(RtGrid *g)
{
    if (!g) return;
    free(g->base);           g->base = NULL;
    free(g->overlay);        g->overlay = NULL;
    free(g->flags);          g->flags = NULL;
    free(g->clearance);      g->clearance = NULL;
    free(g->ssd_x);          g->ssd_x = NULL;
    free(g->ssd_y);          g->ssd_y = NULL;
    free(g->component);      g->component = NULL;
    free(g->component_size); g->component_size = NULL;
    free(g->component_rep);  g->component_rep = NULL;
    free(g->bfs_queue);      g->bfs_queue = NULL;
    free(g->job_queue);      g->job_queue = NULL;
    free(g->job_label);      g->job_label = NULL;
    free(g->split_label);    g->split_label = NULL;
    g->w = g->h = 0;
}

void rt_grid_clear(RtGrid *g)
{
    if (!g) return;
    size_t n = (size_t)g->w * (size_t)g->h;
    memset(g->base, 0, n);
    memset(g->overlay, 0, n * sizeof(uint16_t));
    memset(g->flags, 0, n);
    memset(g->clearance, 0, n * sizeof(uint16_t));
    for (size_t i = 0; i < n; i++) {
        g->component[i] = -1;
        g->ssd_x[i] = SSDP_BIG;
        g->ssd_y[i] = 0;
    }
    g->component_count = 0;
    g->active_components = 0;
    g->pending_comp = -1;
    g->clearance_valid = 0;
    g->version++;
    g->revision++;
}

/* ================================================================ 坐标 */
int rt_grid_cell_x(const RtGrid *g, float world_x)
{
    return (int)floorf(world_x / g->cell);
}
int rt_grid_cell_z(const RtGrid *g, float world_z)
{
    return (int)floorf(world_z / g->cell);
}

/* ================================================================ 编辑 */
static inline void sync_flags_cell(RtGrid *g, size_t i)
{
    g->flags[i] = (uint8_t)(g->base[i] |
                            (g->overlay[i] ? RT_CELL_BLOCKED_BUILDING : 0u));
}

void rt_grid_set_terrain(RtGrid *g, int x, int z, uint8_t flag_bits, int on)
{
    if (!g || !rt_grid_in_bounds(g, x, z)) return;
    size_t i = (size_t)z * g->w + x;
    if (on) g->base[i] |= flag_bits;
    else    g->base[i] &= (uint8_t)~flag_bits;
    sync_flags_cell(g, i);
    g->clearance_valid = 0;      /* flags 变了：clearance 过期，快路径失效 */
    g->revision++;
    g->version++;
}

/* ---- Dirty 初始化：每种派生数据独立范围 ----
 * is_merge 必须由调用方**传进来**，不能读 d->may_merge：
 * 首版在 dirty_fill_rect 里判 d->may_merge，但调用方是在它**之后**才置位的，
 * 于是本次编辑的 pad 取决于上一次编辑的类型（add 用 pad_rm、remove 用 pad_add，
 * 交替且不可预测）。B5 就是被这个错位放大成 124 个差异的。 */
static void dirty_fill_rect(RtGrid *g, RtGridDirty *d, int x0, int z0, int x1, int z1,
                            int is_merge)
{
    d->x0 = x0; d->z0 = z0; d->x1 = x1; d->z1 = z1;

    /* ---- 1. clearance 的 padding ----
     * 判据（必要条件的保守版）：格 P 受新障碍 O 影响  =>  dist(P,O) < 旧 clearance(P)
     *   =>  dist(P, edit_rect) < 旧 clearance(P) <= 全图最大 clearance
     * 所以 pad 必须取**全图**最大 clearance，而不是编辑区域内的最大值
     * （首版用"区域内 max"，差分测试立刻抓到：区域外 5 格的格没被重算，
     *  增量结果与全量差 1 个距离单位）。
     *
     * remove 会让 max 变大（障碍消失，剩余格的距离可以更远），保守取 2 倍。
     * pad 超过 RT_SSEDT_MAX_PAD -> 调用方降级全量。 */
    int c_max = (int)g->clearance_max;
    int pad_add = c_max / 100 + 3;
    /* remove 的 pad 需要覆盖「被拆掉的障碍曾经是最近障碍」的全部格子。
     * 未 clamp 时这个半径 ≤ c_max；clamp 之后 c_max 被截成 16 m，但影响半径
     * （就**标量**而言）也被同一个 clamp 截住了 —— 所以 c_max/100 + 6 两种
     * 情形都够。真正的安全网是重算前的边界向量校验：万一不够，那里会返回 1
     * 让调用方降级全量，不会静默算错（见 rt_grid_rebuild_clearance_region）。 */
    int pad_rm  = c_max / 100 + 6;
    int pad = is_merge ? pad_rm : pad_add;
    if (pad > RT_SSEDT_MAX_PAD) pad = RT_SSEDT_MAX_PAD;
    d->pad = pad;

    d->cx0 = x0 - pad; d->cz0 = z0 - pad;
    d->cx1 = x1 + pad; d->cz1 = z1 + pad;
    if (d->cx0 < 0) d->cx0 = 0;
    if (d->cz0 < 0) d->cz0 = 0;
    if (d->cx1 >= g->w) d->cx1 = g->w - 1;
    if (d->cz1 >= g->h) d->cz1 = g->h - 1;

    /* ---- 2. walkability 的 padding = 0（只有被覆盖的格变化） ---- */

    /* ---- 3. chunk 掩码：覆盖 clearance 重算范围（保守，含所有可能受影响的流场） ---- */
    rt_grid_mask_clear(d->chunk_mask);
    d->chunk_mask_any = 0;
    for (int z = d->cz0; z <= d->cz1; z += RT_CHUNK_PX) {
        for (int x = d->cx0; x <= d->cx1; x += RT_CHUNK_PX) {
            int ch = rt_grid_chunk_of_cell(g, x, z);
            rt_grid_mask_set(d->chunk_mask, ch);
            d->chunk_mask_any = 1;
        }
    }
    /* 边界补齐：确保 dz1/dx1 所在的 chunk 也被标记 */
    int ch = rt_grid_chunk_of_cell(g, d->cx1, d->cz1);
    rt_grid_mask_set(d->chunk_mask, ch);

    d->may_split = 0;
    d->may_merge = 0;
}

int rt_grid_add_building_dirty(RtGrid *g, int x0, int z0, int bw, int bh, RtGridDirty *d)
{
    if (!g || bw <= 0 || bh <= 0) return RT_ERR_INVALID;
    int x1 = x0 + bw - 1, z1 = z0 + bh - 1;
    if (x0 < 0 || z0 < 0 || x1 >= g->w || z1 >= g->h) return RT_ERR_INVALID;

    if (d) {
        dirty_fill_rect(g, d, x0, z0, x1, z1, 0);
        d->may_split = 1;
        d->may_merge = 0;
    }
    for (int z = z0; z <= z1; z++) {
        for (int x = x0; x <= x1; x++) {
            size_t i = (size_t)z * g->w + x;
            if (g->overlay[i] < 0xFFFFu) g->overlay[i]++;
            sync_flags_cell(g, i);
        }
    }
    g->clearance_valid = 0;
    g->revision++;
    g->version++;
    if (d) rt_grid_note_edit(g, d->chunk_mask);
    return RT_OK;
}

int rt_grid_remove_building_dirty(RtGrid *g, int x0, int z0, int bw, int bh, RtGridDirty *d)
{
    if (!g || bw <= 0 || bh <= 0) return RT_ERR_INVALID;
    int x1 = x0 + bw - 1, z1 = z0 + bh - 1;
    if (x0 < 0 || z0 < 0 || x1 >= g->w || z1 >= g->h) return RT_ERR_INVALID;

    if (d) {
        dirty_fill_rect(g, d, x0, z0, x1, z1, 1);
        d->may_split = 0;
        d->may_merge = 1;
    }
    for (int z = z0; z <= z1; z++) {
        for (int x = x0; x <= x1; x++) {
            size_t i = (size_t)z * g->w + x;
            if (g->overlay[i] > 0) g->overlay[i]--;
            sync_flags_cell(g, i);
        }
    }
    g->clearance_valid = 0;
    g->revision++;
    g->version++;
    if (d) rt_grid_note_edit(g, d->chunk_mask);
    return RT_OK;
}

void rt_grid_clear_buildings(RtGrid *g)
{
    if (!g) return;
    size_t n = (size_t)g->w * (size_t)g->h;
    memset(g->overlay, 0, n * sizeof(uint16_t));
    for (size_t i = 0; i < n; i++) sync_flags_cell(g, i);
    g->clearance_valid = 0;
    g->revision++;
    g->version++;
}

/* ================================================================ 8SSEDT */
typedef struct { int32_t dx, dy; } Ssdp;

static inline int32_t ssdp_d2(int32_t dx, int32_t dy) { return dx * dx + dy * dy; }

/* 从 (x+ox, z+oz) 向 (x,z) 传播，只在更优时更新 (x,z)
 *
 * validate = 1 时多一条检查：源格的向量必须指向一个**仍然 blocked** 的格。
 * remove 编辑会让 rect 外一圈某些格的「最近障碍」正是刚被清掉的那一格 —— 向量还
 * 指着它，一次传播就能把「已经不存在的障碍」带进 rect（B5 的门格被写成 (0,0)，
 * 即「自己就是障碍」的幻影）。全量重建不需要这条（向量天然有效），所以用参数
 * 分开，避免给降级路径加分支成本。 */
static inline void ssdp_cmp(RtGrid *g, int x, int z, int ox, int oz, int validate)
{
    int nx = x + ox, nz = z + oz;
    if (nx < 0 || nz < 0 || nx >= g->w || nz >= g->h) return;
    size_t ni = (size_t)nz * g->w + nx;
    size_t ci = (size_t)z * g->w + x;
    int32_t sdx = g->ssd_x[ni], sdy = g->ssd_y[ni];
    if (validate && sdx != SSDP_BIG) {
        int sx = nx + (int)sdx, sz = nz + (int)sdy;
        if (rt_grid_walkable(g, sx, sz)) return;   /* 陈旧向量：障碍已不存在 */
    }
    int32_t ndx = sdx + ox;
    int32_t ndy = sdy + oz;
    if (ssdp_d2(ndx, ndy) < ssdp_d2(g->ssd_x[ci], g->ssd_y[ci])) {
        g->ssd_x[ci] = (int16_t)ndx;
        g->ssd_y[ci] = (int16_t)ndy;
    }
}

/* 两遍扫描；只写 [x0..x1] × [z0..z1] 范围内的格 */
static void ssdp_propagate_rect(RtGrid *g, int x0, int z0, int x1, int z1, int validate)
{
    for (int z = z0; z <= z1; z++) {
        for (int x = x0; x <= x1; x++) {
            ssdp_cmp(g, x, z, -1,  0, validate);
            ssdp_cmp(g, x, z,  0, -1, validate);
            ssdp_cmp(g, x, z, -1, -1, validate);
            ssdp_cmp(g, x, z,  1, -1, validate);
        }
        for (int x = x1; x >= x0; x--) {
            ssdp_cmp(g, x, z, 1, 0, validate);
        }
    }
    for (int z = z1; z >= z0; z--) {
        for (int x = x1; x >= x0; x--) {
            ssdp_cmp(g, x, z,  1,  0, validate);
            ssdp_cmp(g, x, z,  0,  1, validate);
            ssdp_cmp(g, x, z, -1,  1, validate);
            ssdp_cmp(g, x, z,  1,  1, validate);
        }
        for (int x = x0; x <= x1; x++) {
            ssdp_cmp(g, x, z, -1, 0, validate);
        }
    }
}

static void ssdp_write_clearance(RtGrid *g, int x0, int z0, int x1, int z1)
{
    for (int z = z0; z <= z1; z++) {
        for (int x = x0; x <= x1; x++) {
            size_t i = (size_t)z * g->w + x;
            float d = sqrtf((float)ssdp_d2(g->ssd_x[i], g->ssd_y[i]));
            float m = d * g->cell * 100.f;      /* 0.01 m */
            if (m > RT_SSEDT_CLAMP) m = RT_SSEDT_CLAMP;
            if (m > 65535.f) m = 65535.f;
            g->clearance[i] = (uint16_t)(m + 0.5f);
        }
    }
}

static void update_clearance_max(RtGrid *g)
{
    uint16_t mx = 0;
    size_t n = (size_t)g->w * (size_t)g->h;
    for (size_t i = 0; i < n; i++)
        if (g->clearance[i] > mx) mx = g->clearance[i];
    g->clearance_max = mx;
}

void rt_grid_rebuild_clearance_full(RtGrid *g)
{
    if (!g) return;
    size_t n = (size_t)g->w * (size_t)g->h;
    for (size_t i = 0; i < n; i++) {
        if (g->flags[i] & (RT_CELL_BLOCKED_TERRAIN | RT_CELL_BLOCKED_BUILDING)) {
            g->ssd_x[i] = 0; g->ssd_y[i] = 0;
        } else {
            g->ssd_x[i] = SSDP_BIG; g->ssd_y[i] = 0;
        }
    }
    ssdp_propagate_rect(g, 0, 0, g->w - 1, g->h - 1, 0);
    ssdp_write_clearance(g, 0, 0, g->w - 1, g->h - 1);
    update_clearance_max(g);
    g->clearance_valid = 1;
}

/*
 * 区域重算的正确性论证（写在这里，防止以后被"优化"掉）：
 *   8SSEDT 是两遍扫描的 DP。只要**区域外一圈的 (dx,dy) 已经是正确的**，
 *   区域内的 DP 会收敛到与全量完全相同的结果 —— 因为 DP 的转移只依赖邻居。
 *   「区域外一圈正确」由调用方保证：重算范围已外扩 pad，且 pad 取的是
 *   区域内编辑前的最大 clearance，因此区域外一圈格子的最近障碍不可能落在
 *   编辑区域内（否则它到编辑区域的距离会小于它的 clearance，矛盾）。
 *   pad 达到 RT_SSEDT_MAX_PAD 时该论证不成立 -> 调用方须降级全量。
 *
 * M4.6-P4 补丁（B5 抓到）：上面这条只对**标量**成立，向量会漏。remove 之后，
 * rect 外一圈里有些格的「最近障碍」正是刚被清掉的那一格 —— 它们的标量可能因为
 * 16 m clamp 毫无变化（比如 20 m 与 20.3 m 都记成 1600），但向量还指着那个格子。
 * 一次传播就把「已经不存在的障碍」带进 rect，门格被写成 (0,0)（自己就是障碍的幻影）。
 * 处理分两层：
 *   1) ssdp_cmp(validate=1) 直接忽略「指向可走格」的源向量 —— 幻影不会进来；
 *   2) 这里再检查边界环：若某个陈旧向量的标量**还没被 clamp**，说明它的真实影响
 *      半径超出了 pad（本次重算范围不够），返回 1 让调用方降级全量并计数。
 */
int rt_grid_rebuild_clearance_region(RtGrid *g, int x0, int z0, int x1, int z1)
{
    if (!g) return 0;
    if (x0 < 0) x0 = 0;
    if (z0 < 0) z0 = 0;
    if (x1 >= g->w) x1 = g->w - 1;
    if (z1 >= g->h) z1 = g->h - 1;
    if (x0 > x1 || z0 > z1) return 0;

    /* ---- 边界环校验（rect 外一圈，先于重算：此时环上的向量还是旧值）---- */
    for (int z = z0 - 1; z <= z1 + 1; z++) {
        if (z < 0 || z >= g->h) continue;
        for (int x = x0 - 1; x <= x1 + 1; x++) {
            if (x < 0 || x >= g->w) continue;
            if (x >= x0 && x <= x1 && z >= z0 && z <= z1) continue;   /* 只要环 */
            size_t i = (size_t)z * g->w + x;
            int32_t vx = g->ssd_x[i], vy = g->ssd_y[i];
            if (vx == SSDP_BIG) continue;                 /* 本来就没有源 */
            if (!rt_grid_walkable(g, x + (int)vx, z + (int)vy)) continue;  /* 源仍 blocked：有效 */
            if (g->clearance[i] < RT_SSEDT_CLAMP) {
                g->clearance_ring_fallbacks++;
                return 1;                                 /* pad 不够 -> 降级全量 */
            }
            g->clearance_stale_vectors++;                 /* 标量已 clamp：向量作废即可 */
            g->ssd_x[i] = SSDP_BIG;
            g->ssd_y[i] = 0;
        }
    }

    for (int z = z0; z <= z1; z++) {
        for (int x = x0; x <= x1; x++) {
            size_t i = (size_t)z * g->w + x;
            if (g->flags[i] & (RT_CELL_BLOCKED_TERRAIN | RT_CELL_BLOCKED_BUILDING)) {
                g->ssd_x[i] = 0; g->ssd_y[i] = 0;
            } else {
                g->ssd_x[i] = SSDP_BIG; g->ssd_y[i] = 0;
            }
        }
    }
    ssdp_propagate_rect(g, x0, z0, x1, z1, 1);
    ssdp_write_clearance(g, x0, z0, x1, z1);
    g->clearance_valid = 1;   /* 区域已与 flags 对齐（其余区域本来就有效） */
    return 0;
}

/* ================================================================ 连通分量 */
static int32_t comp_new(RtGrid *g)
{
    if (g->component_count >= g->component_cap) {
        int32_t ncap = g->component_cap * 2;
        if (alloc_components(g, ncap) != RT_OK) return -1;
    }
    int32_t id = g->component_count++;
    g->component_size[id] = 0;
    g->component_rep[id] = -1;
    g->active_components++;
    return id;
}

void rt_grid_rebuild_components_full(RtGrid *g)
{
    if (!g) return;
    size_t n = (size_t)g->w * (size_t)g->h;
    for (size_t i = 0; i < n; i++) g->component[i] = -1;
    g->component_count = 0;
    g->active_components = 0;

    static const int DX[8] = { 1, -1, 0, 0, 1, 1, -1, -1 };
    static const int DZ[8] = { 0, 0, 1, -1, 1, -1, 1, -1 };

    for (int z = 0; z < g->h; z++) {
        for (int x = 0; x < g->w; x++) {
            size_t s = (size_t)z * g->w + x;
            if (g->component[s] >= 0) continue;
            if (!rt_grid_walkable(g, x, z)) continue;

            int32_t id = comp_new(g);
            if (id < 0) return;

            int head = 0, tail = 0;
            g->bfs_queue[tail++] = (int32_t)s;
            g->component[s] = id;
            g->component_size[id] = 1;
            g->component_rep[id] = (int32_t)s;

            while (head < tail) {
                int32_t c = g->bfs_queue[head++];
                int cx = (int)(c % g->w);
                int cz = (int)(c / g->w);
                for (int d = 0; d < 8; d++) {
                    int nx = cx + DX[d], nz = cz + DZ[d];
                    if (!rt_grid_in_bounds(g, nx, nz)) continue;
                    size_t nc = (size_t)nz * g->w + nx;
                    if (g->component[nc] >= 0) continue;
                    if (!rt_grid_walkable(g, nx, nz)) continue;
                    if (d >= 4) {   /* 防穿角，与 A* 一致 */
                        if (!rt_grid_walkable(g, cx + DX[d], cz)) continue;
                        if (!rt_grid_walkable(g, cx, cz + DZ[d])) continue;
                    }
                    g->component[nc] = id;
                    g->component_size[id]++;
                    g->bfs_queue[tail++] = (int32_t)nc;
                }
            }
        }
    }
}

/* ---- merge：新解锁的格把若干分量连起来 ---- */
/* 取一个**确实属于 comp** 的格子作为重标起点。
 *
 * component_rep[] 会失效：rep 所在的格子被后建的建筑压掉时，detach_blocked 只把
 * component 置 -1，不会更新 rep。旧代码直接拿 rep 当起点，会把一个 **blocked**
 * 格改写成 to（顺带给它 +1 计数）—— 分区被静默污染，且全量对拍才看得见。
 * 正常路径 O(1)；失效时 O(w*h) 扫一次并回写，罕见。 */
static int32_t comp_find_rep(RtGrid *g, int32_t comp)
{
    size_t n = (size_t)g->w * (size_t)g->h;
    int32_t rep = g->component_rep[comp];
    if (rep >= 0 && (size_t)rep < n && g->component[rep] == comp) return rep;

    for (size_t i = 0; i < n; i++) {
        if (g->component[i] != comp) continue;
        g->component_rep[comp] = (int32_t)i;
        g->relabel_rep_rescan++;
        return (int32_t)i;
    }
    g->component_rep[comp] = -1;
    g->component_size[comp] = 0;      /* 空分量：顺手把漂移的计数归零 */
    return -1;
}

/* ---- 分量重标：把 from 的整片改成 to（O(from 的格子数)） ----
 * 返回 1 = 成功；0 = 队列/容量异常（调用方降级全量）。 */
static int relabel_component(RtGrid *g, int32_t from, int32_t to)
{
    if (from == to) return 1;
    int32_t rep = comp_find_rep(g, from);
    if (rep < 0) return 1;             /* from 已经是空分量 */

    size_t cap = (size_t)g->w * g->h;
    int head = 0, tail = 0;
    g->bfs_queue[tail++] = rep;
    g->component[rep] = to;
    g->component_size[to]++;

    while (head < tail) {
        int32_t c = g->bfs_queue[head++];
        int cx = (int)(c % g->w), cz = (int)(c / g->w);
        for (int e = 0; e < 8; e++) {
            int nx = cx + DX8[e], nz = cz + DZ8[e];
            if (!rt_grid_in_bounds(g, nx, nz)) continue;
            size_t nc = (size_t)nz * g->w + nx;
            if (g->component[nc] != from) continue;
            g->component[nc] = to;
            g->component_size[to]++;
            if ((size_t)tail >= cap) return 0;
            g->bfs_queue[tail++] = (int32_t)nc;
        }
    }
    g->component_size[from] = 0;
    g->component_rep[from] = -1;
    if (g->active_components > 0) g->active_components--;
    return 1;
}

/* ---- merge：新解锁的格把若干分量连起来 ----
 * 返回 1 = 成功；0 = 无法安全增量（调用方降级全量）。
 *
 * M4.6-P3 的事实：一次移除解锁的格子**不一定连成一块** —— 建筑底下可能压着地形
 * 障碍或别的建筑，解锁后是好几块互不相连的空地。旧实现把所有新格无条件写进
 * 同一个 target，造出「一个分量里含互不相连的格子」（M3 起潜伏，差分测试在
 * 「10000 次随机编辑后的 8x8 移除」上抓到）。P3 先用「多块就降级全量」兜住；
 * 这里换成真正的修法：**按连通块分别处理**。
 *
 *   把新格按 8-连通（防穿角）切成 patch；每个 patch 与它邻接的已有分量合成一组，
 *   组内最大分量保留 id、其余重标过来，最后把 patch 的格写进该组。
 *
 * 为什么这与全量重建逐格等价：没有新格参与时旧分量的内部连通性不变（移除只会
 * 增加可走格），所以新的等价类 = 「旧分量 + 新格」这张图上按同一邻接规则的连通块。
 * 一个 patch 内的格互相连通；两个旧分量只可能经某个 patch 相连 —— 正是这里合并的。
 *
 * 复杂度：O(新解锁格 + 被合并的较小分量)，与地图总面积无关。 */
static int components_merge_in_dirty(RtGrid *g, RtGridDirty *d)
{
    int32_t new_cells[4096];
    int32_t patch[4096];          /* 当前块的格（bfs_queue 会被 relabel 复用，必须拷出） */
    int nnew = 0;

    /* 1. 收集本次新解锁的格（free 且尚未分配分量） */
    for (int z = d->z0; z <= d->z1; z++) {
        for (int x = d->x0; x <= d->x1; x++) {
            if (!rt_grid_walkable(g, x, z)) continue;
            size_t i = (size_t)z * g->w + x;
            if (g->component[i] >= 0) continue;
            if (nnew >= 4096) return 0;          /* 区域太大 -> 降级全量 */
            new_cells[nnew++] = (int32_t)i;
            g->component[i] = -2;                /* 待定 */
        }
    }
    if (nnew == 0) return 1;                     /* 实际没有解锁（仍被别的建筑覆盖） */

    /* 2. 逐块处理。scan 单调前进（处理过的格 component >= 0），整体仍是 O(nnew)。 */
    int scan = 0, npatch_total = 0;
    for (;;) {
        while (scan < nnew && g->component[new_cells[scan]] >= 0) scan++;
        if (scan >= nnew) break;

        /* 2a. 洪泛出这一块（防穿角，与全量重建语义一致；-2 待定 / -3 已收） */
        int head = 0, tail = 0;
        int32_t start = new_cells[scan];
        g->component[start] = -3;
        g->bfs_queue[tail++] = start;
        while (head < tail) {
            int32_t c = g->bfs_queue[head++];
            int cx = (int)(c % g->w), cz = (int)(c / g->w);
            for (int e = 0; e < 8; e++) {
                int nx = cx + DX8[e], nz = cz + DZ8[e];
                if (!rt_grid_in_bounds(g, nx, nz)) continue;
                size_t ni = (size_t)nz * g->w + nx;
                if (g->component[ni] != -2) continue;
                if (e >= 4) {
                    if (!rt_grid_walkable(g, cx + DX8[e], cz)) continue;
                    if (!rt_grid_walkable(g, cx, cz + DZ8[e])) continue;
                }
                g->component[ni] = -3;
                g->bfs_queue[tail++] = (int32_t)ni;
            }
        }
        for (int k = 0; k < tail; k++) patch[k] = g->bfs_queue[k];
        int npatch = tail;
        npatch_total++;

        /* 2b. 这一块邻接的已有分量（去重，最多 16 个） */
        int32_t touched[16];
        int ntouched = 0;
        for (int k = 0; k < npatch; k++) {
            int32_t c = patch[k];
            int cx = (int)(c % g->w), cz = (int)(c / g->w);
            for (int e = 0; e < 8; e++) {
                int nx = cx + DX8[e], nz = cz + DZ8[e];
                if (!rt_grid_in_bounds(g, nx, nz)) continue;
                if (!rt_grid_walkable(g, nx, nz)) continue;
                if (e >= 4) {   /* 防穿角：与连通域定义保持一致 */
                    if (!rt_grid_walkable(g, cx + DX8[e], cz)) continue;
                    if (!rt_grid_walkable(g, cx, cz + DZ8[e])) continue;
                }
                int32_t cid = g->component[(size_t)nz * g->w + nx];
                if (cid < 0) continue;           /* -2/-3 = 新格（同块，或角上并不相连的另一块） */
                int dup = 0;
                for (int m = 0; m < ntouched; m++)
                    if (touched[m] == cid) { dup = 1; break; }
                if (dup) continue;
                if (ntouched >= 16) {
                    g->merge_multipatch_fallbacks++;
                    return 0;                    /* 单块邻接分量过多 -> 降级全量 */
                }
                touched[ntouched++] = cid;
            }
        }

        /* 2c. 合并这一块碰到的分量：最大的保留 id（少重标），孤立则新建 */
        int32_t target;
        if (ntouched == 0) {
            target = comp_new(g);
            if (target < 0) return 0;
        } else {
            target = touched[0];
            for (int k = 1; k < ntouched; k++)
                if (g->component_size[touched[k]] > g->component_size[target])
                    target = touched[k];
            for (int k = 0; k < ntouched; k++) {
                int32_t other = touched[k];
                if (other == target) continue;
                if (!relabel_component(g, other, target)) return 0;
            }
            g->merge_detected_count++;           /* 这一块确实把已有分量接了起来 */
        }

        /* 2d. 这一块的格归入 target */
        for (int k = 0; k < npatch; k++) {
            int32_t c = patch[k];
            g->component[c] = target;
            g->component_size[target]++;
            if (g->component_rep[target] < 0) g->component_rep[target] = c;
        }
    }

    if (npatch_total > 1) g->merge_multipatch_count++;
    return 1;
}
/* ---- 并查集（多源 BFS 分组用，规模 <= 64） ---- */
static int uf_root(int *parent, int x)
{
    while (parent[x] != x) {
        parent[x] = parent[parent[x]];
        x = parent[x];
    }
    return x;
}

/* 多源 BFS：判断同一分量的 n 个 seed 是否仍两两连通。
 * 返回 1 = 连通（可提前早停）；0 = 不连通。
 *
 * 为什么不用「单源 BFS 遍历整个分量」：
 *   分量可能有 20 万格，而 seeds 往往只隔几条街。多源 BFS 在所有 seed 处
 *   同时起跑，一旦合并成一组就停 —— 遍历量通常只有几十~几百格。
 *   首版单源 BFS + 固定 96 格 limit，导致 2x2 建筑也要 3.4 ms（占 8ms 预算 42%）。 */
static int group_still_connected(RtGrid *g, int32_t comp,
                                 const int32_t *seeds, int n,
                                 int lx0, int lz0, int lx1, int lz1,
                                 int max_visited)
{
    if (n <= 1) return 1;

    int parent[256];
    for (int i = 0; i < n; i++) parent[i] = i;
    int groups = n;

    size_t cap = (size_t)g->w * g->h;
    int head = 0, tail = 0;

    /* owner 编码：component = -(4 + owner)，与 -1/-2/-3 不冲突 */
    for (int i = 0; i < n; i++) {
        if ((size_t)tail >= cap) return 0;
        g->component[seeds[i]] = (int32_t)(-(4 + i));
        g->bfs_queue[tail++] = seeds[i];
    }

    while (head < tail && groups > 1) {
        /* 访问预算：不连通时会遍历整个可达区域（可能是整张图）。
         * 超过预算就返回「不确定」，交给 component_split_relabel 做精确分组
         * （那一步本来就要全遍历，重复计入没有意义）。 */
        if (max_visited > 0 && tail > max_visited) {
            for (int k = 0; k < tail; k++) {
                int32_t cc = g->bfs_queue[k];
                if (g->component[cc] <= -4) g->component[cc] = comp;
            }
            return 0;
        }
        int32_t c = g->bfs_queue[head++];
        int owner = -(int)g->component[c] - 4;
        int cx = (int)(c % g->w), cz = (int)(c / g->w);
        for (int e = 0; e < 8; e++) {
            int nx = cx + DX8[e], nz = cz + DZ8[e];
            if (nx < lx0 || nx > lx1 || nz < lz0 || nz > lz1) continue;
            if (!rt_grid_walkable(g, nx, nz)) continue;
            /* 防穿角：必须与 rt_grid_rebuild_components_full 语义一致。
             * 首版漏了这三行，BFS 会"穿过"对角缝隙，把已 split 的两块判成连通。 */
            if (e >= 4) {
                if (!rt_grid_walkable(g, cx + DX8[e], cz)) continue;
                if (!rt_grid_walkable(g, cx, cz + DZ8[e])) continue;
            }
            size_t nc = (size_t)nz * g->w + nx;
            int32_t v = g->component[nc];
            if (v <= -4) {                         /* 已访问，比较 owner */
                int other = -(int)v - 4;
                int ra = uf_root(parent, owner);
                int rb = uf_root(parent, other);
                if (ra != rb) { parent[rb] = ra; groups--; }
                continue;
            }
            if (v != comp) continue;               /* 别的分量 / -1 blocked */
            g->component[nc] = (int32_t)(-(4 + owner));
            if ((size_t)tail >= cap) break;        /* 防御：不应发生 */
            g->bfs_queue[tail++] = (int32_t)nc;
        }
    }

    /* 还原所有临时标记 */
    for (int k = 0; k < tail; k++) {
        int32_t c = g->bfs_queue[k];
        if (g->component[c] <= -4) g->component[c] = comp;
    }
    return groups == 1;
}
/* ============================================================================
 * M3.1 增量 split：Affected Component Reconstruction
 *
 * 前提：group_still_connected() 已判定「该分量的 seeds 在几何上不连通」。
 * 做法：只对**这一个受影响分量**做分组重建：
 *   1) 从各 seed 出发分组 BFS（遍历该分量成员，防穿角语义与全量一致）
 *   2) 处理「完全被围住、不接触 dirty 外圈」的成员（如环形障碍中的洞）
 *   3) 最大组**保留旧 id**（ID 稳定性：最大概率被上层缓存引用）
 *   4) 其余组分配新 id，重写 component[] / size / rep
 *
 * 成本：O(受影响分量的格子数)，**与地图总面积无关**。
 * 返回 1 = 已重标；0 = 组数超限/内存异常（调用方降级全量）。
 * ==========================================================================*/
static int component_split_relabel(RtGrid *g, int32_t old_id,
                                   const int32_t *seeds, int nseeds)
{
    uint8_t *lab = g->split_label;
    if (!lab) return 0;

    size_t n = (size_t)g->w * (size_t)g->h;
    memset(lab, 0, n);

    int ngroups = 0;

    /* 1. 从 seeds 出发分组 BFS（只走 component == old_id 的格） */
    for (int i = 0; i < nseeds; i++) {
        int32_t s = seeds[i];
        if (s < 0 || (size_t)s >= n) continue;
        if (lab[s]) continue;
        if (g->component[s] != old_id) continue;
        if (ngroups >= 250) return 0;

        ngroups++;
        lab[s] = (uint8_t)ngroups;
        int head = 0, tail = 0;
        g->bfs_queue[tail++] = s;
        while (head < tail) {
            int32_t c = g->bfs_queue[head++];
            int cx = (int)(c % g->w), cz = (int)(c / g->w);
            for (int e = 0; e < 8; e++) {
                int nx = cx + DX8[e], nz = cz + DZ8[e];
                if (!rt_grid_in_bounds(g, nx, nz)) continue;
                if (!rt_grid_walkable(g, nx, nz)) continue;
                if (e >= 4) {   /* 防穿角：与全量重建语义一致 */
                    if (!rt_grid_walkable(g, cx + DX8[e], cz)) continue;
                    if (!rt_grid_walkable(g, cx, cz + DZ8[e])) continue;
                }
                size_t nc = (size_t)nz * g->w + nx;
                if (g->component[nc] != old_id) continue;
                if (lab[nc]) continue;
                lab[nc] = (uint8_t)ngroups;
                g->bfs_queue[tail++] = (int32_t)nc;
            }
        }
    }

    /* 2. 统计已覆盖的成员数；若小于**真实**成员数，说明有「被完全围住」的成员
     *
     * M4.6-P3 修正：这里原来比的是 g->component_size[old_id] —— 那是增量维护的计数，
     * 经过上万次编辑后会与真实格子数漂移（merge/split 的加减、以及 blocked 格归属的
     * 边角情况）。一旦漂移成「偏大」，这个 if 会被跳过，被围住的成员就不会单独成组，
     * 分区与全量重建不一致（test_incremental 在 10000 次编辑后的大编辑阶段抓到）。
     * 现在用同一次扫描里的实际计数，不再依赖那个会漂移的量。 */
    int cnt[256];
    memset(cnt, 0, sizeof(cnt));
    long covered = 0, actual = 0;
    for (size_t i = 0; i < n; i++) {
        if (g->component[i] == old_id) actual++;
        if (!lab[i]) continue;
        cnt[lab[i]]++;
        covered++;
    }

    if (covered < actual) {
        /* 这些成员不接触 dirty 外圈（例如环形障碍中间的洞被新建筑封死），
         * 必须单独成组，否则会与主组错误共用同一个 id。 */
        for (size_t i = 0; i < n; i++) {
            if (g->component[i] != old_id) continue;
            if (lab[i]) continue;
            if (ngroups >= 250) return 0;

            ngroups++;
            lab[i] = (uint8_t)ngroups;
            int head = 0, tail = 0;
            g->bfs_queue[tail++] = (int32_t)i;
            while (head < tail) {
                int32_t c = g->bfs_queue[head++];
                int cx = (int)(c % g->w), cz = (int)(c / g->w);
                for (int e = 0; e < 8; e++) {
                    int nx = cx + DX8[e], nz = cz + DZ8[e];
                    if (!rt_grid_in_bounds(g, nx, nz)) continue;
                    if (!rt_grid_walkable(g, nx, nz)) continue;
                    if (e >= 4) {
                        if (!rt_grid_walkable(g, cx + DX8[e], cz)) continue;
                        if (!rt_grid_walkable(g, cx, cz + DZ8[e])) continue;
                    }
                    size_t nc = (size_t)nz * g->w + nx;
                    if (g->component[nc] != old_id) continue;
                    if (lab[nc]) continue;
                    lab[nc] = (uint8_t)ngroups;
                    g->bfs_queue[tail++] = (int32_t)nc;
                }
            }
            cnt[ngroups] = 0;
            for (size_t j = 0; j < n; j++)
                if (lab[j] == (uint8_t)ngroups) cnt[ngroups]++;
        }
    }

    if (ngroups <= 0) return 1;                 /* 没有成员（不可能），无操作 */
    if (ngroups == 1) return 1;                 /* 检测阶段的预算提前退出，实际仍连通 */

    /* 3. 最大组保留旧 id（ID 稳定性策略） */
    int keep = 1;
    for (int k = 2; k <= ngroups; k++)
        if (cnt[k] > cnt[keep]) keep = k;

    /* 4. 其余组分配新 id（单调递增，不复用旧 id，避免 ABA） */
    int32_t newid[256];
    for (int k = 0; k <= ngroups; k++) newid[k] = old_id;
    for (int k = 1; k <= ngroups; k++) {
        if (k == keep) { newid[k] = old_id; continue; }
        newid[k] = comp_new(g);
        if (newid[k] < 0) return 0;
    }

    /* 5. 重写 component / size / rep */
    g->component_size[old_id] = 0;
    g->component_rep[old_id] = -1;
    long relabeled = 0;
    for (size_t i = 0; i < n; i++) {
        if (!lab[i]) continue;
        int32_t id = newid[lab[i]];
        g->component[i] = id;
        g->component_size[id]++;
        if (g->component_rep[id] < 0) g->component_rep[id] = (int32_t)i;
        relabeled++;
    }
    g->split_relabel_cells += (uint32_t)relabeled;
    if (ngroups >= 3) g->split_multiway_count++;
    return 1;
}

/* ---- split 检测 + 就地重标 ----
 * 返回 0  = 无 split（或已就地重标成功）
 * 返回 -1 = 无法安全处理（调用方降级全量）
 *
 * 与 M2 的区别：M2 一旦确认 split 就返回「无法证明」→ 全量 25~30ms；
 * M3 改为「只重建受影响的那个分量」，成本与分量大小相关、与地图总面积无关。 */
static int components_split_and_relabel(RtGrid *g, RtGridDirty *d,
                                        const int32_t *lost, int nlost,
                                        struct RtNavJob **job_out)
{
    if (job_out) *job_out = NULL;
    typedef struct { int32_t comp; int n; int32_t seeds[256]; } CompGroup;
    CompGroup groups[16];
    int ngroups = 0;

    /* 1. 收集 dirty 外圈的可走格，按分量分组；同一分量在 ring 内先聚簇，每簇一个 seed。
     *
     * 为什么要聚簇：≥24x24 的编辑，外圈 3 格内同一个分量常有 300~800 个格子，
     * 而 seeds 是固定数组（256），超了就整块降级全量（4.6 ms）。
     *
     * 为什么聚簇是**等价**的（这次把论证落到邻接关系上）：
     *   · 聚簇用的边与全量重建**完全同一条规则**（8 邻域 + 防穿角），所以簇内任意
     *     两格之间存在一条**只经过 ring 格**的路径；
     *   · ring 格在本次编辑中不会被覆盖（编辑只发生在 dirty 内），那条路径编辑后
     *     依然可走 —— 簇内两格必属同一块；
     *   · 于是每簇留一个代表就是充分的：分裂出的任何一块只要含 ring 格，就含它
     *     所在簇的代表，不会被漏判。
     *   · 反过来「每一块都含至少一个 ring 格」也成立：一块里的格子若要和别的块
     *     在编辑前连通，路径必须穿过 dirty 外那圈 3 格厚的 ring。
     *
     * 上一轮同类修法失败的原因正是第一点：用**普通 8-连通**聚簇，斜对角的两个
     * ring 格在建筑凸角处被并成一簇，但全量重建的防穿角规则并不认为它们连通，
     * 于是角落里那块丢掉了唯一的代表 -> 漏判 split（test_incremental iter 1476）。
     *
     * RING = 3：只取 1 圈时，若门的一侧紧邻障碍，外圈只能看到另一侧的 seed，
     * 会误判成「不可能 split」（S7 的 1 格门就被这个坑漏判过）。 */
    uint8_t *cl = g->split_label;          /* w*h：0 = 非 ring 格；k = 簇 k（1 起） */
    if (!cl) return -1;

    int rx0 = d->x0 - 3, rz0 = d->z0 - 3, rx1 = d->x1 + 3, rz1 = d->z1 + 3;
    if (rx0 < 0) rx0 = 0;
    if (rz0 < 0) rz0 = 0;
    if (rx1 >= g->w) rx1 = g->w - 1;
    if (rz1 >= g->h) rz1 = g->h - 1;

    int cl_parent[250];
    int32_t cl_rep[250];
    int ncl = 0, fail = 0;

    /* 行主序扫描：只需与「已扫过的 4 个邻居」求并（标准一趟连通标记） */
    static const int PX4[4] = { -1, -1, 0, 1 };
    static const int PZ4[4] = {  0, -1, -1, -1 };

    for (int z = rz0; z <= rz1 && !fail; z++) {
        for (int x = rx0; x <= rx1; x++) {
            int inside = (x >= d->x0 && x <= d->x1 && z >= d->z0 && z <= d->z1);
            if (inside) continue;
            if (!rt_grid_walkable(g, x, z)) continue;
            int32_t cid = g->component[(size_t)z * g->w + x];
            if (cid < 0) continue;

            /* 必要条件：分量要 split，必然有格子从 free 变 blocked。
             * 只按 RING 邻域收集 seeds 会把「旁边根本没被碰到的大分量」也拉进来，
             * 然后为证明它仍连通而跑一遍全分量 BFS（B4 实测 0.6 -> 21 ms）。 */
            int affected_comp = 0;
            for (int q = 0; q < nlost; q++) if (lost[q] == cid) { affected_comp = 1; break; }
            if (!affected_comp) continue;

            int gi = -1;
            for (int k = 0; k < ngroups; k++)
                if (groups[k].comp == cid) { gi = k; break; }
            if (gi < 0) {
                if (ngroups >= 16) {
                    /* 归因：这 16 个组里有多少个 n==1？n==1 的组永远不会 split
                     * （单个 seed 不存在「断开」），却占着槽位。若它们占多数，
                     * 说明失败是「噪声小岛吃槽位」，而不是真的需要 >16 个可分裂分量。 */
                    int single = 0;
                    for (int q = 0; q < ngroups; q++) if (groups[q].n == 1) single++;
                    g->split_ring_single_at_fail = (uint32_t)single;
                    g->split_fail_ring++;
                    fail = 1;
                    break;
                }
                gi = ngroups++;
                groups[gi].comp = cid;
                groups[gi].n = 0;
            }

            /* 与已扫描的邻居求并（对角必须过防穿角，与全量重建一致） */
            int root = -1;
            for (int e = 0; e < 4; e++) {
                int nx = x + PX4[e], nz = z + PZ4[e];
                if (nx < rx0 || nx > rx1 || nz < rz0 || nz > rz1) continue;
                if (cl[(size_t)nz * g->w + nx] == 0) continue;
                if (g->component[(size_t)nz * g->w + nx] != cid) continue;
                if (PX4[e] != 0 && PZ4[e] != 0) {
                    if (!rt_grid_walkable(g, nx, z)) continue;
                    if (!rt_grid_walkable(g, x, nz)) continue;
                }
                int r = uf_root(cl_parent, (int)cl[(size_t)nz * g->w + nx] - 1);
                if (root < 0) root = r;
                else if (root != r) cl_parent[r] = root;   /* 并到先扫到的簇 */
            }

            if (root < 0) {
                if (ncl >= 250 || groups[gi].n >= 256) {
                    g->split_fail_seeds++;
                    fail = 1;
                    break;
                }
                root = ncl++;
                cl_parent[root] = root;
                cl_rep[root] = (int32_t)((size_t)z * g->w + x);
                groups[gi].seeds[groups[gi].n++] = cl_rep[root];
            }
            cl[(size_t)z * g->w + x] = (uint8_t)(root + 1);
        }
    }

    /* 清掉本轮的簇标记（只清 ring 矩形，O(ring)） */
    for (int z = rz0; z <= rz1; z++)
        memset(cl + (size_t)z * g->w + rx0, 0, (size_t)(rx1 - rx0 + 1));

    if (fail) return -1;

    if (ngroups == 0) return 0;   /* 周围没有连通分量 -> 不可能 split */

    /* 2. 每组独立判定；不连通的组就地重标 */
    int lx0 = d->x0 - RT_SPLIT_LOCAL_RADIUS;
    int lz0 = d->z0 - RT_SPLIT_LOCAL_RADIUS;
    int lx1 = d->x1 + RT_SPLIT_LOCAL_RADIUS;
    int lz1 = d->z1 + RT_SPLIT_LOCAL_RADIUS;
    if (lx0 < 0) lx0 = 0;
    if (lz0 < 0) lz0 = 0;
    if (lx1 >= g->w) lx1 = g->w - 1;
    if (lz1 >= g->h) lz1 = g->h - 1;

    for (int k = 0; k < ngroups; k++) {
        if (groups[k].n <= 1) continue;
        if (group_still_connected(g, groups[k].comp, groups[k].seeds, groups[k].n,
                                  lx0, lz0, lx1, lz1, 4096)) {
            continue;             /* 仍连通，这个分量不受影响 */
        }
        /* 大分量：交给可暂停的 Job（不再同步阻塞整帧） */
        if (job_out && g->component_size[groups[k].comp] > RT_JOB_SPLIT_THRESHOLD) {
            RtNavJob *j = rt_navjob_create(g, g->revision + 1u, groups[k].comp,
                                           groups[k].seeds, groups[k].n,
                                           g->component_size[groups[k].comp],
                                           d->chunk_mask);
            if (j) {
                g->pending_comp = groups[k].comp;
                *job_out = j;
                return 1;          /* 有 job，未完成 */
            }
        }
        /* 小分量：同步重标（M3.1 路径） */
        if (!component_split_relabel(g, groups[k].comp, groups[k].seeds, groups[k].n)) {
            g->split_fail_relabel++;
            return -1;            /* 组数超限 / 内存异常 -> 降级 */
        }
        g->split_detected_count++;
#ifdef M2_TRACE
        printf("[split] comp=%d seeds=%d -> relabeled (cells=%u)\n",
               groups[k].comp, groups[k].n, g->split_relabel_cells);
#endif
    }
    return 0;
}


/* 把 dirty 区域内「从 free 变 blocked」的格从原分量摘掉，
 * 并记录**哪些分量真的丢了格子**（split 的必要条件）。
 * 返回丢失格子的分量个数（写进 lost，最多 16 个）。
 * out_overflow（可空）：丢失格子的分量超过 16 个 -> lost[] 被截断。
 * 这是**正确性**信号：没被记录的分量不会被 split 检测覆盖，调用方必须降级全量。 */
static int detach_blocked(RtGrid *g, const RtGridDirty *d, int32_t *lost, int *out_overflow)
{
    int nlost = 0, overflow = 0;
    for (int z = d->z0; z <= d->z1; z++) {
        for (int x = d->x0; x <= d->x1; x++) {
            if (rt_grid_walkable(g, x, z)) continue;
            size_t i = (size_t)z * g->w + x;
            int32_t cid = g->component[i];
            if (cid < 0) continue;
            if (g->component_size[cid] > 0) g->component_size[cid]--;
            g->component[i] = -1;
            int seen = 0;
            for (int q = 0; q < nlost; q++) if (lost[q] == cid) { seen = 1; break; }
            if (!seen) {
                if (nlost < 16) lost[nlost++] = cid;
                else { overflow = 1; g->detach_lost_overflow++; }
            }
        }
    }
    if (out_overflow) *out_overflow = overflow;
    return nlost;
}

int rt_grid_apply_dirty(RtGrid *g, RtGridDirty *d)
{
    if (!g || !d) return RT_ERR_INVALID;

    /* 1. clearance 区域重算（含降级判定） */
    int pad_hit_cap = (d->pad >= RT_SSEDT_MAX_PAD);
    if (rt_grid_rebuild_clearance_region(g, d->cx0, d->cz0, d->cx1, d->cz1)) {
        /* 边界向量显示影响半径超出重算范围 -> 本次增量不可信 */
        pad_hit_cap = 1;
    }

    /* 2. connectivity */
    int need_full = 0;
    int committed_by_job = 0;   /* job 的 commit 已经 bump 过版本，避免重复 */

    if (d->may_split && !d->may_merge) {
        int32_t lost[16];
        int lost_overflow = 0;
        int nlost = detach_blocked(g, d, lost, &lost_overflow);
        /* lost[] 截断 -> 有分量没被 split 检测覆盖，连通标签可能停在错误状态。
         * 以前这里是静默截断（只计数），现在直接降级全量：正确性优先。 */
        if (lost_overflow) need_full = 1;
        /* split 检测（必须在摘掉之后做：seeds 只取仍可走的）
         * 同步语义：若产生 Job，这里直接跑完并提交，保持 M2/M3.1 的调用契约。 */
        struct RtNavJob *job = NULL;
        if (components_split_and_relabel(g, d, lost, nlost, &job) < 0) need_full = 1;
        if (job) {
            while (!rt_navjob_step(job, g, 1 << 24)) {
                if (job->state == RT_JOB_STALE || job->state == RT_JOB_CANCELLED) break;
            }
            if (rt_navjob_commit(job, g) != RT_OK) need_full = 1;
            else committed_by_job = 1;
            rt_navjob_destroy(job);
        }
    } else if (d->may_merge && !d->may_split) {
        if (!components_merge_in_dirty(g, d)) need_full = 1;
    } else {
        /* 混合编辑或不明确：全量 */
        need_full = 1;
    }

    if (pad_hit_cap) need_full = 1;

    if (need_full) {
        int32_t comps_before = g->component_count;
        rt_grid_rebuild_clearance_full(g);
        rt_grid_rebuild_components_full(g);
        if (g->component_count > comps_before) g->split_detected_count++;
        g->full_rebuild_count++;
        g->version++;
        /* 全量重建 => 所有 chunk 都变过。不记账会让 Route/Region 以为地图没动，
         * 继续用失效的走廊（T9 抓到的另一处）。 */
        rt_grid_note_commit_all(g);
        return RT_ERR_NOT_FOUND;   /* 语义：本次降级为全量 */
    }

    g->version++;
    if (!committed_by_job) rt_grid_note_commit(g, d->chunk_mask);

    /* id 空间压缩（GC）：split 分配新 id 而 merge 只释放不回收，
     * 长时间运行会让 component_count 单调增长。当历史 id 远多于活跃分量
     * 且超出扁平余量时，做一次全量重编号（O(w*h)，只在阈值触发）。
     * 重编号会让**所有** component_id 语义变化 -> label_epoch++，旧引用全部失效。 */
    if (g->component_count > 4 * g->active_components + 1000) {
        rt_grid_rebuild_components_full(g);
        g->id_compaction_count++;
        g->label_epoch++;
    }
    return RT_OK;
}

int rt_grid_apply_dirty_async(RtGrid *g, RtGridDirty *d, struct RtNavJob **job_out)
{
    if (job_out) *job_out = NULL;
    if (!g || !d) return RT_ERR_INVALID;

    int pad_hit_cap = (d->pad >= RT_SSEDT_MAX_PAD);
    if (rt_grid_rebuild_clearance_region(g, d->cx0, d->cz0, d->cx1, d->cz1)) {
        pad_hit_cap = 1;   /* 边界向量显示影响半径超出重算范围 */
    }
    if (pad_hit_cap) {
        /* 不能只重建 clearance：flags 已经变了，component 必须同步追上，
         * 否则会留下「blocked 但 component >= 0」的脏格（C1 抓到的另一处）。 */
        rt_grid_rebuild_clearance_full(g);
        rt_grid_rebuild_components_full(g);
        g->full_rebuild_count++;
        g->version++;
        rt_grid_note_commit_all(g);
        return RT_ERR_NOT_FOUND;
    }

    /* 非 split（merge / 无变化）走同步路径：它们本来就很快 */
    if (!(d->may_split && !d->may_merge)) {
        return rt_grid_apply_dirty(g, d);
    }

    int32_t lost[16];
    int lost_overflow = 0;
    int nlost = detach_blocked(g, d, lost, &lost_overflow);
    if (lost_overflow) {
        /* 同同步路径：lost[] 截断就无法保证 split 检测完整 -> 降级全量 */
        rt_grid_rebuild_clearance_full(g);
        rt_grid_rebuild_components_full(g);
        g->full_rebuild_count++;
        g->version++;
        rt_grid_note_commit_all(g);
        return RT_ERR_NOT_FOUND;
    }

    struct RtNavJob *job = NULL;
    int r = components_split_and_relabel(g, d, lost, nlost, &job);
    if (r < 0) {
        rt_grid_rebuild_clearance_full(g);
        rt_grid_rebuild_components_full(g);
        g->full_rebuild_count++;
        g->version++;
        return RT_ERR_NOT_FOUND;
    }
    if (job) {
        /* 不推进：调用方按预算 step，最后 commit（commit 会 ++version / ++nav_epoch） */
        *job_out = job;
        return RT_OK;
    }
    g->version++;
    rt_grid_note_commit(g, d->chunk_mask);
    return RT_OK;
}

/* ---- 兼容旧接口 ---- */
int rt_grid_add_building(RtGrid *g, int x0, int z0, int bw, int bh)
{
    RtGridDirty d;
    if (rt_grid_add_building_dirty(g, x0, z0, bw, bh, &d) != RT_OK) return RT_ERR_INVALID;
    (void)rt_grid_apply_dirty(g, &d);
    return RT_OK;
}

int rt_grid_remove_building(RtGrid *g, int x0, int z0, int bw, int bh)
{
    RtGridDirty d;
    if (rt_grid_remove_building_dirty(g, x0, z0, bw, bh, &d) != RT_OK) return RT_ERR_INVALID;
    (void)rt_grid_apply_dirty(g, &d);
    return RT_OK;
}

void rt_grid_rebuild_all(RtGrid *g)
{
    if (!g) return;
    size_t n = (size_t)g->w * (size_t)g->h;
    for (size_t i = 0; i < n; i++) sync_flags_cell(g, i);
    rt_grid_rebuild_clearance_full(g);
    rt_grid_rebuild_components_full(g);
    g->version++;
    rt_grid_note_commit_all(g);   /* 全量重建 = 所有 chunk 都变了 */
}

/* ================================================================ 查询 */
float rt_grid_clearance_m(const RtGrid *g, int x, int z)
{
    if (!g || !rt_grid_in_bounds(g, x, z)) return 0.f;
    return (float)g->clearance[(size_t)z * g->w + x] * 0.01f;
}

float rt_grid_clearance_world(const RtGrid *g, float wx, float wz)
{
    if (!g) return 0.f;
    return rt_grid_clearance_m(g, rt_grid_cell_x(g, wx), rt_grid_cell_z(g, wz));
}

int rt_grid_obb_clear_fast(const RtGrid *g, const RtObb2 *o)
{
    /* clearance 是派生数据。编辑后到重算完成之间它是过期的，
     * 此时用它证明"这里没有障碍"会直接导致穿墙 —— 必须拒绝快路径。 */
    if (!g->clearance_valid) return 0;
    int cx = rt_grid_cell_x(g, o->center.x);
    int cz = rt_grid_cell_z(g, o->center.z);
    if (!rt_grid_in_bounds(g, cx, cz)) return 0;
    float need = rt_obb_circumradius(o) + 1.5f * g->cell;
    return rt_grid_clearance_m(g, cx, cz) >= need;
}

int rt_grid_obb_blocked(const RtGrid *g, const RtObb2 *o)
{
    if (!g || !o) return 1;

    RtAabb2 bb = rt_obb_aabb(o);
    float world_w = (float)g->w * g->cell;
    float world_h = (float)g->h * g->cell;
    if (bb.min_x < 0.f || bb.min_z < 0.f || bb.max_x > world_w || bb.max_z > world_h)
        return 1;

    if (rt_grid_obb_clear_fast(g, o)) return 0;

    int x0 = rt_grid_cell_x(g, bb.min_x);
    int z0 = rt_grid_cell_z(g, bb.min_z);
    int x1 = rt_grid_cell_x(g, bb.max_x - 1e-4f);
    int z1 = rt_grid_cell_z(g, bb.max_z - 1e-4f);

    for (int z = z0; z <= z1; z++) {
        for (int x = x0; x <= x1; x++) {
            if (rt_grid_walkable(g, x, z)) continue;
            RtAabb2 cb;
            cb.min_x = (float)x * g->cell;
            cb.max_x = cb.min_x + g->cell;
            cb.min_z = (float)z * g->cell;
            cb.max_z = cb.min_z + g->cell;
            if (rt_obb_overlaps_aabb(o, &cb)) return 1;
        }
    }
    return 0;
}

int32_t rt_grid_component_at(const RtGrid *g, int x, int z)
{
    if (!g || !rt_grid_in_bounds(g, x, z)) return -1;
    return g->component[(size_t)z * g->w + x];
}

int rt_grid_same_component(const RtGrid *g, int x0, int z0, int x1, int z1)
{
    int32_t a = rt_grid_component_at(g, x0, z0);
    int32_t b = rt_grid_component_at(g, x1, z1);
    if (a < 0 || b < 0) return 0;
    return a == b;
}

int rt_grid_same_component_q(const RtGrid *g, int x0, int z0, int x1, int z1,
                             RtQueryState *st)
{
    if (st) *st = RT_QUERY_UNREACHABLE;
    if (!g) return 0;
    int32_t a = rt_grid_component_at(g, x0, z0);
    int32_t b = rt_grid_component_at(g, x1, z1);
    if (a < 0 || b < 0) {
        if (st) *st = RT_QUERY_UNREACHABLE;
        return 0;
    }
    /* 任务书 §十五：依赖正在重建的分量时，必须返回 PENDING 而不是错误的"可达/不可达" */
    if (a == g->pending_comp || b == g->pending_comp) {
        if (st) *st = RT_QUERY_PENDING;
        return 0;
    }
    int same = (a == b);
    if (st) *st = same ? RT_QUERY_VALID : RT_QUERY_UNREACHABLE;
    return same;
}

void rt_grid_note_commit(RtGrid *g, const uint32_t *chunk_mask)
{
    if (!g) return;
    g->nav_epoch++;
    if (!chunk_mask) { rt_grid_note_commit_all(g); return; }
    for (int c = 0; c < RT_CHUNK_N; c++)
        if (chunk_mask[c >> 5] & (1u << (c & 31)))
            g->chunk_ver[c] = g->chunk_ver[c] + 1;
}

void rt_grid_note_edit(RtGrid *g, const uint32_t *chunk_mask)
{
    if (!g || !chunk_mask) return;
    for (int c = 0; c < RT_CHUNK_N; c++)
        if (chunk_mask[c >> 5] & (1u << (c & 31)))
            g->edit_ver[c] = g->edit_ver[c] + 1;
}

void rt_grid_dirty_merge(RtGrid *g, RtGridDirty *out,
                         const RtGridDirty *a, const RtGridDirty *b)
{
    if (!g || !out || !a || !b) return;
    int x0 = a->x0 < b->x0 ? a->x0 : b->x0;
    int z0 = a->z0 < b->z0 ? a->z0 : b->z0;
    int x1 = a->x1 > b->x1 ? a->x1 : b->x1;
    int z1 = a->z1 > b->z1 ? a->z1 : b->z1;
    int may_split = a->may_split || b->may_split;
    int may_merge = a->may_merge || b->may_merge;
    dirty_fill_rect(g, out, x0, z0, x1, z1, may_merge);
    out->may_split = may_split;
    out->may_merge = may_merge;
    /* 掩码取并集（dirty_fill_rect 已按合并后的 bbox 重算，这里再 OR 一次以防 padding 不同） */
    for (int i = 0; i < RT_CHUNK_MASK_WORDS; i++) out->chunk_mask[i] |= a->chunk_mask[i] | b->chunk_mask[i];
    out->chunk_mask_any = 1;
}

void rt_grid_note_commit_all(RtGrid *g)
{
    if (!g) return;
    g->nav_epoch++;
    for (int c = 0; c < RT_CHUNK_N; c++) g->chunk_ver[c] = g->chunk_ver[c] + 1;
}

int rt_grid_job_scratch(RtGrid *g, int32_t **queue, uint8_t **label)
{
    if (!g || !queue || !label) return RT_ERR_INVALID;
    size_t n = (size_t)g->w * (size_t)g->h;
    if (!g->job_queue) {
        g->job_queue = (int32_t *)malloc(n * sizeof(int32_t));
        if (!g->job_queue) return RT_ERR_CAPACITY;
    }
    if (!g->job_label) {
        g->job_label = (uint8_t *)calloc(n, 1);
        if (!g->job_label) return RT_ERR_CAPACITY;
    }
    *queue = g->job_queue;
    *label = g->job_label;
    return RT_OK;
}

int32_t rt_grid_alloc_component_id(RtGrid *g)
{
    return comp_new(g);
}

void rt_grid_set_component_sizes(RtGrid *g, int32_t id, int32_t size, int32_t rep)
{
    if (!g || id < 0 || id >= g->component_cap) return;
    g->component_size[id] = size;
    g->component_rep[id] = rep;
}

void rt_grid_stats(const RtGrid *g, RtGridStats *out)
{
    if (!g || !out) return;
    memset(out, 0, sizeof(*out));
    size_t n = (size_t)g->w * (size_t)g->h;

    float csum = 0.f;
    for (size_t i = 0; i < n; i++) {
        if (g->flags[i] & (RT_CELL_BLOCKED_TERRAIN | RT_CELL_BLOCKED_BUILDING)) {
            out->blocked_cells++;
            continue;
        }
        out->walkable_cells++;
        float c = (float)g->clearance[i] * 0.01f;
        csum += c;
        if (c > out->clearance_max_m) out->clearance_max_m = c;
    }
    out->clearance_mean_m = out->walkable_cells
                          ? csum / (float)out->walkable_cells : 0.f;
    out->component_count = g->active_components;
    for (int32_t i = 0; i < g->component_count; i++)
        if (g->component_size[i] > out->largest_component_cells)
            out->largest_component_cells = g->component_size[i];
}

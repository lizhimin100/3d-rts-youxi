/* ============================================================================
 * test_m8.c -- 队形（FR-FOR）
 *
 *   T1 16 人从散乱位置收敛到 4×4 方阵（ORCA 走位 + 保持间距）
 *   T2 slot 分配：Hilbert + 贪心 + 2-opt 后，路径交叉数不高于「按索引硬分」
 *   T3 窄通道降级：矩形放不下 -> 纵队
 *   T4 朝向平滑与「先原地转」
 *   T5 成本与确定性
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_form.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", (m)); } } while (0)

#define MAXA 512
static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;
static RtFormation FM;

/* 两段相交（不含共享端点） */
static int seg_cross(RtVec2 a, RtVec2 b, RtVec2 c, RtVec2 d)
{
    float d1 = (b.x - a.x) * (c.z - a.z) - (b.z - a.z) * (c.x - a.x);
    float d2 = (b.x - a.x) * (d.z - a.z) - (b.z - a.z) * (d.x - a.x);
    float d3 = (d.x - c.x) * (a.z - c.z) - (d.z - c.z) * (a.x - c.x);
    float d4 = (d.x - c.x) * (b.z - c.z) - (d.z - c.z) * (b.x - c.x);
    return ((d1 > 0.f) != (d2 > 0.f)) && ((d3 > 0.f) != (d4 > 0.f));
}

static int count_crossings(const RtVec2 *pos, const int *slot_of, int n)
{
    int k = 0;
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++) {
            RtVec2 a = pos[i], b = rt_form_slot_world(&FM, slot_of[i]);
            RtVec2 c = pos[j], d = rt_form_slot_world(&FM, slot_of[j]);
            if (seg_cross(a, b, c, d)) k++;
        }
    return k;
}

static void agent_set(int i, float x, float z, float r, float sp)
{
    memset(&AG[i], 0, sizeof(AG[i]));
    AG[i].pos = rt_v2(x, z);
    AG[i].pref_vel = rt_v2(0.f, 0.f);
    AG[i].radius = r;
    AG[i].max_speed = sp;
    AG[i].fp = r * 2.f;
    AG[i].share = 0.5f;
    AG[i].inv_mass = 1.f;
}

/* -----------------------------------------------------------------------------
 * T1：收敛到方阵
 * --------------------------------------------------------------------------*/
static void t1_converge(void)
{
    printf("\n[T1] 16 人收敛到 4x4 方阵\n");
    static RtGrid G;
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    rt_grid_rebuild_all(&G);

    rt_local_destroy(&LC);
    rt_local_init(&LC, 256.f, 256.f, MAXA, 4.5f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);

    rt_form_destroy(&FM);
    rt_form_init(&FM, 64);
    rt_form_build(&FM, RT_FORM_RECT, 16, 1.0f, 1.2f);   /* pitch 2.2 m */
    rt_form_set_anchor(&FM, rt_v2(120.f, 128.f));
    rt_form_set_yaw(&FM, 0.f, 1.f, NULL);

    const int n = 16;
    uint32_t s = 7u;
    for (int i = 0; i < n; i++) {
        s = s * 1664525u + 1013904223u;
        float x = 90.f + (float)(s >> 16 & 63) * 0.5f;
        s = s * 1664525u + 1013904223u;
        float z = 100.f + (float)(s >> 16 & 63) * 0.5f;
        agent_set(i, x, z, 0.5f, 2.0f);
    }
    RtVec2 pos[MAXA];
    int slot_of[MAXA];
    for (int i = 0; i < n; i++) pos[i] = AG[i].pos;
    int got = rt_form_assign(&FM, pos, n, slot_of);

    float worst = 0.f;
    for (int step = 0; step < 1800; step++) {
        for (int i = 0; i < n; i++) {
            RtVec2 tgt = rt_form_slot_world(&FM, slot_of[i]);
            RtVec2 d = rt_v2_sub(tgt, AG[i].pos);
            float l = rt_v2_len(d);
            AG[i].pref_vel = (l > 0.1f) ? rt_v2_mul(d, 2.0f / l) : rt_v2(0.f, 0.f);
        }
        (void)rt_local_step(&LC, AG, n, &G, 1.f / 30.f);
        worst = 0.f;
        for (int i = 0; i < n; i++) {
            float e = rt_v2_dist(AG[i].pos, rt_form_slot_world(&FM, slot_of[i]));
            if (e > worst) worst = e;
        }
        if (worst < 0.35f) break;
    }

    RtVec2 ps[MAXA];
    for (int i = 0; i < n; i++) ps[i] = AG[i].pos;
    float coh = rt_form_cohesion(&FM, ps, slot_of, n, 25.f);

    /* 最小间距 */
    float mind = 1e9f;
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++) {
            float d = rt_v2_dist(AG[i].pos, AG[j].pos);
            if (d < mind) mind = d;
        }
    printf("  assigned=%d worst_slot_err=%.2f m cohesion=%.2f min_pair_dist=%.2f m\n",
           got, worst, coh, mind);
    OK(got == n, "T1 every unit got a slot");
    OK(worst < 0.8f, "T1 everyone reached its slot (<0.8 m)");
    OK(coh > 0.90f, "T1 cohesion > 0.90");
    OK(mind > 1.6f, "T1 members keep spacing (no collapse into one point)");
    rt_form_destroy(&FM);
    rt_grid_destroy(&G);
}

/* -----------------------------------------------------------------------------
 * T2：分配质量（交叉数）
 * --------------------------------------------------------------------------*/
static void t2_crossings(void)
{
    printf("\n[T2] slot 分配：交叉数\n");
    rt_form_destroy(&FM);
    rt_form_init(&FM, 256);
    rt_form_build(&FM, RT_FORM_RECT, 50, 1.0f, 0.5f);    /* pitch 1.5 */
    rt_form_set_anchor(&FM, rt_v2(128.f, 128.f));
    rt_form_set_yaw(&FM, 0.f, 1.f, NULL);

    const int n = 50;
    RtVec2 pos[MAXA];
    uint32_t s = 99u;
    for (int i = 0; i < n; i++) {
        s = s * 1664525u + 1013904223u;
        pos[i].x = 60.f + (float)(s >> 16 & 127);
        s = s * 1664525u + 1013904223u;
        pos[i].z = 60.f + (float)(s >> 16 & 127);
    }
    int naive[MAXA], opt[MAXA];
    for (int i = 0; i < n; i++) naive[i] = i;
    (void)rt_form_assign(&FM, pos, n, opt);

    int c0 = count_crossings(pos, naive, n);
    int c1 = count_crossings(pos, opt, n);
    printf("  crossings: index-order=%d  hilbert+greedy+2opt=%d\n", c0, c1);
    OK(c1 <= c0, "T2 assignment does not increase crossings");
    OK(c1 * 2 <= c0 + 1, "T2 assignment at least halves the crossings");
    rt_form_destroy(&FM);
}

/* -----------------------------------------------------------------------------
 * T3：窄通道降级
 * --------------------------------------------------------------------------*/
static void t3_narrow(void)
{
    printf("\n[T3] 窄通道降级（矩形 -> 纵队）\n");
    rt_form_destroy(&FM);
    rt_form_init(&FM, 64);
    rt_form_build(&FM, RT_FORM_RECT, 16, 1.0f, 1.0f);    /* pitch 2, 4 列 = 8 m */
    rt_form_set_anchor(&FM, rt_v2(50.f, 50.f));
    rt_form_set_yaw(&FM, 0.f, 1.f, NULL);

    int cols0 = FM.cols;
    RtFormKind k1 = rt_form_degrade_for_width(&FM, 12.f);   /* 够宽 */
    int cols_wide = FM.cols;
    RtFormKind k2 = rt_form_degrade_for_width(&FM, 5.f);    /* 不够 */
    int cols_narrow = FM.cols;
    printf("  rect cols=%d | width 12 -> %s cols=%d | width 5 -> %s cols=%d rows=%d\n",
           cols0, k1 == RT_FORM_COLUMN ? "COLUMN" : "RECT", cols_wide,
           k2 == RT_FORM_COLUMN ? "COLUMN" : "RECT", cols_narrow, FM.rows);

    float d01 = rt_v2_dist(rt_form_slot_world(&FM, 0), rt_form_slot_world(&FM, 1));
    OK(k1 == RT_FORM_RECT, "T3 12 m is wide enough for a 4-wide rect");
    OK(k2 == RT_FORM_COLUMN, "T3 5 m degrades to a column");
    OK(cols_narrow == 1, "T3 column has exactly one column");
    OK(fabsf(d01 - FM.pitch_x) < 1e-3f, "T3 column spacing equals pitch");
    rt_form_destroy(&FM);
}

/* -----------------------------------------------------------------------------
 * T4：朝向
 * --------------------------------------------------------------------------*/
static void t4_yaw(void)
{
    printf("\n[T4] 朝向平滑 / 先原地转\n");
    RtFormConfig cfg;
    rt_form_config_default(&cfg);
    rt_form_destroy(&FM);
    rt_form_init(&FM, 8);
    rt_form_build(&FM, RT_FORM_RECT, 4, 1.f, 1.f);
    rt_form_set_yaw(&FM, 0.f, 1.f, &cfg);

    rt_form_set_yaw(&FM, 3.14159265f * 0.5f, 0.1f, &cfg);   /* 目标 90°，dt=0.1 */
    float y1 = FM.yaw;
    int need1 = rt_form_needs_turn_in_place(&FM, &cfg);
    for (int i = 0; i < 40; i++) rt_form_set_yaw(&FM, 3.14159265f * 0.5f, 0.1f, &cfg);
    float y2 = FM.yaw;
    int need2 = rt_form_needs_turn_in_place(&FM, &cfg);

    printf("  after 0.1s yaw=%.1f deg (turn_in_place=%d) -> after 4s yaw=%.1f deg (%d)\n",
           y1 * 57.2958f, need1, y2 * 57.2958f, need2);
    OK(y1 > 0.12f && y1 < 0.20f, "T4 yaw advances at ~90 deg/s");
    OK(need1 == 1, "T4 big heading change asks for turn-in-place");
    OK(fabsf(y2 - 1.5707963f) < 0.02f, "T4 yaw reaches the target");
    OK(need2 == 0, "T4 turn-in-place clears once aligned");
    rt_form_destroy(&FM);
}

/* -----------------------------------------------------------------------------
 * T5：成本 + 确定性
 * --------------------------------------------------------------------------*/
static void t5_cost_det(void)
{
    printf("\n[T5] 成本与确定性\n");
    rt_form_destroy(&FM);
    rt_form_init(&FM, 512);
    rt_form_build(&FM, RT_FORM_RECT, 100, 1.0f, 1.0f);
    rt_form_set_anchor(&FM, rt_v2(128.f, 128.f));
    rt_form_set_yaw(&FM, 0.3f, 1.f, NULL);

    static RtVec2 pos[MAXA];
    uint32_t s = 5u;
    for (int i = 0; i < 100; i++) {
        s = s * 1664525u + 1013904223u;
        pos[i].x = 40.f + (float)(s >> 16 & 127);
        s = s * 1664525u + 1013904223u;
        pos[i].z = 40.f + (float)(s >> 16 & 127);
    }
    int a1[MAXA], a2[MAXA];
    double t0 = now_ms();
    (void)rt_form_assign(&FM, pos, 100, a1);
    double t_assign = now_ms() - t0;

    t0 = now_ms();
    volatile float acc = 0.f;
    for (int k = 0; k < 1000; k++)
        for (int i = 0; i < 100; i++) acc += rt_form_slot_world(&FM, i).x;
    double t_world = (now_ms() - t0) / 1000.0;
    (void)acc;

    (void)rt_form_assign(&FM, pos, 100, a2);
    int same = memcmp(a1, a2, sizeof(int) * 100) == 0;
    printf("  assign 100 units = %.3f ms | slot_world x100 = %.4f ms | deterministic=%s\n",
           t_assign, t_world, same ? "yes" : "NO");
    OK(t_assign < 8.0, "T5 assignment stays under 8 ms (command-time only)");
    OK(t_world < 0.02, "T5 slot_world is cheap enough for the tick");
    OK(same, "T5 assignment is deterministic");
    rt_form_destroy(&FM);
}

int main(void)
{
    timer_init();
    printf("=== M8 tests: formation (FR-FOR) ===\n");
    t1_converge();
    t2_crossings();
    t3_narrow();
    t4_yaw();
    t5_cost_det();
    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    if (g_fail == 0) printf("ALL PASS (%d asserts)\n", g_pass);
    rt_form_destroy(&FM);
    rt_local_destroy(&LC);
    return g_fail == 0 ? 0 : 1;
}

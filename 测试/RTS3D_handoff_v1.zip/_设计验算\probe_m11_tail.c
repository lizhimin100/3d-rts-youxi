/* ============================================================================
 * probe_m11_tail.c -- 诊断：为什么总有 1~3 个单位永远过不去
 *
 * 不是测试，是取证。复刻 test_m11 的对照组（不开仲裁），跑到预算上限，
 * 然后把「没穿过去的单位」的全部状态打出来：位置、速度、期望速度、
 * 卡死状态机、到入口的距离、周围 1.5 m 内有几个人。
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_stuck.h"
#include "rt_yield.h"
#include "rt_corridor.h"
#include "rt_region.h"
#include "rt_group.h"
#include "rt_unit.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
static void timer_init(void) {}
static double now_ms(void) { return 0.0; }
#endif

#define MAXA 1024
#define WALL_X0  128
#define WALL_X1  138
#define TUN_Z0   126.0f
#define TUN_Z1   128.0f
#define COR_X0   128.0f
#define COR_X1   139.0f

static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;
static RtStuckCtx SC;
static RtYieldCtx YC;
static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static RtUnitId IDS[MAXA];
static int TEAM[MAXA];
static int N = 0;

static void build_world(void)
{
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int x = WALL_X0; x <= WALL_X1; x++)
        for (int z = 0; z < 256; z++)
            if (z < (int)TUN_Z0 || z >= (int)TUN_Z1)
                rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);

    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);

    rt_local_destroy(&LC);
    rt_local_init(&LC, 256.f, 256.f, MAXA, 4.0f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);
    rt_stuck_destroy(&SC);
    {
        RtStuckConfig cfg;
        rt_stuck_config_default(&cfg);
        cfg.permanent_time = 60.f;
        rt_stuck_init(&SC, MAXA, &cfg);
    }
    rt_yield_destroy(&YC);
    rt_yield_init(&YC, MAXA, NULL, &G);
}

static void spawn_team(int team, int n, float x0, float z0, int cols)
{
    for (int k = 0; k < n && N < MAXA; k++) {
        float x = x0 + (float)(k % cols) * 1.6f;
        float z = z0 + (float)(k / cols) * 1.6f;
        RtUnitId id = rt_units_spawn(&US, rt_v3(x, 0.f, z), RT_FP_SMALL);
        if (id == RT_UNIT_ID_NONE) break;
        IDS[N] = id;
        TEAM[N] = team;
        memset(&AG[N], 0, sizeof(AG[N]));
        AG[N].pos = rt_v2(x, z);
        AG[N].radius = 0.5f;
        AG[N].max_speed = 2.0f;
        AG[N].fp = 1.0f;
        AG[N].share = 0.5f;
        AG[N].inv_mass = 1.f;
        N++;
    }
}

int main(void)
{
    timer_init();
    printf("=== probe: tail unit forensics (control group, no arbitration) ===\n");

    const int nA = 60, nB = 60;
    build_world();
    spawn_team(0, nA, 28.f, 120.f, 10);
    spawn_team(1, nB, 206.f, 120.f, 10);

    const float dt = 1.f / 30.f;
    const RtVec2 goalA = rt_v2(206.f, 190.f);
    const RtVec2 goalB = rt_v2(28.f, 62.f);
    {
        RtUnitId a[MAXA], b[MAXA];
        int na = 0, nb = 0;
        for (int i = 0; i < N; i++) { if (TEAM[i] == 0) a[na++] = IDS[i]; else b[nb++] = IDS[i]; }
        (void)rt_gw_command(&W, &US, a, na, goalA, 0, RT_CLS_SMALL, 1);
        (void)rt_gw_command(&W, &US, b, nb, goalB, 0, RT_CLS_SMALL, 2);
    }

    RtVec2 prev[MAXA];
    for (int i = 0; i < N; i++) prev[i] = AG[i].pos;

    const int frames_max = 24000;
    for (int s = 0; s < frames_max; s++) {
        for (int i = 0; i < N; i++) {
            RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, IDS[i]);
            int gi = (int)ch->group[rt_unit_slot_index(IDS[i])] - 1;
            RtVec2 pref = rt_v2(0.f, 0.f);
            if (gi >= 0) {
                RtVec2 tgt;
                if (rt_gw_sample(&W, gi, AG[i].pos, &tgt) == RT_OK) {
                    RtVec2 d = rt_v2_sub(tgt, AG[i].pos);
                    float l = rt_v2_len(d);
                    if (l > 1e-3f) pref = rt_v2_mul(d, 2.0f / l);
                }
            }
            AG[i].pref_vel = pref;
        }
        rt_stuck_step(&SC, AG, N, &G, dt, NULL);
        rt_yield_step(&YC, AG, N, &G, dt, NULL, NULL);
        (void)rt_local_step(&LC, AG, N, &G, dt);
        (void)rt_gw_update(&W);

        /* 逐帧追踪「拐角震荡」的单位（跑满 400 s 之后才开始打印，避免刷屏） */
        if (s > 12000 && (s % 3) == 0) {
            for (int i = 0; i < N; i++) {
                if (TEAM[i] != 1) continue;
                if (AG[i].pos.x > COR_X0 - 2.f) continue;
                break;
            }
            int k = 109;
            if (k < N) {
                RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, IDS[k]);
                int gi2 = (int)ch->group[rt_unit_slot_index(IDS[k])] - 1;
                RtVec2 tgt2 = AG[k].pos;
                if (gi2 >= 0) (void)rt_gw_sample(&W, gi2, AG[k].pos, &tgt2);
                printf("    f=%5d pos=(%7.3f,%7.3f) tgt=(%6.2f,%6.2f) walk=%d pref=(%6.2f,%6.2f) vel=(%5.2f,%5.2f) lvl=%d\n",
                       s, AG[k].pos.x, AG[k].pos.z, tgt2.x, tgt2.z,
                       rt_grid_walkable(&G, (int)tgt2.x, (int)tgt2.z),
                       AG[k].pref_vel.x, AG[k].pref_vel.z,
                       AG[k].vel.x, AG[k].vel.z, (int)SC.u[k].level);
            }
        }

        if ((s % 900) == 0) {
            int crossA = 0, crossB = 0;
            for (int i = 0; i < N; i++) {
                if (TEAM[i] == 0) { if (AG[i].pos.x > COR_X1 + 2.f) crossA++; }
                else              { if (AG[i].pos.x < COR_X0 - 2.f) crossB++; }
            }
            printf("  [t=%5.0fs] crossed A=%2d B=%2d\n", (float)s * dt, crossA, crossB);
        }
        for (int i = 0; i < N; i++) prev[i] = AG[i].pos;
    }

    printf("\n-- tail units (not crossed) --\n");
    for (int i = 0; i < N; i++) {
        int crossed = (TEAM[i] == 0) ? (AG[i].pos.x > COR_X1 + 2.f)
                                     : (AG[i].pos.x < COR_X0 - 2.f);
        if (crossed) continue;
        RtStuckUnit *u = &SC.u[i];
        int nb_close = 0;
        for (int j = 0; j < N; j++) {
            if (j == i) continue;
            if (rt_v2_dist(AG[i].pos, AG[j].pos) < 1.5f) nb_close++;
        }
        int cx = (int)AG[i].pos.x, cz = (int)AG[i].pos.z;
        printf("  #%3d team=%d pos=(%6.2f,%6.2f) vel=(%5.2f,%5.2f) pref=(%5.2f,%5.2f)\n",
               i, TEAM[i], AG[i].pos.x, AG[i].pos.z,
               AG[i].vel.x, AG[i].vel.z, AG[i].pref_vel.x, AG[i].pref_vel.z);
        printf("       state=%-8s level=%d stuck_t=%.1f hits=%d blink=%d bay=%d "
               "walkable=%d clr=%.2f nb1.5=%d\n",
               rt_stuck_state_name((int)u->state), (int)u->level, u->stuck_time,
               (int)u->hits, (int)u->blocker, (int)u->bay_ok,
               rt_grid_walkable(&G, cx, cz), rt_grid_clearance_m(&G, cx, cz), nb_close);
    }

    printf("\n-- stuck stats --\n");
    printf("  episodes=%u resolved=%u permanent=%u held_samples=%u\n",
           SC.st.episodes, SC.st.resolved, SC.st.permanent_stuck, SC.st.held_samples);
    printf("  fires L1..L6 = ");
    for (int k = 1; k <= 6; k++) printf("%u ", SC.st.level_fires[k]);
    printf("\n  bay_found=%u bay_none=%u hook_missing=%u\n",
           SC.st.bay_found, SC.st.bay_none, SC.st.hook_missing);

    rt_stuck_destroy(&SC);
    rt_yield_destroy(&YC);
    rt_local_destroy(&LC);
    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return 0;
}

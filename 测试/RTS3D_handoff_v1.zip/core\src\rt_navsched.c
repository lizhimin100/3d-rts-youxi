/* ============================================================================
 * rt_navsched.c -- M3.7 调度器实现
 * ==========================================================================*/
#include "rt_navsched.h"
#include <string.h>

void rt_navsched_init(RtNavSched *s, RtGrid *g)
{
    if (!s) return;
    memset(s, 0, sizeof(*s));
    s->g = g;
}

void rt_navsched_shutdown(RtNavSched *s)
{
    if (!s) return;
    if (s->job) {
        rt_navjob_cancel(s->job);
        rt_navjob_destroy(s->job);
        s->job = NULL;
    }
    if (s->g) s->g->pending_comp = -1;
    s->has_pend = 0;
}

int rt_navsched_submit(RtNavSched *s, const RtGridDirty *d)
{
    if (!s || !s->g || !d) return RT_ERR_INVALID;
    s->stat_submit++;

    /* 正在跑的任务如果依赖被命中，就地取消；staging 清空，Active 一字未动。
     * 注意：取消不等于丢掉这次编辑 —— flags 已经是最新的，pending 会保留。 */
    if (s->job && rt_navjob_is_stale(s->job, s->g)) {
        rt_navjob_cancel(s->job);
        rt_navjob_destroy(s->job);
        s->job = NULL;
        s->g->pending_comp = -1;
        s->stat_cancel++;
        s->stat_coalesced++;
    }

    if (!s->has_pend) {
        s->pend = *d;
        s->has_pend = 1;
        s->pend_age = 0;
        if (s->job) s->pend_dirty_after_job = 1;
    } else {
        RtGridDirty merged;
        rt_grid_dirty_merge(s->g, &merged, &s->pend, d);
        s->pend = merged;
        s->stat_coalesced++;
        if (s->job) s->pend_dirty_after_job = 1;
        if (s->pend_age > (int)s->stat_max_pending_age)
            s->stat_max_pending_age = (uint32_t)s->pend_age;
    }
    return RT_OK;
}

int rt_navsched_tick(RtNavSched *s, int units)
{
    if (!s || !s->g) return 1;
    if (!s->job && !s->has_pend) return 1;
    if (units <= 0) units = 1;

    /* 1. 没有在跑的任务：从合并后的 dirty 启动一次 */
    if (!s->job) {
        struct RtNavJob *job = NULL;
        int rc = rt_grid_apply_dirty_async(s->g, &s->pend, &job);
        if (rc != RT_OK) {
            /* 降级为全量（返回 NOT_FOUND）时派生数据已在内部重建完毕 */
            s->has_pend = 0;
            s->stat_immediate++;
        } else if (!job) {
            s->has_pend = 0;          /* 同步完成（小编辑） */
            s->stat_immediate++;
        } else {
            s->job = job;
            s->stat_scheduled++;
            s->pend_dirty_after_job = 0;   /* 这份 pending 已被 job 吸收 */
        }
        if (!s->job) s->pend_age = 0;
    }

    /* 2. 推进 job */
    if (s->job) {
        int done = rt_navjob_step(s->job, s->g, units);
        if (done) {
            if (rt_navjob_commit(s->job, s->g) == RT_OK) {
                s->stat_commit++;
                /* 只有「pend 全部来自这次 job 的输入」才能清空；
                 * 否则说明 job 运行期间又来了编辑，必须继续追赶（§三十九 不丢更新）。 */
                if (!s->pend_dirty_after_job) {
                    s->has_pend = 0;
                    s->pend_age = 0;
                }
            } else {
                /* commit 被拒（stale）：**不丢更新**，pending 留在原地 */
                s->stat_stale++;
                s->has_pend = 1;
            }
            rt_navjob_destroy(s->job);
            s->job = NULL;
            if (s->has_pend) s->pend_age++;
        }
    }

    return (s->job == NULL && !s->has_pend) ? 1 : 0;
}

void rt_navsched_drain(RtNavSched *s)
{
    if (!s) return;
    int guard = 0;
    while (!rt_navsched_tick(s, 1 << 20) && guard++ < 100000) {}
}

/* ============================================================================
 * bench_m45.c -- M4.5：多支部队并存
 *
 * 场景：K 支部队各 100 人，均匀分布在半径 90 m 的环上，各去对面的目标。
 * 量四件事：
 *   1. 第 K 条命令的耗时（并存逻辑不能是 O(已有组数 × 成员数) 的平方爆炸）
 *   2. 命令结束后同时存活的组数
 *   3. 全量采样耗时（K×100 个单位 / 帧）
 *   4. 无编辑时 rt_gw_update 的耗时（应为 0 次重建）
 * 另外校验：每支部队的采样目标都朝自己的目标点（没有串组）。
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c bench/bench_m45.c -o bench_m45
 * ==========================================================================*/
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

#define PER_CMD 100
#define MAX_K   16

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;

static void world_reset(int dim)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_grid_init(&G, dim, dim, 1.0f);
}

static void world_build(void)
{
    rt_grid_rebuild_all(&G);
    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
}

/* 在一个锚点周围铺 n 个单位（10 列，1.2 m 间距） */
static int spawn_block(RtUnitId *ids, int n, float cx, float cz)
{
    int k = 0;
    for (int i = 0; i < n * 4 && k < n; i++) {
        float x = cx + (float)(i % 10) * 1.2f;
        float z = cz + (float)(i / 10) * 1.2f;
        int gx = rt_grid_cell_x(&G, x), gz = rt_grid_cell_z(&G, z);
        if (!rt_grid_walkable(&G, gx, gz)) continue;
        RtUnitId id = rt_units_spawn(&US, rt_v3(x, 0.f, z), RT_FP_SMALL);
        if (id != RT_UNIT_ID_NONE) ids[k++] = id;
    }
    return k;
}

int main(void)
{
    timer_init();
    printf("=== M4.5 bench: K concurrent move commands (100 units each) ===\n");
    printf("map 256x256, open (no terrain)\n");
    printf("\n  K   units  groups  new<=   cmd_med(ms)  cmd_max(ms)  update(ms)  sample(ms)  wrong degen  worst_back(m)\n");

    const float cx = 128.f, cz = 128.f, ring = 90.f;

    for (int K = 1; K <= MAX_K; K *= 2) {
        world_reset(256);
        world_build();

        static RtUnitId ids[MAX_K][PER_CMD];
        RtVec2 aim[MAX_K];
        int n[16];
        double t_all0 = now_ms();
        double ct[16];
        int max_new_groups = 0;
        for (int k = 0; k < K; k++) {
            float ang = 2.f * 3.14159265f * (float)k / (float)K;
            float ax = cx + cosf(ang) * ring, az = cz + sinf(ang) * ring;
            n[k] = spawn_block(ids[k], PER_CMD, ax - 6.f, az - 6.f);
            aim[k] = rt_v2(cx - cosf(ang) * ring * 0.85f, cz - sinf(ang) * ring * 0.85f);
            int g0 = W.group_count;
            double t0 = now_ms();
            rt_gw_command(&W, &US, ids[k], n[k], aim[k], 0, RT_CLS_SMALL, (uint32_t)k + 1);
            ct[k] = now_ms() - t0;
            int ng = W.group_count - g0;
            if (ng > max_new_groups) max_new_groups = ng;
        }
        double cmd_all = now_ms() - t_all0;
        /* 中位数 / 最大值：最后一条命令的耗时取决于它自己跨了几个区域，不代表趋势 */
        for (int a = 1; a < K; a++) {
            double v = ct[a];
            int b = a - 1;
            while (b >= 0 && ct[b] > v) { ct[b + 1] = ct[b]; b--; }
            ct[b + 1] = v;
        }
        double cmd_med = ct[K / 2];
        double cmd_max = ct[K - 1];
        int groups = W.group_count;

        double t0 = now_ms();
        int rebuilt = rt_gw_update(&W);
        double upd = now_ms() - t0;

        int total = 0;
        for (int k = 0; k < K; k++) total += n[k];

        /* 全量采样：每个单位走它自己 chunk->group 指定的组 */
        double best_sample = 1e30;
        int wrong = 0, degenerate = 0;
        float worst_back = 0.f;
        for (int rep = 0; rep < 7; rep++) {
            int bad = 0, deg = 0;
            float wb = 0.f;
            volatile float acc = 0.f;
            double ts = now_ms();
            for (int k = 0; k < K; k++) {
                for (int i = 0; i < n[k]; i++) {
                    RtVec3 p = rt_units_pos(&US, ids[k][i]);
                    const RtUnitChunk *c = rt_units_chunk_c(&US, ids[k][i]);
                    int gi = (int)c->group[rt_unit_slot_index(ids[k][i])] - 1;
                    RtVec2 tgt;
                    if (gi < 0 || gi >= W.group_count ||
                        rt_gw_sample(&W, gi, rt_v2(p.x, p.z), &tgt) != RT_OK) { bad++; continue; }
                    acc += tgt.x + tgt.z;
                    /* 方向校验：局部目标允许「小幅回退」（区域栅格的门户是折线，
                     * M4.4-A 已把回退容差定在 0.35 m；这里放宽到 2 m 才算错，
                     * 并单独记录最大回退量，见 17_M4.5_报告.md §6.3）。 */
                    RtVec2 d = rt_v2_sub(aim[k], rt_v2(p.x, p.z));
                    RtVec2 t = rt_v2_sub(tgt, rt_v2(p.x, p.z));
                    float tl = sqrtf(t.x * t.x + t.z * t.z);
                    float dl = sqrtf(d.x * d.x + d.z * d.z);
                    if (tl < 0.5f || dl < 1e-3f) { deg++; continue; }
                    float proj = (d.x * t.x + d.z * t.z) / dl;
                    if (proj < 0.f) {
                        float back = -proj;
                        if (back > wb) wb = back;
                        if (back > 2.0f) bad++;
                    }
                }
            }
            double dt = now_ms() - ts;
            if (dt < best_sample) { best_sample = dt; wrong = bad; degenerate = deg; worst_back = wb; }
            (void)acc;
        }

        printf("  %2d  %5d  %6d %8d %11.4f %10.4f  %10.4f  %10.4f  %9d %6d %9.2f%s\n",
               K, total, groups, max_new_groups, cmd_med, cmd_max, upd, best_sample,
               wrong, degenerate, worst_back, wrong ? "  <-- BAD" : "");
        (void)rebuilt;
    }

    printf("\n-- interpretation --\n");
    printf("  groups: K <= groups <= 2K (a 12x12 m block can span >4 regions -> a 2nd group)\n");
    printf("  cmd_med is flat in K; cmd_max spikes only when one block straddles >4 regions\n");
    printf("  (that command creates 2-3 groups => 2-3 A* builds, not a scan over all armies)\n");
    printf("  update(ms) ~ 0 rebuilds when nothing changed; sample grows linearly with units\n");
    printf("  worst_back: local targets may sit slightly behind (region-grid dogleg);\n");
    printf("              only >2 m counts as wrong (M4.4-A allows small back-steps)\n");

    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return 0;
}

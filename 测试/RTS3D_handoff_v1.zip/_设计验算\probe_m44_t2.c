/* 临时：T2 场景逐格轨迹（每换格打一行）。跑完即删。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;

static int seg_clear(RtVec2 a, RtVec2 b)
{
    float dx = b.x - a.x, dz = b.z - a.z;
    float len = sqrtf(dx * dx + dz * dz);
    int steps = (int)(len / 0.25f) + 1;
    for (int i = 0; i <= steps; i++) {
        float t = (float)i / (float)steps;
        int cx = rt_grid_cell_x(&G, a.x + dx * t), cz = rt_grid_cell_z(&G, a.z + dz * t);
        if (!rt_grid_walkable(&G, cx, cz)) return 0;
    }
    return 1;
}

int main(void)
{
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int i = 0; i < 8; i++)
        for (int t = 0; t < 2; t++)
            rt_grid_set_terrain(&G, 64 + i, 80 + i + t, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);

    RtVec2 s = rt_v2(20.5f, 83.5f);
    RtUnitId id = rt_units_spawn(&US, rt_v3(s.x, 0.f, s.z), RT_FP_SMALL);
    RtUnitId one[1] = { id };
    rt_gw_command(&W, &US, one, 1, rt_v2(230.5f, 83.5f), 0, RT_CLS_SMALL, 1);
    int gi = (int)((RtUnitChunk *)rt_units_chunk_c(&US, id))->group[rt_unit_slot_index(id)] - 1;

    RtRoute *rt = &W.groups[gi].routes[0].route;
    printf("n=%d goal=(%.1f,%.1f)\n", rt->n, W.groups[gi].goal_pos.x, W.groups[gi].goal_pos.z);
    for (int i = 0; i < rt->n; i++) {
        RtVec2 q = (i == rt->n - 1) ? W.groups[gi].goal_pos : rt->portal[i];
        if (W.groups[gi].routes[0].seg_block[i]) printf("  blocked seg[%d] (%0.1f,%.1f)\n", i, q.x, q.z);
    }

    RtVec2 p = s;
    int lastcx = -1, lastcz = -1, printed = 0;
    for (int i = 0; i < 6000; i++) {
        RtVec2 tgt;
        if (rt_gw_sample(&W, gi, p, &tgt) != RT_OK) { printf("ERR\n"); break; }
        int cx = rt_grid_cell_x(&G, p.x), cz = rt_grid_cell_z(&G, p.z);
        if ((cx != lastcx || cz != lastcz) && printed < 90) {
            printf("  step%04d cell=(%3d,%3d) pos=(%6.2f,%6.2f) tgt=(%6.2f,%6.2f) used=%u\n",
                   i, cx, cz, p.x, p.z, tgt.x, tgt.z, W.stats.fine_used);
            printed++;
            lastcx = cx; lastcz = cz;
        }
        RtVec2 d = rt_v2_sub(tgt, p);
        float len = rt_v2_len(d);
        if (len < 1e-4f) { printf("  STALL at (%0.2f,%.2f)\n", p.x, p.z); break; }
        float st = 0.2f;
        if (st > len) st = len;
        RtVec2 np = rt_v2_add(p, rt_v2_mul(d, st / len));
        if (!seg_clear(p, np)) { printf("  PEN at (%0.2f,%.2f)\n", p.x, p.z); break; }
        p = np;
        if (rt_gw_is_arrived(&W, gi, p, 1.5f)) { printf("  ARRIVED step %d\n", i); break; }
    }
    return 0;
}

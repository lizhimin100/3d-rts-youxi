/* ============================================================================
 * bench_m44.c -- M4.4：走廊推进语义 + 有界 fine flow 的成本 / 效果
 *
 * 四段：
 *   A. U 形陷阱（A 层单独生效，fine flow 不该被触发）
 *   B. 斜向薄墙（直线被挡）：fine off / on 的 stuck 率与到达步数
 *   C. 1000 单位：采样成本（开放 / 10% 噪声），fine flow 构建次数与窗口覆盖率
 *   D. 走廊段被封率 + fine flow 槽位/内存
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c bench/bench_m44.c -o bench_m44
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void t_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void t_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;

static void world_reset(int w)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_grid_init(&G, w, w, 1.0f);
}

static void world_build(void)
{
    rt_grid_rebuild_all(&G);
    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
}

static int seg_clear(RtVec2 a, RtVec2 b)
{
    float dx = b.x - a.x, dz = b.z - a.z;
    float len = sqrtf(dx * dx + dz * dz);
    int steps = (int)(len / 0.25f) + 1;
    for (int i = 0; i <= steps; i++) {
        float t = (float)i / (float)steps;
        int cx = rt_grid_cell_x(&G, a.x + dx * t), cz = rt_grid_cell_z(&G, a.z + dz * t);
        if (!rt_grid_walkable(&G, cx, cz)) return 0;
    }
    return 1;
}

typedef struct { int units, arrived, stuck, pen_units, steps_sum; } WalkAgg;

static WalkAgg walk_all(const RtUnitId *ids, int n, RtVec2 goal, int max_steps)
{
    WalkAgg a; memset(&a, 0, sizeof(a));
    a.units = n;
    for (int i = 0; i < n; i++) {
        RtVec3 p0 = rt_units_pos(&US, ids[i]);
        RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[i]);
        int gi = (int)ch->group[rt_unit_slot_index(ids[i])] - 1;
        RtVec2 p = rt_v2(p0.x, p0.z);
        int steps = 0, arrived = 0, pen = 0;
        for (int s = 0; s < max_steps && !arrived; s++) {
            RtVec2 tgt;
            if (gi < 0 || rt_gw_sample(&W, gi, p, &tgt) != RT_OK) break;
            RtVec2 d = rt_v2_sub(tgt, p);
            float len = rt_v2_len(d);
            if (len < 1e-4f) break;                     /* tgt==pos：记 stuck */
            float st = 0.2f;
            if (st > len) st = len;
            RtVec2 np = rt_v2_add(p, rt_v2_mul(d, st / len));
            if (!seg_clear(p, np)) { pen = 1; break; }
            p = np; steps++;
            if (rt_gw_is_arrived(&W, gi, p, 1.5f)) arrived = 1;
        }
        if (arrived) { a.arrived++; a.steps_sum += steps; }
        else         { a.stuck++; }
        if (pen) a.pen_units++;
    }
    return a;
}

/* ---------------------------------------------------------------- 场景 */
static void map_u_trap(void)
{
    world_reset(256);
    for (int z = 50; z <= 110; z++)
        for (int x = 90; x <= 140; x++) {
            int wall = (z == 50 || z == 110 || x == 90) ||
                       (x >= 110 && x <= 118 && z >= 70 && z <= 78);
            if (wall) rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
    world_build();
}

static void map_diagonal(int thick)
{
    world_reset(256);
    int x0 = 64, z0 = 80;
    for (int i = 0; i < 8; i++)
        for (int t = 0; t < thick; t++)
            rt_grid_set_terrain(&G, x0 + i, z0 + i + t, RT_CELL_BLOCKED_TERRAIN, 1);
    world_build();
}

static void map_noise(int permille, int with_wall)
{
    world_reset(256);
    if (permille > 0) {
        uint64_t st = 0xC0FFEEull;
        for (int z = 0; z < 256; z++)
            for (int x = 0; x < 256; x++) {
                uint64_t k = (st += 0x9E3779B97F4A7C15ull);
                k = (k ^ (k >> 30)) * 0xBF58476D1CE4E5B9ull;
                k = (k ^ (k >> 27)) * 0x94D049BB133111EBull;
                k ^= k >> 31;
                if ((k >> 40) % 1000 < (uint64_t)permille)
                    rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
            }
    }
    if (with_wall) {
        for (int z = 0; z < 256; z++)
            if (z != 128) rt_grid_set_terrain(&G, 128, z, RT_CELL_BLOCKED_TERRAIN, 1);
        for (int dz = -1; dz <= 1; dz++) {
            rt_grid_set_terrain(&G, 127, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
            rt_grid_set_terrain(&G, 128, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
            rt_grid_set_terrain(&G, 129, 128 + dz, RT_CELL_BLOCKED_TERRAIN, 0);
        }
    }
    world_build();
}

static int spawn_disc(RtUnitId *ids, int n, float cx, float cz, float r)
{
    int k = 0;
    for (int i = 0; i < n * 4 && k < n; i++) {
        float rad = r * sqrtf((float)i / (float)(n * 4));
        float ang = (float)i * 2.39996323f;
        int x = rt_grid_cell_x(&G, cx + cosf(ang) * rad);
        int z = rt_grid_cell_z(&G, cz + sinf(ang) * rad);
        if (!rt_grid_walkable(&G, x, z)) continue;
        RtUnitId id = rt_units_spawn(&US, rt_v3((float)x + 0.5f, 0.f, (float)z + 0.5f), RT_FP_SMALL);
        if (id != RT_UNIT_ID_NONE) ids[k++] = id;
    }
    return k;
}

static void row_agg(const char *tag, WalkAgg a, int fine_on)
{
    printf("  %-22s fine=%d units=%-4d arrived=%-4d stuck=%-3d (%.1f%%) pen_units=%-3d avg_steps=%.1f\n",
           tag, fine_on, a.units, a.arrived, a.stuck,
           a.units ? 100.0 * (double)a.stuck / (double)a.units : 0.0,
           a.pen_units, a.arrived ? (double)a.steps_sum / (double)a.arrived : 0.0);
}

static void scene_a(void)
{
    printf("\n-- A. U-shaped trap (4 units; corridor semantics only) --\n");
    map_u_trap();
    static RtUnitId ids[4];
    RtVec2 s[4] = { { 100.5f, 60.5f }, { 100.5f, 100.5f }, { 130.5f, 60.5f }, { 130.5f, 100.5f } };
    for (int i = 0; i < 4; i++)
        ids[i] = rt_units_spawn(&US, rt_v3(s[i].x, 0.f, s[i].z), RT_FP_SMALL);
    rt_gw_command(&W, &US, ids, 4, rt_v2(200.5f, 80.5f), 0, RT_CLS_SMALL, 1);
    uint32_t segs = W.stats.corridor_segments, blk = W.stats.corridor_blocked;
    WalkAgg a = walk_all(ids, 4, W.groups[0].goal_pos, 4000);
    row_agg("U trap", a, 1);
    printf("  segments=%u blocked=%u | fine builds=%u used=%u\n",
           segs, blk, W.stats.fine_builds, W.stats.fine_used);
}

static void scene_b(void)
{
    printf("\n-- B. diagonal wall crossing a region (straight line blocked) --\n");
    for (int thick = 1; thick <= 3; thick++) {
        for (int on = 0; on <= 1; on++) {
            map_diagonal(thick);
            rt_gw_set_fine_enabled(&W, on);
            static RtUnitId ids[4];
            RtVec2 s[4] = { { 20.5f, 76.5f }, { 20.5f, 83.5f }, { 20.5f, 90.5f }, { 30.5f, 83.5f } };
            for (int i = 0; i < 4; i++)
                ids[i] = rt_units_spawn(&US, rt_v3(s[i].x, 0.f, s[i].z), RT_FP_SMALL);
            rt_gw_command(&W, &US, ids, 4, rt_v2(230.5f, 84.5f), 0, RT_CLS_SMALL, 1);
            WalkAgg a = walk_all(ids, 4, W.groups[0].goal_pos, 6000);
            char tag[32]; snprintf(tag, sizeof(tag), "thick=%d", thick);
            row_agg(tag, a, on);
            printf("      segments=%u blocked=%u | fine builds=%u used=%u outside=%u rejected=%u\n",
                   W.stats.corridor_segments, W.stats.corridor_blocked,
                   W.stats.fine_builds, W.stats.fine_used,
                   W.stats.fine_outside, W.stats.fine_rejected);
        }
    }
}

static double sample_pass(const RtUnitId *ids, int n, volatile float *acc)
{
    double t0 = now_ms();
    for (int i = 0; i < n; i++) {
        RtVec3 p = rt_units_pos(&US, ids[i]);
        RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[i]);
        int gi = (int)ch->group[rt_unit_slot_index(ids[i])] - 1;
        RtVec2 tgt;
        if (gi >= 0 && rt_gw_sample(&W, gi, rt_v2(p.x, p.z), &tgt) == RT_OK) *acc += tgt.x;
    }
    return now_ms() - t0;
}

static void scene_c(void)
{
    printf("\n-- C. 1000 units: sampling cost, fine builds, window coverage --\n");
    printf("  M4.6-P1: 建场预算 = 1 次/帧（默认）。first = 命令后的第一次采样，steady = 后续 8 次中位\n");

    const char *names[2] = { "open map", "10% noise" };
    int perms[2] = { 0, 100 };
    int walls[2] = { 0, 1 };            /* 噪声图加墙 + 门：与 bench_m42 同图，首次遍历会建多个场 */
    for (int c = 0; c < 2; c++) {
        for (int budget = 1; budget >= -1; budget -= 2) {   /* 1 = 分帧，-1 = M4.4 旧行为 */
            map_noise(perms[c], walls[c]);
            rt_gw_set_fine_budget(&W, budget);
            static RtUnitId ids[1024];
            int n = spawn_disc(ids, 1000, 50.f, 60.f, 12.f);
            rt_gw_command(&W, &US, ids, n, rt_v2(210.5f, 190.5f), 0, RT_CLS_SMALL, 1);
            volatile float acc = 0.f;

            double first = sample_pass(ids, n, &acc);
            uint32_t b_first = W.stats.fine_builds;
            double samples[8];
            for (int rep = 0; rep < 8; rep++) samples[rep] = sample_pass(ids, n, &acc);

            /* 取中位（4 个值排序后取中间两个均值） */
            for (int a = 0; a < 8; a++) for (int b = a + 1; b < 8; b++)
                if (samples[b] < samples[a]) { double t = samples[a]; samples[a] = samples[b]; samples[b] = t; }
            double med = (samples[3] + samples[4]) * 0.5;

            uint32_t used = W.stats.fine_used, outside = W.stats.fine_outside;
            double cov = (used + outside) ? 100.0 * (double)used / (double)(used + outside) : 0.0;
            printf("  %-10s budget=%-3d first=%.4f ms (%u build) steady=%.4f ms | "
                   "total builds=%u skip=%u used=%u outside=%u cov=%.0f%%\n",
                   names[c], budget, first, b_first, med,
                   W.stats.fine_builds, W.stats.fine_budget_skip, used, outside, cov);
        }
    }

    printf("\n  (参考) 走廊段被封率与 fine 内存：\n");
    map_noise(100, 1);
    static RtUnitId ids2[1024];
    int n2 = spawn_disc(ids2, 1000, 50.f, 60.f, 12.f);
    rt_gw_command(&W, &US, ids2, n2, rt_v2(210.5f, 190.5f), 0, RT_CLS_SMALL, 1);
    volatile float acc2 = 0.f;
    (void)sample_pass(ids2, n2, &acc2);
    printf("            10%% noise: segments=%u blocked=%u (%.1f%%) | fine slots=%d KB=%.1f\n",
           W.stats.corridor_segments, W.stats.corridor_blocked,
           W.stats.corridor_segments ? 100.0 * (double)W.stats.corridor_blocked /
                                       (double)W.stats.corridor_segments : 0.0,
           rt_gw_fine_count(&W), (double)rt_gw_fine_bytes(&W) / 1024.0);
}

int main(void)
{
    t_init();
    printf("=== M4.4 bench: corridor progression + bounded fine flow ===\n");
    printf("fine window = %dx%d cells (target cell +/-%d), %d slots\n",
           RT_FINE_WIN, RT_FINE_WIN, RT_FINE_RADIUS, RT_FINE_SLOTS);

    scene_a();
    scene_b();
    scene_c();

    printf("\n-- notes --\n");
    printf("  stuck  = unit did not arrive within max_steps (tgt==pos or wall clip)\n");
    printf("  avg_steps = walking frames at 6 m/s @30 Hz (0.2 m per frame)\n");
    printf("  window coverage = fine_used / (fine_used + fine_outside):\n");
    printf("    share of blocked-segment samples whose standing cell is inside the 24x24 window\n");
    printf("  segment blocked rate = corridor segments whose portal-to-portal line crosses a wall\n");

    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return 0;
}

/* ============================================================================
 * rt_local.h -- LocalAvoidance 层：ORCA 互避 + 墙体约束（M5）
 *
 * 层级契约（CON-5）：本层**不认识 Navigation**。
 *   它只吃「期望速度 pref_vel」，不知道那是 A*、流场还是脚本给的。
 *   期望速度由 Simulation 层从 rt_gw_sample() 采到后填进来。
 *
 * 为什么墙不进 ORCA 半平面（设计裁定，01 §⑤）：
 *   把每格墙变成半平面会让线数从 2k 涨到 2k+几十，且与 clearance 快路径重复。
 *   做法是「ORCA 只处理单位之间，墙用 OBB 精确检查 + 逐轴滑动」：
 *   算完新速度后试着走一步，被挡就按 x / z 分解各试一次，都不行就停住。
 *   这样永不穿墙，且不会出现「为了躲人把自己挤进墙里」。
 *
 * 确定性（CON-8）：
 *   单位按索引顺序处理；邻居来自自建栅格的桶序（同一输入必然同一顺序），
 *   距离相同按索引小者优先。无哈希遍历、无指针排序。
 * ==========================================================================*/
#ifndef RT_LOCAL_H
#define RT_LOCAL_H

#include "rt_types.h"
#include "rt_grid.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 每个单位最多考虑多少个邻居。ORCA 的成本 ≈ O(N·k)，k=10 时 1000 单位实测 0.25 ms。 */
#define RT_LOCAL_MAX_NEIGHBORS 12
/* 半平面数上限：每个邻居 1 条 + LP3 的投影线余量 */
#define RT_LOCAL_MAX_LINES     (RT_LOCAL_MAX_NEIGHBORS + 8)

typedef struct {
    RtVec2 pos;
    RtVec2 vel;
    RtVec2 pref_vel;   /* 期望速度（调用方保证已按 max_speed 截断） */
    float  radius;     /* 内切圆半径 = footprint/2（ORCA 用） */
    float  max_speed;
    float  fp;         /* footprint（格宽），墙体检查用 */
    float  share;      /* 责任分担：0.5 = 各让一半；1 = 自己全让（对静止单位用） */
    float  inv_mass;   /* 0 = 不被推动（静止/建筑化单位）；1 = 普通 */
} RtLocalAgent;

typedef struct {
    /* 参数 */
    float neighbor_dist;    /* 邻居搜索半径（米）；必须 >= 2*max_radius */
    float time_horizon;     /* ORCA τ（秒），默认 2.0 */
    int   max_neighbors;    /* k，<= RT_LOCAL_MAX_NEIGHBORS */
    int   wall_slide;       /* 1 = 撞墙按轴滑动（默认）；0 = 撞墙即停（对照用） */
    int   wall_escape;      /* 1 = 滑动无效时绕 ±45°/±60°/±90° 蹭出去（默认，M17） */
    float wall_escape_m;    /* 蹭墙里程预算（米，默认 0.8）。漏桶：只有**正常行驶**
                             * 才回充，所以在封闭房间里蹭完就停 —— 这是 M6 T2 /
                             * M13 T3「不可达必须给出 GAVE_UP」的护栏（同 M13 的
                             * follow_max_dist：绕行必须有预算，否则永远在转圈）。 */
    float max_accel;        /* <=0 表示不限（按速度差一步到位） */

    /* 自建栅格（每步重建，计数排序，无 malloc） */
    float  cell;
    int    gw, gh;
    int   *start;           /* gw*gh+1 */
    int   *wr;              /* gw*gh（构建写指针） */
    int   *items;           /* max_agents */
    int   *cell_of;         /* max_agents */
    RtVec2 *newv;           /* max_agents：本步算出的速度（先算完再统一生效） */
    float *esc_budget;      /* max_agents：蹭墙里程预算（米，漏桶） */
    int    cap;

    /* 统计（不是装饰：每次降级/夹紧都要能解释） */
    uint32_t stat_steps;
    uint32_t stat_lines;        /* 累计半平面数 */
    uint32_t stat_infeasible;   /* LP2 失败 -> 走 LP3 的次数 */
    uint32_t stat_wall_clamped; /* 撞墙被夹紧的次数 */
    uint32_t stat_wall_escape;  /* 滑动无效、改绕角蹭出去的次数（M17） */
    uint32_t stat_escape_denied;/* 想蹭但预算用完的次数（诊断：说明在沿墙磨） */
    uint32_t stat_radius_warn;  /* neighbor_dist < 2*radius（可能漏邻居） */
    float    last_ms;
} RtLocalCtx;

int  rt_local_init(RtLocalCtx *c, float world_w, float world_h, int max_agents,
                   float neighbor_dist);
void rt_local_destroy(RtLocalCtx *c);

void rt_local_set_params(RtLocalCtx *c, float time_horizon, int max_neighbors,
                         int wall_slide, float max_accel);

/* 一步：解 ORCA 得到新速度 -> 积分 -> 墙体约束。
 * agents 原地更新；g 可为 NULL（只做互避，不做墙体，测试用）。 */
int rt_local_step(RtLocalCtx *c, RtLocalAgent *agents, int n,
                  const RtGrid *g, float dt);

#ifdef __cplusplus
}
#endif

#endif /* RT_LOCAL_H */

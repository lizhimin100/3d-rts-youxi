/* ============================================================================
 * rt_fineflow.h -- M4.4-B 有界 fine flow（cell 级引导场）
 *
 * 定位：**只在「走廊段直线的 cell 级检查被挡」时才用的兜底引导场**。
 * 它不替换 RtRoute、不参与 Global Route 搜索，只回答一个问题：
 * 「这一步往哪个相邻格走，才能绕开挡在直线上的那道墙/柱子」。
 *
 * 边界（题面 M4.4-B）：
 *   - 窗口固定 = 目标格 ± 12 cell（24×24 = 576 格），越界就不建（不放大窗口）。
 *   - 窗口内 BFS（8 邻域 + 防穿角），next[] 指向目标。
 *   - 缓存 4 槽，key = (目标格, clearance 类别, 窗口原点)，依赖 = 窗口覆盖的 chunk 版本。
 *   - 依赖失效就整块重建，不做局部修复。
 *
 * ⚠ 这是**引导场，不是最优路径**：边权用 BFS 步数（uniform cost），
 *   不做对角 1.414 的代价修正，也不保证窗口内的路径最短。
 *   它的职责只是把单位带出「直线被挡」的凹角，一旦直线恢复通畅，
 *   rt_gw_sample 立刻回到「门户节点 + 直线」，不再经过本模块。
 * ==========================================================================*/
#ifndef RT_FINEFLOW_H
#define RT_FINEFLOW_H

#include "rt_types.h"
#include "rt_grid.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RT_FINE_RADIUS   12                    /* 目标格 ± 12 cell */
#define RT_FINE_WIN      (RT_FINE_RADIUS * 2)  /* 24×24（含下界、不含上界） */
#define RT_FINE_PAD      (RT_FINE_WIN + 2)     /* 26：外扩 1 格边框，省掉邻居的边界判断 */
#define RT_FINE_CELLS    (RT_FINE_PAD * RT_FINE_PAD)
#define RT_FINE_SLOTS    4                     /* 同时缓存的 fine flow 数 */
#define RT_FINE_DEP_MAX  8                     /* 24×24 窗口最多跨 2×2 = 4 个 chunk */
#define RT_FINE_NONE     255                   /* 阻挡 / 窗口边框 */
#define RT_FINE_FREE     254                   /* 可走但 BFS 未访问 */
#define RT_FINE_DONE     253                   /* 已访问且是 BFS 源（目标格本身） */

#define RT_FINE_NEXT_STRIDE RT_FINE_PAD        /* next[] 用 padded stride，直接按邻居下标写 */

typedef struct {
    uint8_t  state;          /* 0 = 空, 1 = ready */
    uint8_t  cls;            /* clearance 类别（BFS 的可通行判据） */
    int32_t  tx, tz;         /* 目标格（窗口锚点） */
    int32_t  ox, oz;         /* 窗口原点（格坐标，闭区间起点） */
    int32_t  w, h;           /* 逻辑窗口尺寸（= 24×24，靠边不裁剪而是拒建） */
    uint8_t *next;           /* [RT_FINE_CELLS]，padded 布局（边框恒 NONE）：
                              * 值 0..7 = 朝目标的下一跳方向，255 = 无解/不可走 */
    uint32_t dep_chunks[RT_FINE_DEP_MAX];
    uint32_t dep_vers[RT_FINE_DEP_MAX];
    int      dep_n, dep_overflow;
    uint32_t last_used;
    uint32_t builds, hits;   /* 该槽位的构建 / 命中次数（诊断，不跨槽清零） */
    int      reached;        /* 本次 BFS 到达的格子数（成本归因） */
} RtFineFlow;

/* BFS 工作区：由 owner 持有并复用，build 内不 malloc。容量 = RT_FINE_CELLS。 */
typedef struct {
    int32_t *queue;
    int      cap;
} RtFineSolver;

int  rt_fine_solver_init(RtFineSolver *s, int max_cells);
void rt_fine_solver_destroy(RtFineSolver *s);
void rt_fine_free(RtFineFlow *f);

/* 把目标格吸附到「可走且 clearance 足够」的格（±3 环内，取最近、最宽敞）。
 * 走廊门户是区域边界点，正常都可走；但 rt_route 在 rt_region_portal() 失败时
 * 会退化成「区域中心」，而噪声地图上的区域中心可能落在墙里。
 * 不吸附的话每次采样都会走到 build 的失败分支（实测 1519 次无效构建）。 */
int  rt_fine_snap_cell(const RtGrid *g, int x, int z, float need, int *sx, int *sz);

/* 以 (tx,tz) 为源做反向 BFS。窗口越界 -> RT_ERR_INVALID（调用方必须计数，
 * 不允许静默放大窗口）。f 的 state 成功时为 1。 */
int  rt_fineflow_build(RtFineFlow *f, RtFineSolver *s, const RtGrid *g,
                       int tx, int tz, int cls);

/* 依赖校验：窗口覆盖的每个 chunk 的 chunk_ver 未变即有效。 */
int  rt_fineflow_valid(const RtFineFlow *f, const RtGrid *g);

/* 单位所在格在窗口内且 next[] 有方向时，写出下一格中心并返回 1；
 * 不在窗口内 / 该格无解返回 0（调用方必须回退到门户节点，并计数）。 */
int  rt_fineflow_next_pos(const RtFineFlow *f, const RtGrid *g,
                          int cx, int cz, RtVec2 *out);

/* 线段是否可走：整数 DDA 逐格走，只看 walkability（不看 clearance），
 * 一格 1 次判定，不做 0.5 m 细采样 —— 这是采样热路径上唯一允许的线段检查。
 * 返回 1 = 全程可走。 */
int  rt_los_clear(const RtGrid *g, RtVec2 a, RtVec2 b);

#ifdef __cplusplus
}
#endif

#endif /* RT_FINEFLOW_H */

#!/usr/bin/env bash
# ============================================================================
# build_and_test.sh -- 编译 + 断言 + 基准（一条命令验证内核）
#
# 用法：
#   ./build_and_test.sh
#   ZIG=/path/to/zig ./build_and_test.sh      # 指定编译器
#   ./build_and_test.sh --assert-only         # 只跑单元/对抗测试，不跑基准
#
# 退出码：0 = 全部通过；非 0 = 有失败（便于 CI）
# ============================================================================
set -u

cd "$(dirname "$0")" || exit 1

# --assert-only 从 M16 起跑**全部门禁**（20 个测试）。
# 早期版本这里只跑到 test_m43，M5~M16 的断言根本不在门禁里 —— 那等于没有门禁。
if [ "${1:-}" = "--assert-only" ]; then
    exec bash gate_all.sh
fi

# ---- 选编译器（优先级：ZIG 环境变量 > PATH 里的 zig > venv 里的 zig > gcc） ----
ZIG_FALLBACK="$HOME/.workbuddy/binaries/python/envs/default/Lib/site-packages/ziglang/zig.exe"
if [ -n "${ZIG:-}" ] && [ -x "${ZIG}" ]; then
    CC_KIND="zig"; CC_BIN="${ZIG}"
elif command -v zig >/dev/null 2>&1; then
    CC_KIND="zig"; CC_BIN="$(command -v zig)"
elif [ -x "$ZIG_FALLBACK" ]; then
    CC_KIND="zig"; CC_BIN="$ZIG_FALLBACK"
elif command -v gcc >/dev/null 2>&1; then
    CC_KIND="gcc"; CC_BIN="gcc"
else
    echo "[FATAL] 找不到 C 编译器。见 build.md 第 1 节。"
    exit 127
fi

SRC="core/src/rt_core.c core/src/rt_unit.c core/src/rt_grid.c core/src/rt_spatial.c \
     core/src/rt_navjob.c core/src/rt_navver.c core/src/rt_flowcache.c core/src/rt_navsched.c \
     core/src/rt_region.c core/src/rt_route.c core/src/rt_group.c"
CFLAGS="-O2 -std=c11 -Wall -Wextra -Icore/include"

compile() {
    local out="$1"; shift
    if [ "$CC_KIND" = "zig" ]; then
        "$CC_BIN" cc $CFLAGS "$@" -o "$out"
    else
        "$CC_BIN" $CFLAGS "$@" -o "$out" -lm
    fi
}

run() {
    local name="$1"; shift
    echo "== running $name ..."
    "$@"
    local rc=$?
    if [ $rc -ne 0 ]; then
        echo "[FAIL] $name（exit=$rc）"
        exit $rc
    fi
}

echo "== compiler: $CC_KIND ($CC_BIN)"

echo "== building test_core ..."
compile test_core $SRC tests/test_core.c || { echo "[FAIL] 编译失败"; exit 1; }
run "test_core (79 asserts)" ./test_core

echo "== building test_incremental (M2 differential) ..."
compile test_incremental $SRC tests/test_incremental.c || { echo "[FAIL] 增量测试编译失败"; exit 1; }
echo "   （完整 10000 iters @256 见 README：约 40s）"
run "test_incremental 1000x128" ./test_incremental 1000 128

echo "== building test_m3 (split adversarial) ..."
compile test_m3 $SRC tests/test_m3.c || { echo "[FAIL] M3 测试编译失败"; exit 1; }
run "test_m3 (S1~S8)" ./test_m3

echo "== building test_m34 (frame-budgeted job) ..."
compile test_m34 $SRC tests/test_m34.c || { echo "[FAIL] M3.4 测试编译失败"; exit 1; }
run "test_m34 (J1~J9)" ./test_m34

echo "== building test_m35 (version / flowcache / coalescing) ..."
compile test_m35 $SRC tests/test_m35.c || { echo "[FAIL] M3.5~3.7 测试编译失败"; exit 1; }
run "test_m35 (V/F/C)" ./test_m35

echo "== building test_m4 (global route / groups) ..."
compile test_m4 $SRC tests/test_m4.c || { echo "[FAIL] M4 测试编译失败"; exit 1; }
run "test_m4 (T1~T10)" ./test_m4

echo "== building test_m42 (route cache / precise invalidation) ..."
compile test_m42 $SRC tests/test_m42.c || { echo "[FAIL] M4.2 测试编译失败"; exit 1; }
run "test_m42 (T1~T9)" ./test_m42

echo "== building test_m43 (goal flow / adaptive) ..."
compile test_m43 $SRC tests/test_m43.c || { echo "[FAIL] M4.3 测试编译失败"; exit 1; }
run "test_m43 (T1~T10)" ./test_m43

echo "== building bench_core ..."
compile bench_core $SRC bench/bench_core.c || { echo "[FAIL] 基准编译失败"; exit 1; }
./bench_core | tee bench_result.txt

echo "== building bench_m2 ..."
compile bench_m2 $SRC bench/bench_m2.c || { echo "[FAIL] M2 基准编译失败"; exit 1; }
echo "== running bench_m2 (may take ~60s) ..."
./bench_m2 | tee bench_m2_result.txt

echo "== building bench_m4 ..."
compile bench_m4 $SRC bench/bench_m4.c || { echo "[FAIL] M4 基准编译失败"; exit 1; }
echo "== running bench_m4 (naive baseline is slow by design, ~40s) ..."
./bench_m4 | tee bench_m4_result.txt

echo "== building bench_m42 ..."
compile bench_m42 $SRC bench/bench_m42.c || { echo "[FAIL] M4.2 基准编译失败"; exit 1; }
echo "== running bench_m42 ..."
./bench_m42 | tee bench_m42_result.txt

echo "== building bench_m43 ..."
compile bench_m43 $SRC bench/bench_m43.c || { echo "[FAIL] M4.3 基准编译失败"; exit 1; }
echo "== running bench_m43 ..."
./bench_m43 | tee bench_m43_result.txt

echo
echo "== all green"

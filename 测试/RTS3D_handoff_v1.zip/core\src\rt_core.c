/* ============================================================================
 * rt_core.c -- RNG / Arena / 审计
 * ==========================================================================*/
#include "rt_core.h"
#include <stdlib.h>
#include <string.h>

/* ---------------------------------------------------------------- RNG */
/*
 * splitmix64：状态只有一个 uint64，可序列化（回放/同步友好）。
 * 参考值表由 tests/test_core.c 的「跨语言硬比对点」校验（Python 侧同实现）。
 * 注意：不使用 rand()/srand() —— 平台相关，且实现可能不同。
 */
void rt_rng_seed(RtRng *r, uint64_t seed)
{
    r->state = seed;
}

uint64_t rt_rng_u64(RtRng *r)
{
    uint64_t z = (r->state += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
}

uint32_t rt_rng_u32(RtRng *r)
{
    return (uint32_t)(rt_rng_u64(r) >> 32);
}

float rt_rng_f32(RtRng *r)
{
    /* 取高 24 位 -> [0,1)，与 float32 尾数精度一致 */
    return (float)(rt_rng_u64(r) >> 40) * (1.0f / 16777216.0f);
}

int rt_rng_range(RtRng *r, int lo, int hi)
{
    if (hi <= lo) return lo;
    return lo + (int)(rt_rng_u64(r) % (uint64_t)(hi - lo));
}

float rt_rng_f32_range(RtRng *r, float lo, float hi)
{
    return lo + (hi - lo) * rt_rng_f32(r);
}

/* ---------------------------------------------------------------- Arena */
int rt_arena_init(RtArena *a, size_t cap)
{
    if (!a) return RT_ERR_INVALID;
    a->base = (uint8_t *)malloc(cap ? cap : 1);
    if (!a->base) {
        a->cap = a->used = a->peak = 0;
        a->overflow = 1;
        return RT_ERR_CAPACITY;
    }
    a->cap = cap;
    a->used = 0;
    a->peak = 0;
    a->overflow = 0;
    return RT_OK;
}

void rt_arena_reset(RtArena *a)
{
    a->used = 0;
}

void rt_arena_destroy(RtArena *a)
{
    free(a->base);
    a->base = NULL;
    a->cap = a->used = a->peak = 0;
}

void *rt_arena_alloc(RtArena *a, size_t size, size_t align)
{
    if (!a || !size) return NULL;
    if (align == 0) align = 1;
    /* align 必须是 2 的幂 */
    if (align & (align - 1)) return NULL;

    size_t off = (a->used + align - 1) & ~(align - 1);
    if (off + size > a->cap) {
        /* 不 abort：+1 审计后返回 NULL，调用方必须降级（题面 FR-MEM-4） */
        a->overflow++;
        return NULL;
    }
    a->used = off + size;
    if (a->used > a->peak) a->peak = a->used;
    return a->base + off;
}

size_t rt_arena_used(const RtArena *a)
{
    return a ? a->used : 0;
}

/* ---------------------------------------------------------------- 审计 */
void rt_audit_reset(RtOverflowCounters *c)
{
    if (c) memset(c, 0, sizeof(*c));
}

uint32_t rt_audit_total(const RtOverflowCounters *c)
{
    if (!c) return 0;
    return c->path_pool_overflow + c->flowfield_overflow + c->group_overflow +
           c->formation_overflow + c->corridor_overflow + c->unit_overflow +
           c->debug_dropped;
}

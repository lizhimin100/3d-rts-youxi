/* 临时：对角阶梯墙（跨整个区域，逼出被挡的走廊段）—— fine on/off 对比。跑完即删。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;

typedef struct { int arr, pen, steps; float endx, endz; } WalkRes;

static WalkRes walk(RtVec2 start, int gi, int max_steps)
{
    WalkRes r; memset(&r, 0, sizeof(r));
    RtVec2 p = start;
    for (int i = 0; i < max_steps && !r.arr; i++) {
        RtVec2 tgt;
        if (rt_gw_sample(&W, gi, p, &tgt) != RT_OK) break;
        RtVec2 d = rt_v2_sub(tgt, p);
        float len = rt_v2_len(d);
        if (len < 1e-4f) { r.pen += 1000; break; }
        float step = 0.2f;
        if (step > len) step = len;
        RtVec2 np = rt_v2_add(p, rt_v2_mul(d, step / len));
        if (!rt_los_clear(&G, p, np)) { r.pen++; break; }
        p = np; r.steps++;
        if (rt_gw_is_arrived(&W, gi, p, 1.5f)) r.arr = 1;
    }
    r.endx = p.x; r.endz = p.z;
    return r;
}

static void build_stair(int rx, int rz, int thick)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_grid_init(&G, 256, 256, 1.0f);
    int x0 = rx * 8, z0 = rz * 8;
    for (int i = 0; i < 8; i++)
        for (int t = 0; t < thick; t++)
            rt_grid_set_terrain(&G, x0 + i, z0 + i + t, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
}

static void one(int rx, int rz, int thick, int fine_on, RtVec2 s, RtVec2 d)
{
    build_stair(rx, rz, thick);
    rt_gw_set_fine_enabled(&W, fine_on);
    RtUnitId id = rt_units_spawn(&US, rt_v3(s.x, 0.f, s.z), RT_FP_SMALL);
    RtUnitId ids[1] = { id };
    rt_gw_command(&W, &US, ids, 1, d, 0, RT_CLS_SMALL, 1);
    int gi = (int)((RtUnitChunk *)rt_units_chunk_c(&US, id))->group[rt_unit_slot_index(id)] - 1;
    WalkRes r = walk(s, gi, 6000);
    printf("  stair(rx=%d,rz=%d,t=%d) fine=%d : n=%2d blocked=%u | arr=%d pen=%d steps=%d end=(%.1f,%.1f)"
           " | fine b=%u h=%u used=%u out=%u rej=%u\n",
           rx, rz, thick, fine_on, W.groups[gi].routes[0].route.n, W.stats.corridor_blocked,
           r.arr, r.pen, r.steps, r.endx, r.endz,
           W.stats.fine_builds, W.stats.fine_hits, W.stats.fine_used,
           W.stats.fine_outside, W.stats.fine_rejected);
}

int main(void)
{
    printf("=== stair wall: fine ON vs OFF ===\n");
    int rzs[3] = { 6, 10, 14 };
    for (int q = 0; q < 3; q++) {
        int rz = rzs[q];
        float z = (float)(rz * 8) + 3.5f;
        RtVec2 s = rt_v2(20.5f, z), d = rt_v2(230.5f, z);
        for (int thick = 1; thick <= 3; thick++) {
            one(8, rz, thick, 0, s, d);
            one(8, rz, thick, 1, s, d);
        }
    }
    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return 0;
}

/* ============================================================================
 * probe_m13_t1.c -- T1（墙 + 2 m 缺口）为什么绕不过去？
 * 逐秒打印：位置 / 规划层状态 / 旋向 / 本帧方向 / 前瞻点 / 到目标距离
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_stuck.h"
#include "rt_plan.h"
#include "rt_types.h"

#define MAXA 8

static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;
static RtStuckCtx SC;
static RtStuckHooks HK;
static RtPlanCtx PL;
static RtGrid G;
static RtVec2 AIM[MAXA], GOAL[MAXA];
static int N = 1;

int main(void)
{
    rt_grid_init(&G, 256, 256, 1.0f);
    rt_grid_rebuild_all(&G);
    for (int z = 0; z < 256; z++) {
        if (z >= 127 && z <= 128) continue;
        rt_grid_set_terrain(&G, 128, z, RT_CELL_BLOCKED_TERRAIN, 1);
    }
    rt_grid_rebuild_all(&G);

    memset(AG, 0, sizeof(AG));
    AG[0].pos = rt_v2(124.f, 116.f);
    AG[0].radius = 0.5f;
    AG[0].max_speed = 2.0f;
    AG[0].fp = 1.0f;
    AG[0].share = 0.5f;
    AG[0].inv_mass = 1.f;
    AG[0].vel = rt_v2(0.f, 0.f);

    rt_local_init(&LC, 256.f, 256.f, MAXA, 4.5f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);
    rt_stuck_init(&SC, MAXA, NULL);
    rt_plan_init(&PL, MAXA, NULL);
    memset(&HK, 0, sizeof(HK));
    HK.local_repath = rt_plan_hook;
    HK.ud = &PL;

    RtVec2 goal = rt_v2(200.f, 128.f);
    AIM[0] = goal; GOAL[0] = goal;

    const float dt = 1.f / 30.f;
    const float LOOK = 8.0f;

    printf("=== probe M13 T1: wall x=128, gap z=127..128, unit (124,116) -> (200,128) ===\n");
    printf("  t     pos            aim            gd   state    side dir(deg)  |pref|  clr  wall_d\n");

    for (int s = 0; s < 1800; s++) {
        /* 调用方：朝目标 */
        RtVec2 d = rt_v2_sub(goal, AG[0].pos);
        float l = rt_v2_len(d);
        AG[0].pref_vel = (l > 1e-3f) ? rt_v2_mul(d, 2.0f / l) : rt_v2(0.f, 0.f);
        AIM[0] = (l > LOOK) ? rt_v2_add(AG[0].pos, rt_v2_mul(d, LOOK / l)) : goal;

        (void)rt_plan_step(&PL, AG, N, AIM, GOAL, &G, dt);
        rt_stuck_step(&SC, AG, N, &G, dt, &HK);
        (void)rt_local_step(&LC, AG, N, &G, dt);

        if ((s % 15) == 0) {
            int cx = rt_grid_cell_x(&G, AG[0].pos.x), cz = rt_grid_cell_z(&G, AG[0].pos.z);
            float ang = atan2f(PL.u[0].dir.z, PL.u[0].dir.x) * 57.29578f;
            printf("%5.1f (%6.2f,%6.2f) (%6.2f,%6.2f) %5.1f %-8s %+d %7.1f  %5.2f  %.2f  %.1f\n",
                   s * dt, AG[0].pos.x, AG[0].pos.z, AIM[0].x, AIM[0].z,
                   rt_v2_dist(AG[0].pos, goal),
                   rt_plan_state_name(PL.u[0].state), (int)PL.u[0].side, ang,
                   rt_v2_len(AG[0].pref_vel),
                   rt_grid_clearance_m(&G, cx, cz),
                   128.f - AG[0].pos.x);
        }
    }

    printf("\nstats: engaged=%u finished=%u exhausted=%u no_exit=%u unreachable=%u\n",
           PL.st.engaged, PL.st.finished, PL.st.exhausted, PL.st.no_exit, PL.st.unreachable);
    printf("final pos=(%.2f,%.2f) dist=%.2f\n", AG[0].pos.x, AG[0].pos.z,
           rt_v2_dist(AG[0].pos, goal));
    return 0;
}

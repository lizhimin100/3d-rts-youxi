/* ============================================================================
 * rt_corridor.h -- 窄通道所有权（FR-STK-3，M10/M11）
 *
 * 问题：一条只能过一列人的通道，两队人相向而行时，谁先过？
 *       M6 的让路梯度能解开「两个人对穿」，但 6 对 6 时会反复退让、吞吐极低
 *       （M9 城门 0.2% 的 PermanentStuck 就是这个）。
 *
 * 做法（01 §12 / FR-STK-3）：**通道级仲裁**，不是单位级。
 *   - 通道是一块矩形区域（由上层注册：门洞 / 走廊）；
 *   - 队伍申请所有权 -> 得到 owner + TTL；
 *   - 只有 owner 的队伍允许进入；另一方去**侧向等待区**（staging），
 *     不站在门口 —— 站在门口等于把 owner 的出口堵住，那是最常见的伪解；
 *   - owner 的队伍全部离开，或 TTL 到期 -> 释放，下一队按 FCFS 接手。
 *
 * M11 补的三件：
 *   1. `rt_corr_set_staging()` + `rt_corr_staging_point()`：给每一侧一个
 *      矩形等待区，按槽位分配落点（与队形/ORCA 正交，只给期望速度）。
 *   2. `rt_corr_want()/rt_corr_acquire()`：FCFS，先到先得，不会饿死一方。
 *   3. `rt_corr_gate()`：把「非 owner 往门里走」的期望速度改成「去等待点」；
 *      已经在通道里的非 owner 被推出**最近的一端**（绝不逆着 owner 走）。
 *
 * 不做：按单位粒度排队（成本高、且会让队伍被切碎）；也不做抢占优先级
 * （题面没有要求，先把「不互相堵死」做对）。
 * ==========================================================================*/
#ifndef RT_CORRIDOR_H
#define RT_CORRIDOR_H

#include "rt_types.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RT_CORR_MAX_TEAMS 8

typedef struct {
    float   x0, z0, x1, z1;   /* 通道矩形（世界坐标） */
    int32_t axis;             /* 0 = 沿 x 通过，1 = 沿 z 通过 */
    int32_t owner;            /* 当前 owner 的队伍 id，-1 = 空闲 */
    float   ttl;              /* 距离强制释放还剩多久（诊断） */
    float   held;             /* owner 已连续占用时间 */
    float   idle_t;           /* owner 的 pending 为 0 的持续时间 */
    int32_t inside;           /* 上一次 note 时，owner 还要用通道的人数（整队） */
    int32_t near;             /* 其中「在通道内或门口 12 m 内」的人数 */
    int32_t passed;           /* 调用方报告的「已通过人数」（单调递增，换 owner 归零） */
    uint32_t grants;          /* 累计授予次数 */
    uint32_t expires;         /* TTL 到期强制释放次数 */
    uint32_t denials;         /* 被拒绝的次数（诊断） */
    uint32_t handoffs;        /* owner 变更次数 */
    uint32_t stalls;          /* 「占着不走」被收回的次数（门口有人但零通过） */
    int32_t  last_passed;     /* 上一次 tick 时的 passed（判断有没有在推进） */
    float    stall_t;         /* passed 没有增加的持续时间 */

    /* 侧向等待区：side 0 = 低坐标端（axis 0 时 x<x0），side 1 = 高坐标端 */
    float   stg[2][4];
    int32_t has_stg[2];

    /* FCFS：每队第一次「想进」的时间；<0 = 不在排队 */
    float   want[RT_CORR_MAX_TEAMS];
} RtCorridor;

typedef struct {
    RtCorridor *c;
    int   cap, n;
    float hold_ttl;           /* 一次授予的默认租期（秒，诊断用） */
    float max_hold;           /* 连续占用上限（防止 owner 卡死在通道里） */
    float gate_radius;        /* 门控半径：离入口多近才把非 owner 引去等待区 */
    float staging_slack;      /* 到等待点多近算到位（米） */
    float stall_limit;        /* pending 多久不下降就认定「占着不走」（秒，默认 20） */
} RtCorrCtx;

int  rt_corr_init(RtCorrCtx *ctx, int max_corridors, float hold_ttl, float max_hold);
void rt_corr_destroy(RtCorrCtx *ctx);

/* 注册一个通道，返回 id；满了返回 -1 */
int  rt_corr_add(RtCorrCtx *ctx, float x0, float z0, float x1, float z1, int axis);

/* 清空所有通道（保留缓冲区）。关卡编辑后重新注册用：几何变了，
 * 旧的所有权与等待区都不再有意义，重新排队是唯一正确的语义。 */
void rt_corr_clear_all(RtCorrCtx *ctx);

/* 注册某一侧的等待区（矩形） */
void rt_corr_set_staging(RtCorrCtx *ctx, int cid, int side,
                         float x0, float z0, float x1, float z1);
/* 门控参数（默认 gate_radius=28 m，staging_slack=1.2 m） */
void rt_corr_set_gate_params(RtCorrCtx *ctx, float gate_radius, float staging_slack);
/* 「占着不走」的判定窗口。owner 的 pending 在这个时间内一次都没下降，
 * 就收回所有权（计入 stalls）。这是**liveness 的唯一保证**：
 * 只要 owner 还有几个永远过不去的掉队者，pending 就永远 > 0，
 * 没有这条规则另一队会被饿死（M11 第一版：grants=1、B 0/80 跑满 400 s）。
 * 默认 20 s，<=0 表示关闭（不建议）。 */
void rt_corr_set_stall_limit(RtCorrCtx *ctx, float seconds);

int  rt_corr_contains(const RtCorridor *c, RtVec2 p);

/* 单位在通道的哪一侧：0 / 1；-1 = 在通道内。通道为空时返回 0。 */
int  rt_corr_side(const RtCorridor *c, RtVec2 p);

/* 等待区落点：把等待区切成 nslots 个格，取第 slot 个的中心。
 * 未注册等待区时退化为「入口外 6 m」的一个点（不静默乱走）。 */
RtVec2 rt_corr_staging_point(const RtCorrCtx *ctx, int cid, int side,
                             int slot, int nslots);

/* 申请：空闲则授予并返回 1；已被别人占用返回 0（计 denials） */
int  rt_corr_request(RtCorrCtx *ctx, int cid, int team);
/* 该队伍现在能不能进 */
int  rt_corr_allowed(const RtCorrCtx *ctx, int cid, int team);
/* 主动释放（队伍已全部通过） */
void rt_corr_release(RtCorrCtx *ctx, int cid, int team);

/* ---- FCFS ---- */
/* 记录「队伍 team 从时刻 t 起就想进通道」。已记录则不覆盖（先到先得）。 */
void rt_corr_want(RtCorrCtx *ctx, int cid, int team, float t);
/* 队伍不再需要通道（已全部通过 / 命令取消）。 */
void rt_corr_unwant(RtCorrCtx *ctx, int cid, int team);
/* 空闲时把所有权授予**最早开始等待**的那一队。返回 owner（-1 = 仍空闲）。 */
int  rt_corr_acquire(RtCorrCtx *ctx, int cid);

/* 门控：返回该单位本帧应该用的期望速度。
 *   owner            -> 原样返回；
 *   通道空闲         -> 原样返回（谁都可以进，真正的授权由 acquire 决定）；
 *   非 owner 在门附近往门里走 -> 改朝 wait_pt；
 *   非 owner 已在通道内     -> 推向最近的一端（绝不逆着 owner 走）；
 *   离门超过 gate_radius    -> 原样返回（还没到需要排队的距离）。 */
RtVec2 rt_corr_gate(const RtCorrCtx *ctx, int cid, int team,
                    RtVec2 pos, RtVec2 pref, RtVec2 wait_pt);

/* 每帧：调用方先报告 owner「还要用通道」的人数（通道内 + 入口排队），再推进 TTL。
 * **不要只报通道内的**：队伍还没进门时 inside=0，会被当成「用完了」提前释放，
 * 两队就会每帧互抢（M10 实测 grants=302、谁也没过去）。
 * 为 0 持续 0.3 s 才释放，避免「最后一个刚出门，对面就冲进来」把它堵回去。
 *
 * 三个数（`rt_corr_note_state`）：
 *   total  = 整队还没过完的人数                -> 决定「什么时候算用完」
 *   near   = 其中在通道内 / 门口 12 m 内的人数 -> 决定「门口有没有人在等」
 *   passed = 已经通过的人数（单调递增）        -> 决定「是不是卡住了」
 * 三个都要，少任何一个都会判错：
 *   · 只报 near  -> 队伍尾巴在 50 m 外就被当成用完，频繁换手，谁也过不去；
 *   · 只报 total -> 队伍还在 100 m 外走过来，20 s 不降就被判「占着不走」
 *                   （M11：stalls=2 全是假警报）；
 *   · 用 near 判推进 -> 管道饱和时「走一个、来一个」，计数恒定，
 *                   正在顺畅通过的队伍被判成卡住（M11：stalls=3、perm 从 1 涨到 10）。
 * 只有 **passed 是否增加** 才是真正的进度信号。 */
void rt_corr_note_pending(RtCorrCtx *ctx, int cid, int owner_units_pending);
void rt_corr_note_pending2(RtCorrCtx *ctx, int cid, int total, int near);
void rt_corr_note_state(RtCorrCtx *ctx, int cid, int total, int near, int passed);
void rt_corr_tick(RtCorrCtx *ctx, float dt);

#ifdef __cplusplus
}
#endif

#endif /* RT_CORRIDOR_H */

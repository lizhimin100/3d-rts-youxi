/* ============================================================================
 * rt_yield.c -- 静止单位让路（FR-YLD，M7）
 * 设计口径见 rt_yield.h 顶部。
 * ==========================================================================*/
#include "rt_yield.h"

#include <stdlib.h>
#include <string.h>
#include <math.h>

void rt_yield_config_default(RtYieldConfig *c)
{
    if (!c) return;
    memset(c, 0, sizeof(*c));
    c->actual_ratio     = 0.50f;
    c->enter_pressure   = 8.0f;
    c->exit_pressure    = 2.5f;
    c->decay            = 0.80f;
    c->decay_interval   = 0.5f;
    c->reentry_cooldown = 3.0f;
    c->arrive_dist      = 0.70f;
    c->home_dist        = 0.60f;
    c->max_out_time     = 6.0f;
    c->cell             = 2.0f;
    c->radii[0]         = 2.0f;
    c->radii[1]         = 4.0f;
}

int rt_yield_init(RtYieldCtx *c, int max_units, const RtYieldConfig *cfg,
                  const RtGrid *g)
{
    if (!c || max_units <= 0) return RT_ERR_INVALID;
    memset(c, 0, sizeof(*c));
    if (cfg) c->cfg = *cfg;
    else     rt_yield_config_default(&c->cfg);

    c->cap = max_units;
    c->u = (RtYieldUnit *)calloc((size_t)max_units, sizeof(RtYieldUnit));
    if (!c->u) return RT_ERR_CAPACITY;

    if (g) {
        c->pcell = (c->cfg.cell > 0.1f) ? c->cfg.cell : 2.0f;
        c->pw = (int)((float)g->w * g->cell / c->pcell) + 1;
        c->ph = (int)((float)g->h * g->cell / c->pcell) + 1;
        if (c->pw < 1) c->pw = 1;
        if (c->ph < 1) c->ph = 1;
        c->press = (float *)calloc((size_t)c->pw * c->ph, sizeof(float));
        if (!c->press) { rt_yield_destroy(c); return RT_ERR_CAPACITY; }
    }
    for (int i = 0; i < max_units; i++) c->u[i].state = RT_YIELD_IDLE;
    return RT_OK;
}

void rt_yield_destroy(RtYieldCtx *c)
{
    if (!c) return;
    free(c->u);     c->u = NULL;
    free(c->press); c->press = NULL;
    c->cap = 0;
    c->pw = c->ph = 0;
}

const char *rt_yield_state_name(int s)
{
    switch (s) {
        case RT_YIELD_IDLE: return "IDLE";
        case RT_YIELD_OUT:  return "OUT";
        case RT_YIELD_HOLD: return "HOLD";
        case RT_YIELD_BACK: return "BACK";
        default:            return "?";
    }
}

/* ----------------------------------------------------------------------------
 * 压力场
 * --------------------------------------------------------------------------*/
static inline int press_index(const RtYieldCtx *c, float x, float z)
{
    int gx = (int)((x - c->px0) / c->pcell);
    int gz = (int)((z - c->pz0) / c->pcell);
    if (gx < 0) gx = 0;
    if (gx >= c->pw) gx = c->pw - 1;
    if (gz < 0) gz = 0;
    if (gz >= c->ph) gz = c->ph - 1;
    return gz * c->pw + gx;
}

float rt_yield_pressure_at(const RtYieldCtx *c, RtVec2 p)
{
    if (!c || !c->press) return 0.f;
    return c->press[press_index(c, p.x, p.z)];
}

static float pressure_sum3x3(const RtYieldCtx *c, RtVec2 p)
{
    if (!c->press) return 0.f;
    int gx = (int)((p.x - c->px0) / c->pcell);
    int gz = (int)((p.z - c->pz0) / c->pcell);
    float s = 0.f;
    for (int dz = -1; dz <= 1; dz++) {
        int nz = gz + dz;
        if (nz < 0 || nz >= c->ph) continue;
        for (int dx = -1; dx <= 1; dx++) {
            int nx = gx + dx;
            if (nx < 0 || nx >= c->pw) continue;
            s += c->press[nz * c->pw + nx];
        }
    }
    return s;
}

static void pressure_decay(RtYieldCtx *c)
{
    if (!c->press) return;
    int n = c->pw * c->ph;
    float f = c->cfg.decay;
    for (int k = 0; k < n; k++) c->press[k] *= f;
}

/* ----------------------------------------------------------------------------
 * 候选位置
 * --------------------------------------------------------------------------*/
static int pos_ok(const RtGrid *g, RtLocalAgent *a, RtVec2 p)
{
    if (!g) return 1;
    int cx = (int)p.x, cz = (int)p.z;
    if (!rt_grid_in_bounds(g, cx, cz)) return 0;
    if (!rt_grid_walkable(g, cx, cz)) return 0;
    if (rt_grid_clearance_m(g, cx, cz) < a->radius + 0.10f) return 0;
    RtObb2 o = rt_obb_make(p, a->fp, 0.f);
    if (rt_grid_obb_blocked(g, &o)) return 0;
    return 1;
}

static int pick_candidate(RtYieldCtx *c, const RtGrid *g, RtLocalAgent *a,
                          RtVec2 *out)
{
    float best = -1e30f;
    RtVec2 bp = rt_v2(0.f, 0.f);
    int found = 0;

    /* 人流方向 = 压力梯度的反方向（压力从「被堵的那堆人」向外衰减）。
     * 让路要往**侧向**让，不是往前进方向让 —— 往前挪 2 m 还是在走廊里挡着。 */
    float gx = 0.f, gz = 0.f;
    if (c->press) {
        float cs = c->pcell;
        gx = rt_yield_pressure_at(c, rt_v2(a->pos.x + cs, a->pos.z)) -
             rt_yield_pressure_at(c, rt_v2(a->pos.x - cs, a->pos.z));
        gz = rt_yield_pressure_at(c, rt_v2(a->pos.x, a->pos.z + cs)) -
             rt_yield_pressure_at(c, rt_v2(a->pos.x, a->pos.z - cs));
        float gl = sqrtf(gx * gx + gz * gz);
        if (gl > 1e-4f) { gx /= gl; gz /= gl; } else { gx = gz = 0.f; }
    }

    for (int k = 0; k < RT_YIELD_DIRS; k++) {
        float ang = 6.2831853f * (float)k / (float)RT_YIELD_DIRS;
        float dx = cosf(ang), dz = sinf(ang);
        for (int r = 0; r < RT_YIELD_RADII; r++) {
            float rad = c->cfg.radii[r];
            RtVec2 p = rt_v2(a->pos.x + dx * rad, a->pos.z + dz * rad);
            if (!pos_ok(g, a, p)) continue;
            /* 用**候选格自身**的压力，不要用 3×3：
             * 壁龛紧贴走廊，3×3 会把走廊里排队的人算进来，
             * 于是「唯一能站人的壁龛」被误判成「也是人流」而排除。 */
            float pr = rt_yield_pressure_at(c, p);
            if (pr > c->cfg.enter_pressure * 0.5f) continue;
            float clr = g ? rt_grid_clearance_m(g, (int)p.x, (int)p.z) : 1.f;
            /* 侧向分量：垂直于人流方向 */
            float lat = fabsf(dx * (-gz) + dz * gx);
            float score = -0.5f * rad - 0.30f * pr + 0.7f * clr + 2.0f * lat;
            if (score > best) { best = score; bp = p; found = 1; }
        }
    }
    if (found) { *out = bp; }
    return found;
}

/* 原位是否被别的单位占着（回位前检查） */
static int home_free(RtYieldCtx *c, RtLocalAgent *ag, int n, int self, RtVec2 home)
{
    for (int j = 0; j < n; j++) {
        if (j == self) continue;
        RtVec2 d = rt_v2_sub(ag[j].pos, home);
        float need = ag[self].radius + ag[j].radius + 0.30f;
        if (rt_v2_len2(d) < need * need) return 0;
    }
    (void)c;
    return 1;
}

/* ----------------------------------------------------------------------------
 * 每帧
 * --------------------------------------------------------------------------*/
void rt_yield_step(RtYieldCtx *c, RtLocalAgent *ag, int n, const RtGrid *g,
                   float dt, RtYieldMayFn may_yield, void *ud)
{
    if (!c || !ag || n <= 0 || dt <= 0.f) return;
    if (n > c->cap) n = c->cap;

    const float move_eps = 0.05f;

    /* ---- 1. 累积压力：被堵住的 mover 给它所在格 +1/s ---- */
    if (c->press) {
        for (int i = 0; i < n; i++) {
            if (ag[i].inv_mass <= 0.f) continue;
            float want = rt_v2_len(ag[i].pref_vel);
            if (want < 0.20f) continue;                 /* 静止/没命令，不是交通 */
            if (rt_v2_len(ag[i].vel) >= c->cfg.actual_ratio * want) continue;
            /* 一个被堵住的 mover 每秒贡献 2 点压力（配合 0.5 s ×0.8 衰减，
             * 单个堵住的人稳态约 5，两个人就过 8 的触发线）。 */
            c->press[press_index(c, ag[i].pos.x, ag[i].pos.z)] += dt * 2.0f;
        }
        c->dec_t += dt;
        if (c->dec_t >= c->cfg.decay_interval) {
            c->dec_t -= c->cfg.decay_interval;
            pressure_decay(c);
        }
    }

    /* ---- 2. 每个静止单位的让路状态机 ---- */
    uint32_t cnt[4] = { 0, 0, 0, 0 };
    for (int i = 0; i < n; i++) {
        RtYieldUnit *u = &c->u[i];
        RtLocalAgent *a = &ag[i];

        if (u->cooldown > 0.f) u->cooldown -= dt;

        /* 上层下了新命令（pref 不是我们写的那个）-> 立刻退出让路，交还控制权 */
        if (u->state != RT_YIELD_IDLE) {
            RtVec2 d = rt_v2_sub(a->pref_vel, u->wrote);
            if (rt_v2_len(d) > 0.10f * (a->max_speed > 0.f ? a->max_speed : 1.f)) {
                u->state = RT_YIELD_IDLE;
                u->home = a->pos;
                u->cooldown = 0.f;
            }
        }

        u->timer += dt;

        switch (u->state) {
        case RT_YIELD_IDLE: {
            /* 只在「真的没命令」时才考虑让路；顺手把 home 更新到当前位置。
             * 注意**不要**按 inv_mass 过滤：inv_mass=0 正是「别人推不动、但自己可以走」
             * 的静止单位，也就是本层要服务的那一类。
             * max_speed<=0 是「已经不是单位了」（到达后停车 / 已销毁），直接跳过。 */
            if (a->max_speed <= 0.f) break;
            if (rt_v2_len2(a->pref_vel) > move_eps * move_eps) {
                u->home = a->pos;    /* 有命令 = mover，不是我们要管的静止单位 */
                break;
            }
            if (rt_v2_len2(u->home) < 1e-6f) u->home = a->pos;
            if (u->cooldown > 0.f) break;

            float pr = pressure_sum3x3(c, a->pos);
            if (pr <= c->cfg.enter_pressure) break;
            if (may_yield && !may_yield(ud, i)) { c->st.denied++; break; }

            RtVec2 tgt;
            if (!pick_candidate(c, g, a, &tgt)) {
                c->st.no_candidate++;
                u->cooldown = 1.0f;      /* 别每帧都试 */
                break;
            }
            u->target = tgt;
            u->state = RT_YIELD_OUT;
            u->timer = 0.f;
            u->yields++;
            c->st.triggers++;
            break;
        }
        case RT_YIELD_OUT: {
            RtVec2 d = rt_v2_sub(u->target, a->pos);
            float l = rt_v2_len(d);
            if (l < c->cfg.arrive_dist) {
                u->state = RT_YIELD_HOLD;
                u->timer = 0.f;
                a->pref_vel = rt_v2(0.f, 0.f);
            } else if (u->timer > c->cfg.max_out_time) {
                c->st.timeouts++;
                u->state = RT_YIELD_BACK;
                u->timer = 0.f;
            } else {
                float sp = a->max_speed > 0.f ? a->max_speed : 1.f;
                a->pref_vel = rt_v2_mul(d, (sp * 0.6f) / (l > 1e-3f ? l : 1.f));
            }
            break;
        }
        case RT_YIELD_HOLD: {
            a->pref_vel = rt_v2(0.f, 0.f);
            /* 压力下去了、而且自己这边不再堵着 -> 回去 */
            if (pressure_sum3x3(c, a->pos) < c->cfg.exit_pressure) {
                u->state = RT_YIELD_BACK;
                u->timer = 0.f;
            } else if (u->timer > c->cfg.max_out_time * 4.f) {
                u->state = RT_YIELD_BACK;      /* 太久也回去（别永久挪窝） */
                u->timer = 0.f;
            }
            break;
        }
        case RT_YIELD_BACK: {
            RtVec2 d = rt_v2_sub(u->home, a->pos);
            float l = rt_v2_len(d);
            if (l < c->cfg.home_dist) {
                u->state = RT_YIELD_IDLE;
                u->cooldown = c->cfg.reentry_cooldown;
                u->timer = 0.f;
                a->pref_vel = rt_v2(0.f, 0.f);
                c->st.completed++;
            } else if (!home_free(c, ag, n, i, u->home)) {
                c->st.home_blocked++;
                a->pref_vel = rt_v2(0.f, 0.f);   /* 原位被占：等，不硬挤 */
                u->timer = 0.f;
            } else {
                float sp = a->max_speed > 0.f ? a->max_speed : 1.f;
                a->pref_vel = rt_v2_mul(d, (sp * 0.6f) / (l > 1e-3f ? l : 1.f));
            }
            break;
        }
        default:
            break;
        }

        u->wrote = a->pref_vel;   /* 记下自己写的值，供「上层接管」检测 */
        int s = (int)u->state;
        if (s >= 0 && s < 4) cnt[s]++;
    }
    for (int s = 0; s < 4; s++) c->st.count[s] = cnt[s];
}

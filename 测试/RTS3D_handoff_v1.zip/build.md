# 构建与验证说明

> 目标语言是 **C（C11）**。本机原本**没有任何 C 编译器**（全盘搜索 gcc/cl/clang 零命中），
> 因此构建链是逐步试出来的。本文记录**可复现路径**与**踩过的坑**，避免评审环境重走。

---

## 1. 工具链（三选一，按可靠性排序）

### 方案 A（推荐，本机已验证）：zig cc

zig 自带 clang 后端，`zig cc` 就是 clang，支持 C11 + `-O2`，性能与 GCC 同量级。

```bash
# 1) 通过 PyPI 安装（清华镜像没有此包，必须用官方源）
python -m venv .venv
.venv/Scripts/python.exe -m pip install --index-url https://pypi.org/simple ziglang

# 2) zig 可执行文件位置
#    <site-packages>/ziglang/zig.exe
.venv/Scripts/python.exe -c "import ziglang,os;print(os.path.dirname(ziglang.__file__))"
```

> **首次编译会慢**：zig 需要构建内置 libc 缓存，本机第一次 `zig cc` 用了 **3 分 55 秒**，
> 之后同一 target 的编译约 **1.8 秒**。不要以为卡死了。

### 方案 B：GCC（MinGW-w64 / w64devkit）

```bash
# 本机尝试下载 w64devkit 失败（67 MB，GitHub 限速到 ~30 KB/s，多次续传中断）
# 如果在你的环境能下载：
curl -L -o w64devkit.7z.exe \
  https://github.com/skeeto/w64devkit/releases/download/v2.10.1/w64devkit-x64-2.10.1.7z.exe
./w64devkit.7z.exe -y -o.
```

### 方案 C：MSVC / clang-cl

`cl /std:c11 /O2 /Icore\include ...` 应该可用，但**本机未安装 VS**，未验证。

### ⚠ 不要用 Digital Mars C（dmc）

本机试过（`dmc.zip` 3.3 MB，可编译运行），但实测**64 位无符号乘法有 bug**：

```
0x9E3779BB07979AF0 * 0xBF58476D1CE4E5B9
  正确（Python/zig）: 0x6F68261B57E7A770
  dmc 计算:           0x2D4A455B57E7A770   <- 高 32 位错误
```

这个 bug 让 splitmix64 的 4 条跨语言断言全红，**看起来像自己的 RNG 实现错了**。
dmc 只能用来做语法检查，不能用于数值正确性或性能验证。

---

## 2. 编译与运行

```bash
# 断言（79 条，含负例）
zig cc -O2 -std=c11 -Wall -Wextra -Icore/include \
    core/src/rt_core.c core/src/rt_unit.c core/src/rt_grid.c core/src/rt_spatial.c \
    tests/test_core.c -o test_core
./test_core
# 期望输出：79/79 passed, 0 failed / ALL PASS (79 asserts)

# 基准
zig cc -O2 -std=c11 -Wall -Wextra -Icore/include \
    core/src/rt_core.c core/src/rt_unit.c core/src/rt_grid.c core/src/rt_spatial.c \
    bench/bench_core.c -o bench_core
./bench_core
```

### 一键脚本

```bash
./build_and_test.sh        # 编译 + 跑断言 + 跑基准
```

---

## 3. 设计探针（可选，产出 `_设计验算/probe_result_c.txt`）

```bash
cd _设计验算
zig cc -O2 -std=c11 -o design_probe design_probe.c -lm
./design_probe > probe_result_c.txt
```

**注意**：探针里有个变量名 `far` 与 `windows.h` 的宏冲突（MSVC/MinGW 把 `far` 定义为空），
代码里已改名为 `far_cell`。如果你在别的平台编译，这个坑不会出现。

Python 代理版（无编译器环境可用）：
```bash
python _设计验算/design_probe.py > _设计验算/probe_result_py.txt
```

---

## 4. 已知的构建坑（都踩过）

| 现象 | 原因 | 解法 |
|---|---|---|
| `Fatal error: unable to open input file 'coresrcrt_core.c'` | bash 把 `\` 当转义 | 用正斜杠 `core/src/rt_core.c` |
| `error: call to undeclared library function 'memset'` | 漏 `#include <string.h>` | 补头文件（zig cc 的 C11 模式不隐式声明） |
| `error: expected identifier or '('` 在 `int far = ...` | `far` 是 windows.h 的宏 | 改名 `far_cell` |
| `warning: '/*' within block comment` | 注释里写了 `src/*.c`，`/*` 开启嵌套注释 | 写成 `rt_*.c` |
| 首次 zig 编译耗时 4 分钟 | 构建内置 libc 缓存 | 等待；后续 1.8 s |
| dmc 编译通过但数值错 | dmc 64 位乘法 bug | 换 zig/gcc |

---


---

## 6. M2 增量测试与基准

```bash
# 差分测试：Incremental == Full（先小规模确认，再跑完整）
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_incremental.c -o test_incremental
./test_incremental 1000 128        # ~2 s
./test_incremental 10000 256       # ~40 s，交付要求的规模

# M2 基准：B1~B8 + 两种交叉点扫描
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c bench/bench_m2.c -o bench_m2
./bench_m2 | tee bench_m2_result.txt
```

**期望**：
```
10000 次差分 -> differing iters: 0 / total flag diffs: 0 / total clear diff: 0 / PASS
B1 add 2x2   -> inc med ≈ 0.03 ms   （全量 ≈ 27 ms，约 950x）
B2 add 20x20 -> inc med ≈ 0.10 ms   （约 283x）
B4 split     -> 降级全量 ≈ 28 ms    （已知问题 K1/K2，见 04 §12）
```

### M3.4~M3.7 测试

```bash
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m34.c -o test_m34
./test_m34        # J1~J9：帧预算 / 取消 / stale / PENDING（约 20 s）
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m35.c -o test_m35
./test_m35        # V/F/C：版本 / 流场缓存 / 编辑合并（约 15 s）
```

**判读**：
```
median max_frame < 4ms     -> 没有帧尖峰
worst 偶发 8~17ms          -> 本机 OS 抢占（2 核低压 U），看中位数
J9 stale=0                 -> 无关区域编辑不会取消任务
C1~C5 partition == full    -> 取消/合并后仍与全量一致
```

### M4.1 测试与基准

```bash
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m4.c -o test_m4
./test_m4        # T1~T10（约 10 s）
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c bench/bench_m4.c -o bench_m4
./bench_m4       # 含 naive cell-A* 对照，约 40 s（naive 是故意慢的）
```

**判读**：
```
builds 随「源区域数」增长，不随单位数增长   -> 共享生效
1000 单位 builds=8（naive 1000）            -> 主线目标达成
naive per_unit_ms ≈ 24 ms                    -> 每单位 A* 不可行
```

### M3 对抗测试

```bash
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m3.c -o test_m3
./test_m3        # ~60s：S1~S8（split / merge / 查询 / 多规模）
```

**M3 后 `degraded to full` 应为 0**（M2 时约 24.7%）。
如果 M3 版差分测试仍出现降级，说明某条 split/merge 路径退回了全量。

### M3.4~M3.7 测试

```bash
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m34.c -o test_m34
./test_m34        # J1~J9：帧预算 / 取消 / stale / PENDING（约 20 s）
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m35.c -o test_m35
./test_m35        # V/F/C：版本 / 流场缓存 / 编辑合并（约 15 s）
```

**判读**：
```
median max_frame < 4ms     -> 没有帧尖峰
worst 偶发 8~17ms          -> 本机 OS 抢占（2 核低压 U），看中位数
J9 stale=0                 -> 无关区域编辑不会取消任务
C1~C5 partition == full    -> 取消/合并后仍与全量一致
```

### M4.1 测试与基准

```bash
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m4.c -o test_m4
./test_m4        # T1~T10（约 10 s）
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c bench/bench_m4.c -o bench_m4
./bench_m4       # 含 naive cell-A* 对照，约 40 s（naive 是故意慢的）
```

**判读**：
```
builds 随「源区域数」增长，不随单位数增长   -> 共享生效
1000 单位 builds=8（naive 1000）            -> 主线目标达成
naive per_unit_ms ≈ 24 ms                    -> 每单位 A* 不可行
```

### M3 对抗测试

```bash
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m3.c -o test_m3
./test_m3        # ~60s：S1~S8（split / merge / 查询 / 多规模）
```

**M3 后 `degraded to full` 应为 0**（M2 时约 24.7%）。
如果 M3 版差分测试仍出现降级，说明某条 split/merge 路径退回了全量。

**注意**：差分测试的 `degraded to full` 是**正常**的 —— 它表示「本次编辑无法用增量证明正确」，
系统自动降级全量并计数（`g->full_rebuild_count`）。差异数为 0 才是正确性判据。

---

## 5. 目录约定

```
core/include/   rt_types.h（容量/错误码）· rt_math.h（内联数学）· rt_core.h · rt_grid.h · rt_unit.h · rt_spatial.h
core/src/       对应 .c（无引擎依赖，可独立编译）
tests/          test_core.c（断言 + 负例自检）
bench/          bench_core.c（自适应重复次数的基准）
_设计验算/       design_probe.c/.py + 原始输出（设计取证，不进编译）
```

**纪律**：
- `core/` 内**禁止** include 任何引擎头文件或平台头文件（`windows.h` 只在 bench/probe 里出现）；
- 所有容量上界只在 `rt_types.h` 定义；
- 任何「因容量不足丢弃」必须计数（`RtOverflowCounters`），不允许静默。

### M4.4 测试与基准（本轮新增）

```bash
# 注意：rt_fineflow.c 是 M4.4 新增的源文件，rt_group.c 依赖它（core/src/rt_*.c 通配已覆盖）
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m44.c -o test_m44
./test_m44       # T1~T7（34 断言，几秒）
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c bench/bench_m44.c -o bench_m44
./bench_m44      # stuck 率 / 到达步数 / 采样 ms / 构建次数 / 窗口覆盖率
```

**判读**：
```
test_m44 的 T2 会同时打印 fine=on / fine=off 两行 —— off 必须失败，它证明 B 不是摆设
U 形陷阱 stuck 0%、斜向薄墙 fine=on 0% / fine=off 75%
1000 单位采样 warm ≈ 0.11~0.13 ms；cold 多出 1 次一次性建场（见 14_M4.4_报告.md §6.1）
```

### M4.6 测试（P1 建场分帧 + P2 区域图增量）

```bash
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m46.c -o test_m46
./test_m46       # M1~M10（32 断言）：分帧 5 条 + 区域增量 5 条
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c bench/bench_m46.c -o bench_m46
./bench_m46      # 刷新成本（2x2~64x64）/ 编辑管线成本 / 50 次编辑正确性抽样
```

**判读**：
```
M1 budget=1 首次遍历 builds 必须是 1，且 skip > 0
M2 budget=-1 同图 builds 必须 >= 2（否则 M1 是空测试）
M3 每帧 update 之后 builds 逐帧 +1，skip 停止增长
M5 斜向薄墙在 budget=1 + 每帧 update 下仍 4/4 到达、0 穿墙
M6 mismatched 必须是 0（增量区域图与整图逐字段相同）；avg regions 应远小于 1024
M7 rect 至少比整图便宜 3×（实测 ~56×）
M8 reason=2 + equal=1（矩形外变化被抓住并扩成整图）
M9 reason=1（label_epoch 变化强制整图）
M10 4/4 到达 + 0 穿墙，且 region_regions 远小于 1024（走的是增量而不是兜底）
```

**部署注意**：编辑流程里 `rt_gw_note_edit(&W, &dirty)` 是**可选但强烈建议**的一步。
不调用不会算错（`command`/`update` 会整图兜底），只是每次编辑白付 ~0.5 ms。

### M4.5 测试与基准（多组并存）

```bash
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m45.c -o test_m45
./test_m45       # N1~N7（35 断言）：并存 / 部分重令 / 隔离 / id 回写 / clear / 回归
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c bench/bench_m45.c -o bench_m45
./bench_m45      # K=1/2/4/8/16 支部队：命令耗时、组数、采样、串组检查
```

**判读**：
```
N1 第二条命令必须「增加」组而不是清空（groups 1 -> 2）
N2 A 组恰好少 10 人、B 组 goal 完全不变
N3 每个单位 chunk->group 指向的组，其 goal 必须是自己本次命令的目标（0 失败）
N5 编辑后 A 的 route 失效、B 的仍然 valid、update 只重建 1 条
bench: cmd_med 与 K 无关（~0.1 ms）；cmd_max 只在「方阵跨 >4 区域」时出现 2-3 倍尖峰
```

**语义提醒**：`rt_gw_command` 现在只影响传入的 `ids`；想清空整个世界用
`rt_gw_clear(w, units)`。旧的「一条命令取代所有命令」行为已经不存在了 ——
它本来就只能靠「重新对所有单位下令」来模拟。

### M10 测试（窄通道所有权 FR-STK-3）

```bash
# T1~T3：2 格走廊 6 对穿 / 申请与释放语义 / 强制释放
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m10.c -o test_m10
./test_m10
```

**判读**：
```
T1 对照组必须 0/12（不仲裁就是死锁）；仲裁组必须 12/12，grants >= 2
T2 第二队被拒、只有 owner 能进、队伍还在时所有权不释放、清空后释放并能交接
T3 超过 max_hold 强制释放，expires 计数 +1
```

**接入约定**：每帧先算 owner「还要用通道」的人数（**通道内 + 入口排队**，
不是只算通道内），调 `rt_corr_note_pending()`，再 `rt_corr_tick()`。
非 owner 的等待线要离出口 3 m 以上，否则会挡住对方出门。

### M11 测试（通道仲裁接进流水线）

```bash
# T0：API 级（几何 / 等待区 / 门控方向 / FCFS / stall 三种情形）
# T1/T2：2 m × 10 m 隧道 60 v 60，关/开仲裁同机对照
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m11.c -o test_m11
./test_m11
```

**判读**：
```
T0 必须全绿（20 条）—— 这一层是纯几何/时序，出错一定是逻辑错，不是性能
T1 对照组 grants=0
T2 A 队 95% 通过 < 212 s×0.70；双方完成不得慢于对照组 1.05×；perm=0
```

**接入约定（M11 起）**：
1. 三个数要分开报：`rt_corr_note_state(total, near, passed)`。
   `total` 决定何时算用完，`near` 决定门口有没有人，`passed`（单调）决定是否卡住。
   只报一个数的旧接口 `rt_corr_note_pending` 会**退出 stall 判定**。
2. 非 owner 的**整队**都要 `rt_stuck_set_hold(1)`（不只是门口那几十米），
   否则后排会在队列里被判卡死。
3. 只有门口 `gate_radius`（默认 28 m）内才改道去等待区，远处照常走导航。
4. 极窄通道（≤2 m）要把 `permanent_time` 从默认 20 s 放宽（实测 60 s），
   否则正常排队会被判永久卡死。

### M9 测试（四层集成）

```bash
# 开阔地 1000 / 城门 1000 / 城门 200，输出 FR-TST-2 指标
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m9.c -o test_m9
./test_m9        # 约 20 s
```

**判读**：
```
S1 开阔地 1000：到达 >=98%，mean < 8 ms
S2 城门 1000：到达 >=95%，PermanentStuck < 0.5%
S3 城门 200：到达 >=98%
全场景：最终帧 0 对重叠、最大穿透 < 0.5 m
frame 里 nav 应只占 ~5%，local（ORCA）~92%
```

**注意**：`test_m3` 的 S2 有一条 **4 ms 单次计时门禁**，本机噪声 ±30~40% 时会偶发
失败（实测 6.7 ms）。重跑 3 次均 18/18 全绿，属环境噪声，不是回归。

### M15 测试（跨通道协调 / 通道链）

```bash
# T1/T2 分组与退化，T3 原子性，T4 Z 形三方对照，T5 独立链
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m15.c -o test_m15
./test_m15        # 30 条断言，约 3 s
```

**判读**：
```
T1 Z 形 -> 3 段同一个 chain id，注册 3 通道 + 1 链（nseg=3）
T1' rt_portal_register（不接链路）仍然 0 注册（安全默认没破）
T2 两条独立隧道 -> 2 条链各 1 段（与 M11 行为一致）
T3 中间段被占 -> 申请整条失败、partial_fail=1、**没有任何段泄漏**
T3' 人为释放一段 -> 整链收回、seg_lost=1、没有残留
T4 三方对照：不仲裁 23/24 ｜ 逐段仲裁 0/24（死锁）｜ 链级 22/24、handoffs=2
T5 两条不相接的链分别授予不同队伍，互不干扰
```

**这一轮的结论别读歪**：Z 形带 2×2 拐角自由块**本来就有会车空间**，不仲裁也能过。
链级仲裁的收益不是吞吐，是**消掉逐段仲裁制造的互锁**（0/24 → 22/24）并给出确定顺序。

**接入**（在 M11 那套之外只多两行）：

```c
rt_chain_want(&CH, ch, team, now);   /* 或 rt_chain_unwant */
rt_chain_acquire(&CH, ch);           /* 原子：要么全拿要么一段不拿 */
rt_corr_note_state(...); rt_corr_tick(&CC, dt);
rt_chain_tick(&CH, dt);              /* 同步段所有权；任一段被强制释放 -> 整链收回 */
```

**四条不许踩的线**：

1. **`passed` 要用链级求和，不能按段**。段走空后 `passed` 恒定，20 s 的 stall
   会把它判成「占着不走」，owner 每 20 s 被收走一次（实测 seg_lost=8、B 永远轮不到）。
2. **`stall_limit` 要配得上链长**。60 m 的链一段就要走 30~40 s，默认 20 s 是给
   11 m 隧道调的值。按场景放宽到 90 s（参数问题，同 M11 的 permanent_time）。
3. **拐角必须留 2×2 的自由块**。两臂只在 1 格相接时，1×1 单位转身零余量，
   12 人只过 5 个 —— 和 M13「射线通 ≠ 身体过」同源。
4. **等待区要检查可走性**（`pick_staging_center`）。几何算出来的点可能正中墙心，
   M14 只验证了「不与通道矩形重叠」。

**取证**：`test_m15` 会把每个没通过的单位打印位置 / 可走性 / clearance / pref /
held / 状态机。`passed` 饱和和 `GAVE_UP` 卡队列两个坑都是靠这个 dump 定位的。

### M14 测试（窄通道自动检测 + 自动仲裁注册）

```bash
# T1/T2/T3/T5/T8/T9 检测语义，T6 成本，T4 60v60 复现（自动注册）
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m14.c -o test_m14
./test_m14        # 36 条断言，约 2.6 s
```

**判读**：
```
T1 11 m × 2 m 隧道：1 条 portal，rect=[128,139]×[126,128]，axis=0，len=11，width=2，cells=22
   —— 必须与手工 rt_corr_add(128,126,139,128,0) 逐字段相同
T2 开阔地：portals=0（无假阳性）
T3 拓宽到 6 m：portals 1 -> 0，registered=0
T5 3 m / 6 m 的洞：都不判为单车道
T8 两条隧道：portals=2，cid=0/1，顺序按 z 确定
T9 L 形：切成 2 段直走廊，两段都标 chained -> registered=0（跨通道协调未做）
T6 256² 全量扫描：中位数 < 2 ms（实测 0.63）
T4 60v60：自动仲裁 A 队 95% @ ~114 s，对照组 160 s 时只有 16/60；380 s 两队都 >=95%
```

**接入（关卡加载/编辑后，不是每帧）**：

```c
rt_portal_scan(&PM, &G);        /* 0.63 ms @256² */
rt_portal_register(&PM, &CC);   /* 内部 rt_corr_clear_all()：几何变了就重新排队 */
/* 每帧仍走 M11 的 rt_corr_*，cid 从 PM.p[i].cid 取 */
```

**判据为什么是「自由行程长度」**：`clearance` 会把所有墙根都标成窄（贴墙的格子
clearance 都是 1.0）；按 8 m 区域边界找 portal 只在墙正好压在边界上时有效。
真正的通道特征是「一个方向很长、另一个方向很短」，所以
`narrow = min(span_x, span_z) <= 2.5 m`，两趟 run-length 就够。
**宽度用 `2 × min_clearance`（最窄处），不要用 bbox 短边** —— L 形的 bbox 是方的。

**三个参数不许乱调**：
- `lane_width = 2.5`：M11 实测 2 m 是真单车道、3 m 能自己交错。调大等于过度串行化。
- `min_cells = 8`：1 格厚的门洞（2 格）不需要仲裁，M11 测过。
- `staging_side > staging_size/2`：否则等待区会压回通道轴线，把 owner 的出口堵住。

### M13 测试（局部规划器 / 地形绕行）

```bash
# T1/T2/T3/T4/T5/T6：找缺口 / 小队 / 不可达 / 无退化 / 成本 / 确定性
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m13.c -o test_m13
./test_m13
```

**判读**：
```
T1 墙 + 2 m 缺口，单兵：对照组 0/1（永久放弃），规划组 1/1（~42 s）
T2 同一道墙，4 人小队：对照组 0/4，规划组 >=3/4
T3 封闭房间：规划组 engaged 必须为 0（分量快筛生效）、unreachable >=1，
   give-up 仍 22.4 s（与 M6 T2 基线一致），L1~L6 仍全触发
T4 开阔地 200 人：engaged 必须为 0（完全不介入），成本 <0.10 ms
T5 1000 人 + 12 格门（真导航）：到达数不比对照组少、perm 必须为 0、plan 均值 <0.60 ms
```

**接入顺序（M13 起）**：

```
pref ← rt_gw_sample  →  rt_plan_step  →  rt_stuck_step  →  rt_yield_step  →  rt_local_step
```

**四个必须遵守的约定**（每一条都对应一次实测失败）：

1. `aim[]` 必须是**本地目标**（导航的 11 m 前瞻点），**不能**是命令目标。拿命令目标
   喂进去，整个几十米的接近过程都会被判成「绕行」，预算瞬间耗尽（实测 T1 三次耗尽、
   人还在 73 m 外）。`goal[]` 另外单独传 —— 它只用来做连通分量快筛。
2. 直线检测必须按**单位本体**扫（中心 + 两侧偏移 `radius+0.1` 三条射线）。
   只测中心线时，2 m 缺口里 z=127.0 就判「通了」，交还后 ORCA 撞墙、
   GAVE_UP、冻结 52 s。
3. **不可达靠连通分量判，不靠预算兜底**：`rt_grid_component_at(单位) != (目标)`
   就不接管。只给预算会把 M6 的 give-up 顶到 31.4~55.2 s。
4. 重臂（`BLOCKED` -> `IDLE`）的条件是 **`nav_epoch` 前进**（地图真的变了），
   不是「等够时间」—— 时间重臂会让不可达场景每 8 s 重试一次。

**与卡死层的接法**：把 `rt_plan_hook` 挂到 `RtStuckHooks.local_repath`。
绕行中它返回 1，L3 就不会用自己的奇偶侧移覆盖绕行方向。

**取证探针**：`_设计验算/probe_m13_t1.c`（逐帧打印位置 / 状态 / 旋向 / 方向 /
clearance / 到墙距离）。

### M12 测试（队形接入流水线）

```bash
# T1/T2/T3：144 人 12×12 方阵 vs 点目标，同机对照
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m12.c -o test_m12
./test_m12
```

**判读**：
```
T1 队形：slot 覆盖 >=95%、就位 >=98%、凝聚度 >0.90、平均误差 <0.50 m
   实测晶格间距 2.19/2.20 m（pitch 2.2 ±0.25）—— 这是「方阵到底有没有格距」的直接判据
   最近邻中位数 >=1.75（理论基线 2.2 - 0.35 ≈ 1.85，min-of-4 序统计量天然偏低）
   nn_min >=1.30（证明没人被顶到 ORCA 接触距离 1.00）
T2 点目标：slot 覆盖远低于队形、晶格间距 <0.75×、最近邻 <0.80×、质心 <6 m（队列必然偏）
T3 两组：穿透 <0.6 m、0 永久放弃、帧均值 <8 ms
```

**为什么不用「全场最小间距」当判据**：10368 对里最差的一对，一个人被挤一下就红；
且 pitch 2.2 / 容差 0.35 时理论下界就是 1.50，永远不可能稳定 >1.60。
用 `pitch_*_meas`（列均值相邻差的中位数）+ `nn_median` 才分得开「方阵」和「挤一堆」。

**落脚策略是库里的，不是台架的**：`rt_form_steer_point` / `rt_form_member_steer`
（`RtFormSettle`：arrive 0.35 / reengage 0.90 / creep 0.12）。点目标与槽位两组共用同一套
停法，差异只来自「去哪」。**不要**在台架里写 `if (dist<1.2) pref=0` 并锁存 ——
M12 第一版就是这么写的，88/144 的人停在容差边缘，整块方阵塌成 1.0~1.5 m 的接触堆。

**取证探针**：`_设计验算/probe_m12_pair.c`（谁和谁贴着 + 每列/每行坐标）、
`_设计验算/probe_m12_ablate.c`（落脚策略 × 让路锁 四组消融）。
让路层**已排除**：锁与不锁差 1 个近邻对；`may_yield` 仍是调用方的选择。

### M8 测试（队形 FR-FOR）

```bash
# T1~T5：收敛 / 分配交叉数 / 窄道降级 / 朝向 / 成本与确定性
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m8.c -o test_m8
./test_m8
```

**判读**：
```
T1 16 人 4x4：worst_slot_err < 0.8 m，cohesion > 0.90，最小间距 > 1.6 m（不许塌成一团）
T2 50 人随机：分配后的交叉数必须 <= 按索引硬分的一半（实测 262 -> 79）
T3 宽度 12 m 保持矩形；5 m 降级为纵队（cols=1），槽距不变
T4 yaw 以 90°/s 平滑；差 >30° 时 needs_turn_in_place=1，到位后 0
T5 100 人分配 < 8 ms（命令时）；slot_world x100 < 0.02 ms（tick 内可用）
```

### M7 测试（静止单位让路 FR-YLD）

```bash
# T1~T5：单格走廊+壁龛 / 无交通不乱动 / 连续交通滞回 / 1000 人成本 / 确定性
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m7.c -o test_m7
./test_m7
```

**判读**：
```
T1 对照组必须 0/8（走廊被站着的人堵死）；让路组必须 8/8，且让路单位侧移 >1.2 m、回位 <0.8 m
T2 无交通：triggers 必须为 0，位移 < 0.05 m
T3 5 批连续交通：triggers <= 6，状态切换 <= 12（不许横跳）
T4 1000 人：mean < 0.2 ms，worst < 0.6 ms
T5 确定性：agent memcmp 相同、计数相同
```

**接入约定**：`pref_vel` 是**意图**，`vel` 是**结果**。被堵住的 mover 必须保留自己的
`pref_vel`（否则压力场读不到 `actual/desired`，永远不触发）。每帧顺序：
填 mover 的 `pref_vel` → `rt_yield_step` → `rt_local_step`。

### M6 测试（卡死检测 + 分级恢复 FR-STK）

```bash
# T1~T6：单格走廊对穿 / 目标不可达 / 合法排队 / 静止挡路 / 1000 人成本 / 确定性
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m6.c -o test_m6
./test_m6
```

**判读**：
```
T1 对照组（不调 rt_stuck_step）必须 0/2 通过；恢复组必须 2/2
   且 max_step <= max_speed*dt（不许传送，CON-9）
T2 封闭房间：permanent_stuck 必须为 1，give_up 时间 10~30 s，L1..L6 全部触发
T3 队列前车在走：episodes 必须为 0（合法排队不是 STUCK）
T4 静止单位挡走廊：episodes 必须为 0、permanent 必须为 0（QUEUED != STUCK）
T5 1000 人：mean < 0.6 ms，最坏采样帧 < 1.0 ms
T6 确定性：agent 与状态机 memcmp 都必须相同
```

**接入顺序（很重要）**：每帧先由 Simulation 填 `pref_vel`（来自 `rt_gw_sample()`），
再调 `rt_stuck_step()`，最后 `rt_local_step()`。`rt_stuck_step` 只写 `pref_vel`，
不写位置；它把「调用方想去的方向」记在 `want_dir` 里，下一采样用这个方向判进展。

**M11b 追加（waiting bay 回岗 + 放弃可重试）**：

- L6 的 bay 是**让路的位置，不是终点**：到位后若「这一轮卡死有人参与」（`ep_crowd`）
  且周围 2 m 无人 → 回原任务（`stats.resumes`）。
- `GAVE_UP` 不再是「本条命令的终态」：放弃时附近有人（`gave_up_crowd`）→
  人群散开 `revive_after`（默认 5 s）后重试（`stats.retries`）。
  `permanent_stuck` 统计**单位数**，重试不会重复计数。
- **两条恢复都必须挂在「有没有人参与」上**：没有这个门控，M6 T2 的封闭房间会
  「恢复 → 撞墙 → 再恢复」无限循环，永远给不出 `GAVE_UP`（实测 T2 从 19/19 掉到 17/19）。
- 试过但**已回退**：「没战术阻挡且在动 → 本层 10 s 不接管」，会把不可达检测吃掉，
  与 T2 契约冲突。凹角极限环要靠局部规划器（wall-following），不能靠本层少管。
- 取证探针：`_设计验算/probe_m11_tail.c`（打印掉队单位的完整状态机）。

### M5 测试与基准（局部避障 / ORCA）

```bash
# T1~T8：对穿 / 环形压力 / 撞墙 / 确定性 / 混合尺寸 / 1000 人成本 / 静止挡路 / 过城门
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m5.c -o test_m5
./test_m5

# N / k / 邻居半径 三段扫描
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c bench/bench_m5.c -o bench_m5
./bench_m5
```

**判读**：
```
T2 环形 900 步：最大穿透必须是 0（稠密场景允许 < 0.35，但本场景实测 0）
T3 往墙里走：blocked_frames 必须为 0，max_x 必须 < 墙坐标 - 半宽
T4 确定性：memcmp 必须相同（同输入同结果，CON-8）
T6 1000 人 best < 8 ms（实测 ~0.7~1.1 ms）
T8 24 人全过城门 + 0 穿墙（接缝测试：导航采样 -> ORCA -> 墙体）
bench：100/300/1000/2000 人 ≈ 0.09 / 0.29 / 1.09 / 2.35 ms（best）
```

**参数建议**：`neighbor_dist ≈ 2*max_radius + max_speed*τ`（典型 4 m）。
取 8 m 会让成本 ×2（见 bench C 段）；取 3 m 更快，但高速单位会「看不见」将要撞上的人。

**分层契约**：`rt_local.c` 不认识 Navigation（只 include `rt_grid.h`）。
期望速度由 Simulation 层从 `rt_gw_sample()` 采到后填进 `RtLocalAgent.pref_vel`。

### M4.6-P5 测试与探针（路线 B：异步 split）

```bash
# M11~M14：异步 split / 挂起期间下命令 / 挂起期间再编辑 / 挂起期间不穿墙
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m46.c -o test_m46
./test_m46

# 同步 vs 异步的同机 A/B（每次编辑后还原，两个 mode 从同一状态出发）
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c _设计验算/probe_m46_split_async.c -o probe_split_async
./probe_split_async
```

**判读**：
```
M11 提交后 pending 必须为 1（大分量 split 不能一帧跑完）
    frames >= 2，worst_frame < 1.5 ms，分区/区域图与全量逐个相等
M12 挂起期间 rt_gw_sample 仍返回 RT_OK；rt_gw_command 返回前 split_pending 必须变 0
M13 第二笔编辑命中同一 chunk -> cancels=1，两笔都不丢（分区 == 全量）
M14 pen=0（挂起期间旧 route 也绝不穿墙）
probe: sync 4.2~5.0 ms 一帧 -> async 最坏一帧 0.5~1.05 ms，8 帧摊完
```

**世界层新接口**：`rt_gw_submit_edit()`（提交编辑，可能挂起）、`rt_gw_split_pending()`、
`rt_gw_set_split_budget()`（默认 8000 节点/帧）、`rt_gw_set_async_split(0)`（回退同步）。

**调用契约**：用 `submit_edit` 之后**必须每帧调 `rt_gw_update`**，否则 split 永远不提交
（与 fine flow 预算同一个退化边界）。挂起期间不要直接读 `rt_grid_component_at`。

### M4.6-P4 测试与探针（大移除多块解锁 / ring 聚簇）

```bash
# 差分门禁：10000 次随机编辑 + 大编辑硬断言 + B4/B5 + 多块解锁
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_incremental.c -o test_incremental
./test_incremental 10000 256

# 大移除/大新增的成本 + 正确性 + 计数器
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c _设计验算/probe_m46_merge.c -o probe_m46_merge
./probe_m46_merge

# B5（unblock 的 clearance 差异）最小复现与画像
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c _设计验算/probe_b5_clear.c -o probe_b5_clear
./probe_b5_clear
```

**判读**：
```
test_incremental 的 "large edits (hard assertions)" 必须 PASS
  add 24x24 degraded 必须为 0（ring 聚簇后不再撞 256 seed 上限）
  del 24x24 degraded 必须为 0（多块解锁按连通块归属，不再降级）
multipatch unblock 必须 PASS，且 multipatch>0、fallback=0
probe_m46_merge:  del 8x8~64x64 从 4.7 ms（全量）降到 0.02~0.5 ms；
                  mpFall 必须为 0；rep_rescan 通常为 0
probe_b5_clear:  B5 clear_diffs 必须为 0；clearance_ring_fallbacks 为 0
```

**新增常驻计数器**（都在 `RtGrid`）：

| 字段 | 含义 |
|---|---|
| `merge_multipatch_count` | 一次移除切出 >1 块、且全部按块处理成功（正常） |
| `merge_multipatch_fallbacks` | 单块邻接 >16 个分量 / 重标失败 → 降级全量（应为 0） |
| `relabel_rep_rescan` | `component_rep` 失效后重扫次数（说明压过 rep 的编辑） |
| `clearance_stale_vectors` | 区域重算边界环上「向量指向已可走格」且标量已 clamp 的格子 |
| `clearance_ring_fallbacks` | 陈旧向量的标量未 clamp → pad 不够，降级全量（应为 0） |

### M4.6-P3 归因探针（不是测试）

```bash
zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c _设计验算/probe_grid_needfull.c -o pnf
./pnf            # 4x4..64x64 加建筑：耗时 / rc / pad / full+ / split_fail_*
```

**判读**：
```
rc=-3 且 full+=1     -> 这次编辑降级成了全量（看 split_fail_* 是哪一个）
split_fail_seeds=1   -> 编辑外圈同一分量的 seed 超过 256（>=24x24 的典型）
split+=1 且 rc=0     -> 没降级，但同步跑完了一个 split Job（12x12 的 2.3 ms）
lostOvf>0            -> lost[] 截断，已自动降级全量；若持续出现说明编辑面过大
```

四个 `split_fail_*` 计数器应为 0；非 0 就是「有编辑被迫走全量」的直接证据。

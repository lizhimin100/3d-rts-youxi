/* ============================================================================
 * probe_fineflow.c -- M4.4 设计前置取证（跑完即删，不进产品代码）
 *
 * 要回答三个问题：
 *   1. 「门户点 + 直线」到底多常被挡住？（凹角 stuck 的规模）
 *   2. 一次 LOS 检查的成本是多少？（决定能不能放进 rt_gw_sample）
 *   3. 修好它需要多大的窗口？（决定 fine flow 的 bounded window）
 *
 * 地图 B：U 形陷阱（三面墙，开口朝右），单位在陷阱内、目标在陷阱外右侧。
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void t_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void t_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;

static int seg_clear(RtVec2 a, RtVec2 b)
{
    float dx = b.x - a.x, dz = b.z - a.z;
    float len = sqrtf(dx * dx + dz * dz);
    int steps = (int)(len / 0.5f) + 1;
    for (int i = 0; i <= steps; i++) {
        float t = (float)i / (float)steps;
        int cx = rt_grid_cell_x(&G, a.x + dx * t), cz = rt_grid_cell_z(&G, a.z + dz * t);
        if (!rt_grid_walkable(&G, cx, cz)) return 0;
    }
    return 1;
}

/* U 形陷阱：x=100..140, z=60..100，开口朝 +x（x=140 那侧不封） */
static void build_trap(void)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int z = 50; z <= 110; z++) {
        for (int x = 90; x <= 140; x++) {
            int wall = 0;
            if (z == 50 || z == 110) wall = 1;         /* 上下 */
            if (x == 90) wall = 1;                      /* 左侧封口 */
            /* 内部再放一根柱子，制造凹角 */
            if (x >= 110 && x <= 118 && z >= 70 && z <= 78) wall = 1;
            if (wall) rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
    }
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
}

int main(void)
{
    t_init();
    printf("=== probe: fine-flow necessity (M4.4 design gate) ===\n");

    build_trap();
    RtUnitId ids[8];
    int n = 0;
    float starts[4][2] = { {100.5f, 60.5f}, {100.5f, 100.5f}, {130.5f, 60.5f}, {130.5f, 100.5f} };
    for (int i = 0; i < 4; i++)
        ids[n++] = rt_units_spawn(&US, rt_v3(starts[i][0], 0.f, starts[i][1]), RT_FP_SMALL);

    RtVec2 dest = rt_v2(200.5f, 80.5f);
    rt_gw_command(&W, &US, ids, n, dest, 0, RT_CLS_SMALL, 1);
    printf("groups=%d routes=%d builds=%u\n", W.group_count,
           W.groups[0].route_count, W.stats.route_builds);

    /* 用 walker 走，统计「直线被挡」的次数（= 需要 fine flow 的时刻） */
    for (int u = 0; u < n; u++) {
        RtVec3 p0 = rt_units_pos(&US, ids[u]);
        RtVec2 p = rt_v2(p0.x, p0.z);
        RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, ids[u]);
        int gi = (int)ch->group[rt_unit_slot_index(ids[u])] - 1;
        if (gi < 0) continue;
        int steps = 0, blocked = 0, arrived = 0;
        for (int i = 0; i < 4000 && !arrived; i++) {
            RtVec2 tgt;
            if (rt_gw_sample(&W, gi, p, &tgt) != RT_OK) break;
            RtVec2 d = rt_v2_sub(tgt, p);
            float len = rt_v2_len(d);
            if (len < 1e-4f) break;
            float step = 6.0f / 30.0f;
            if (step > len) step = len;
            RtVec2 np = rt_v2_add(p, rt_v2_mul(d, step / len));
            if (!seg_clear(p, np)) { blocked++; break; }   /* 直线被挡：fine flow 的用武之地 */
            p = np; steps++;
            if (rt_gw_is_arrived(&W, gi, p, 1.5f)) arrived = 1;
        }
        printf("  unit%d start=(%.0f,%.0f) steps=%d blocked=%d arrived=%d end=(%.1f,%.1f)\n",
               u, starts[u][0], starts[u][1], steps, blocked, arrived, p.x, p.z);
    }

    /* LOS 成本：每帧 1000 单位各做一次 1 m 步长的线段检查 */
    RtVec2 a = rt_v2(100.5f, 60.5f), b = rt_v2(130.5f, 100.5f);
    int rep = 20000;
    double t0 = now_ms();
    int acc = 0;
    for (int i = 0; i < rep; i++) acc += seg_clear(a, b);
    double t1 = now_ms();
    printf("\nLOS check: %.3f us/call (len=%.0f m, 0.5 m step), acc=%d\n",
           (t1 - t0) * 1000.0 / rep, sqrtf(30 * 30 + 40 * 40), acc);
    printf("=> 1000 units/frame x 1 LOS = %.3f ms\n", (t1 - t0) / rep * 1000.0);

    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return 0;
}

/* ============================================================================
 * rt_fineflow.c -- M4.4-B 有界 fine flow（cell 级引导场）
 * ==========================================================================*/
#include "rt_fineflow.h"
#include "rt_region.h"          /* rt_clear_radius_m */
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* 与 rt_route.c 相同的八邻域顺序（确定性 + 与区域层一致的下标含义） */
static const int FX8[8] = { 1, -1, 0, 0, 1, 1, -1, -1 };
static const int FZ8[8] = { 0, 0, 1, -1, -1, 1, 1, -1 };
/* padded 布局下的邻居偏移（stride = RT_FINE_PAD）：边框恒为阻挡，
 * 于是 BFS 内层不需要任何边界判断 —— 每次邻域检查少 4 次比较。 */
static const int FOFF[8] = {
    1, -1, RT_FINE_PAD, -RT_FINE_PAD,
    -RT_FINE_PAD + 1, RT_FINE_PAD + 1, RT_FINE_PAD - 1, -RT_FINE_PAD - 1
};
/* 对角防穿角要检查的两条正交边对应的方向下标 */
static const uint8_t FHOR[8] = { 0, 0, 0, 0, 0, 0, 1, 1 };
static const uint8_t FVER[8] = { 0, 0, 0, 0, 3, 2, 2, 3 };
/* 反向方向：opp[e] 是 -FX8[e],-FZ8[e] 的下标（查表代替 8 次比较） */
static const uint8_t FOPP[8] = { 1, 0, 3, 2, 7, 6, 5, 4 };

int rt_fine_solver_init(RtFineSolver *s, int max_cells)
{
    if (!s || max_cells <= 0) return RT_ERR_INVALID;
    memset(s, 0, sizeof(*s));
    s->queue = (int32_t *)malloc((size_t)max_cells * sizeof(int32_t));
    if (!s->queue) { rt_fine_solver_destroy(s); return RT_ERR_CAPACITY; }
    s->cap = max_cells;
    return RT_OK;
}

void rt_fine_solver_destroy(RtFineSolver *s)
{
    if (!s) return;
    free(s->queue); s->queue = NULL;
    s->cap = 0;
}

void rt_fine_free(RtFineFlow *f)
{
    if (!f) return;
    free(f->next);
    f->next = NULL;
    f->state = 0;
    f->dep_n = 0;
    f->dep_overflow = 0;
    f->reached = 0;
    f->w = f->h = 0;
}

/* 一格是否可走。clearance 过期时（编辑后未重算）**禁止**用它判定可通行
 * （rt_grid.h 的 safety 规则），退化为 flags 判定。
 * clearance 用整数（0.01 m）比较，避免每格一次 uint16->float 转换。 */
static inline int fine_cell_ok(const RtGrid *g, int x, int z, uint16_t need_cm)
{
    if (!rt_grid_walkable(g, x, z)) return 0;
    if (need_cm == 0 || !g->clearance_valid) return 1;
    return g->clearance[(size_t)z * g->w + x] + 1u >= (uint32_t)need_cm;
}

static void fine_note_dep(RtFineFlow *f, const RtGrid *g, int x, int z)
{
    int ch = rt_grid_chunk_of_cell(g, x, z);
    if (ch < 0 || ch >= RT_CHUNK_N) { f->dep_overflow = 1; return; }
    for (int i = 0; i < f->dep_n; i++) if ((int)f->dep_chunks[i] == ch) return;
    if (f->dep_n >= RT_FINE_DEP_MAX) { f->dep_overflow = 1; return; }
    f->dep_chunks[f->dep_n] = (uint32_t)ch;
    f->dep_vers[f->dep_n] = g->chunk_ver[ch];
    f->dep_n++;
}

int rt_fine_snap_cell(const RtGrid *g, int x, int z, float need, int *sx, int *sz)
{
    if (!g) return 0;
    uint16_t need_cm = (uint16_t)(need * 100.f + 0.5f);
    if (fine_cell_ok(g, x, z, need_cm)) { *sx = x; *sz = z; return 1; }
    /* ±3 环，取最小环；同环内取 clearance 最大者，再平手取固定顺序（确定性） */
    for (int ring = 1; ring <= 3; ring++) {
        int bx = x, bz = z, bc = -1;
        for (int dz = -ring; dz <= ring; dz++) {
            for (int dx = -ring; dx <= ring; dx++) {
                if (abs(dx) != ring && abs(dz) != ring) continue;
                int nx = x + dx, nz = z + dz;
                if (!fine_cell_ok(g, nx, nz, need_cm)) continue;
                int c = g->clearance_valid ? (int)g->clearance[(size_t)nz * g->w + nx] : 100000;
                if (c > bc) { bc = c; bx = nx; bz = nz; }
            }
        }
        if (bc >= 0) { *sx = bx; *sz = bz; return 1; }
    }
    return 0;
}

int rt_fineflow_build(RtFineFlow *f, RtFineSolver *s, const RtGrid *g,
                      int tx, int tz, int cls)
{
    if (!f || !s || !g) return RT_ERR_INVALID;
    if (cls < 0) cls = 0;
    if (cls >= RT_CLEAR_CLASSES) cls = RT_CLEAR_CLASSES - 1;

    uint16_t need_cm = (uint16_t)(rt_clear_radius_m(cls) * 100.f + 0.5f);

    /* 先把目标格吸附到能站的格，再定窗口；所有早退都在 memset 之前，
     * 避免「每次采样都白做一次 576×2 字节的清零」这种隐性开销。 */
    int sx, sz;
    if (!rt_fine_snap_cell(g, tx, tz, (float)need_cm * 0.01f, &sx, &sz)) {
        f->state = 0;
        return RT_ERR_NOT_FOUND;
    }
    tx = sx; tz = sz;

    int ox = tx - RT_FINE_RADIUS;
    int oz = tz - RT_FINE_RADIUS;
    /* 窗口尺寸固定（24×24），用编译期常量做 stride：队列里的 cell index
     * 用 / 和 % 还原坐标时，运行期除数会变成真除法（每次 ~20 cycle）。 */
    const int FW = RT_FINE_WIN;
    const int PS = RT_FINE_PAD;
    int w = FW, h = FW;

    /* 「超出即不建」：窗口被地图裁掉一半时引导场会退化成一个偏心的局部场，
     * 比不建更危险（会把单位领到边界外）。这里直接拒建，由调用方计数。 */
    if (ox < 0 || oz < 0 || ox + w > g->w || oz + h > g->h) {
        f->state = 0;
        return RT_ERR_INVALID;
    }
    if (RT_FINE_CELLS > s->cap) return RT_ERR_CAPACITY;

    if (!f->next || f->w != w || f->h != h) {
        free(f->next);
        f->next = (uint8_t *)malloc(RT_FINE_CELLS);
        if (!f->next) { f->w = f->h = 0; f->state = 0; return RT_ERR_CAPACITY; }
    }
    f->w = w; f->h = h;
    f->tx = tx; f->tz = tz;
    f->ox = ox; f->oz = oz;
    f->cls = (uint8_t)cls;
    f->dep_n = 0;
    f->dep_overflow = 0;
    f->reached = 0;
    f->state = 0;

    /* 把窗口搬进 padded 缓冲，直接复用 next[] 当状态数组（不再多一个 bitmap）：
     *   - 边框恒 NONE(255) = 阻挡，BFS 内层不需要任何边界判断；
     *   - 254 = 可走未访问，0..7 = 已访问且记录了朝目标的下一跳，255 = 阻挡；
     *   - 否则每格 8 邻域 × (walkable + clearance + 对角 2 次) 是 9k 次 grid 查询，
     *     单次建场实测 27 µs；搬完之后是 576 次。 */
    memset(f->next, RT_FINE_NONE, RT_FINE_CELLS);
    for (int z = 0; z < h; z++) {
        int gz = oz + z;
        uint8_t *row = f->next + (size_t)(z + 1) * PS + 1;
        for (int x = 0; x < w; x++)
            row[x] = fine_cell_ok(g, ox + x, gz, need_cm) ? RT_FINE_FREE : RT_FINE_NONE;
    }

    int head = 0, tail = 0;

    int lx = tx - ox, lz = tz - oz;
    if (lx < 0 || lz < 0 || lx >= w || lz >= h) return RT_ERR_INVALID;
    int li = (lz + 1) * PS + (lx + 1);
    if (f->next[li] != RT_FINE_FREE) return RT_ERR_NOT_FOUND;

    f->next[li] = RT_FINE_DONE;
    s->queue[tail++] = li;
    f->reached = 1;

    while (head < tail) {
        int cur = s->queue[head++];
        for (int e = 0; e < 8; e++) {
            int ni = cur + FOFF[e];
            if (f->next[ni] != RT_FINE_FREE) continue;
            /* 防穿角：对角移动要求两条正交边都通（与区域层 edge_ok 同语义） */
            if (e >= 4) {
                if (f->next[cur + FOFF[FHOR[e]]] == RT_FINE_NONE) continue;
                if (f->next[cur + FOFF[FVER[e]]] == RT_FINE_NONE) continue;
            }
            f->next[ni] = FOPP[e];                     /* 从 ni 走向 cur = 朝目标的下一跳 */
            s->queue[tail++] = ni;
            f->reached++;
        }
    }

    /* 依赖：只记窗口覆盖到的 chunk（2×2），任一 chunk 版本变化 => 整块失效 */
    fine_note_dep(f, g, ox, oz);
    fine_note_dep(f, g, ox + w - 1, oz);
    fine_note_dep(f, g, ox, oz + h - 1);
    fine_note_dep(f, g, ox + w - 1, oz + h - 1);
    if (f->dep_overflow) { f->state = 0; return RT_ERR_CAPACITY; }

    f->state = 1;
    return RT_OK;
}

int rt_fineflow_valid(const RtFineFlow *f, const RtGrid *g)
{
    if (!f || !g || f->state != 1 || !f->next) return 0;
    if (f->dep_overflow) return 0;
    for (int i = 0; i < f->dep_n; i++) {
        uint32_t c = f->dep_chunks[i];
        if (c >= RT_CHUNK_N) return 0;
        if (g->chunk_ver[c] != f->dep_vers[i]) return 0;
    }
    return 1;
}

int rt_fineflow_next_pos(const RtFineFlow *f, const RtGrid *g,
                         int cx, int cz, RtVec2 *out)
{
    if (!f || !g || !out || f->state != 1 || !f->next) return 0;
    int lx = cx - f->ox, lz = cz - f->oz;
    if (lx < 0 || lz < 0 || lx >= f->w || lz >= f->h) return 0;
    uint8_t d = f->next[(lz + 1) * RT_FINE_PAD + (lx + 1)];
    if (d >= 8) return 0;
    int nx = cx + FX8[d], nz = cz + FZ8[d];
    /* 输出格中心：与 rt_region_anchor 保持同一约定（+0.5 cell） */
    *out = rt_v2(((float)nx + 0.5f) * g->cell, ((float)nz + 0.5f) * g->cell);
    return 1;
}

int rt_los_clear(const RtGrid *g, RtVec2 a, RtVec2 b)
{
    if (!g) return 0;
    float cell = (g->cell > 1e-6f) ? g->cell : 1.f;
    float x0 = a.x / cell, z0 = a.z / cell;
    float x1 = b.x / cell, z1 = b.z / cell;

    int cx = (int)floorf(x0), cz = (int)floorf(z0);
    int ex = (int)floorf(x1), ez = (int)floorf(z1);
    if (!rt_grid_walkable(g, cx, cz)) return 0;

    int dx = (x1 > x0) ? 1 : ((x1 < x0) ? -1 : 0);
    int dz = (z1 > z0) ? 1 : ((z1 < z0) ? -1 : 0);
    float ddx = x1 - x0, ddz = z1 - z0;
    float tdx = (dx != 0) ? fabsf(1.f / ddx) : 1e30f;
    float tdz = (dz != 0) ? fabsf(1.f / ddz) : 1e30f;
    float tmx = (dx > 0) ? ((float)(cx + 1) - x0) * tdx
                         : ((dx < 0) ? (x0 - (float)cx) * tdx : 1e30f);
    float tmz = (dz > 0) ? ((float)(cz + 1) - z0) * tdz
                         : ((dz < 0) ? (z0 - (float)cz) * tdz : 1e30f);

    /* 步数上界：地图对角线的格数 + 少量冗余，避免浮点退化导致死循环 */
    int guard = g->w + g->h + 4;
    while ((cx != ex || cz != ez) && guard-- > 0) {
        if (tmx < tmz) { cx += dx; tmx += tdx; }
        else           { cz += dz; tmz += tdz; }
        if (!rt_grid_walkable(g, cx, cz)) return 0;
    }
    return (cx == ex && cz == ez);
}

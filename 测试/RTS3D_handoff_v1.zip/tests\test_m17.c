/* ============================================================================
 * test_m17.c -- GAVE_UP 不是终态（复活判据三条）+ 墙角蹭墙预算（M17）
 *
 * 要证明的事：
 *   T1  三条判据各自都够用（CLEAR / PATH / FLOW），且只走该走的那一条
 *   T2  「家具不算人群」：两个放弃者互为邻居时仍然都能复活
 *       （M15 实测：相距 1.86 m，含放弃单位的最小邻域计数恒为 1 -> 永不复活）
 *   T3  不是「无论如何都复活」：前方有活人且没人动 -> 不复活；超过 revive_cap -> 不再重试
 *   T4  不可达契约不变：封闭房间仍是一次 PermanentStuck、0 次重试、10~30 s 内
 *   T5  墙角蹭墙：轴对齐 pref 顶在墙角能蹭出去，且单帧位移 <= v*dt（不传送）、
 *       预算（wall_escape_m）用完就停
 *   T6  确定性：两次相同输入逐位相同
 *
 * 关于「伪造 GAVE_UP 状态」：T1/T2/T3/T5 用 force_gave_up() 直接把单位置成放弃态。
 * 这是**判据级**单元测试，故意绕过 20 s 的六级爬梯子（那是 M6 T2 / 本文件 T4 的事），
 * 否则每个用例都要跑 30 s 且互相污染状态。
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_stuck.h"

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", (m)); } } while (0)

#define MAXA 64
#define DT   (1.f / 30.f)

static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;
static RtStuckCtx SC;
static RtGrid G;

/* ---------------------------------------------------------------------------
 * 通用脚手架
 * -------------------------------------------------------------------------*/
static void agent_set(int i, float x, float z, float r, float speed, float px, float pz)
{
    memset(&AG[i], 0, sizeof(AG[i]));
    AG[i].pos = rt_v2(x, z);
    AG[i].vel = rt_v2(0.f, 0.f);
    AG[i].pref_vel = rt_v2(px, pz);
    AG[i].radius = r;
    AG[i].max_speed = speed;
    AG[i].fp = r * 2.f;
    AG[i].share = 0.5f;
    AG[i].inv_mass = 1.f;
}

static void grid_open(void)
{
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    rt_grid_rebuild_all(&G);
}

static void local_reset(int cap)
{
    rt_local_destroy(&LC);
    rt_local_init(&LC, 256.f, 256.f, cap, 4.5f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);
}

/* 判据测试要的配置：静默期短、探测快，这样几百帧就能跑完一个用例 */
static void stuck_cfg_fast(RtStuckConfig *c)
{
    rt_stuck_config_default(c);
    c->sample_hz     = 10.f;
    c->revive_after  = 0.40f;
    c->revive_cap    = 4;
    c->permanent_time = 20.f;
}

/* 直接把单位置成「放弃」态（见文件头说明） */
static void force_gave_up(int i, RtVec2 want)
{
    RtStuckUnit *u = &SC.u[i];
    u->state = RT_STUCK_GAVE_UP;
    u->level = RT_STUCK_MAX_LEVEL + 1;
    u->gave_up_crowd = 1;
    u->ever_gave_up = 1;
    u->revive_t = 0.f;
    u->probe_t = 0.f;
    u->revive_tries = 0;
    u->want_dir = rt_v2_norm(want);
    u->stuck_time = 0.f;
    SC.st.permanent_stuck = 1;
}

static int count_all_within(int i, int n, float radius)
{
    float r2 = radius * radius;
    int c = 0;
    for (int j = 0; j < n; j++) {
        if (j == i) continue;
        if (rt_v2_len2(rt_v2_sub(AG[j].pos, AG[i].pos)) <= r2) c++;
    }
    return c;
}

/* 每帧：pref 由用例给定 -> 卡死层 -> 局部层。返回单帧最大位移（查传送）。 */
static float step_all(int n, float *pref_x, float *pref_z)
{
    if (pref_x && pref_z)
        for (int i = 0; i < n; i++) AG[i].pref_vel = rt_v2(pref_x[i], pref_z[i]);

    RtVec2 before[MAXA];
    for (int i = 0; i < n; i++) before[i] = AG[i].pos;

    rt_stuck_step(&SC, AG, n, &G, DT, NULL);
    rt_local_step(&LC, AG, n, &G, DT);

    float mx = 0.f;
    for (int i = 0; i < n; i++) {
        float d = rt_v2_dist(before[i], AG[i].pos);
        if (d > mx) mx = d;
    }
    return mx;
}

/* ============================================================================
 * T1：三条判据各走一条
 * ==========================================================================*/
static void t1_criteria(void)
{
    printf("\n[T1] 三条复活判据各自都够用\n");

    /* --- T1a R1 CLEAR：周围没人 --- */
    {
        grid_open();
        local_reset(4);
        RtStuckConfig cfg; stuck_cfg_fast(&cfg);
        rt_stuck_destroy(&SC);
        rt_stuck_init(&SC, 4, &cfg);

        const int n = 1;
        agent_set(0, 128.5f, 128.5f, 0.5f, 2.0f, 2.0f, 0.f);
        force_gave_up(0, rt_v2(1.f, 0.f));

        for (int s = 0; s < 60; s++) {           /* 2 s */
            (void)step_all(n, NULL, NULL);
            AG[0].pref_vel = rt_v2(2.0f, 0.f);
        }
        printf("      CLEAR: retries=%u clear=%u path=%u flow=%u state=%s tries=%d\n",
               SC.st.retries, SC.st.revives_clear, SC.st.revives_path, SC.st.revives_flow,
               rt_stuck_state_name((int)SC.u[0].state), (int)SC.u[0].revive_tries);
        OK(SC.st.revives_clear >= 1, "T1a nobody around -> revive (CLEAR)");
        OK(SC.u[0].state != RT_STUCK_GAVE_UP, "T1a unit is no longer GAVE_UP");
    }

    /* --- T1b R2 PATH：身后有人、前方没人 --- */
    {
        grid_open();
        local_reset(4);
        RtStuckConfig cfg; stuck_cfg_fast(&cfg);
        rt_stuck_destroy(&SC);
        rt_stuck_init(&SC, 4, &cfg);

        const int n = 2;
        agent_set(0, 128.5f, 128.5f, 0.5f, 2.0f, 2.0f, 0.f);   /* 想往 +x 走 */
        agent_set(1, 127.0f, 128.5f, 0.5f, 0.0f, 0.f, 0.f);    /* 停在身后 1.5 m */
        force_gave_up(0, rt_v2(1.f, 0.f));
        const int n_all = count_all_within(0, n, 2.0f);        /* 复活前测，之后它会走开 */

        for (int s = 0; s < 60; s++) {
            (void)step_all(n, NULL, NULL);
            AG[0].pref_vel = rt_v2(2.0f, 0.f);
            AG[1].pref_vel = rt_v2(0.f, 0.f);
        }
        printf("      PATH : retries=%u clear=%u path=%u flow=%u state=%s\n",
               SC.st.retries, SC.st.revives_clear, SC.st.revives_path, SC.st.revives_flow,
               rt_stuck_state_name((int)SC.u[0].state));
        OK(n_all == 1, "T1b the parked unit really is within 2 m");
        OK(SC.st.revives_clear == 0, "T1b CLEAR does not fire (someone is within 2 m)");
        OK(SC.st.revives_path >= 1, "T1b PATH fires: nobody blocks the way forward");
    }

    /* --- T1c R3 FLOW：正前方有人，但整条队伍在走 --- */
    {
        grid_open();
        local_reset(4);
        RtStuckConfig cfg; stuck_cfg_fast(&cfg);
        rt_stuck_destroy(&SC);
        rt_stuck_init(&SC, 4, &cfg);

        const int n = 2;
        agent_set(0, 128.5f, 128.5f, 0.5f, 1.0f, 2.0f, 0.f);
        agent_set(1, 130.0f, 128.5f, 0.5f, 1.0f, 1.0f, 0.f);   /* 正前方 1.5 m，匀速走 */
        AG[1].max_speed = 1.0f;
        force_gave_up(0, rt_v2(1.f, 0.f));

        float px[2] = { 2.0f, 1.0f }, pz[2] = { 0.f, 0.f };
        for (int s = 0; s < 60; s++) (void)step_all(n, px, pz);   /* 两个都持续要 +x */

        float netp = SC.u[1].net_progress;
        printf("      FLOW : retries=%u clear=%u path=%u flow=%u  leader_netp=%.2f state=%s\n",
               SC.st.retries, SC.st.revives_clear, SC.st.revives_path, SC.st.revives_flow,
               netp, rt_stuck_state_name((int)SC.u[0].state));
        OK(SC.st.revives_clear == 0, "T1c CLEAR does not fire");
        OK(SC.st.revives_flow >= 1, "T1c FLOW fires when the queue ahead is draining");
        OK(SC.u[0].revive_why == RT_STUCK_REVIVE_FLOW, "T1c the recorded reason is FLOW");
    }
}

/* ============================================================================
 * T2：家具不算人群
 * ==========================================================================*/
static void t2_furniture(void)
{
    printf("\n[T2] 两个放弃者互为邻居：仍然都要复活\n");
    grid_open();
    local_reset(4);
    RtStuckConfig cfg; stuck_cfg_fast(&cfg);
    rt_stuck_destroy(&SC);
    rt_stuck_init(&SC, 4, &cfg);

    const int n = 2;
    agent_set(0, 128.50f, 128.50f, 0.5f, 2.0f, 2.0f, 0.f);
    agent_set(1, 128.50f, 130.36f, 0.5f, 2.0f, 2.0f, 0.f);   /* 相距 1.86 m（= M15 实测距离） */
    force_gave_up(0, rt_v2(1.f, 0.f));
    force_gave_up(1, rt_v2(1.f, 0.f));

    const int n_all = count_all_within(0, n, 2.0f);
    for (int s = 0; s < 60; s++) {
        (void)step_all(n, NULL, NULL);
        AG[0].pref_vel = rt_v2(2.0f, 0.f);
        AG[1].pref_vel = rt_v2(2.0f, 0.f);
    }
    printf("      n_all(2m)=%d  retries=%u clear=%u  states: %s / %s  x=%.1f/%.1f\n",
           n_all, SC.st.retries, SC.st.revives_clear,
           rt_stuck_state_name((int)SC.u[0].state), rt_stuck_state_name((int)SC.u[1].state),
           AG[0].pos.x, AG[1].pos.x);
    OK(n_all == 1, "T2 each abandoned unit sees exactly one neighbour (the other one)");
    OK(SC.st.retries == 2, "T2 both of them revive anyway (furniture is not a crowd)");
    OK(AG[0].pos.x - 128.5f > 2.0f && AG[1].pos.x - 128.5f > 2.0f,
       "T2 both actually moved out instead of standing there");
}

/* ============================================================================
 * T3：不是「无论如何都复活」
 * ==========================================================================*/
static void t3_not_always(void)
{
    printf("\n[T3] 前方有活人且没人动 -> 不复活；超过 revive_cap -> 不再重试\n");

    /* --- T3a 静止挡路的人：三条判据都不成立 --- */
    {
        grid_open();
        local_reset(4);
        RtStuckConfig cfg; stuck_cfg_fast(&cfg);
        rt_stuck_destroy(&SC);
        rt_stuck_init(&SC, 4, &cfg);

        const int n = 2;
        agent_set(0, 128.5f, 128.5f, 0.5f, 2.0f, 2.0f, 0.f);
        agent_set(1, 130.0f, 128.5f, 0.5f, 0.0f, 0.f, 0.f);   /* 正前方 1.5 m，停着 */
        force_gave_up(0, rt_v2(1.f, 0.f));

        for (int s = 0; s < 180; s++) {          /* 6 s，远大于 revive_after */
            (void)step_all(n, NULL, NULL);
            AG[0].pref_vel = rt_v2(2.0f, 0.f);
            AG[1].pref_vel = rt_v2(0.f, 0.f);
        }
        printf("      parked blocker: retries=%u clear=%u path=%u flow=%u state=%s\n",
               SC.st.retries, SC.st.revives_clear, SC.st.revives_path, SC.st.revives_flow,
               rt_stuck_state_name((int)SC.u[0].state));
        OK(SC.st.retries == 0, "T3a no revive while a live unit still blocks the way");
        OK(SC.u[0].state == RT_STUCK_GAVE_UP, "T3a unit stays GAVE_UP");
    }

    /* --- T3b 复活上限 --- */
    {
        grid_open();
        local_reset(4);
        RtStuckConfig cfg; stuck_cfg_fast(&cfg);
        cfg.revive_cap = 1;
        rt_stuck_destroy(&SC);
        rt_stuck_init(&SC, 4, &cfg);

        const int n = 2;
        agent_set(0, 128.5f, 128.5f, 0.5f, 2.0f, 2.0f, 0.f);
        agent_set(1, 127.0f, 128.5f, 0.5f, 0.0f, 0.f, 0.f);   /* 身后 -> PATH 成立 */
        force_gave_up(0, rt_v2(1.f, 0.f));

        for (int s = 0; s < 60; s++) {           /* 第一次复活 */
            (void)step_all(n, NULL, NULL);
            AG[0].pref_vel = rt_v2(2.0f, 0.f);
            AG[1].pref_vel = rt_v2(0.f, 0.f);
        }
        const int tries1 = (int)SC.u[0].revive_tries;
        force_gave_up(0, rt_v2(1.f, 0.f));       /* 再放弃一次（同一条命令内） */
        SC.u[0].revive_tries = tries1;           /* force_* 会清零，这里保留计数 */
        for (int s = 0; s < 120; s++) {
            (void)step_all(n, NULL, NULL);
            AG[0].pref_vel = rt_v2(2.0f, 0.f);
            AG[1].pref_vel = rt_v2(0.f, 0.f);
        }
        printf("      cap=1: tries=%d capped=%u retries=%u state=%s\n",
               (int)SC.u[0].revive_tries, SC.st.revives_capped, SC.st.retries,
               rt_stuck_state_name((int)SC.u[0].state));
        OK(tries1 == 1, "T3b first revive consumed the whole budget");
        OK(SC.u[0].revive_tries <= 1, "T3b revive_cap=1 is respected");
        OK(SC.st.revives_capped >= 1, "T3b the refusal is counted, not silent");
    }
}

/* ============================================================================
 * T4：不可达契约（M6 T2 口径）—— 复活判据没有把封闭房间变成永动机
 * ==========================================================================*/
static void t4_unreachable(void)
{
    printf("\n[T4] 封闭房间：一次 PermanentStuck、0 次重试、10~30 s 内\n");
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int x = 100; x <= 104; x++) {
        rt_grid_set_terrain(&G, x, 100, RT_CELL_BLOCKED_TERRAIN, 1);
        rt_grid_set_terrain(&G, x, 104, RT_CELL_BLOCKED_TERRAIN, 1);
    }
    for (int z = 100; z <= 104; z++) {
        rt_grid_set_terrain(&G, 100, z, RT_CELL_BLOCKED_TERRAIN, 1);
        rt_grid_set_terrain(&G, 104, z, RT_CELL_BLOCKED_TERRAIN, 1);
    }
    rt_grid_rebuild_all(&G);
    local_reset(8);

    RtStuckConfig cfg;
    rt_stuck_config_default(&cfg);      /* 默认 permanent_time = 20 s */
    rt_stuck_destroy(&SC);
    rt_stuck_init(&SC, 8, &cfg);

    const int n = 1;
    agent_set(0, 102.5f, 102.5f, 0.4f, 1.2f, 0.f, 0.f);
    const RtVec2 goal = rt_v2(120.f, 102.5f);
    float maxstep = 0.f;
    int gave_frame = -1;
    for (int s = 0; s < 1200; s++) {
        RtVec2 d = rt_v2_sub(goal, AG[0].pos);
        float l = rt_v2_len(d);
        AG[0].pref_vel = (l > 0.5f) ? rt_v2_mul(d, 1.2f / l) : rt_v2(0.f, 0.f);
        float mx = step_all(n, NULL, NULL);
        if (mx > maxstep) maxstep = mx;
        if (gave_frame < 0 && SC.st.permanent_stuck > 0) gave_frame = s;
    }
    float t_gave = (gave_frame >= 0) ? (float)gave_frame * DT : -1.f;
    printf("      gave_up=%.1fs state=%s retries=%u lvl_fires=%u/%u/%u/%u/%u/%u max_step=%.4f\n",
           t_gave, rt_stuck_state_name((int)SC.u[0].state), SC.st.retries,
           SC.st.level_fires[1], SC.st.level_fires[2], SC.st.level_fires[3],
           SC.st.level_fires[4], SC.st.level_fires[5], SC.st.level_fires[6], maxstep);
    OK(SC.st.permanent_stuck == 1, "T4 exactly one PermanentStuck");
    OK(SC.st.retries == 0, "T4 terrain dead ends are never retried");
    OK(t_gave >= 10.0f && t_gave <= 30.0f, "T4 give-up stays inside the 10~30 s window");
    OK(SC.st.level_fires[1] > 0 && SC.st.level_fires[6] > 0, "T4 the whole L1..L6 ladder fired");
    OK(maxstep <= 1.2f * DT + 1e-3f, "T4 no teleport");
}

/* ============================================================================
 * T5：墙角蹭墙（预算 + 不传送）
 * ==========================================================================*/
static void t5_wall_escape(void)
{
    printf("\n[T5] 墙角：轴对齐 pref 蹭出去，预算用完就停，全程不穿墙\n");
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    /* 东墙 x>=120、北墙 z>=120：内侧是一个直角凹角，单位在 (119.5,119.5) 附近 */
    for (int z = 0; z < 256; z++)
        for (int x = 120; x < 128; x++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int x = 0; x < 256; x++)
        for (int z = 120; z < 128; z++)
            if (x < 120) rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);
    local_reset(4);

    RtStuckConfig cfg; stuck_cfg_fast(&cfg);
    rt_stuck_destroy(&SC);
    rt_stuck_init(&SC, 4, &cfg);

    const int n = 1;
    agent_set(0, 118.2f, 118.2f, 0.5f, 2.0f, 2.0f, 0.f);   /* 只想要 +x，笔直怼墙 */
    const float z0 = AG[0].pos.z;
    float maxstep = 0.f;
    int in_wall = 0;
    for (int s = 0; s < 400; s++) {
        /* 不走卡死层：这一条只验局部层的几何行为 */
        RtVec2 before = AG[0].pos;
        AG[0].pref_vel = rt_v2(2.0f, 0.f);
        (void)rt_local_step(&LC, AG, n, &G, DT);
        float d = rt_v2_dist(before, AG[0].pos);
        if (d > maxstep) maxstep = d;
        RtObb2 o = rt_obb_make(AG[0].pos, AG[0].fp, 0.f);
        if (rt_grid_obb_blocked(&G, &o)) in_wall++;
    }
    float dz = AG[0].pos.z - z0;                 /* 切向位移：蹭墙唯一能走的方向 */
    printf("      end=(%.2f,%.2f) dz=%.2f escape=%u denied=%u clamped=%u max_step=%.4f in_wall=%d\n",
           AG[0].pos.x, AG[0].pos.z, dz, LC.stat_wall_escape, LC.stat_escape_denied,
           LC.stat_wall_clamped, maxstep, in_wall);
    OK(LC.stat_wall_escape > 0, "T5 the corner escape fired");
    OK(dz > 0.30f, "T5 the unit got off the dead point instead of creeping at 0.0003 m/frame");
    OK(fabsf(dz) <= LC.wall_escape_m + 0.15f,
       "T5 travel along the wall stays inside the mileage budget");
    OK(maxstep <= 2.0f * DT + 1e-3f, "T5 no teleport (<= v*dt)");
    OK(in_wall == 0, "T5 never enters a blocked cell");
    OK(LC.stat_escape_denied > 0, "T5 the budget running out is counted, not silent");

    /* 对照：关掉蹭墙，同一场景就该冻在原地 */
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int z = 0; z < 256; z++)
        for (int x = 120; x < 128; x++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    for (int x = 0; x < 256; x++)
        for (int z = 120; z < 128; z++)
            if (x < 120) rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);
    local_reset(4);
    LC.wall_escape = 0;
    agent_set(0, 118.2f, 118.2f, 0.5f, 2.0f, 2.0f, 0.f);
    for (int s = 0; s < 400; s++) {
        AG[0].pref_vel = rt_v2(2.0f, 0.f);
        (void)rt_local_step(&LC, AG, n, &G, DT);
    }
    float dz_ctrl = AG[0].pos.z - z0;
    printf("      control(escape=0): end=(%.2f,%.2f) dz=%.2f escape=%u\n",
           AG[0].pos.x, AG[0].pos.z, dz_ctrl, LC.stat_wall_escape);
    OK(fabsf(dz_ctrl) < 0.05f && LC.stat_wall_escape == 0,
       "T5 control: without the escape the unit just freezes at the corner");
    LC.wall_escape = 1;
}

/* ============================================================================
 * T6：确定性
 * ==========================================================================*/
static void t6_determinism(void)
{
    printf("\n[T6] 确定性：两次相同输入逐位相同\n");
    RtVec2 p[2][3];
    for (int run = 0; run < 2; run++) {
        rt_grid_destroy(&G);
        rt_grid_init(&G, 256, 256, 1.0f);
        for (int z = 0; z < 256; z++)
            for (int x = 120; x < 128; x++)
                rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        for (int x = 0; x < 256; x++)
            for (int z = 120; z < 128; z++)
                if (x < 120) rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        rt_grid_rebuild_all(&G);
        local_reset(8);
        RtStuckConfig cfg; stuck_cfg_fast(&cfg);
        rt_stuck_destroy(&SC);
        rt_stuck_init(&SC, 8, &cfg);

        const int n = 3;
        agent_set(0, 118.2f, 118.2f, 0.5f, 2.0f, 2.0f, 0.f);
        agent_set(1, 118.2f, 116.0f, 0.5f, 2.0f, 2.0f, 0.f);
        agent_set(2, 114.0f, 118.2f, 0.5f, 2.0f, 2.0f, 0.f);
        for (int s = 0; s < 300; s++) (void)step_all(n, NULL, NULL);
        for (int i = 0; i < n; i++) p[run][i] = AG[i].pos;
    }
    int same = 1;
    for (int i = 0; i < 3; i++)
        if (p[0][i].x != p[1][i].x || p[0][i].z != p[1][i].z) same = 0;
    printf("      run0=(%.4f,%.4f) run1=(%.4f,%.4f) identical=%d\n",
           p[0][0].x, p[0][0].z, p[1][0].x, p[1][0].z, same);
    OK(same, "T6 two identical runs produce bit-identical positions");
}

int main(void)
{

    printf("=== M17 tests: GAVE_UP is not a terminal state + wall-corner escape ===\n");

    t1_criteria();
    t2_furniture();
    t3_not_always();
    t4_unreachable();
    t5_wall_escape();
    t6_determinism();

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    if (g_fail == 0) printf("ALL PASS (%d asserts)\n", g_pass);

    rt_stuck_destroy(&SC);
    rt_local_destroy(&LC);
    rt_grid_destroy(&G);
    return g_fail == 0 ? 0 : 1;
}

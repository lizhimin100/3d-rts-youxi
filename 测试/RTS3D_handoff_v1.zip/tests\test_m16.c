/* ============================================================================
 * test_m16.c -- 队形落脚点五级降级（FR-FOR-5 / 01 §11.1）
 *
 * M8 只回答了「生成 / 分配 / 窄道降级」，落脚点一律假设 anchor 是好的。
 * 本文件问的是：**点击点在墙里 / 在 45° 斜带上 / 在 3 m 隧道里 / 根本放不下**
 * 时，队形应该落在哪、代价多少、哪一级被触发。
 *
 * 四个探针都是解析形状（不建网格），这样失败只可能来自搜索本身：
 *   SolidWorld  —— 空地 + 若干实心矩形（墙心起步 / 边界）
 *   TunnelWorld —— 只有 free 矩形内可走（隧道 / 口袋 / 全实心）
 *   BandWorld   —— 45° 斜带（只有转向才能放下的情形）
 *   RtGrid 适配 —— 最后一条：真的接一次网格，逐槽复核
 *
 * 断言口径：
 *   1. 每一级都必须是**零冲突**（valid 槽用探针复核，不信返回值）
 *   2. L0~L4 的位移按切比雪夫半径递增 → 第一个解就是最小位移
 *   3. L5 允许冲突，但 valid 槽必须真的可用、且互相不压（>= fp）
 *   4. 确定性：同输入两次，slot 局部坐标逐位相同
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_math.h"
#include "rt_form.h"
#include "rt_grid.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", (m)); } } while (0)

static RtFormation FM;

static void form_new(int cap)
{
    rt_form_destroy(&FM);
    rt_form_init(&FM, cap);
}

/* ---- 探针 1：空地 + 实心矩形 ---- */
typedef struct {
    RtAabb2 solids[8];
    int     ns;
    float   wx, wz;
} SolidWorld;

static int solid_state(void *ud, const RtObb2 *o)
{
    SolidWorld *w = (SolidWorld *)ud;
    RtAabb2 bb = rt_obb_aabb(o);
    if (bb.min_x < 0.f || bb.min_z < 0.f || bb.max_x > w->wx || bb.max_z > w->wz) return 2;
    for (int i = 0; i < w->ns; i++)
        if (rt_obb_overlaps_aabb(o, &w->solids[i])) return 1;
    return 0;
}

/* ---- 探针 2：只有 free 矩形内可走（隧道 / 口袋），可选柱子 ---- */
typedef struct {
    RtAabb2 free_r[8];
    int     nf;
    RtAabb2 solids[4];
    int     nss;
    float   wx, wz;
} TunnelWorld;

static int tunnel_state(void *ud, const RtObb2 *o)
{
    TunnelWorld *w = (TunnelWorld *)ud;
    RtVec2 c[4];
    rt_obb_corners(o, c);
    for (int i = 0; i < 4; i++) {
        if (c[i].x < 0.f || c[i].z < 0.f || c[i].x > w->wx || c[i].z > w->wz) return 2;
    }
    for (int r = 0; r < w->nss; r++)
        if (rt_obb_overlaps_aabb(o, &w->solids[r])) return 1;
    for (int r = 0; r < w->nf; r++) {
        const RtAabb2 *b = &w->free_r[r];
        int in = 1;
        for (int i = 0; i < 4; i++) {
            if (c[i].x < b->min_x - 1e-4f || c[i].x > b->max_x + 1e-4f ||
                c[i].z < b->min_z - 1e-4f || c[i].z > b->max_z + 1e-4f) { in = 0; break; }
        }
        if (in) return 0;
    }
    return 1;
}

/* ---- 探针 3：45° 斜带 ---- */
typedef struct {
    RtVec2 c;
    float  nx, nz;     /* 带法线（单位） */
    float  half_w;
    float  half_len;
    float  wx, wz;
} BandWorld;

static int band_state(void *ud, const RtObb2 *o)
{
    BandWorld *b = (BandWorld *)ud;
    RtAabb2 bb = rt_obb_aabb(o);
    if (bb.min_x < 0.f || bb.min_z < 0.f || bb.max_x > b->wx || bb.max_z > b->wz) return 2;

    float dx = o->center.x - b->c.x, dz = o->center.z - b->c.z;
    float ax = o->cos_a, az = o->sin_a;        /* 本地 x 轴 */
    float bx = -o->sin_a, bz = o->cos_a;       /* 本地 z 轴 */

    float hn = fabsf(b->nx * ax + b->nz * az) * o->half.x +
               fabsf(b->nx * bx + b->nz * bz) * o->half.z;
    if (fabsf(dx * b->nx + dz * b->nz) + hn > b->half_w + 1e-4f) return 1;

    float tx = -b->nz, tz = b->nx;
    float ht = fabsf(tx * ax + tz * az) * o->half.x +
               fabsf(tx * bx + tz * bz) * o->half.z;
    if (fabsf(dx * tx + dz * tz) + ht > b->half_len + 1e-4f) return 1;
    return 0;
}

/* ---- 复核工具（不信返回值）---- */
static int count_valid_slots(const RtFormation *f)
{
    int c = 0;
    for (int i = 0; i < f->slot_count; i++) if (f->slots[i].valid) c++;
    return c;
}

static int all_valid_free(const RtFormation *f, const RtFormProbe *p, float fp)
{
    for (int i = 0; i < f->slot_count; i++) {
        if (!f->slots[i].valid) continue;
        RtObb2 o = rt_obb_make(rt_form_slot_world(f, i), fp, f->yaw);
        if (p->obb_state(p->ud, &o) != 0) return 0;
    }
    return 1;
}

static float min_pair_valid(const RtFormation *f)
{
    float best = 1e9f;
    for (int i = 0; i < f->slot_count; i++) {
        if (!f->slots[i].valid) continue;
        for (int j = i + 1; j < f->slot_count; j++) {
            if (!f->slots[j].valid) continue;
            float d = rt_v2_dist(rt_form_slot_world(f, i), rt_form_slot_world(f, j));
            if (d < best) best = d;
        }
    }
    return best;
}

/* ============================================================================
 * T1 开阔地：L0 原样落，一次评估
 * ==========================================================================*/
static void t1_open(void)
{
    printf("\n[T1] 开阔地：L0（不搜）\n");
    SolidWorld w;
    memset(&w, 0, sizeof(w));
    w.wx = w.wz = 256.f;
    RtFormProbe p = { &w, solid_state };

    form_new(256);
    RtFormPlaceStat s;
    double t0 = now_ms();
    int rc = rt_form_place(&FM, 100, 1.0f, 1.0f, rt_v2(128.f, 128.f), 0.f, &p, NULL, &s);
    double ms = now_ms() - t0;

    printf("  level=%d evals=%d cost=%.2f cols=%d rows=%d pitch=%.2f valid=%d  %.3f ms\n",
           s.level, s.evals, s.cost, s.cols, s.rows, s.pitch_x, count_valid_slots(&FM), ms);
    OK(rc == RT_OK, "T1 returns RT_OK");
    OK(s.level == 0, "T1 open field lands at L0 (no search)");
    OK(s.evals == 1, "T1 L0 costs exactly one evaluation");
    OK(count_valid_slots(&FM) == 100, "T1 all 100 slots valid");
    OK(all_valid_free(&FM, &p, 1.0f), "T1 every valid slot is really free");
    OK(fabsf(s.pitch_x - 2.0f) < 1e-4f && fabsf(s.pitch_z - 2.0f) < 1e-4f, "T1 pitch = fp + gap");
    OK(FM.slot_count == 100, "T1 slot_count == count");
}

/* ============================================================================
 * T2 墙心起步：L1 平移，位移最小
 * ==========================================================================*/
static void t2_wall_anchor(void)
{
    printf("\n[T2] anchor 在 8x8 实心块中心：L1\n");
    SolidWorld w;
    memset(&w, 0, sizeof(w));
    w.wx = w.wz = 256.f;
    w.ns = 1;
    w.solids[0].min_x = 124.f; w.solids[0].max_x = 132.f;
    w.solids[0].min_z = 124.f; w.solids[0].max_z = 132.f;
    RtFormProbe p = { &w, solid_state };

    form_new(256);
    RtFormPlaceStat s;
    int rc = rt_form_place(&FM, 36, 1.0f, 1.0f, rt_v2(128.f, 128.f), 0.f, &p, NULL, &s);
    float shift = rt_v2_dist(s.anchor, rt_v2(128.f, 128.f));

    printf("  level=%d evals=%d shift=%.1f m anchor=(%.1f,%.1f) valid=%d\n",
           s.level, s.evals, shift, s.anchor.x, s.anchor.z, count_valid_slots(&FM));
    OK(rc == RT_OK, "T2 returns RT_OK");
    OK(s.level == 1, "T2 wall anchor falls back to L1 (translate only)");
    OK(shift >= 9.0f, "T2 the formation is pushed clear of the block");
    OK(count_valid_slots(&FM) == 36, "T2 all slots valid after the shift");
    OK(all_valid_free(&FM, &p, 1.0f), "T2 every valid slot is really free");
    OK(fabsf(FM.yaw) < 1e-4f, "T2 L1 keeps the requested yaw");
}

/* ============================================================================
 * T3 45° 斜带：只有转向才放得下 → L2
 * ==========================================================================*/
static void t3_band(void)
{
    printf("\n[T3] 45 度斜带（宽 15 m）：L2 转向\n");
    BandWorld w;
    memset(&w, 0, sizeof(w));
    w.c = rt_v2(128.f, 128.f);
    w.nx = 0.70710678f; w.nz = 0.70710678f;
    w.half_w = 7.5f;
    w.half_len = 45.f;
    w.wx = w.wz = 256.f;
    RtFormProbe p = { &w, band_state };

    form_new(128);
    RtFormPlaceStat s;
    int rc = rt_form_place(&FM, 49, 1.0f, 1.0f, rt_v2(128.f, 128.f), 0.f, &p, NULL, &s);
    float yaw_deg = fabsf(s.yaw) * 57.29578f;

    printf("  level=%d evals=%d yaw=%.1f deg valid=%d\n",
           s.level, s.evals, yaw_deg, count_valid_slots(&FM));
    OK(rc == RT_OK, "T3 returns RT_OK");
    OK(s.level == 2, "T3 diagonal band needs L2 (rotate)");
    OK(fabsf(yaw_deg - 45.f) < 1.0f, "T3 picks ~45 deg (the only orientation that fits)");
    OK(count_valid_slots(&FM) == 49, "T3 all slots valid after rotating");
    OK(all_valid_free(&FM, &p, 1.0f), "T3 every valid slot is really free");
}

/* ============================================================================
 * T4 3 m 隧道：矩形/转向都不行 → L3 变形（纵队）
 * ==========================================================================*/
static void t4_tunnel_column(void)
{
    printf("\n[T4] 3 m 宽 40 m 长隧道：L3 变形（纵队）\n");
    TunnelWorld w;
    memset(&w, 0, sizeof(w));
    w.nf = 1;
    w.free_r[0].min_x = 40.f; w.free_r[0].max_x = 80.f;
    w.free_r[0].min_z = 30.f; w.free_r[0].max_z = 33.f;
    w.wx = w.wz = 256.f;
    RtFormProbe p = { &w, tunnel_state };

    form_new(128);
    RtFormPlaceStat s;
    int rc = rt_form_place(&FM, 16, 1.0f, 1.0f, rt_v2(42.f, 31.5f), 0.f, &p, NULL, &s);

    printf("  level=%d evals=%d kind=%s cols=%d rows=%d anchor=(%.1f,%.1f) valid=%d\n",
           s.level, s.evals, FM.kind == RT_FORM_COLUMN ? "COLUMN" : "RECT",
           s.cols, s.rows, s.anchor.x, s.anchor.z, count_valid_slots(&FM));
    OK(rc == RT_OK, "T4 returns RT_OK");
    OK(s.level == 3, "T4 3 m tunnel needs L3 (reshape)");
    OK(FM.kind == RT_FORM_COLUMN && s.cols == 1 && s.rows == 16, "T4 degrades to a single column");
    OK(s.anchor.x > 60.f, "T4 anchor slides forward so the queue fits in the tunnel");
    OK(count_valid_slots(&FM) == 16, "T4 all slots valid");
    OK(all_valid_free(&FM, &p, 1.0f), "T4 every valid slot is really inside the tunnel");
}

/* ============================================================================
 * T4b 同一个隧道，允许 180°：会「省 28 m 但整队朝后」—— 默认封顶 90° 的证据
 * ==========================================================================*/
static void t4b_yaw_cap(void)
{
    printf("\n[T4b] 同一隧道 + max_yaw_dev=180：180 度纵队省位移但反向\n");
    TunnelWorld w;
    memset(&w, 0, sizeof(w));
    w.nf = 1;
    w.free_r[0].min_x = 40.f; w.free_r[0].max_x = 80.f;
    w.free_r[0].min_z = 30.f; w.free_r[0].max_z = 33.f;
    w.wx = w.wz = 256.f;
    RtFormProbe p = { &w, tunnel_state };

    RtFormPlaceCfg cfg;
    rt_form_place_default(&cfg);
    cfg.max_yaw_dev = 3.14159265f;

    form_new(64);
    RtFormPlaceStat s;
    int rc = rt_form_place(&FM, 16, 1.f, 1.f, rt_v2(42.f, 31.5f), 0.f, &p, &cfg, &s);

    printf("  level=%d evals=%d yaw=%.0f deg anchor_x=%.1f\n",
           s.level, s.evals, s.yaw * 57.29578f, s.anchor.x);
    OK(rc == RT_OK, "T4b returns RT_OK");
    OK(s.level == 3, "T4b still L3");
    OK(fabsf(fabsf(s.yaw) - 3.14159265f) < 0.01f, "T4b 180 deg is chosen when allowed");
    OK(s.anchor.x < 45.f, "T4b anchor does not move (the queue points forward instead)");
}

/* ============================================================================
 * T5 5 m x 12 m 隧道：只有压缩间距才放得下 → L4
 * ==========================================================================*/
static void t5_compress(void)
{
    printf("\n[T5] 5 m x 12 m 隧道（fp=2, pitch=3）：L4 压缩\n");
    TunnelWorld w;
    memset(&w, 0, sizeof(w));
    w.nf = 1;
    w.free_r[0].min_x = 40.f; w.free_r[0].max_x = 52.f;
    w.free_r[0].min_z = 30.f; w.free_r[0].max_z = 35.f;
    w.wx = w.wz = 256.f;
    RtFormProbe p = { &w, tunnel_state };

    form_new(64);
    RtFormPlaceStat s;
    int rc = rt_form_place(&FM, 9, 2.0f, 1.0f, rt_v2(46.f, 32.5f), 0.f, &p, NULL, &s);

    printf("  level=%d evals=%d cols=%d rows=%d pitch=%.2f valid=%d\n",
           s.level, s.evals, s.cols, s.rows, s.pitch_x, count_valid_slots(&FM));
    OK(rc == RT_OK, "T5 returns RT_OK");
    OK(s.level == 4, "T5 needs L4 (compress pitch)");
    OK(fabsf(s.pitch_x - 2.2f) < 1e-4f, "T5 pitch compressed to fp + 0.2");
    OK(s.cols == 5 && s.rows == 2, "T5 reshapes to 5x2 to fit 12 m length");
    OK(count_valid_slots(&FM) == 9, "T5 all slots valid");
    OK(all_valid_free(&FM, &p, 2.0f), "T5 every valid slot is really inside");
}

/* ============================================================================
 * T6 6x6 口袋 + 100 人：L5 部分落 + 3x3 兜底 + 环绕队列
 * ==========================================================================*/
static void t6_pocket(void)
{
    printf("\n[T6] 6x6 口袋装 100 人：L5 部分落\n");
    TunnelWorld w;
    memset(&w, 0, sizeof(w));
    w.nf = 1;
    w.free_r[0].min_x = 125.f; w.free_r[0].max_x = 131.f;
    w.free_r[0].min_z = 125.f; w.free_r[0].max_z = 131.f;
    w.wx = w.wz = 256.f;
    RtFormProbe p = { &w, tunnel_state };

    form_new(256);
    RtFormPlaceStat s;
    int rc = rt_form_place(&FM, 100, 1.0f, 1.0f, rt_v2(128.f, 128.f), 0.f, &p, NULL, &s);
    int valid = count_valid_slots(&FM);

    printf("  level=%d evals=%d conflicts=%d nudged=%d invalid=%d queued=%d valid=%d min_pair=%.2f\n",
           s.level, s.evals, s.conflicts, s.nudged_slots, s.invalid_slots,
           s.queued_slots, valid, min_pair_valid(&FM));
    OK(rc == RT_OK, "T6 returns RT_OK");
    OK(s.level == 5, "T6 partial placement is L5");
    OK(s.conflicts > 50, "T6 L5 reports the conflicts (not silent)");
    OK(valid >= 4, "T6 at least a few slots land inside the pocket");
    OK(valid + s.invalid_slots == 100,
       "T6 every member is accounted for (valid [incl. nudged] + queued)");
    OK(s.queued_slots == 0, "T6 no free orbit spot outside a sealed pocket");
    OK(all_valid_free(&FM, &p, 1.0f), "T6 valid slots are really free");
    OK(min_pair_valid(&FM) >= 0.94f, "T6 valid slots never overlap each other");
}

/* ============================================================================
 * T6b 5x5 房间 + 中心柱子：L5 的 3x3 兜底真的挪得动
 *   —— 房间刚好等于方阵尺寸，所以 L1~L4 全是零解；只有 1 个槽压在柱子上。
 *   兜底必须拒绝「挪 1 m 就贴到邻居身上」的四邻位（间距 < fp+0.2），
 *   只接受对角（1.41 m）。
 * ==========================================================================*/
static void t6b_nudge(void)
{
    printf("\n[T6b] 5x5 房间 + 0.6 m 柱子：L5 的 3x3 兜底\n");
    TunnelWorld w;
    memset(&w, 0, sizeof(w));
    w.nf = 1;
    w.free_r[0].min_x = 125.f; w.free_r[0].max_x = 130.f;
    w.free_r[0].min_z = 125.f; w.free_r[0].max_z = 130.f;
    w.nss = 1;
    w.solids[0].min_x = 127.2f; w.solids[0].max_x = 127.8f;
    w.solids[0].min_z = 127.2f; w.solids[0].max_z = 127.8f;
    w.wx = w.wz = 256.f;
    RtFormProbe p = { &w, tunnel_state };

    form_new(64);
    RtFormPlaceStat s;
    int rc = rt_form_place(&FM, 9, 1.0f, 1.0f, rt_v2(127.5f, 127.5f), 0.f, &p, NULL, &s);

    printf("  level=%d conflicts=%d nudged=%d invalid=%d valid=%d center=(%.1f,%.1f)\n",
           s.level, s.conflicts, s.nudged_slots, s.invalid_slots,
           count_valid_slots(&FM), FM.slots[4].local.x, FM.slots[4].local.z);
    OK(rc == RT_OK, "T6b returns RT_OK");
    OK(s.level == 5, "T6b exact-fit room + pillar has no zero-conflict layout");
    OK(s.conflicts == 1, "T6b exactly one slot sits on the pillar");
    OK(s.nudged_slots == 1, "T6b 3x3 nudge recovers that slot");
    OK(s.invalid_slots == 0, "T6b nobody is left in the orbit queue");
    OK(count_valid_slots(&FM) == 9, "T6b all 9 slots are usable");
    OK(all_valid_free(&FM, &p, 1.0f), "T6b every slot is really free after the nudge");
    OK(fabsf(FM.slots[4].local.x - 1.f) < 1e-3f &&
       fabsf(FM.slots[4].local.z - 1.f) < 1e-3f,
       "T6b the slot moved diagonally (neighbours are 1 m away on the axes)");
    OK(min_pair_valid(&FM) >= 1.19f, "T6b nudge keeps >= fp + 0.2 from every other slot");
}

/* ============================================================================
 * T6c 30x6 长廊：放不下 100 人，但**两端还有空间** → 环绕队列必须用上
 *   —— 第一版「按自己的 lattice 点往外推」在这里一个都对不上（推出去还在墙里），
 *      改成「从 anchor 出发、16 方向 × 半径外扩」之后，队形前后两端各站得下 1 个。
 * ==========================================================================*/
static void t6c_orbit(void)
{
    printf("\n[T6c] 30x6 长廊装 100 人：环绕队列\n");
    TunnelWorld w;
    memset(&w, 0, sizeof(w));
    w.nf = 1;
    w.free_r[0].min_x = 113.f; w.free_r[0].max_x = 143.f;
    w.free_r[0].min_z = 125.f; w.free_r[0].max_z = 131.f;
    w.wx = w.wz = 256.f;
    RtFormProbe p = { &w, tunnel_state };

    form_new(256);
    RtFormPlaceStat s;
    int rc = rt_form_place(&FM, 100, 1.0f, 1.0f, rt_v2(128.f, 128.f), 0.f, &p, NULL, &s);

    int queued = 0, queued_bad = 0;
    for (int i = 0; i < FM.slot_count; i++) {
        if (!FM.slots[i].queued) continue;
        queued++;
        RtVec2 qp = rt_form_slot_world(&FM, i);
        printf("    queued slot %d at (%.2f, %.2f)\n", i, qp.x, qp.z);
        RtObb2 o = rt_obb_make(qp, 1.0f, FM.yaw);
        if (p.obb_state(p.ud, &o) != 0) queued_bad++;
    }
    printf("  anchor=(%.2f,%.2f) yaw=%.2f\n", s.anchor.x, s.anchor.z, s.yaw);
    printf("  level=%d conflicts=%d valid=%d invalid=%d queued=%d bad=%d\n",
           s.level, s.conflicts, count_valid_slots(&FM), s.invalid_slots, queued, queued_bad);
    OK(rc == RT_OK, "T6c returns RT_OK");
    OK(s.level == 5, "T6c 30x6 cannot host 100 units");
    OK(queued >= 1, "T6c the orbit queue finds the free ends of the corridor");
    OK(queued == s.queued_slots, "T6c queued_slots matches the per-slot flags");
    OK(queued_bad == 0, "T6c every queued spot is really free");
    OK(count_valid_slots(&FM) + s.invalid_slots == 100, "T6c accounting closes");
}

/* ============================================================================
 * T7 全实心：L5 全放弃，但必须终止且不越预算
 * ==========================================================================*/
static void t7_solid(void)
{
    printf("\n[T7] 全实心（无处可落）\n");
    TunnelWorld w;
    memset(&w, 0, sizeof(w));
    w.wx = w.wz = 256.f;
    RtFormProbe p = { &w, tunnel_state };

    form_new(64);
    RtFormPlaceStat s;
    double t0 = now_ms();
    int rc = rt_form_place(&FM, 16, 1.0f, 1.0f, rt_v2(128.f, 128.f), 0.f, &p, NULL, &s);
    double ms = now_ms() - t0;

    printf("  level=%d evals=%d truncated=%d invalid=%d valid=%d  %.2f ms\n",
           s.level, s.evals, s.truncated, s.invalid_slots,
           count_valid_slots(&FM), ms);
    OK(rc == RT_OK, "T7 still returns a layout (never fails silently)");
    OK(s.level == 5 && s.invalid_slots == 16, "T7 all 16 slots are queued");
    OK(count_valid_slots(&FM) == 0, "T7 no slot claims to be valid");
    OK(s.truncated == 0, "T7 full search fits inside the eval budget");
    OK(ms < 200.0, "T7 worst case stays command-time cheap (<200 ms)");
}

/* ============================================================================
 * T8 确定性
 * ==========================================================================*/
static void t8_determinism(void)
{
    printf("\n[T8] 确定性（同输入两次逐位相同）\n");
    TunnelWorld w;
    memset(&w, 0, sizeof(w));
    w.nf = 1;
    w.free_r[0].min_x = 40.f; w.free_r[0].max_x = 80.f;
    w.free_r[0].min_z = 30.f; w.free_r[0].max_z = 33.f;
    w.wx = w.wz = 256.f;
    RtFormProbe p = { &w, tunnel_state };

    static RtVec2 loc1[64], loc2[64];
    RtFormPlaceStat s1, s2;

    form_new(64);
    rt_form_place(&FM, 16, 1.f, 1.f, rt_v2(42.f, 31.5f), 0.f, &p, NULL, &s1);
    for (int i = 0; i < 16; i++) loc1[i] = FM.slots[i].local;

    form_new(64);
    rt_form_place(&FM, 16, 1.f, 1.f, rt_v2(42.f, 31.5f), 0.f, &p, NULL, &s2);
    for (int i = 0; i < 16; i++) loc2[i] = FM.slots[i].local;

    int same = (memcmp(loc1, loc2, sizeof(RtVec2) * 16) == 0);
    printf("  level %d/%d evals %d/%d slots identical=%s\n",
           s1.level, s2.level, s1.evals, s2.evals, same ? "yes" : "NO");
    OK(same, "T8 identical placements");
    OK(s1.level == s2.level && s1.evals == s2.evals, "T8 identical level / eval count");
    OK(fabsf(s1.anchor.x - s2.anchor.x) < 1e-6f, "T8 identical anchor");
}

/* ============================================================================
 * T9 边界：anchor 贴角 → 整体被推回图内
 * ==========================================================================*/
static void t9_bounds(void)
{
    printf("\n[T9] anchor 在 (3,3)，图 256：L1 推回图内\n");
    SolidWorld w;
    memset(&w, 0, sizeof(w));
    w.wx = w.wz = 256.f;
    RtFormProbe p = { &w, solid_state };

    form_new(256);
    RtFormPlaceStat s;
    int rc = rt_form_place(&FM, 100, 1.0f, 1.0f, rt_v2(3.f, 3.f), 0.f, &p, NULL, &s);

    int inside = 1;
    for (int i = 0; i < 100; i++) {
        RtVec2 c = rt_form_slot_world(&FM, i);
        if (c.x - 0.5f < 0.f || c.z - 0.5f < 0.f || c.x + 0.5f > 256.f || c.z + 0.5f > 256.f) inside = 0;
    }
    printf("  level=%d shift=%.1f anchor=(%.1f,%.1f)\n",
           s.level, rt_v2_dist(s.anchor, rt_v2(3.f, 3.f)), s.anchor.x, s.anchor.z);
    OK(rc == RT_OK, "T9 returns RT_OK");
    OK(s.level == 1, "T9 corner anchor is handled by L1");
    OK(inside, "T9 the whole formation ends up inside the map");
    OK(s.oob == 0, "T9 the chosen placement itself is not out of bounds");
}

/* ============================================================================
 * T10 4x4 大 footprint：pitch 5、整体 50 m
 * ==========================================================================*/
static void t10_big_fp(void)
{
    printf("\n[T10] 4x4 单位 x100（整体 50x50 m）\n");
    SolidWorld w;
    memset(&w, 0, sizeof(w));
    w.wx = w.wz = 256.f;
    RtFormProbe p = { &w, solid_state };

    form_new(256);
    RtFormPlaceStat s;
    double t0 = now_ms();
    int rc = rt_form_place(&FM, 100, 4.0f, 1.0f, rt_v2(10.f, 10.f), 0.f, &p, NULL, &s);
    double ms = now_ms() - t0;

    printf("  level=%d evals=%d shift=%.1f pitch=%.1f valid=%d  %.2f ms\n",
           s.level, s.evals, rt_v2_dist(s.anchor, rt_v2(10.f, 10.f)),
           s.pitch_x, count_valid_slots(&FM), ms);
    OK(rc == RT_OK, "T10 returns RT_OK");
    OK(s.level == 1, "T10 50 m block near the corner is shifted inward");
    OK(fabsf(s.pitch_x - 5.0f) < 1e-4f, "T10 pitch = 4 + 1");
    OK(count_valid_slots(&FM) == 100, "T10 all valid");
    OK(all_valid_free(&FM, &p, 4.0f), "T10 every 4x4 footprint is free");
}

/* ============================================================================
 * T11 网格适配器：真的接一次 RtGrid，逐槽复核
 * ==========================================================================*/
static void t11_grid(void)
{
    printf("\n[T11] RtGrid 适配器（隧道 40x3）\n");
    static RtGrid G;
    rt_grid_destroy(&G);
    rt_grid_init(&G, 128, 128, 1.0f);
    for (int z = 0; z < 128; z++)
        for (int x = 0; x < 128; x++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN,
                                (x < 20 || x > 60 || z < 40 || z > 43) ? 1 : 0);
    rt_grid_rebuild_all(&G);

    RtFormProbe p;
    rt_form_probe_grid(&p, &G);

    form_new(64);
    RtFormPlaceStat s;
    int rc = rt_form_place(&FM, 16, 1.0f, 1.0f, rt_v2(22.f, 41.5f), 0.f, &p, NULL, &s);

    int bad = 0;
    for (int i = 0; i < FM.slot_count; i++) {
        if (!FM.slots[i].valid) continue;
        RtObb2 o = rt_obb_make(rt_form_slot_world(&FM, i), 1.0f, FM.yaw);
        if (rt_grid_obb_blocked(&G, &o)) bad++;
    }
    printf("  level=%d evals=%d kind=%s valid=%d blocked=%d\n",
           s.level, s.evals, FM.kind == RT_FORM_COLUMN ? "COLUMN" : "RECT",
           count_valid_slots(&FM), bad);
    OK(rc == RT_OK, "T11 returns RT_OK");
    OK(s.level == 3, "T11 grid tunnel also needs L3");
    OK(FM.kind == RT_FORM_COLUMN, "T11 grid tunnel degrades to a column");
    OK(count_valid_slots(&FM) == 16, "T11 all slots valid");
    OK(bad == 0, "T11 independent grid check agrees: no slot inside a wall");
    rt_grid_destroy(&G);
}

/* ============================================================================
 * T12 API 契约
 * ==========================================================================*/
static void t12_api(void)
{
    printf("\n[T12] API 契约\n");
    SolidWorld w;
    memset(&w, 0, sizeof(w));
    w.wx = w.wz = 64.f;
    RtFormProbe p = { &w, solid_state };
    RtFormPlaceStat s;

    form_new(8);
    int rc_cap = rt_form_place(&FM, 9, 1.f, 1.f, rt_v2(32.f, 32.f), 0.f, &p, NULL, &s);
    int rc_null = rt_form_place(&FM, 4, 1.f, 1.f, rt_v2(32.f, 32.f), 0.f, &p, NULL, NULL);
    int rc_bad = rt_form_place(&FM, 4, 1.f, 1.f, rt_v2(32.f, 32.f), 0.f, NULL, NULL, &s);
    int rc_zero = rt_form_place(&FM, 0, 1.f, 1.f, rt_v2(32.f, 32.f), 0.f, &p, NULL, &s);

    printf("  over-capacity=%d null-out=%d null-probe=%d zero=%d\n",
           rc_cap, rc_null, rc_bad, rc_zero);
    OK(rc_cap == RT_ERR_CAPACITY, "T12 over capacity is rejected");
    OK(rc_null == RT_OK, "T12 out-stat is optional");
    OK(rc_bad == RT_ERR_INVALID, "T12 missing probe is rejected");
    OK(rc_zero == RT_ERR_INVALID, "T12 count 0 is rejected");
    OK(FM.slot_count == 4, "T12 rejected calls leave the formation untouched");

    RtFormPlaceStat s1;
    form_new(4);
    int rc_one = rt_form_place(&FM, 1, 1.f, 1.f, rt_v2(32.f, 32.f), 0.f, &p, NULL, &s1);
    OK(rc_one == RT_OK && s1.level == 0 && FM.slot_count == 1,
       "T12 a single unit lands at L0");
}

int main(void)
{
    timer_init();
    printf("=== M16 tests: formation landing search (FR-FOR-5) ===\n");
    t1_open();
    t2_wall_anchor();
    t3_band();
    t4_tunnel_column();
    t4b_yaw_cap();
    t5_compress();
    t6_pocket();
    t6b_nudge();
    t6c_orbit();
    t7_solid();
    t8_determinism();
    t9_bounds();
    t10_big_fp();
    t11_grid();
    t12_api();
    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    if (g_fail == 0) printf("ALL PASS (%d asserts)\n", g_pass);
    rt_form_destroy(&FM);
    return g_fail == 0 ? 0 : 1;
}

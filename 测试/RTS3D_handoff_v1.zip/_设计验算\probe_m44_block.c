/* 临时：方块柱子（7x7 留 1 格缝）能否造成被挡的走廊段？跑完即删。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;

static void scene(int bx, int bz, int bw, int bh)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int z = bz; z < bz + bh; z++)
        for (int x = bx; x < bx + bw; x++)
            rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
}

int main(void)
{
    printf("=== block pillar candidates ===\n");
    /* 8x8 区域 x[64..71] z[80..87]，块 7x7 贴左上，留右下 1 格缝 */
    struct { int bx, bz, bw, bh; } cand[] = {
        { 64, 80, 7, 7 }, { 65, 80, 7, 7 }, { 64, 81, 7, 7 }, { 65, 81, 6, 6 },
        { 64, 80, 8, 5 }, { 64, 80, 5, 8 },
    };
    for (int i = 0; i < 6; i++) {
        scene(cand[i].bx, cand[i].bz, cand[i].bw, cand[i].bh);
        RtUnitId id = rt_units_spawn(&US, rt_v3(20.5f, 0.f, 84.5f), RT_FP_SMALL);
        RtUnitId ids[1] = { id };
        rt_gw_command(&W, &US, ids, 1, rt_v2(230.5f, 84.5f), 0, RT_CLS_SMALL, 1);
        printf("  block(%d,%d,%dx%d): n=%d segs=%u blocked=%u\n",
               cand[i].bx, cand[i].bz, cand[i].bw, cand[i].bh,
               W.groups[0].route_count > 0 ? W.groups[0].routes[0].route.n : -1,
               W.stats.corridor_segments, W.stats.corridor_blocked);
    }
    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return 0;
}

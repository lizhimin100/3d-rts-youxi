/* ============================================================================
 * rt_types.h -- RTS 3D 移动内核 · 基础类型与全局常量
 *
 * 设计纪律：
 *   1. 本文件是**唯一**的容量上界来源；禁止在别处出现魔数（由审计脚本检查）。
 *   2. 所有容量都是**理论上界 + 越界告警计数**，不做静默丢弃（2D 工程题的教训：
 *      容量算错导致数据被丢 → 指标被低估，且看不出来）。
 *   3. 不含任何引擎头文件。本内核可独立编译、独立测试。
 * ==========================================================================*/
#ifndef RT_TYPES_H
#define RT_TYPES_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---------------------------------------------------------------- 版本 */
#define RT_VERSION_MAJOR 0
#define RT_VERSION_MINOR 1
#define RT_VERSION_PATCH 0

/* ------------------------------------------------------------ 容量上界 */
/* 题面压测 1000~2000；上界留 2 倍余量。超过即报 RT_ERR_CAPACITY。 */
#define RT_MAX_UNITS        4096
#define RT_MAX_GROUPS       128
#define RT_MAX_FORMATIONS   128
#define RT_MAX_PATHS        512
#define RT_MAX_FLOWFIELDS   8
#define RT_MAX_CORRIDORS    64
#define RT_MAX_LAYERS       8
#define RT_MAX_PORTALS      512

/* 网格：题面最小 256x256，压测 512x512；上界 1024 供大图 */
#define RT_GRID_MAX_DIM     1024
#define RT_GRID_MIN_DIM     32

/* ---------------------------------------------------------------- 时间 */
/* 逻辑固定步长：30Hz（题面 §25 建议区间 15/30/60 的默认值） */
#define RT_TICK_HZ          30
#define RT_DT               (1.0f / 30.0f)
#define RT_MAX_SUBSTEPS     4

/* ------------------------------------------------------------ 单位尺寸 */
/* footprint 边长（格 = 米）。题面 §2：1x1 / 2x2 / 4x4 */
#define RT_FP_SMALL         1
#define RT_FP_MEDIUM        2
#define RT_FP_LARGE         4
/* 单位高度（米），参与遮挡/视线 */
#define RT_HEIGHT_SMALL     1.2f
#define RT_HEIGHT_MEDIUM    1.8f
#define RT_HEIGHT_LARGE     3.0f

/* ------------------------------------------------------------ 错误码 */
typedef enum {
    RT_OK               =  0,
    RT_ERR_CAPACITY     = -1,   /* 固定池满（必须被计数，不允许静默丢弃） */
    RT_ERR_INVALID      = -2,   /* 参数非法 */
    RT_ERR_NOT_FOUND    = -3,   /* id 不存在/已释放 */
    RT_ERR_BLOCKED      = -4,   /* 目标被硬阻挡 */
    RT_ERR_UNREACHABLE  = -5,   /* 连通域不可达 */
    RT_ERR_DEGENERATE   = -6    /* 退化输入（零长度、零容量等） */
} RtResult;

/* ------------------------------------------------------------ 单位状态 */
typedef enum {
    RT_STATE_IDLE        = 0,   /* 静止，无命令 */
    RT_STATE_MOVING      = 1,   /* 自由移动（单体/群体无队形） */
    RT_STATE_FORMATION   = 2,   /* 队形移动（跟 slot） */
    RT_STATE_YIELDING    = 3,   /* 静止让路中（F-YLD） */
    RT_STATE_RETURNING   = 4,   /* 让路后返回原位 */
    RT_STATE_UNSTUCK     = 5,   /* 卡死恢复中（FR-STK-2） */
    RT_STATE_COUNT       = 6
} RtUnitState;

/* ------------------------------------------------------------ 网格标志 */
enum {
    RT_CELL_BLOCKED_TERRAIN = 1u << 0,   /* 地形硬阻挡（不可被建筑覆盖改变） */
    RT_CELL_BLOCKED_BUILDING= 1u << 1,   /* 建筑硬阻挡（动态，overlay 计数 > 0） */
    RT_CELL_SLOPE           = 1u << 2,   /* 斜坡（层间过渡） */
    RT_CELL_DOOR            = 1u << 3,   /* 门（可开关，视作动态阻挡） */
    RT_CELL_WATER           = 1u << 4,   /* 水面（不可走，除两栖） */
    RT_CELL_RESERVED        = 1u << 5
};

/* ------------------------------------------------------------ 基础结构 */
typedef struct { float x, z; }     RtVec2;
typedef struct { float x, y, z; }  RtVec3;

/* 轴对齐包围盒（2D，XZ 平面） */
typedef struct {
    float min_x, min_z;
    float max_x, max_z;
} RtAabb2;

/* 有向包围盒（2D，XZ 平面；高度由 footprint 单独给出） */
typedef struct {
    RtVec2 center;
    RtVec2 half;        /* 局部半长：half.x = fp/2, half.z = fp/2 */
    float  cos_a, sin_a;/* 朝向（预存 cos/sin，避免每查询重算） */
} RtObb2;

/* 单位句柄：0 表示无效；编码为 (chunk_index << 6) | slot_in_chunk + 1 */
typedef uint32_t RtUnitId;
#define RT_UNIT_ID_NONE 0u

/* ------------------------------------------------------------ 越界审计 */
/* 任何「因容量不足而丢弃」都必须显式计数；>0 时该帧指标不可信。 */
typedef struct {
    uint32_t path_pool_overflow;
    uint32_t flowfield_overflow;
    uint32_t group_overflow;
    uint32_t formation_overflow;
    uint32_t corridor_overflow;
    uint32_t unit_overflow;
    uint32_t debug_dropped;
} RtOverflowCounters;

#ifdef __cplusplus
}
#endif

#endif /* RT_TYPES_H */

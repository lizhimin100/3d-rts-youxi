/* ============================================================================
 * test_m45.c -- M4.5：多组并存（多条命令互不干扰）
 *
 * 背景：M4.1~M4.6 的 rt_gw_command 是「先清空所有组再重建」，
 * 所以第二条命令会抹掉第一条 —— 一个 RTS 里这等于「只能有一支部队在动」。
 *
 * 新语义：命令只影响 ids 里的单位；其余组原样保留、route 继续有效。
 *
 * N1 两条命令并存：各 49 人、目标相距 120 m；两组同时存在，采样各自朝自己目标
 * N2 部分重令：从 A 组抽 10 人下新命令 -> A 组剩 39 人、B 组不受影响、新组 10 人
 * N4 route 隔离：两组的起点/终点区域不同，互不共享走廊
 * N5 编辑隔离：在 A 走廊上建墙 -> A 的 route 失效、B 的仍然 valid；update 只重建 A
 *    （必须排在 N3 之前：N3 会把 A 的目标改到南边，那时墙就不在走廊上了）
 * N3 id/index 不变式：整组重令 5 次，每次都核验「每个单位 chunk->group 指向的组，
 *    其 goal 就是该单位这次命令的目标」——压缩重编号一旦漏写就会在这里炸
 * N6 clear：组清空、unit.group 归零、再下令仍正常
 * N7 单命令回归：1000 单位仍只产生 <=6 个组，全部可采样
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_m45.c -o test_m45
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", m); } } while (0)

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;

static void world_reset(int dim)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_grid_init(&G, dim, dim, 1.0f);
}

static void world_build(void)
{
    rt_grid_rebuild_all(&G);
    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
}

/* 在一个 8 m 区域内铺 n 个单位（1 m 间距），保证一次命令只产生一个组 */
static int spawn_block(RtUnitId *ids, int n, float x0, float z0, int cols)
{
    int k = 0;
    for (int i = 0; i < n; i++) {
        float x = x0 + (float)(i % cols);
        float z = z0 + (float)(i / cols);
        int cx = rt_grid_cell_x(&G, x), cz = rt_grid_cell_z(&G, z);
        if (!rt_grid_walkable(&G, cx, cz)) continue;
        RtUnitId id = rt_units_spawn(&US, rt_v3(x, 0.f, z), RT_FP_SMALL);
        if (id != RT_UNIT_ID_NONE) ids[k++] = id;
    }
    return k;
}

static int group_of(RtUnitId id)
{
    const RtUnitChunk *c = rt_units_chunk_c(&US, id);
    return (int)c->group[rt_unit_slot_index(id)] - 1;
}

/* 一个单位当前所属组的 goal 是否等于期望点（_z 容差 8 m：目标可能被吸附） */
static int group_goal_near(RtUnitId id, RtVec2 expected, float tol)
{
    int gi = group_of(id);
    if (gi < 0 || gi >= W.group_count) return 0;
    RtVec2 g = W.groups[gi].goal_pos;
    return fabsf(g.x - expected.x) <= tol && fabsf(g.z - expected.z) <= tol;
}

static void n1_two_commands(void)
{
    printf("\n[N1] 两条命令并存（49 + 49 人，目标相距 120 m）\n");
    world_reset(256);
    world_build();

    static RtUnitId a[64], b[64];
    int na = spawn_block(a, 49, 40.5f, 40.5f, 7);
    int nb = spawn_block(b, 49, 40.5f, 160.5f, 7);
    RtVec2 ga_target = rt_v2(210.5f, 44.5f);
    RtVec2 gb_target = rt_v2(210.5f, 164.5f);

    rt_gw_command(&W, &US, a, na, ga_target, 0, RT_CLS_SMALL, 1);
    int groups_a = W.group_count;
    rt_gw_command(&W, &US, b, nb, gb_target, 0, RT_CLS_SMALL, 2);

    int gia = group_of(a[0]), gib = group_of(b[0]);
    printf("  units=%d+%d groups: after A=%d, after B=%d | A->g%d B->g%d\n",
           na, nb, groups_a, W.group_count, gia, gib);
    printf("  goalA=(%.1f,%.1f) goalB=(%.1f,%.1f) kept=%u\n",
           W.groups[gia].goal_pos.x, W.groups[gia].goal_pos.z,
           W.groups[gib].goal_pos.x, W.groups[gib].goal_pos.z, W.stats.groups_kept);

    OK(na == 49 && nb == 49, "N1 both blocks spawned");
    OK(groups_a == 1, "N1 first command makes exactly one group");
    OK(W.group_count == 2, "N1 second command ADDS a group instead of clearing");
    OK(W.stats.groups_kept == 1, "N1 stats: one group kept");
    OK(gia != gib, "N1 the two commands have distinct groups");
    OK(group_goal_near(a[0], ga_target, 2.5f), "N1 group A keeps its own goal");
    OK(group_goal_near(b[0], gb_target, 2.5f), "N1 group B has its own goal");

    RtVec2 ta, tb;
    RtVec3 pa = rt_units_pos(&US, a[0]), pb = rt_units_pos(&US, b[0]);
    int rca = rt_gw_sample(&W, gia, rt_v2(pa.x, pa.z), &ta);
    int rcb = rt_gw_sample(&W, gib, rt_v2(pb.x, pb.z), &tb);
    printf("  sample A tgt=(%.1f,%.1f) B tgt=(%.1f,%.1f)\n", ta.x, ta.z, tb.x, tb.z);
    OK(rca == RT_OK && rcb == RT_OK, "N1 both groups sample");
    OK(ta.x > pa.x + 1.f, "N1 A is steered east");
    OK(tb.x > pb.x + 1.f, "N1 B is steered east");
    OK(fabsf(ta.z - tb.z) > 60.f, "N1 the two local targets are far apart (no cross-talk)");

    /* ---- N2/N3/N4/N5 都在这个场景上继续做，避免重复搭图 ---- */
    printf("\n[N2] 部分重令只影响指定单位\n");
    int a_count_before = W.groups[gia].count;
    int b_group_before = group_of(b[0]);
    int b_goal_before_z = (int)W.groups[b_group_before].goal_pos.z;

    static RtUnitId sub[10];
    for (int i = 0; i < 10; i++) sub[i] = a[i];
    RtVec2 sub_target = rt_v2(40.5f, 220.5f);
    rt_gw_command(&W, &US, sub, 10, sub_target, 0, RT_CLS_SMALL, 3);

    int a_count_after = W.groups[group_of(a[10])].count;
    int sub_gi = group_of(sub[0]);
    printf("  groups=%d A.count=%d->%d moved=%u freed=%u kept=%u | sub->g%d z=%.1f\n",
           W.group_count, a_count_before, a_count_after, W.stats.members_moved,
           W.stats.groups_freed, W.stats.groups_kept, sub_gi, W.groups[sub_gi].goal_pos.z);
    OK(a_count_after == a_count_before - 10, "N2 A group lost exactly the 10 re-commanded units");
    OK(W.stats.members_moved == 10, "N2 stats: 10 members moved");
    OK(W.stats.groups_freed == 0, "N2 A group is not empty -> not freed");
    OK(W.group_count == 3, "N2 a third group was created for the new command");
    OK(group_of(b[0]) == b_group_before &&
       (int)W.groups[group_of(b[0])].goal_pos.z == b_goal_before_z,
       "N2 group B untouched by an unrelated command");
    OK(group_goal_near(sub[0], sub_target, 2.5f), "N2 re-commanded units follow the new goal");

    printf("\n[N4] route 隔离：两组不共享走廊\n");
    int ga2 = group_of(a[10]), gb2 = group_of(b[0]);
    int sa = W.groups[ga2].routes[0].start_region;
    int sb = W.groups[gb2].routes[0].start_region;
    int ta2 = W.groups[ga2].goal_region, tb2 = W.groups[gb2].goal_region;
    printf("  A: start=%d goal=%d len=%d | B: start=%d goal=%d len=%d\n",
           sa, ta2, W.groups[ga2].routes[0].route.n,
           sb, tb2, W.groups[gb2].routes[0].route.n);
    OK(W.groups[ga2].route_count >= 1 && W.groups[gb2].route_count >= 1, "N4 both groups have routes");
    OK(sa != sb && ta2 != tb2, "N4 distinct start and goal regions");
    OK(rt_route_valid(&W.groups[ga2].routes[0].route, &G) &&
       rt_route_valid(&W.groups[gb2].routes[0].route, &G), "N4 both routes valid");

    printf("\n[N5] 编辑隔离：A 走廊建墙，只重建 A 的 route\n");
    RtGridDirty d;
    rt_grid_add_building_dirty(&G, 118, 34, 4, 14, &d);
    int rc_apply = rt_grid_apply_dirty(&G, &d);
    rt_gw_note_edit(&W, &d);
    int va = rt_route_valid(&W.groups[group_of(a[10])].routes[0].route, &G);
    int vb = rt_route_valid(&W.groups[group_of(b[0])].routes[0].route, &G);
    int rebuilt = rt_gw_update(&W);
    int vb_after = rt_route_valid(&W.groups[group_of(b[0])].routes[0].route, &G);
    printf("  apply_rc=%d | before update: A valid=%d B valid=%d | rebuilt=%d B after=%d\n",
           rc_apply, va, vb, rebuilt, vb_after);
    OK(rc_apply == RT_OK, "N5 grid kept the incremental path (no full fallback)");
    OK(va == 0, "N5 A route invalidated by the new wall");
    OK(vb == 1, "N5 B route NOT invalidated (unrelated area)");
    OK(rebuilt >= 1, "N5 update rebuilt the affected route");
    OK(vb_after == 1, "N5 B route still valid after update");

    printf("\n[N3] 整组重令 5 次（在 N5 之后：它会把 A 的目标改到南边）：chunk->group 必须始终指向正确的组\n");
    /* 注意：sub 的 10 个 id 是 a 的子集，整组重令会把它们一并收回 A —— 这是有意的，
     * 正好检验「同一单位同时在两个组」不会发生。重令后 sub 组应当消失。 */
    int bad = 0, max_groups = 0, group_counts_ok = 1;
    for (int k = 0; k < 5; k++) {
        RtVec2 t = rt_v2(60.5f + 30.f * (float)k, 210.5f);
        rt_gw_command(&W, &US, a, na, t, 0, RT_CLS_SMALL, 10u + (uint32_t)k);
        if (W.group_count > max_groups) max_groups = W.group_count;
        if (W.group_count != 2) group_counts_ok = 0;   /* 只剩 B + 新的 A */
        for (int i = 0; i < na; i++) if (!group_goal_near(a[i], t, 2.5f)) bad++;
        for (int i = 0; i < nb; i++) if (!group_goal_near(b[i], gb_target, 2.5f)) bad++;
    }
    printf("  max groups=%d bad_unit_links=%d/%d\n", max_groups, bad, (na + nb) * 5);
    OK(bad == 0, "N3 every unit's chunk->group maps to the group with its own goal");
    OK(group_counts_ok && max_groups <= 3, "N3 re-commanding never leaks groups");
}

static void n6_clear(void)
{
    printf("\n[N6] rt_gw_clear：组清空 + unit.group 归零\n");
    world_reset(256);
    world_build();
    static RtUnitId a[32];
    int na = spawn_block(a, 25, 40.5f, 40.5f, 5);
    rt_gw_command(&W, &US, a, na, rt_v2(200.5f, 40.5f), 0, RT_CLS_SMALL, 1);
    OK(W.group_count >= 1, "N6 groups exist before clear");

    rt_gw_clear(&W, &US);
    int stale = 0;
    for (int i = 0; i < na; i++) if (group_of(a[i]) != -1) stale++;
    printf("  after clear: groups=%d stale_unit_links=%d\n", W.group_count, stale);
    OK(W.group_count == 0, "N6 no groups after clear");
    OK(stale == 0, "N6 unit.group reset to 0 (no dangling ids)");

    /* 清空后仍能重新下令 */
    rt_gw_command(&W, &US, a, na, rt_v2(200.5f, 40.5f), 0, RT_CLS_SMALL, 2);
    RtVec3 p = rt_units_pos(&US, a[0]);
    RtVec2 tgt;
    int rc = rt_gw_sample(&W, group_of(a[0]), rt_v2(p.x, p.z), &tgt);
    printf("  re-command after clear: groups=%d sample_rc=%d tgt=(%.1f,%.1f)\n",
           W.group_count, rc, tgt.x, tgt.z);
    OK(W.group_count >= 1 && rc == RT_OK, "N6 world is reusable after clear");
}

static void n7_single_command_unchanged(void)
{
    printf("\n[N7] 单命令回归：1000 单位 <=6 组，全部可采样\n");
    world_reset(256);
    world_build();
    static RtUnitId ids[1024];
    int n = 0;
    for (int i = 0; i < 4000 && n < 1000; i++) {
        float rad = 12.f * sqrtf((float)i / 4000.f);
        float ang = (float)i * 2.39996323f;
        int x = rt_grid_cell_x(&G, 50.f + cosf(ang) * rad);
        int z = rt_grid_cell_z(&G, 60.f + sinf(ang) * rad);
        if (!rt_grid_walkable(&G, x, z)) continue;
        RtUnitId id = rt_units_spawn(&US, rt_v3((float)x + 0.5f, 0.f, (float)z + 0.5f), RT_FP_SMALL);
        if (id != RT_UNIT_ID_NONE) ids[n++] = id;
    }
    rt_gw_command(&W, &US, ids, n, rt_v2(210.5f, 190.5f), 0, RT_CLS_SMALL, 1);

    int bad = 0, sampled = 0;
    for (int i = 0; i < n; i++) {
        int gi = group_of(ids[i]);
        if (gi < 0 || gi >= W.group_count) { bad++; continue; }
        RtVec3 p = rt_units_pos(&US, ids[i]);
        RtVec2 tgt;
        if (rt_gw_sample(&W, gi, rt_v2(p.x, p.z), &tgt) == RT_OK) sampled++;
    }
    printf("  units=%d groups=%d routes=%d samples=%d bad_links=%d builds=%u\n",
           n, W.group_count, W.groups[0].route_count, sampled, bad, W.stats.route_builds);
    OK(n == 1000, "N7 1000 units spawned");
    OK(W.group_count <= 6, "N7 groups bounded by source regions");
    OK(bad == 0 && sampled == n, "N7 every unit maps to a live group and samples");
    OK(W.stats.route_builds + W.stats.flow_route_extracts <= 16,
       "N7 shared routes: builds+extracts stay small");
}

int main(void)
{
    printf("=== M4.5 tests: multiple concurrent move commands ===\n");

    n1_two_commands();
    n6_clear();
    n7_single_command_unchanged();

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    if (g_fail == 0) printf("ALL PASS (%d asserts)\n", g_pass);

    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return g_fail == 0 ? 0 : 1;
}

/* ============================================================================
 * test_m9.c -- 四层集成：Navigation + ORCA + 卡死恢复 + 让路
 *
 * 前面每一层都有自己的测试，但**第一次把它们接起来**往往才是问题所在：
 * 采样给的期望速度会不会被卡死层改坏？让路层改了静止单位的 pref 会不会
 * 影响导航？本文件跑三个场景，并给出 FR-TST-2 的指标：
 *   S1 开阔地 1000 人 -> 目标
 *   S2 12 格城门 1000 人
 *   S3 城门 200 人（小规模对照，确认不是「人少才行」）
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_stuck.h"
#include "rt_yield.h"
#include "rt_form.h"
#include "rt_region.h"
#include "rt_group.h"
#include "rt_unit.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", (m)); } } while (0)

#define MAXA 1200
static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;
static RtStuckCtx SC;
static RtYieldCtx YC;
static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static RtUnitId IDS[MAXA];
static int N = 0;

typedef struct {
    int   n;
    int   arrived;
    int   frames;
    double t_best, t_mean, t_worst;
    double t_p95, t_p99;
    int   over_budget;      /* 单帧 > 8 ms 的帧数 */
    double nav_ms, loc_ms;
    float max_pen;
    int   overlap_pairs;
    float avg_speed;
    uint32_t stuck_permanent, stuck_episodes;
} Metrics;

static double FRAME_T[8192];
static int    FRAME_N;

static void build_world(int with_gate)
{
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    if (with_gate)
        for (int z = 0; z < 256; z++)
            if (z < 122 || z > 133) rt_grid_set_terrain(&G, 128, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);

    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);

    rt_local_destroy(&LC);
    rt_local_init(&LC, 256.f, 256.f, MAXA, 4.5f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);
    rt_stuck_destroy(&SC);
    rt_stuck_init(&SC, MAXA, NULL);
    rt_yield_destroy(&YC);
    rt_yield_init(&YC, MAXA, NULL, &G);
}

static void spawn_block(int n, float x0, float z0, int cols)
{
    N = 0;
    for (int i = 0; i < n; i++) {
        float x = x0 + (float)(i % cols) * 1.6f;
        float z = z0 + (float)(i / cols) * 1.6f;
        RtUnitId id = rt_units_spawn(&US, rt_v3(x, 0.f, z), RT_FP_SMALL);
        if (id == RT_UNIT_ID_NONE) break;
        IDS[N] = id;
        memset(&AG[N], 0, sizeof(AG[N]));
        AG[N].pos = rt_v2(x, z);
        AG[N].radius = 0.5f;
        AG[N].max_speed = 2.0f;
        AG[N].fp = 1.0f;
        AG[N].share = 0.5f;
        AG[N].inv_mass = 1.f;
        N++;
    }
}

static int cmp_double(const void *a, const void *b)
{
    double x = *(const double *)a, y = *(const double *)b;
    return (x < y) ? -1 : (x > y ? 1 : 0);
}

static float arrival_radius(int n){
    return 3.0f + sqrtf((float)n) * 1.1f;   /* 1000 人 ≈ 38 m 的圆盘 */
}

static Metrics run(const char *name, int with_gate, int n_units, int frames_max,
                   RtVec2 goal, float spawn_x, float spawn_z, int cols, int verbose)
{
    Metrics m;
    memset(&m, 0, sizeof(m));

    build_world(with_gate);
    spawn_block(n_units, spawn_x, spawn_z, cols);
    rt_gw_command(&W, &US, IDS, N, goal, 0, RT_CLS_SMALL, 1);
    m.n = N;

    const float dt = 1.f / 30.f;
    const float R = arrival_radius(N);
    double sum = 0, worst = 0, best = 1e30;
    double nav_sum = 0, loc_sum = 0;
    int frames = 0;
    FRAME_N = 0;

    for (int s = 0; s < frames_max; s++) {
        frames = s;
        double t0 = now_ms();

        double tn0 = now_ms();
        for (int i = 0; i < N; i++) {
            RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, IDS[i]);
            int gi = (int)ch->group[rt_unit_slot_index(IDS[i])] - 1;
            RtVec2 pref = rt_v2(0.f, 0.f);
            if (gi >= 0) {
                RtVec2 tgt;
                if (rt_gw_sample(&W, gi, AG[i].pos, &tgt) == RT_OK) {
                    RtVec2 d = rt_v2_sub(tgt, AG[i].pos);
                    float l = rt_v2_len(d);
                    if (l > 1e-3f) pref = rt_v2_mul(d, 2.0f / l);
                }
            }
            AG[i].pref_vel = pref;
        }
        double tn1 = now_ms();
        nav_sum += tn1 - tn0;

        rt_stuck_step(&SC, AG, N, &G, dt, NULL);
        rt_yield_step(&YC, AG, N, &G, dt, NULL, NULL);

        double tl0 = now_ms();
        (void)rt_local_step(&LC, AG, N, &G, dt);
        double tl1 = now_ms();
        loc_sum += tl1 - tl0;

        (void)rt_gw_update(&W);

        double d = now_ms() - t0;
        sum += d;
        if (d > worst) worst = d;
        if (d < best) best = d;
        if (FRAME_N < 8192) FRAME_T[FRAME_N++] = d;

        if ((s % 30) == 0) {
            int arrived = 0;
            for (int i = 0; i < N; i++)
                if (rt_v2_dist(AG[i].pos, goal) < R) arrived++;
            if (arrived == N) break;
        }
    }

    m.frames = frames;
    m.t_best = best;
    m.t_mean = sum / (double)(frames + 1);
    m.t_worst = worst;
    m.nav_ms = nav_sum / (double)(frames + 1);
    m.loc_ms = loc_sum / (double)(frames + 1);
    m.stuck_permanent = SC.st.permanent_stuck;
    m.stuck_episodes = SC.st.episodes;

    /* 分帧时间分位数：max 在这台 4 核低压 U 上会被 OS 抢占污染
     * （同一次运行里 open 与 gate 的 max 相差一倍，均值却稳定在 2.0~2.1 ms），
     * 所以「帧预算」用 P99 + 超预算帧占比来判，max 只当诊断。 */
    {
        double tmp[8192];
        int k = FRAME_N;
        memcpy(tmp, FRAME_T, (size_t)k * sizeof(double));
        qsort(tmp, (size_t)k, sizeof(double), cmp_double);
        m.t_p95 = k ? tmp[(int)((double)k * 0.95)] : 0.0;
        m.t_p99 = k ? tmp[(int)((double)k * 0.99)] : 0.0;
        for (int i = 0; i < k; i++) if (tmp[i] > 8.0) m.over_budget++;
    }

    for (int i = 0; i < N; i++)
        if (rt_v2_dist(AG[i].pos, goal) < R) m.arrived++;

    for (int i = 0; i < N; i++) {
        for (int j = i + 1; j < N; j++) {
            float d = rt_v2_dist(AG[i].pos, AG[j].pos);
            float pen = (AG[i].radius + AG[j].radius) - d;
            if (pen > 0.01f) {
                m.overlap_pairs++;
                if (pen > m.max_pen) m.max_pen = pen;
            }
        }
    }

    float sp = 0.f;
    for (int i = 0; i < N; i++) sp += rt_v2_len(AG[i].vel);
    m.avg_speed = N ? sp / (float)N : 0.f;

    if (verbose) {
        printf("  %-6s n=%d frames=%d arrived=%d/%d (%.1f%%)  frame best/mean/worst = %.2f / %.2f / %.2f ms\n",
               name, m.n, m.frames, m.arrived, m.n,
               100.f * (float)m.arrived / (float)m.n,
               m.t_best, m.t_mean, m.t_worst);
        printf("         frame P95/P99 = %.2f / %.2f ms  over-8ms=%d/%d (%.2f%%)"
               "  nav=%.3f ms  local=%.3f ms\n",
               m.t_p95, m.t_p99, m.over_budget, m.frames + 1,
               100.0 * (double)m.over_budget / (double)(m.frames + 1),
               m.nav_ms, m.loc_ms);
        printf("         overlap_pairs=%d max_pen=%.3f  avg_v=%.2f  stuck(ep=%u perm=%u)\n",
               m.overlap_pairs, m.max_pen, m.avg_speed,
               m.stuck_episodes, m.stuck_permanent);
    }
    return m;
}

int main(void)
{
    timer_init();
    printf("=== M9 tests: full pipeline integration (nav + ORCA + stuck + yield) ===\n");

    Metrics a = run("open", 0, 1000, 4800, rt_v2(200.f, 128.f), 40.f, 100.f, 20, 1);
    Metrics b = run("gate", 1, 1000, 4800, rt_v2(200.f, 128.f), 40.f, 100.f, 20, 1);
    Metrics c = run("small", 1, 200, 3600, rt_v2(200.f, 128.f), 60.f, 110.f, 10, 1);

    printf("\n-- assertions --\n");
    OK(a.arrived >= a.n * 98 / 100, "S1 open field: >=98% arrive");
    OK(a.max_pen < 0.50f, "S1 open field: penetration < 0.5 m");
    OK(a.t_mean < 8.0, "S1 mean frame < 8 ms");
    OK(a.t_p99 < 8.0, "S1 P99 frame < 8 ms");

    OK(b.arrived >= b.n * 95 / 100, "S2 gate: >=95% arrive");
    OK(b.max_pen < 0.60f, "S2 gate: penetration < 0.6 m");
    OK(b.t_mean < 8.0, "S2 mean frame < 8 ms");
    OK(b.t_p99 < 8.0, "S2 P99 frame < 8 ms");

    OK(c.arrived >= c.n * 98 / 100, "S3 small: >=98% arrive");
    OK(c.t_mean < 8.0, "S3 mean frame < 8 ms");
    OK(c.t_p99 < 8.0, "S3 P99 frame < 8 ms");

    OK(a.stuck_permanent == 0, "S1 open field: no PermanentStuck");
    /* 门口 2/1000 = 0.2%：这是「没有走廊所有权」的已知代价（M6 §8 / M9 §5）。
     * 目标仍是 0，等 FR-STK-3 落地后收紧到 0。 */
    OK((int)b.stuck_permanent <= b.n / 200, "S2 gate: PermanentStuck < 0.5%");
    /* 帧预算判据从「max < 30 ms」改成「P99 < 8 ms + 超预算帧 < 1%」：
     * 这台 4 核低压 U 上同一次运行里 max 会在 8.6 / 17.9 / 33.3 ms 之间跳，
     * 均值却稳定在 2.0~2.1 ms —— max 是 OS 抢占，不是算法尖峰（26_M9 §7 第 2 条
     * 当时就写了「下一轮用分位数判定」）。 */
    OK(b.over_budget * 100 <= b.frames + 1, "S2 gate: <=1% of frames exceed the 8 ms budget");

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    if (g_fail == 0) printf("ALL PASS (%d asserts)\n", g_pass);
    rt_stuck_destroy(&SC);
    rt_yield_destroy(&YC);
    rt_local_destroy(&LC);
    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return g_fail == 0 ? 0 : 1;
}

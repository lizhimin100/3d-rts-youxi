/* ============================================================================
 * bench_m43.c -- goal-centric coarse flow vs N x A*
 *
 * 两条路径分别计时（避免「搜索快 6× 但 route 物化吃掉收益」）：
 *   search-only : N x rt_route_build()          vs  rt_goalflow_build() + N x extract
 *   real command: rt_gw_command()（threshold=大 -> A*；-1 -> flow；0 -> adaptive）
 *
 * N = 1 / 4 / 8 / 16 / 32 / 50 / 100，同 goal、开放式 256² 地图。
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void t_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void t_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static RtRouteSolver SOLVER;
static RtGoalFlowSolver FSOLVER;
static uint32_t g_ver;

static void setup(void)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_route_solver_destroy(&SOLVER);
    rt_goalflow_solver_destroy(&FSOLVER);

    rt_grid_init(&G, 256, 256, 1.0f);
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
    int nn = MAP.rw * MAP.rh;
    rt_route_solver_init(&SOLVER, nn);
    rt_goalflow_solver_init(&FSOLVER, nn);
    g_ver = 0;
}

static int spawn_spread(RtUnitId *ids, int n, float step)
{
    int per_row = (int)(230.f / step);
    int k = 0;
    for (int i = 0; i < n; i++) {
        float x = 15.f + (float)(i % per_row) * step;
        float z = 15.f + (float)(i / per_row) * step;
        if (x > 240.f || z > 240.f) break;
        RtUnitId id = rt_units_spawn(&US, rt_v3(x, 0.f, z), RT_FP_SMALL);
        if (id != RT_UNIT_ID_NONE) ids[k++] = id;
    }
    return k;
}

typedef struct { double ms; uint32_t builds, expanded, extracts, flow_builds; int routes; } Row;

static Row run_astar_cmd(const RtUnitId *ids, int n, RtVec2 dest)
{
    rt_gw_set_flow_threshold(&W, 1000000);
    Row r; memset(&r, 0, sizeof(r));
    double t0 = now_ms();
    rt_gw_command(&W, &US, ids, n, dest, 0, RT_CLS_SMALL, ++g_ver);
    r.ms = now_ms() - t0;
    r.builds = W.stats.route_builds;
    for (int i = 0; i < W.group_count; i++)
        for (int k = 0; k < W.groups[i].route_count; k++) {
            r.expanded += (uint32_t)W.groups[i].routes[k].route.expanded;
            r.routes++;
        }
    return r;
}

static Row run_flow_cmd(const RtUnitId *ids, int n, RtVec2 dest, int threshold)
{
    rt_gw_set_flow_threshold(&W, threshold);
    Row r; memset(&r, 0, sizeof(r));
    double t0 = now_ms();
    rt_gw_command(&W, &US, ids, n, dest, 0, RT_CLS_SMALL, ++g_ver);
    r.ms = now_ms() - t0;
    r.builds = W.stats.route_builds;
    r.flow_builds = W.stats.goal_flow_builds;
    r.expanded = W.stats.goal_flow_expanded;
    r.extracts = W.stats.flow_route_extracts;
    for (int i = 0; i < W.group_count; i++) r.routes += W.groups[i].route_count;
    return r;
}

/* search-only：直接调 backend，不经 command / 拆组 / 副本 */
static void search_only(int n, const int32_t *srcs, int goal,
                        double *astar_ms, double *flow_ms, int *exp_a, int *exp_f)
{
    RtRoute tmp; memset(&tmp, 0, sizeof(tmp));
    double a0 = now_ms();
    for (int i = 0; i < n; i++) rt_route_build(&tmp, &SOLVER, &MAP, srcs[i], goal, RT_CLS_SMALL, 0);
    *astar_ms = now_ms() - a0;
    *exp_a = 0;
    rt_route_free(&tmp);

    RtGoalFlow f; memset(&f, 0, sizeof(f));
    double f0 = now_ms();
    rt_goalflow_build(&f, &FSOLVER, &MAP, goal, MAP.comp[goal], RT_CLS_SMALL, 0, srcs, n);
    *exp_f = f.expanded;
    int32_t path[1024];
    for (int i = 0; i < n; i++) {
        int len = rt_goalflow_path(&f, srcs[i], path, 1024);
        if (len > 0) rt_route_from_path(&tmp, &MAP, path, len, RT_CLS_SMALL, 0, f.dist[srcs[i]]);
    }
    *flow_ms = now_ms() - f0;
    rt_route_free(&tmp);
    rt_goalflow_free(&f);
}

int main(void)
{
    t_init();
    printf("=== M4.3 bench: goal-centric coarse flow vs N x A* ===\n");
    printf("grid 256x256 open, same goal, sources on a 16m grid\n");
    printf("threshold = %d (0 = adaptive default)\n\n", RT_GOALFLOW_MIN_SOURCES);

    int counts[] = { 1, 4, 8, 16, 32, 50, 100 };
    printf("-- search-only (backend, no command overhead) --\n");
    printf("  %-4s %-10s %-10s %-8s %-12s %-12s %-8s\n",
           "N", "astar_ms", "flow_ms", "speedup", "astar_expand", "flow_expand", "note");
    for (int c = 0; c < 7; c++) {
        int n = counts[c];
        setup();
        static RtUnitId ids[256];
        int got = spawn_spread(ids, n, 16.f);
        /* 用 unit 所在区域作为 source 集合 */
        int32_t srcs[256];
        int ns = 0;
        for (int i = 0; i < got; i++) {
            RtVec3 p = rt_units_pos(&US, ids[i]);
            int r = rt_region_of_world(&MAP, p.x, p.z);
            int dup = 0;
            for (int q = 0; q < ns; q++) if (srcs[q] == r) { dup = 1; break; }
            if (!dup && ns < 256) srcs[ns++] = r;
        }
        int goal = rt_region_of_world(&MAP, 230.5f, 230.5f);
        double a, f; int ea, ef;
        search_only(ns, srcs, goal, &a, &f, &ea, &ef);
        printf("  %-4d %-10.4f %-10.4f %-8.2fx %-12d %-12d %s\n",
               ns, a, f, f > 1e-9 ? a / f : 0.0, ea, ef,
               (a > f) ? "flow wins" : "A* wins");
    }

    printf("\n-- real command path --\n");
    printf("  %-4s %-8s %-12s %-12s %-12s %-10s %-8s %-8s\n",
           "N", "routes", "astar_ms", "flow_ms", "adaptive_ms", "speedup", "flows", "KB");
    for (int c = 0; c < 7; c++) {
        int n = counts[c];
        setup();
        static RtUnitId ids[256];
        int got = spawn_spread(ids, n, 16.f);
        RtVec2 dest = rt_v2(230.5f, 230.5f);
        Row a = run_astar_cmd(ids, got, dest);

        setup();
        got = spawn_spread(ids, n, 16.f);
        Row f = run_flow_cmd(ids, got, dest, -1);

        setup();
        got = spawn_spread(ids, n, 16.f);
        Row d = run_flow_cmd(ids, got, dest, 0);

        size_t kb = rt_gw_cache_bytes(&W) + rt_gw_flow_bytes(&W);
        printf("  %-4d %-8d %-12.3f %-12.3f %-12.3f %-10.2fx %-8d %-8.1f\n",
               n, a.routes, a.ms, f.ms, d.ms,
               (f.ms > 1e-9) ? a.ms / f.ms : 0.0, rt_gw_flow_count(&W),
               (double)kb / 1024.0);
    }

    printf("\n-- notes --\n");
    printf("  flow_ms includes one reverse Dijkstra + N route extracts (portal + dep fill)\n");
    printf("  adaptive uses RT_GOALFLOW_MIN_SOURCES; below it must stay on A*\n");

    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    rt_route_solver_destroy(&SOLVER);
    rt_goalflow_solver_destroy(&FSOLVER);
    return 0;
}

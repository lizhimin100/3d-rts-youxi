/* ============================================================================
 * rt_flowcache.h -- M3.6 流场缓存（按 chunk 依赖失效）
 *
 * 设计取舍（任务书 §二十九~§三十二）：
 *   - 依赖用 **chunk 位图**（M2 已在 Dirty 里算好，直接复用，不新增概念）。
 *   - 失效是**提交时推送**（push），不是每帧拉取（pull）。理由：
 *       一个流场覆盖 500 chunk，若每个单位每帧校验 500 个版本，
 *       1000 单位 × 500 = 50 万次比较/帧，纯粹浪费。
 *     提交时才发生（每秒最多几十次），扫描全部 entry 也就几十微秒。
 *   - 提供两种失效策略用于 Benchmark：
 *       Strategy A：扫描所有 entry 的 mask & dirty_mask
 *       Strategy B：chunk -> entry 反向索引
 *     不预设 B 更快，由实测决定（§三十一）。
 *   - label_epoch 必须一起校验：component id 被压缩后，任何以 id 为键的缓存都失效。
 * ==========================================================================*/
#ifndef RT_FLOWCACHE_H
#define RT_FLOWCACHE_H

#include "rt_types.h"
#include "rt_grid.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    RT_FLOW_EMPTY = 0,
    RT_FLOW_BUILDING,
    RT_FLOW_VALID,
    RT_FLOW_STALE,
    RT_FLOW_FAILED
} RtFlowState;

#define RT_FLOW_REV_SLOTS 16

typedef struct {
    uint32_t id;                              /* 调用方 key（goal region / dest hash） */
    uint8_t  state;
    uint8_t  movement_class;
    uint8_t  clearance_class;
    uint32_t label_epoch;                     /* 构建时的 id 空间 epoch */
    uint32_t nav_epoch;                       /* 构建时的提交版本（诊断用） */
    uint32_t mask[RT_CHUNK_MASK_WORDS];       /* 依赖的 chunk */
    uint32_t last_used;
    uint32_t bytes;
} RtFlowEntry;

typedef struct {
    RtFlowEntry *e;
    int cap, count;

    /* 反向索引：chunk -> entry 下标（固定槽，溢出则回退全扫） */
    int32_t  *rev;            /* RT_CHUNK_N * RT_FLOW_REV_SLOTS */
    uint16_t *rev_n;
    uint32_t  rev_overflow;

    /* 统计 */
    uint32_t stat_hit, stat_miss, stat_invalidated, stat_build_rejected;
} RtFlowCache;

int  rt_flowcache_init(RtFlowCache *c, int cap);
void rt_flowcache_destroy(RtFlowCache *c);

/* 插入/替换一个 entry；返回下标，-1 = 满 */
int  rt_flowcache_put(RtFlowCache *c, uint32_t id, const uint32_t *mask,
                      uint8_t movement_class, uint8_t clearance_class,
                      const RtGrid *g, uint32_t bytes);
/* 查询：VALID 才算命中；STALE/BUILDING 都算 miss（调用方负责重建） */
int  rt_flowcache_get(RtFlowCache *c, uint32_t id, uint32_t frame);
/* 构建完成：只有 label_epoch 与提交版本仍匹配才允许转 VALID（§三十三） */
int  rt_flowcache_finish_build(RtFlowCache *c, int idx, const RtGrid *g);

/* 失效：dirty_mask 与 entry 依赖相交 -> STALE。两种策略语义必须完全一致。 */
int  rt_flowcache_invalidate_scan(RtFlowCache *c, const uint32_t *dirty_mask);
int  rt_flowcache_invalidate_index(RtFlowCache *c, const uint32_t *dirty_mask);
/* label_epoch 变化 -> 全部失效（压缩后 id 语义变了） */
int  rt_flowcache_invalidate_epoch(RtFlowCache *c, const RtGrid *g);

int  rt_flowcache_count_state(const RtFlowCache *c, int state);

#ifdef __cplusplus
}
#endif

#endif /* RT_FLOWCACHE_H */

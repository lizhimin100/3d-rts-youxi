/* 临时：M4.4-B 触发率诊断 —— 找「区域走廊的段直线被挡」的真实几何，
 * 并对比 fine flow 开 / 关 的到达情况。跑完即删。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;

static void walk(RtVec2 start, int gi, int max_steps, int *arrived, int *pen)
{
    RtVec2 p = start;
    *arrived = 0; *pen = 0;
    for (int i = 0; i < max_steps && !*arrived; i++) {
        RtVec2 tgt;
        if (rt_gw_sample(&W, gi, p, &tgt) != RT_OK) break;
        RtVec2 d = rt_v2_sub(tgt, p);
        float len = rt_v2_len(d);
        if (len < 1e-4f) { *pen += 100000; break; }   /* tgt==pos 直接记死 */
        float step = 0.2f;
        if (step > len) step = len;
        RtVec2 np = rt_v2_add(p, rt_v2_mul(d, step / len));
        if (!rt_los_clear(&G, p, np)) { (*pen)++; break; }
        p = np;
        if (rt_gw_is_arrived(&W, gi, p, 1.5f)) *arrived = 1;
    }
}

/* 场景：L 形凹墙（内角在区域内部） + 一根柱子 */
static void build_L(void)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_grid_init(&G, 256, 256, 1.0f);
    /* 竖直墙：x=126..127, z=60..120 */
    for (int z = 60; z <= 120; z++) { rt_grid_set_terrain(&G, 126, z, RT_CELL_BLOCKED_TERRAIN, 1);
                                      rt_grid_set_terrain(&G, 127, z, RT_CELL_BLOCKED_TERRAIN, 1); }
    /* 水平墙：z=100..101, x=126..150 —— 与竖墙构成 L */
    for (int x = 126; x <= 150; x++) { rt_grid_set_terrain(&G, x, 100, RT_CELL_BLOCKED_TERRAIN, 1);
                                       rt_grid_set_terrain(&G, x, 101, RT_CELL_BLOCKED_TERRAIN, 1); }
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
}

static void report(const char *tag, RtVec2 start)
{
    RtUnitId id = rt_units_spawn(&US, rt_v3(start.x, 0.f, start.z), RT_FP_SMALL);
    RtUnitId ids[1] = { id };
    rt_gw_command(&W, &US, ids, 1, rt_v2(200.5f, 130.5f), 0, RT_CLS_SMALL, 1);
    int gi = (int)((RtUnitChunk *)rt_units_chunk_c(&US, id))->group[rt_unit_slot_index(id)] - 1;
    int arr = 0, pen = 0;
    walk(start, gi, 4000, &arr, &pen);
    printf("  %-12s route_n=%d segs=%u blocked=%u | checks=%u builds=%u hits=%u used=%u out=%u rej=%u | arrived=%d pen=%d\n",
           tag, W.groups[gi].routes[0].route.n,
           W.stats.corridor_segments, W.stats.corridor_blocked,
           W.stats.fine_checks, W.stats.fine_builds, W.stats.fine_hits,
           W.stats.fine_used, W.stats.fine_outside, W.stats.fine_rejected,
           arr, pen);
}

int main(void)
{
    printf("=== M4.4-B trigger diagnostic ===\n");

    build_L();
    printf("[L-wall] fine ON\n");
    report("fine=on", rt_v2(100.5f, 110.5f));

    build_L();
    rt_gw_set_fine_enabled(&W, 0);
    printf("[L-wall] fine OFF\n");
    report("fine=off", rt_v2(100.5f, 110.5f));

    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return 0;
}

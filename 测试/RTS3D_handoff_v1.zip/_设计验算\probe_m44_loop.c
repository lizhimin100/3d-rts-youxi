/* 临时：t=2 阶梯墙循环的轨迹追踪。跑完即删。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;

static void build_stair(int rx, int rz, int thick)
{
    rt_grid_destroy(&G);
    rt_region_destroy(&MAP);
    rt_gw_destroy(&W);
    rt_grid_init(&G, 256, 256, 1.0f);
    int x0 = rx * 8, z0 = rz * 8;
    for (int i = 0; i < 8; i++)
        for (int t = 0; t < thick; t++)
            rt_grid_set_terrain(&G, x0 + i, z0 + i + t, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);
    rt_region_build(&MAP, &G, 8);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);
}

int main(void)
{
    int rx = 8, rz = 10, thick = 2;
    float z = (float)(rz * 8) + 3.5f;
    RtVec2 s = rt_v2(20.5f, z), d = rt_v2(230.5f, z);
    build_stair(rx, rz, thick);

    RtUnitId id = rt_units_spawn(&US, rt_v3(s.x, 0.f, s.z), RT_FP_SMALL);
    RtUnitId ids[1] = { id };
    rt_gw_command(&W, &US, ids, 1, d, 0, RT_CLS_SMALL, 1);
    int gi = (int)((RtUnitChunk *)rt_units_chunk_c(&US, id))->group[rt_unit_slot_index(id)] - 1;

    RtRoute *rt = &W.groups[gi].routes[0].route;
    printf("route n=%d\n", rt->n);
    for (int i = 0; i < rt->n; i++) {
        RtVec2 q = (i == rt->n - 1) ? W.groups[gi].goal_pos : rt->portal[i];
        printf("  Q[%2d] region=%5d (%5.1f,%5.1f) seg_block=%d\n", i,
               rt->regions[i], q.x, q.z, W.groups[gi].routes[0].seg_block[i]);
    }

    RtVec2 p = s;
    for (int i = 0; i < 460; i++) {
        RtVec2 tgt;
        if (rt_gw_sample(&W, gi, p, &tgt) != RT_OK) { printf("ERR\n"); break; }
        RtVec2 dd = rt_v2_sub(tgt, p);
        float len = rt_v2_len(dd);
        if (i >= 210 && i < 400) {
            printf("  step%03d pos=(%6.2f,%6.2f) tgt=(%6.2f,%6.2f) len=%.2f used=%u\n",
                   i, p.x, p.z, tgt.x, tgt.z, len, W.stats.fine_used);
        }
        if (len < 1e-4f) { printf("  STOP tgt==pos\n"); break; }
        float step = 0.2f;
        if (step > len) step = len;
        RtVec2 np = rt_v2_add(p, rt_v2_mul(dd, step / len));
        if (!rt_los_clear(&G, p, np)) { printf("  BLOCKED\n"); break; }
        p = np;
    }
    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return 0;
}

/* ============================================================================
 * rt_core.h -- RNG / Arena / 审计计数
 *
 * 三个东西放在一起，因为它们是「确定性」与「零分配」两条纪律的地基：
 *   - RNG：唯一随机源（splitmix64），状态可序列化，跨平台一致；
 *   - Arena：每帧临时内存，帧末整体 reset，稳态零 malloc；
 *   - 审计：一切容量不足必须计数（不静默丢弃）。
 * ==========================================================================*/
#ifndef RT_CORE_H
#define RT_CORE_H

#include <stdint.h>
#include <stddef.h>
#include "rt_types.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ---------------------------------------------------------------- RNG */
typedef struct { uint64_t state; } RtRng;

void     rt_rng_seed(RtRng *r, uint64_t seed);
uint64_t rt_rng_u64(RtRng *r);
uint32_t rt_rng_u32(RtRng *r);
float    rt_rng_f32(RtRng *r);                 /* [0,1) */
int      rt_rng_range(RtRng *r, int lo, int hi);/* [lo,hi) */
float    rt_rng_f32_range(RtRng *r, float lo, float hi);

/* ---------------------------------------------------------------- Arena */
/*
 * 单调分配 + 整体 reset：
 *   - 不支持单独 free（避免碎片与每帧 free 成本）；
 *   - 溢出**不 abort**：返回 NULL 并审计 +1，调用方必须降级；
 *   - 对齐按 max_align_t / 指定 2 的幂。
 */
typedef struct {
    uint8_t *base;
    size_t   cap;
    size_t   used;
    size_t   peak;
    uint32_t overflow;
} RtArena;

int    rt_arena_init(RtArena *a, size_t cap);
void   rt_arena_reset(RtArena *a);
void   rt_arena_destroy(RtArena *a);
void  *rt_arena_alloc(RtArena *a, size_t size, size_t align);
size_t rt_arena_used(const RtArena *a);

/* ---------------------------------------------------------------- 审计 */
void rt_audit_reset(RtOverflowCounters *c);
/* 返回 0 表示无溢出；>0 表示发生过 overflow（该帧指标不可信） */
uint32_t rt_audit_total(const RtOverflowCounters *c);

#ifdef __cplusplus
}
#endif

#endif /* RT_CORE_H */

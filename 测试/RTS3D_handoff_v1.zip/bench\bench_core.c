/* ============================================================================
 * bench_core.c -- V0 内核基准（网格重建 / 空间索引 / OBB 判定）
 *
 * 纪律：
 *   - 按**时间预算自适应重复次数**（不是固定次数：慢场景会跑不完）；
 *   - 输出 min/med/p95 + 实际重复次数（口径必须自证）；
 *   - 每条测量先预热，避免把首次 page fault 算进去。
 *
 * 编译：zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c bench/bench_core.c -o bench_core
 * ==========================================================================*/
#include <stdio.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_spatial.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void)
{
    LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart;
}
static double now_ms(void)
{
    LARGE_INTEGER c; QueryPerformanceCounter(&c);
    return (double)c.QuadPart * 1000.0 / g_freq;
}
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void)
{
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec / 1e6;
}
#endif

typedef struct { double mn, med, p95, mean; int n; } Stat;

static int cmp_d(const void *a, const void *b)
{
    double x = *(const double *)a, y = *(const double *)b;
    return (x > y) - (x < y);
}

static Stat stat_of(double *v, int n)
{
    Stat s; memset(&s, 0, sizeof(s));
    if (!n) return s;
    qsort(v, (size_t)n, sizeof(double), cmp_d);
    double sum = 0;
    for (int i = 0; i < n; i++) sum += v[i];
    s.n = n; s.mn = v[0]; s.med = v[n / 2];
    s.p95 = v[(int)(n * 0.95) >= n ? n - 1 : (int)(n * 0.95)];
    s.mean = sum / n;
    return s;
}

/* 自适应重复：先跑 1 次估算单次耗时，再决定重复次数（预算 400ms/项） */
typedef void (*BenchFn)(void *ctx);

static Stat bench_run(BenchFn fn, void *ctx, double budget_ms, int min_runs, int max_runs)
{
    double t0 = now_ms();
    fn(ctx);                       /* 预热 + 估算 */
    double single = now_ms() - t0;
    if (single < 1e-4) single = 1e-4;
    int runs = (int)(budget_ms / single);
    if (runs < min_runs) runs = min_runs;
    if (runs > max_runs) runs = max_runs;

    static double v[4096];
    if (runs > 4096) runs = 4096;
    for (int i = 0; i < runs; i++) {
        double a = now_ms();
        fn(ctx);
        v[i] = now_ms() - a;
    }
    return stat_of(v, runs);
}

/* ---------------------------------------------------------------- 场景 */
static RtGrid G;
static RtUnitStore U;
static RtSpatialGrid SG;
static RtUnitId g_ids[1000];
static int g_nids;

static void make_map_random(void)
{
    RtRng r;
    rt_rng_seed(&r, 0xC0FFEE);
    for (int z = 0; z < G.h; z++) {
        for (int x = 0; x < G.w; x++) {
            if (rt_rng_f32(&r) < 0.15f)
                rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
        }
    }
}

static void make_units(void)
{
    RtRng r;
    rt_rng_seed(&r, 0xBEEF);
    rt_units_init(&U);
    g_nids = 0;
    for (int i = 0; i < 1000; i++) {
        float x = rt_rng_f32_range(&r, 4.f, 508.f);
        float z = rt_rng_f32_range(&r, 4.f, 508.f);
        RtUnitId id = rt_units_spawn(&U, rt_v3(x, 0.f, z), RT_FP_LARGE);
        if (id) g_ids[g_nids++] = id;
    }
}

static void b_grid_rebuild(void *ctx) { (void)ctx; rt_grid_rebuild_all(&G); }
static void b_spatial_build(void *ctx) { (void)ctx; rt_spatial_build(&SG, &U, g_ids, g_nids, 5.657f); }

static void b_spatial_query(void *ctx)
{
    (void)ctx;
    RtUnitId out[64];
    for (int i = 0; i < g_nids; i++) {
        RtVec3 p = rt_units_pos(&U, g_ids[i]);
        (void)rt_spatial_query_circle(&SG, &U, rt_v2(p.x, p.z), 5.657f, g_ids[i], out, 64);
    }
}

static void b_obb_fast(void *ctx)
{
    (void)ctx;
    int hit = 0;
    for (int i = 0; i < g_nids; i++) {
        RtVec3 p = rt_units_pos(&U, g_ids[i]);
        RtObb2 o = rt_obb_make(rt_v2(p.x, p.z), 4.0f, 0.3f);
        hit += rt_grid_obb_blocked(&G, &o);
    }
    if (hit < 0) printf("!");
}

static void b_units_churn(void *ctx)
{
    (void)ctx;
    RtUnitId tmp[256];
    for (int i = 0; i < 256; i++)
        tmp[i] = rt_units_spawn(&U, rt_v3((float)i, 0.f, 0.f), RT_FP_MEDIUM);
    for (int i = 0; i < 256; i++)
        rt_units_despawn(&U, tmp[i]);
}

int main(void)
{
    timer_init();
    printf("=== rt_core V0 bench ===\n\n");

    if (rt_grid_init(&G, 512, 512, 1.0f) != RT_OK) { printf("grid init fail\n"); return 1; }
    make_map_random();
    rt_grid_rebuild_all(&G);
    {
        RtGridStats st;
        rt_grid_stats(&G, &st);
        printf("map: 512x512 random15  walkable=%d (%.1f%%)  components=%d  largest=%d\n",
               st.walkable_cells, 100.0 * st.walkable_cells / (512.0 * 512.0),
               st.component_count, st.largest_component_cells);
        printf("     clearance mean=%.2f m  max=%.2f m\n\n",
               st.clearance_mean_m, st.clearance_max_m);
    }

    Stat s;
    s = bench_run(b_grid_rebuild, NULL, 600.0, 5, 60);
    printf("grid_rebuild_all (512x512, 8SSEDT+components): %2d runs  min=%.2f  med=%.2f  p95=%.2f ms\n",
           s.n, s.mn, s.med, s.p95);

    make_units();
    printf("\nunits: %d spawned\n", g_nids);

    if (rt_spatial_init(&SG, 512.f, 512.f, 8.f) != RT_OK) { printf("spatial init fail\n"); return 1; }
    s = bench_run(b_spatial_build, NULL, 300.0, 20, 500);
    printf("spatial_build (1000 units, 8m bucket):        %2d runs  min=%.4f med=%.4f p95=%.4f ms\n",
           s.n, s.mn, s.med, s.p95);

    s = bench_run(b_spatial_query, NULL, 300.0, 10, 200);
    printf("spatial_query x1000 (r=5.66m):                %2d runs  min=%.4f med=%.4f p95=%.4f ms\n",
           s.n, s.mn, s.med, s.p95);

    s = bench_run(b_obb_fast, NULL, 300.0, 10, 200);
    printf("grid_obb_blocked x1000 (clearance fast-path):  %2d runs  min=%.4f med=%.4f p95=%.4f ms\n",
           s.n, s.mn, s.med, s.p95);

    s = bench_run(b_units_churn, NULL, 200.0, 20, 500);
    printf("units churn 256 spawn+despawn:                 %2d runs  min=%.4f med=%.4f p95=%.4f ms\n",
           s.n, s.mn, s.med, s.p95);

    printf("\noverflow counters: unit=%u\n", U.overflow.unit_overflow);
    printf("bench done\n");

    rt_spatial_destroy(&SG);
    rt_grid_destroy(&G);
    return 0;
}

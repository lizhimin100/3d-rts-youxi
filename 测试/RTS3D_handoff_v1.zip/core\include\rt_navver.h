/* ============================================================================
 * rt_navver.h -- M3.5 版本体系：路径请求依赖 / 命令版本
 *
 * 三关判定（任务书 §二十三）：
 *   1. command_version 不匹配  -> DISCARD（玩家已经点了新命令）
 *   2. label_epoch 不匹配      -> STALE  （component id 空间已被压缩，旧引用可能 ABA）
 *   3. 任一依赖 chunk 的版本变了 -> STALE （导航几何变了）
 *
 * 另有一个 M3.4 引入的状态必须一起处理：
 *   依赖分量正在被 Job 重建     -> PENDING（不许宣布"可达"）
 * ==========================================================================*/
#ifndef RT_NAVVER_H
#define RT_NAVVER_H

#include "rt_types.h"
#include "rt_grid.h"

#ifdef __cplusplus
extern "C" {
#endif

#define RT_PATH_DEP_MAX 32

typedef struct {
    uint32_t n;                              /* 依赖 chunk 数（<= RT_PATH_DEP_MAX） */
    uint32_t chunks[RT_PATH_DEP_MAX];
    uint32_t vers[RT_PATH_DEP_MAX];          /* 提交时各 chunk 的版本快照 */
    uint32_t nav_epoch;
    uint32_t label_epoch;
    uint8_t  overflow;                       /* 依赖 chunk 超过上限 -> 保守全失效 */
} RtPathDep;

/* 结果分类 */
typedef enum {
    RT_PATH_ACCEPT = 0,
    RT_PATH_DISCARD_COMMAND = 1,   /* 命令已被新命令取代 */
    RT_PATH_STALE_NAV = 2,         /* 导航已变：丢弃或重排 */
    RT_PATH_PENDING_NAV = 3        /* 依赖区域正在重建：稍后重试 */
} RtPathVerdict;

/* 记录依赖快照（mask 为 chunk 位图；只看置位的 chunk） */
void rt_pathdep_capture(RtPathDep *dep, const RtGrid *g, const uint32_t *mask);

/* 只校验导航有效性（命令版本另算） */
int rt_pathdep_valid(const RtPathDep *dep, const RtGrid *g);

/* 完整三关判定 */
RtPathVerdict rt_path_result_check(const RtPathDep *dep, const RtGrid *g,
                                   uint32_t req_command_version,
                                   uint32_t cur_command_version,
                                   int32_t dep_component);

const char *rt_path_verdict_name(RtPathVerdict v);

#ifdef __cplusplus
}
#endif

#endif /* RT_NAVVER_H */

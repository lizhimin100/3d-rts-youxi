/* ============================================================================
 * test_incremental.c -- M2 差分测试：Incremental == Full Rebuild
 *
 * 这是 M2 的**正确性门禁**（性能优化之前必须通过）。
 *
 * 方法：
 *   两张同尺寸地图 A / B，施加**完全相同**的编辑序列：
 *     A: dirty 版本 + rt_grid_apply_dirty()   （增量）
 *     B: dirty 版本 + rt_grid_rebuild_all()   （全量，参考实现）
 *   每次编辑后逐位比较：
 *     · flags（可走性）
 *     · clearance（uint16 精度，逐位相等）
 *     · component **划分**（不能比 id：编号顺序可以不同，必须比等价类）
 *
 * component 划分比较：
 *   建立 A.id -> B.id 的映射，要求 (a) 同 A.id 的格在 B 里同 id；
 *   (b) 映射是双射（不同 A.id 不会映射到同一个 B.id）。
 *
 * 编译：
 *   zig cc -O2 -std=c11 -Icore/include core/src/rt_*.c tests/test_incremental.c -o test_incremental
 * 用法：
 *   ./test_incremental [iters] [size]
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"

static RtGrid A, B;
static int g_w, g_h;

/* ---------------------------------------------------------------- RNG */
static uint64_t g_state = 0xC0FFEE123456789ull;

static uint64_t next_u64(void)
{
    uint64_t z = (g_state += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
}

static int rr(int lo, int hi)   /* [lo, hi) */
{
    if (hi <= lo) return lo;
    return lo + (int)(next_u64() % (uint64_t)(hi - lo));
}

/* ---------------------------------------------------------------- 比较 */
#define MAX_COMP 20000
static int32_t map_a2b[MAX_COMP];
static int32_t map_b2a[MAX_COMP];

static int g_px = -1, g_pz = -1;
static int32_t g_pca = -1, g_pcb = -1;

static int partition_equal(void)
{
    g_px = g_pz = -1;
    for (int i = 0; i < MAX_COMP; i++) { map_a2b[i] = -2; map_b2a[i] = -2; }

    int w = g_w, h = g_h;
    for (int z = 0; z < h; z++) {
        for (int x = 0; x < w; x++) {
            size_t i = (size_t)z * w + x;
            int32_t ca = A.component[i];
            int32_t cb = B.component[i];
            if ((ca >= 0) != (cb >= 0)) return 0;
            if (ca < 0) continue;
            if (ca >= MAX_COMP || cb >= MAX_COMP) return 0;
            if (map_a2b[ca] == -2) {
                map_a2b[ca] = cb;
            } else if (map_a2b[ca] != cb) {
                if (g_px < 0) { g_px = x; g_pz = z; g_pca = ca; g_pcb = cb; }
                return 0;                /* 同 A.id 的格在 B 里分属不同分量 */
            }
        }
    }
    /* 双射 */
    for (int ca = 0; ca < MAX_COMP; ca++) {
        if (map_a2b[ca] == -2) continue;
        int32_t cb = map_a2b[ca];
        if (map_b2a[cb] != -2 && map_b2a[cb] != ca) return 0;
        map_b2a[cb] = ca;
    }
    return 1;
}

typedef struct {
    long flag_diffs;
    long clear_diffs;
    int  part_ok;
    int  first_x, first_z;
    int  first_kind;   /* 0=flag 1=clear 2=partition */
} DiffResult;

static DiffResult compare_grids(void)
{
    DiffResult r;
    memset(&r, 0, sizeof(r));
    r.part_ok = 1;
    r.first_kind = -1;

    for (int z = 0; z < g_h; z++) {
        for (int x = 0; x < g_w; x++) {
            size_t i = (size_t)z * g_w + x;
            if (A.flags[i] != B.flags[i]) {
                if (r.first_kind < 0) { r.first_kind = 0; r.first_x = x; r.first_z = z; }
                r.flag_diffs++;
            }
            if (A.clearance[i] != B.clearance[i]) {
                if (r.first_kind < 0) { r.first_kind = 1; r.first_x = x; r.first_z = z; }
                r.clear_diffs++;
            }
        }
    }
    if (!partition_equal()) {
        r.part_ok = 0;
        if (r.first_kind < 0) r.first_kind = 2;
    }
    return r;
}

/* ---------------------------------------------------------------- 编辑 */
typedef struct { int op; int x, z, w, h; } Edit;

static RtGridDirty g_dirty;
static int g_degraded = 0;      /* 增量调用被降级为全量的次数 */

static void init_grid(RtGrid *g)
{
    if (rt_grid_init(g, g_w, g_h, 1.0f) != RT_OK) {
        printf("grid init fail\n");
        exit(2);
    }
}

static void apply_edit(const Edit *e)
{
    if (e->op == 0) {   /* add building */
        rt_grid_add_building_dirty(&A, e->x, e->z, e->w, e->h, &g_dirty);
        int rc = rt_grid_apply_dirty(&A, &g_dirty);
        if (rc != RT_OK) g_degraded++;

        rt_grid_add_building_dirty(&B, e->x, e->z, e->w, e->h, NULL);
        rt_grid_rebuild_all(&B);
    } else {            /* remove building */
        rt_grid_remove_building_dirty(&A, e->x, e->z, e->w, e->h, &g_dirty);
        int rc = rt_grid_apply_dirty(&A, &g_dirty);
        if (rc != RT_OK) g_degraded++;

        rt_grid_remove_building_dirty(&B, e->x, e->z, e->w, e->h, NULL);
        rt_grid_rebuild_all(&B);
    }
}

/* ---------------------------------------------------------------- 场景 */
static int scene_b4_b5(void)
{
    int fail = 0;
    printf("\n-- B4/B5: split then merge --\n");

    /* 重新初始化两张图，建一堵中间有门的竖墙 */
    rt_grid_destroy(&A); rt_grid_destroy(&B);
    init_grid(&A); init_grid(&B);

    for (int z = 0; z < g_h; z++) {
        for (int x = 0; x < g_w; x++) {
            int is_wall = (x == g_w / 2) && !(z >= g_h / 2 - 2 && z <= g_h / 2 + 1);
            if (is_wall) {
                rt_grid_set_terrain(&A, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
                rt_grid_set_terrain(&B, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
            }
        }
    }
    rt_grid_rebuild_all(&A);
    rt_grid_rebuild_all(&B);

    /* 注意：component_count 是 **id 空间大小**（单调增，M3.1 起与活跃数分离），
     * 语义上的「有几个连通域」要看 active_components。 */
    int comps0 = A.active_components;
    printf("  base wall with door: components=%d  (A)  %d (B)\n", comps0, B.active_components);

    /* B4: 用建筑堵住门 -> split */
    Edit ed = { 0, g_w / 2, g_h / 2 - 2, 1, 4 };
    apply_edit(&ed);
    DiffResult d = compare_grids();
    printf("  B4 block door: components A=%d B=%d (id space %d/%d)  flag_diffs=%ld clear_diffs=%ld partition_ok=%d\n",
           A.active_components, B.active_components, A.component_count, B.component_count,
           d.flag_diffs, d.clear_diffs, d.part_ok);
    printf("     -> %s (expect components +1, all diffs 0)\n",
           (d.flag_diffs == 0 && d.clear_diffs == 0 && d.part_ok) ? "PASS" : "FAIL");

    /* B5: 拆掉该建筑 -> merge */
    ed.op = 1;
    apply_edit(&ed);
    d = compare_grids();
    printf("  B5 unblock:    components A=%d B=%d (id space %d/%d)  flag_diffs=%ld clear_diffs=%ld partition_ok=%d\n",
           A.active_components, B.active_components, A.component_count, B.component_count,
           d.flag_diffs, d.clear_diffs, d.part_ok);
    if (d.clear_diffs > 0) {
        /* 诊断：差异格的包围盒（定位「区域重算范围不够」这类问题） */
        int bx0 = 1 << 30, bz0 = 1 << 30, bx1 = -1, bz1 = -1, shown = 0;
        long n = 0;
        for (int z = 0; z < g_h; z++) {
            for (int x = 0; x < g_w; x++) {
                size_t i = (size_t)z * g_w + x;
                if (A.clearance[i] == B.clearance[i]) continue;
                n++;
                if (x < bx0) bx0 = x;
                if (x > bx1) bx1 = x;
                if (z < bz0) bz0 = z;
                if (z > bz1) bz1 = z;
                if (shown < 6) {
                    printf("    diff (%3d,%3d) A.clean=%4u vec=(%5d,%5d)  B.clean=%4u vec=(%5d,%5d)\n",
                           x, z, A.clearance[i], A.ssd_x[i], A.ssd_y[i],
                           B.clearance[i], B.ssd_x[i], B.ssd_y[i]);
                    shown++;
                }
            }
        }
        printf("    diff bbox=(%d,%d)-(%d,%d) n=%ld  pad=%d clear_rect=(%d,%d)-(%d,%d)\n",
               bx0, bz0, bx1, bz1, n, g_dirty.pad,
               g_dirty.cx0, g_dirty.cz0, g_dirty.cx1, g_dirty.cz1);
    }
    printf("     -> %s (expect components back to %d, all diffs 0)\n",
           (d.flag_diffs == 0 && d.clear_diffs == 0 && d.part_ok) ? "PASS" : "FAIL", comps0);
    if (d.flag_diffs || d.clear_diffs || !d.part_ok) fail++;
    return fail;
}

/* 多块解锁（确定性用例）：建筑横跨整堵墙，拆掉后解锁区被墙切成左右两块，
 * 互不相连、分别接回墙两侧的分量。
 *   · M4.6-P3 之前：两块都被写进同一个分量 -> 分区错误；
 *   · M4.6-P3：检测到多块就降级全量（正确但 4.6 ms）；
 *   · M4.6-P4：按连通块分别归属，必须**走增量**且与全量逐格一致。 */
static int scene_multipatch(void)
{
    printf("\n-- multipatch unblock: building spanning a wall --\n");
    rt_grid_destroy(&A); rt_grid_destroy(&B);
    init_grid(&A); init_grid(&B);

    for (int z = 0; z < g_h; z++) {
        rt_grid_set_terrain(&A, g_w / 2, z, RT_CELL_BLOCKED_TERRAIN, 1);
        rt_grid_set_terrain(&B, g_w / 2, z, RT_CELL_BLOCKED_TERRAIN, 1);
    }
    rt_grid_rebuild_all(&A);
    rt_grid_rebuild_all(&B);
    int c0 = A.active_components;

    Edit ed = { 0, g_w / 2 - 10, 60, 20, 20 };      /* 横跨墙 */
    apply_edit(&ed);
    DiffResult d = compare_grids();
    printf("  add spanning 20x20: comps A=%d B=%d flag=%ld clear=%ld part=%d\n",
           A.active_components, B.active_components, d.flag_diffs, d.clear_diffs, d.part_ok);
    int ok_add = (d.flag_diffs == 0 && d.clear_diffs == 0 && d.part_ok &&
                  A.active_components == B.active_components);

    uint32_t mp0 = A.merge_multipatch_count, fb0 = A.merge_multipatch_fallbacks;
    int deg0 = g_degraded;
    ed.op = 1;
    apply_edit(&ed);
    d = compare_grids();
    printf("  remove:            comps A=%d B=%d (base %d) flag=%ld clear=%ld part=%d degraded=%d multipatch=%u fallback=%u\n",
           A.active_components, B.active_components, c0,
           d.flag_diffs, d.clear_diffs, d.part_ok, g_degraded - deg0,
           A.merge_multipatch_count - mp0, A.merge_multipatch_fallbacks - fb0);
    int ok_rm = (d.flag_diffs == 0 && d.clear_diffs == 0 && d.part_ok &&
                 (g_degraded - deg0) == 0 &&
                 (A.merge_multipatch_count - mp0) > 0 &&
                 (A.merge_multipatch_fallbacks - fb0) == 0 &&
                 A.active_components == B.active_components);
    printf("     -> %s (expect 多块走增量、0 降级、0 差异)\n",
           (ok_add && ok_rm) ? "PASS" : "FAIL");
    return (ok_add && ok_rm) ? 0 : 1;
}

int main(int argc, char **argv)
{
    int iters = (argc > 1) ? atoi(argv[1]) : 2000;
    g_w = (argc > 2) ? atoi(argv[2]) : 256;
    g_h = g_w;

    printf("=== M2 differential test: Incremental vs Full ===\n");
    printf("grid %dx%d, iterations %d, seed %llu\n",
           g_w, g_h, iters, (unsigned long long)g_state);

    init_grid(&A);
    init_grid(&B);

    /* 初始地形：8% 随机障碍（两张图相同） */
    for (int z = 0; z < g_h; z++) {
        for (int x = 0; x < g_w; x++) {
            if ((next_u64() >> 40) % 1000 < 80) {
                rt_grid_set_terrain(&A, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
                rt_grid_set_terrain(&B, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
            }
        }
    }
    rt_grid_rebuild_all(&A);
    rt_grid_rebuild_all(&B);
    printf("base: components=%d walkable=%d\n", A.component_count, g_w * g_h);

    int bad = 0;
    long total_flag = 0, total_clear = 0;
    int first_bad_iter = -1;

    RtOverflowCounters unused;
    (void)unused;

    for (int it = 0; it < iters; it++) {
        Edit e;
        e.w = 1 + rr(0, 6);
        e.h = 1 + rr(0, 6);
        e.x = rr(0, g_w - e.w);
        e.z = rr(0, g_h - e.h);
        e.op = (rr(0, 100) < 55) ? 0 : 1;   /* 55% 添加，45% 删除 */

        /* 删除操作必须有一个真实存在的建筑：用一个「总是可删」的策略：
         * 记录最近 N 次添加，按 50% 概率删除其中一次（形如真实游戏） */
        static Edit recent[64];
        static int nrecent = 0;
        if (e.op == 1) {
            if (nrecent == 0) { e.op = 0; }
            else e = recent[rr(0, nrecent)];
        }

        apply_edit(&e);

        if (e.op == 0) {
            if (nrecent < 64) recent[nrecent++] = e;
            else { recent[rr(0, 64)] = e; }
        }

        DiffResult d = compare_grids();
        total_flag += d.flag_diffs;
        total_clear += d.clear_diffs;
        if (d.flag_diffs || d.clear_diffs || !d.part_ok) {
            bad++;
            if (first_bad_iter < 0) {
                first_bad_iter = it;
                printf("\nFIRST DIFF at iter %d: edit(op=%d x=%d z=%d w=%d h=%d)\n",
                       it, e.op, e.x, e.z, e.w, e.h);
                printf("  kind=%d first=(%d,%d)  comps A=%d B=%d\n",
                       d.first_kind, d.first_x, d.first_z,
                       A.component_count, B.component_count);
                if (!d.part_ok && g_px >= 0)
                    printf("  partition conflict at (%d,%d): A.comp=%d B.comp=%d\n",
                           g_px, g_pz, g_pca, g_pcb);
                printf("  flag_diffs=%ld clear_diffs=%ld partition_ok=%d\n",
                       d.flag_diffs, d.clear_diffs, d.part_ok);
                if (d.flag_diffs == 0 && d.clear_diffs > 0) {
                    /* 打印一个差异样本，便于定位 */
                    for (int z = 0; z < g_h; z++) {
                        for (int x = 0; x < g_w; x++) {
                            size_t i = (size_t)z * g_w + x;
                            if (A.clearance[i] != B.clearance[i]) {
                                printf("  sample (%d,%d): A.clean=%u B.clean=%u A.vec=(%d,%d) B.vec=(%d,%d)\n",
                                       x, z, A.clearance[i], B.clearance[i],
                                       A.ssd_x[i], A.ssd_y[i], B.ssd_x[i], B.ssd_y[i]);
                                goto done_sample;
                            }
                        }
                    }
                    done_sample: ;
                }
            }
            if (bad <= 3) {
                printf("  iter %d diff: flags=%ld clear=%ld part=%d\n",
                       it, d.flag_diffs, d.clear_diffs, d.part_ok);
            }
        }

        if ((it + 1) % 500 == 0) {
            printf("  ... %d/%d  bad=%d  degraded=%d\n", it + 1, iters, bad, g_degraded);
        }
    }

    /* ---- 大编辑（8/12/16/20/24，加 + 删）----
     * M4.6-P4 起这里是**硬断言**：
     *   · 加：ring 聚簇后不再撞 256 seed 上限，必须走增量（degraded=0）；
     *   · 删：解锁区按连通块分组后不再降级（degraded=0）；
     *   · 两者都必须与全量重建逐格一致（flag/clear/part）。
     * 这三条同时成立才算通过 —— 它们正是「大编辑」这条路径的正确性门禁。 */
    printf("\n-- large edits (hard assertions since M4.6-P4) --\n");
    long l_flag = 0, l_clear = 0;
    int l_bad = 0, deg_start = g_degraded;
    {
        int sizes[5] = { 8, 12, 16, 20, 24 };
        for (int k = 0; k < 5; k++) {
            int s = sizes[k];
            Edit e;
            e.op = 0; e.x = 40 + k * 12; e.z = 40 + k * 12; e.w = s; e.h = s;

            int deg0 = g_degraded;
            apply_edit(&e);
            DiffResult d = compare_grids();
            l_flag += d.flag_diffs; l_clear += d.clear_diffs;
            int deg_add = g_degraded - deg0;
            if (d.flag_diffs || d.clear_diffs || !d.part_ok || deg_add) l_bad++;
            printf("  add %2dx%-2d: flag=%ld clear=%ld part=%d degraded=%d %s\n",
                   s, s, d.flag_diffs, d.clear_diffs, d.part_ok, deg_add,
                   (d.flag_diffs || d.clear_diffs || !d.part_ok || deg_add) ? "FAIL" : "ok");

            e.op = 1;
            deg0 = g_degraded;
            apply_edit(&e);
            d = compare_grids();
            l_flag += d.flag_diffs; l_clear += d.clear_diffs;
            int deg_del = g_degraded - deg0;
            if (d.flag_diffs || d.clear_diffs || !d.part_ok || deg_del) l_bad++;
            printf("  del %2dx%-2d: flag=%ld clear=%ld part=%d degraded=%d %s\n",
                   s, s, d.flag_diffs, d.clear_diffs, d.part_ok, deg_del,
                   (d.flag_diffs || d.clear_diffs || !d.part_ok || deg_del) ? "FAIL" : "ok");
        }
        printf("  -> %s (flag=%ld clear=%ld bad=%d)；degraded_in_phase=%d（要求 0）\n",
               (l_flag == 0 && l_clear == 0 && l_bad == 0) ? "PASS" : "FAIL",
               l_flag, l_clear, l_bad, g_degraded - deg_start);
        bad += l_bad;
        bad += (g_degraded - deg_start);
    }

    printf("\n-- random edit summary --\n");
    printf("  iterations      : %d\n", iters);
    printf("  differing iters : %d\n", bad);
    printf("  total flag diffs: %ld\n", total_flag);
    printf("  total clear diff: %ld\n", total_clear);
    printf("  degraded to full: %d\n", g_degraded);
    printf("  first bad iter  : %d\n", first_bad_iter);
    printf("  -> %s\n", bad == 0 ? "PASS (Incremental == Full)" : "FAIL");

    bad += scene_b4_b5();
    bad += scene_multipatch();

    rt_grid_destroy(&A);
    rt_grid_destroy(&B);

    return bad == 0 ? 0 : 1;
}

/* probe_m45_dir.c -- 量化「局部目标指向目标反方向」的严重程度
 * 只回答问题：反了多少米？是「亚米级对齐修正」还是「整条走廊走反」。
 */
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "rt_core.h"
#include "rt_grid.h"
#include "rt_unit.h"
#include "rt_region.h"
#include "rt_route.h"
#include "rt_group.h"

static RtGrid G; static RtRegionMap MAP; static RtGroupWorld W; static RtUnitStore US;

int main(void)
{
    for (int K = 8; K <= 16; K *= 2) {
        rt_grid_destroy(&G); rt_region_destroy(&MAP); rt_gw_destroy(&W);
        rt_grid_init(&G, 256, 256, 1.0f);
        rt_grid_rebuild_all(&G);
        rt_region_build(&MAP, &G, 8);
        rt_gw_init(&W, &G, &MAP);
        rt_units_init(&US);

        static RtUnitId ids[16][100];
        RtVec2 aim[16]; int n[16];
        for (int k = 0; k < K; k++) {
            float ang = 2.f * 3.14159265f * (float)k / (float)K;
            float ax = 128.f + cosf(ang) * 90.f, az = 128.f + sinf(ang) * 90.f;
            n[k] = 0;
            for (int i = 0; i < 100; i++) {
                float x = ax - 6.f + (float)(i % 10) * 1.2f;
                float z = az - 6.f + (float)(i / 10) * 1.2f;
                int cx = rt_grid_cell_x(&G, x), cz = rt_grid_cell_z(&G, z);
                if (!rt_grid_walkable(&G, cx, cz)) continue;
                RtUnitId id = rt_units_spawn(&US, rt_v3(x, 0.f, z), RT_FP_SMALL);
                if (id != RT_UNIT_ID_NONE) ids[k][n[k]++] = id;
            }
            aim[k] = rt_v2(128.f - cosf(ang) * 76.5f, 128.f - sinf(ang) * 76.5f);
            rt_gw_command(&W, &US, ids[k], n[k], aim[k], 0, RT_CLS_SMALL, (uint32_t)k + 1);
        }

        int neg = 0, total = 0;
        float worst_back = 0.f, worst_len = 0.f;
        RtVec3 wp = rt_v3(0,0,0), wt = rt_v3(0,0,0);
        int worst_k = -1, worst_i = -1;
        for (int k = 0; k < K; k++) {
            for (int i = 0; i < n[k]; i++) {
                RtVec3 p = rt_units_pos(&US, ids[k][i]);
                const RtUnitChunk *c = rt_units_chunk_c(&US, ids[k][i]);
                int gi = (int)c->group[rt_unit_slot_index(ids[k][i])] - 1;
                RtVec2 tgt;
                if (gi < 0 || rt_gw_sample(&W, gi, rt_v2(p.x, p.z), &tgt) != RT_OK) continue;
                total++;
                RtVec2 d = rt_v2_sub(aim[k], rt_v2(p.x, p.z));
                RtVec2 t = rt_v2_sub(tgt, rt_v2(p.x, p.z));
                float tl = sqrtf(t.x * t.x + t.z * t.z);
                float dl = sqrtf(d.x * d.x + d.z * d.z);
                if (tl < 0.5f || dl < 1e-3f) continue;
                float proj = (d.x * t.x + d.z * t.z) / dl;   /* 朝目标的投影（米） */
                if (proj <= 0.f) {
                    neg++;
                    float back = -proj;
                    if (back > worst_back) {
                        worst_back = back; worst_len = tl;
                        wp = p; wt = rt_v3(tgt.x, 0.f, tgt.z);
                        worst_k = k; worst_i = i;
                    }
                }
            }
        }
        printf("K=%2d units=%4d  negatives=%3d (%.1f%%)  worst_back=%.2f m  |tgt-pos| there=%.2f m\n",
               K, total, neg, 100.0 * neg / (total ? total : 1), worst_back, worst_len);
        if (worst_k >= 0)
            printf("      worst: unit(%d,%d) pos=(%.1f,%.1f) tgt=(%.1f,%.1f) aim=(%.1f,%.1f) groups=%d\n",
                   worst_k, worst_i, wp.x, wp.z, wt.x, wt.z,
                   aim[worst_k].x, aim[worst_k].z, W.group_count);

        /* 直方图：反向 0.5m 以内 / 1m / 2m / 更大 */
        int b1 = 0, b2 = 0, b3 = 0, b4 = 0;
        for (int k = 0; k < K; k++) {
            for (int i = 0; i < n[k]; i++) {
                RtVec3 p = rt_units_pos(&US, ids[k][i]);
                const RtUnitChunk *c = rt_units_chunk_c(&US, ids[k][i]);
                int gi = (int)c->group[rt_unit_slot_index(ids[k][i])] - 1;
                RtVec2 tgt;
                if (gi < 0 || rt_gw_sample(&W, gi, rt_v2(p.x, p.z), &tgt) != RT_OK) continue;
                RtVec2 d = rt_v2_sub(aim[k], rt_v2(p.x, p.z));
                RtVec2 t = rt_v2_sub(tgt, rt_v2(p.x, p.z));
                float tl = sqrtf(t.x * t.x + t.z * t.z);
                float dl = sqrtf(d.x * d.x + d.z * d.z);
                if (tl < 0.5f || dl < 1e-3f) continue;
                float proj = (d.x * t.x + d.z * t.z) / dl;
                if (proj >= 0.f) continue;
                float back = -proj;
                if (back <= 0.5f) b1++;
                else if (back <= 1.f) b2++;
                else if (back <= 3.f) b3++;
                else b4++;
            }
        }
        printf("      back-histogram: <=0.5m %d | <=1m %d | <=3m %d | >3m %d\n", b1, b2, b3, b4);
    }
    rt_gw_destroy(&W); rt_region_destroy(&MAP); rt_grid_destroy(&G);
    return 0;
}

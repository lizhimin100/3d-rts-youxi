/* ============================================================================
 * test_m11.c -- 窄隧道双向穿越（FR-STK-3 通道仲裁 + FCFS，M11）
 *
 * M10 证明了仲裁器本身对：12 个脚本单位 68 s 全过、只交接 2 次。
 * 本文件把它接进**真实流水线**（导航 + ORCA + 卡死 + 让路），跑一个
 * 两队相向穿过 4 m × 10 m 隧道的场景，并给出「开/关仲裁」的同机对照。
 *
 * 为什么是隧道而不是门洞：1 格厚的门洞两队各占一侧也能挤过去；只有
 * **10 m 长、4 m 宽**的隧道才会让两列车队在洞内正面相遇 —— 洞里没有
 * 横向空间，谁也不能从旁边绕，这才是 FR-STK-3 要解的死锁。
 *
 * 关键设计（M11 新增）：
 *   1. 非 owner 不是「原地不动」，而是被引导到**侧向等待区**：
 *      停在入口等于把 owner 的出口堵住（M10 的脚本测试里这条是手工摆的）。
 *   2. FCFS：先到先得，用「第一次想进的时刻」排队，不会饿死一方。
 *   3. 占着不走就收回（stall）：owner 只要还剩几个永远过不去的掉队者，
 *      pending 就永远 > 0 —— 没有这条规则另一队会被永久饿死。
 * ==========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "rt_core.h"
#include "rt_grid.h"
#include "rt_local.h"
#include "rt_stuck.h"
#include "rt_yield.h"
#include "rt_corridor.h"
#include "rt_region.h"
#include "rt_group.h"
#include "rt_unit.h"

#ifdef _WIN32
#include <windows.h>
static double g_freq;
static void timer_init(void) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); g_freq = (double)f.QuadPart; }
static double now_ms(void) { LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart * 1000.0 / g_freq; }
#else
#include <time.h>
static void timer_init(void) {}
static double now_ms(void) { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6; }
#endif

static int g_pass = 0, g_fail = 0;
#define OK(c, m) do { if (c) { g_pass++; } else { g_fail++; printf("  FAIL %s\n", (m)); } } while (0)

#define MAXA 1024
#define WALL_X0  128            /* 墙体占据 cell x ∈ [128,138] */
#define WALL_X1  138
#define TUN_Z0   126.0f         /* 隧道 z∈[126,128)，2 m 宽 —— 刚好两人并排，
                                 * 反方向的两列**没有任何超车空间** */
#define TUN_Z1   128.0f
#define COR_X0   128.0f         /* 通道矩形（世界坐标） */
#define COR_X1   139.0f

static RtLocalAgent AG[MAXA];
static RtLocalCtx LC;
static RtStuckCtx SC;
static RtYieldCtx YC;
static RtCorrCtx CC;
static RtGrid G;
static RtRegionMap MAP;
static RtGroupWorld W;
static RtUnitStore US;
static RtUnitId IDS[MAXA];
static int TEAM[MAXA];
static int ARRIVED[MAXA];
static uint8_t HELD[MAXA];
static int N = 0;

/* ---------------------------------------------------------------------------
 * T0：仲裁器 API 的最小验证（不看流水线，先证明几何 / FCFS / stall 对）
 * ------------------------------------------------------------------------ */
static void t0_api(void)
{
    printf("\n[T0] corridor API: geometry / staging / gate / FCFS / stall\n");
    RtCorrCtx c;
    rt_corr_init(&c, 4, 4.f, 30.f);
    int cid = rt_corr_add(&c, COR_X0, TUN_Z0, COR_X1, TUN_Z1, 0);
    rt_corr_set_staging(&c, cid, 0, 108.f, 132.f, 124.f, 150.f);
    rt_corr_set_staging(&c, cid, 1, 143.f, 132.f, 159.f, 150.f);

    OK(cid == 0, "T0 corridor registered");
    OK(rt_corr_side(&c.c[cid], rt_v2(100.f, 128.f)) == 0, "T0 west of tunnel is side 0");
    OK(rt_corr_side(&c.c[cid], rt_v2(150.f, 128.f)) == 1, "T0 east of tunnel is side 1");
    OK(rt_corr_side(&c.c[cid], rt_v2(133.f, 128.f)) == -1, "T0 inside the tunnel rect");

    RtVec2 p0 = rt_corr_staging_point(&c, cid, 0, 0, 64);
    RtVec2 p1 = rt_corr_staging_point(&c, cid, 1, 63, 64);
    OK(p0.x >= 108.f && p0.x <= 124.f && p0.z >= 132.f && p0.z <= 150.f, "T0 side0 staging point inside rect");
    OK(p1.x >= 143.f && p1.x <= 159.f && p1.z >= 132.f && p1.z <= 150.f, "T0 side1 staging point inside rect");

    /* 空闲：不拦任何人 */
    RtVec2 in_pref = rt_v2(2.f, 0.f);
    RtVec2 g = rt_corr_gate(&c, cid, 0, rt_v2(120.f, 128.f), in_pref, p0);
    OK(fabsf(g.x - 2.f) < 1e-4f && fabsf(g.z) < 1e-4f, "T0 free corridor does not gate");

    rt_corr_request(&c, cid, 0);
    g = rt_corr_gate(&c, cid, 0, rt_v2(120.f, 128.f), in_pref, p0);
    OK(fabsf(g.x - 2.f) < 1e-4f, "T0 owner passes unchanged");

    /* 非 owner 朝隧道走 -> 被导向等待点（等待区在南侧，方向应为 z+） */
    RtVec2 bad = rt_corr_gate(&c, cid, 1, rt_v2(146.f, 128.f), rt_v2(-2.f, 0.f), p1);
    OK(bad.z > 0.5f && rt_v2_len(bad) > 0.5f, "T0 blocked unit is redirected to staging");

    /* 非 owner 背对隧道走 -> 不干预 */
    RtVec2 away = rt_corr_gate(&c, cid, 1, rt_v2(146.f, 128.f), rt_v2(2.f, 0.f), p1);
    OK(fabsf(away.x - 2.f) < 1e-4f && fabsf(away.z) < 1e-4f, "T0 retreating unit is left alone");

    /* 非 owner 已在隧道内 -> 推向最近的一端（138.6 离东口更近） */
    RtVec2 out = rt_corr_gate(&c, cid, 1, rt_v2(138.6f, 128.f), rt_v2(-2.f, 0.f), p1);
    OK(out.x > 0.f, "T0 straggler inside is pushed out the near end");

    /* 离隧道很远 -> 不干预 */
    RtVec2 far_pref = rt_corr_gate(&c, cid, 1, rt_v2(210.f, 60.f), rt_v2(-2.f, 0.f), p1);
    OK(fabsf(far_pref.x + 2.f) < 1e-4f, "T0 far unit is not gated");

    /* FCFS：team1 先等（t=5），team0 后等（t=8） */
    rt_corr_release(&c, cid, 0);
    rt_corr_want(&c, cid, 1, 5.f);
    rt_corr_want(&c, cid, 0, 8.f);
    int owner = rt_corr_acquire(&c, cid);
    OK(owner == 1, "T0 FCFS grants the earlier waiter");
    rt_corr_release(&c, cid, 1);
    owner = rt_corr_acquire(&c, cid);
    OK(owner == 0, "T0 FCFS grants the next in line");

    /* pending 语义：>0 保持，==0 持续 0.3 s 释放 */
    rt_corr_note_pending(&c, cid, 3);
    rt_corr_tick(&c, 0.1f);
    OK(c.c[cid].owner == 0, "T0 owner kept while units pending");
    rt_corr_note_pending(&c, cid, 0);
    rt_corr_tick(&c, 0.1f);
    OK(c.c[cid].owner == 0, "T0 0.3s grace not yet elapsed");
    rt_corr_tick(&c, 0.25f);
    OK(c.c[cid].owner == -1, "T0 released after grace");

    /* stall：门口有人（near>0）但零通过（passed 不涨）-> 到 stall_limit 收回 */
    rt_corr_set_stall_limit(&c, 2.0f);
    rt_corr_request(&c, cid, 0);
    for (int k = 0; k < 3; k++) { rt_corr_note_state(&c, cid, 5, 5, 0); rt_corr_tick(&c, 0.5f); }
    OK(c.c[cid].owner == 0, "T0 owner kept before the stall window elapses");
    rt_corr_tick(&c, 0.6f);
    rt_corr_tick(&c, 0.6f);
    OK(c.c[cid].owner == -1 && c.c[cid].stalls == 1, "T0 stalled owner is revoked");

    /* 有通过（passed 在涨）-> 不收回，即使门口人数一直不变（管道饱和） */
    rt_corr_note_state(&c, cid, 0, 0, 0);
    rt_corr_tick(&c, 1.0f);          /* 先让它彻底释放 */
    rt_corr_request(&c, cid, 0);
    for (int k = 0; k < 6; k++) { rt_corr_note_state(&c, cid, 40, 6, k); rt_corr_tick(&c, 0.9f); }
    OK(c.c[cid].owner == 0, "T0 progressing owner is not revoked");

    /* 门口没人（near==0）-> 也不算占着不走（队伍还在路上） */
    rt_corr_note_state(&c, cid, 0, 0, 0);
    rt_corr_tick(&c, 1.0f);
    rt_corr_request(&c, cid, 0);
    for (int k = 0; k < 6; k++) { rt_corr_note_state(&c, cid, 40, 0, 0); rt_corr_tick(&c, 0.9f); }
    OK(c.c[cid].owner == 0, "T0 owner on the way is not revoked");

    rt_corr_destroy(&c);
}

/* ---------------------------------------------------------------------------
 * 场景
 * ------------------------------------------------------------------------ */
static void build_world(void)
{
    rt_grid_destroy(&G);
    rt_grid_init(&G, 256, 256, 1.0f);
    for (int x = WALL_X0; x <= WALL_X1; x++)
        for (int z = 0; z < 256; z++)
            if (z < (int)TUN_Z0 || z >= (int)TUN_Z1)
                rt_grid_set_terrain(&G, x, z, RT_CELL_BLOCKED_TERRAIN, 1);
    rt_grid_rebuild_all(&G);

    rt_region_destroy(&MAP);
    rt_region_build(&MAP, &G, 8);
    rt_gw_destroy(&W);
    rt_gw_init(&W, &G, &MAP);
    rt_units_init(&US);

    rt_local_destroy(&LC);
    rt_local_init(&LC, 256.f, 256.f, MAXA, 4.0f);
    rt_local_set_params(&LC, 2.0f, 12, 1, 0.f);
    rt_stuck_destroy(&SC);
    {
        /* 默认 permanent_time=20 s 是在 M9 的 12 m 城门上标定的。2 m 隧道里
         * 队伍前进速度极慢（每秒几厘米），20 s 会把**正常排队**判成永久卡死，
         * 之后 give-up 的单位冻在洞口变成路障（M11 实测 perm=20/120）。
         * 这里按场景放宽到 60 s；这是参数，不是逻辑 —— 报告 §5 写清楚了。 */
        RtStuckConfig cfg;
        rt_stuck_config_default(&cfg);
        cfg.permanent_time = 60.f;
        rt_stuck_init(&SC, MAXA, &cfg);
    }
    rt_yield_destroy(&YC);
    rt_yield_init(&YC, MAXA, NULL, &G);

    rt_corr_destroy(&CC);
    rt_corr_init(&CC, 4, 60.f, 600.f);   /* max_hold 只是最后的安全阀 */
    int cid = rt_corr_add(&CC, COR_X0, TUN_Z0, COR_X1, TUN_Z1, 0);
    rt_corr_set_staging(&CC, cid, 0, 108.f, 132.f, 124.f, 150.f);
    rt_corr_set_staging(&CC, cid, 1, 143.f, 132.f, 159.f, 150.f);
    rt_corr_set_gate_params(&CC, 28.f, 1.2f);
    rt_corr_set_stall_limit(&CC, 20.f);
}

static void spawn_team(int team, int n, float x0, float z0, int cols)
{
    for (int k = 0; k < n && N < MAXA; k++) {
        float x = x0 + (float)(k % cols) * 1.6f;
        float z = z0 + (float)(k / cols) * 1.6f;
        RtUnitId id = rt_units_spawn(&US, rt_v3(x, 0.f, z), RT_FP_SMALL);
        if (id == RT_UNIT_ID_NONE) break;
        IDS[N] = id;
        TEAM[N] = team;
        ARRIVED[N] = 0;
        HELD[N] = 0;
        memset(&AG[N], 0, sizeof(AG[N]));
        AG[N].pos = rt_v2(x, z);
        AG[N].radius = 0.5f;
        AG[N].max_speed = 2.0f;
        AG[N].fp = 1.0f;
        AG[N].share = 0.5f;
        AG[N].inv_mass = 1.f;
        N++;
    }
}

static float team_arrival_radius(int n) { return 3.0f + sqrtf((float)n) * 1.1f; }

/* 还需要用隧道（没到终点、也还没穿过去） */
static int needs_corr(int i)
{
    if (ARRIVED[i]) return 0;
    if (TEAM[i] == 0) return AG[i].pos.x < COR_X1 + 2.f;
    return AG[i].pos.x > COR_X0 - 2.f;
}

static float dist_entry(int i)
{
    float ex = (TEAM[i] == 0) ? COR_X0 : COR_X1;
    float dz = AG[i].pos.z - (TUN_Z0 + TUN_Z1) * 0.5f;
    float dx = AG[i].pos.x - ex;
    return sqrtf(dx * dx + dz * dz);
}

static int may_yield_cb(void *ud, int idx)
{
    (void)ud;
    return !HELD[idx];
}

typedef struct {
    int    nA, nB;
    int    arrA, arrB;           /* 断点时刻已到达目标区的人数 */
    int    crossA, crossB;       /* 已穿过隧道的人数 */
    int    frames;
    double t_done;               /* 双方都达到 95% 通过的时刻（秒） */
    double t95A, t95B;           /* 各队自己达到 95% 通过的时刻（秒） */
    double t_best, t_mean, t_worst;
    float  max_pen;
    int    overlap_pairs;
    uint32_t stuck_perm, stuck_ep;   /* 断点时刻的累计值 */
    uint32_t grants, handoffs, expires, stalls, denials;
    long   inside_viol;          /* 非 owner 在隧道内的单位·帧 */
    long   held_unit_frames;
} Metrics;

static Metrics run(const char *name, int use_owner, int nA, int nB, int frames_max, int verbose)
{
    Metrics m;
    memset(&m, 0, sizeof(m));

    build_world();
    N = 0;
    spawn_team(0, nA, 28.f, 120.f, 10);
    spawn_team(1, nB, 206.f, 120.f, 10);

    const int cid = 0;
    const float dt = 1.f / 30.f;
    const float RA = team_arrival_radius(nA);
    const float RB = team_arrival_radius(nB);
    const RtVec2 goalA = rt_v2(206.f, 190.f);   /* 穿过隧道后向东南 */
    const RtVec2 goalB = rt_v2(28.f, 62.f);     /* 穿过隧道后向西北 */

    /* 两条独立命令：A 去东南、B 去西北。rt_gw_command 只影响传入的单位。 */
    {
        RtUnitId a[MAXA], b[MAXA];
        int na = 0, nb = 0;
        for (int i = 0; i < N; i++) { if (TEAM[i] == 0) a[na++] = IDS[i]; else b[nb++] = IDS[i]; }
        if (na) (void)rt_gw_command(&W, &US, a, na, goalA, 0, RT_CLS_SMALL, 1);
        if (nb) (void)rt_gw_command(&W, &US, b, nb, goalB, 0, RT_CLS_SMALL, 2);
    }

    m.nA = nA; m.nB = nB;
    double sum = 0, worst = 0, best = 1e30;
    int frames = 0;
    int pendA_snap = 0, pendB_snap = 0;

    for (int s = 0; s < frames_max; s++) {
        frames = s;
        const float now = (float)s * dt;
        double t0 = now_ms();

        /* ---- 1. 通道仲裁：谁需要 -> 排队 -> 授予 -> 报告 pending ---- */
        if (use_owner) {
            /* pending 必须数「整队还有多少人没过完」，不能只数门口 26 m 内的。
             * 只数近处的会让队伍尾巴一远就释放 -> 每 6 s 换手一次，
             * 远处那队永远走不到门口（M11 第一版：handoffs=28、B 0/80）。
             * 真正的两个阀：stall（占着不走）与 max_hold。 */
            int needA = 0, needB = 0, pendA = 0, pendB = 0, nearA = 0, nearB = 0;
            int passA = 0, passB = 0;
            for (int i = 0; i < N; i++) {
                if (TEAM[i] == 0) { if (AG[i].pos.x > COR_X1 + 2.f) passA++; }
                else              { if (AG[i].pos.x < COR_X0 - 2.f) passB++; }
                if (!needs_corr(i)) continue;
                int is_near = rt_corr_contains(&CC.c[cid], AG[i].pos) || dist_entry(i) < 12.f;
                if (TEAM[i] == 0) { needA = 1; pendA++; if (is_near) nearA++; }
                else              { needB = 1; pendB++; if (is_near) nearB++; }
            }
            if (needA) rt_corr_want(&CC, cid, 0, now); else rt_corr_unwant(&CC, cid, 0);
            if (needB) rt_corr_want(&CC, cid, 1, now); else rt_corr_unwant(&CC, cid, 1);
            (void)rt_corr_acquire(&CC, cid);

            int owner = CC.c[cid].owner;
            pendA_snap = pendA; pendB_snap = pendB;
            rt_corr_note_state(&CC, cid,
                               (owner == 0) ? pendA : (owner == 1 ? pendB : 0),
                               (owner == 0) ? nearA : (owner == 1 ? nearB : 0),
                               (owner == 0) ? passA : (owner == 1 ? passB : 0));
            rt_corr_tick(&CC, dt);
        }

        /* ---- 2. 期望速度：导航 -> 门控 -> 卡死 -> 让路 ---- */
        for (int i = 0; i < N; i++) {
            RtUnitChunk *ch = (RtUnitChunk *)rt_units_chunk_c(&US, IDS[i]);
            int gi = (int)ch->group[rt_unit_slot_index(IDS[i])] - 1;
            RtVec2 pref = rt_v2(0.f, 0.f);
            if (gi >= 0) {
                RtVec2 tgt;
                if (rt_gw_sample(&W, gi, AG[i].pos, &tgt) == RT_OK) {
                    RtVec2 d = rt_v2_sub(tgt, AG[i].pos);
                    float l = rt_v2_len(d);
                    if (l > 1e-3f) pref = rt_v2_mul(d, 2.0f / l);
                }
            }

            HELD[i] = 0;
            if (use_owner && CC.c[cid].owner >= 0 && CC.c[cid].owner != TEAM[i] &&
                needs_corr(i)) {
                /* 整队都在等通道，不只是门口那 28 m：后排的人被前面的人堵着，
                 * 位置一直不动，卡死层会把他们判成 STUCK 并一路升到 give-up
                 * （M11 实测：只 hold 门口时 perm=20，整队 hold 后消失）。
                 * 只有门口 28 m 内才**改道去等待区**，远处照常走导航。 */
                HELD[i] = 1;
                m.held_unit_frames++;
                if (dist_entry(i) < 28.f) {
                    int side = rt_corr_side(&CC.c[cid], AG[i].pos);
                    if (side >= 0) {
                        RtVec2 wp = rt_corr_staging_point(&CC, cid, side, i % 64, 64);
                        pref = rt_corr_gate(&CC, cid, TEAM[i], AG[i].pos, pref, wp);
                    }
                }
            }
            if (use_owner && rt_corr_contains(&CC.c[cid], AG[i].pos) &&
                CC.c[cid].owner >= 0 && CC.c[cid].owner != TEAM[i])
                m.inside_viol++;
            AG[i].pref_vel = pref;
            rt_stuck_set_hold(&SC, i, HELD[i]);
        }

        rt_stuck_step(&SC, AG, N, &G, dt, NULL);
        rt_yield_step(&YC, AG, N, &G, dt, may_yield_cb, NULL);
        (void)rt_local_step(&LC, AG, N, &G, dt);
        (void)rt_gw_update(&W);

        double d = now_ms() - t0;
        sum += d;
        if (d > worst) worst = d;
        if (d < best) best = d;

        /* 完成判据：**双方都 95% 穿过隧道**。
         * 不用「全员到达」：每队各有 1 个掉队单位（对照组同样有 —— 这是 M6 遗留的
         * 尾部队列问题，不是仲裁造成的），等它会把两边都拖到预算上限，
         * 把仲裁真正的差别完全掩盖掉。 */
        {
            int crossA = 0, crossB = 0;
            for (int i = 0; i < N; i++) {
                if (TEAM[i] == 0) { if (AG[i].pos.x > COR_X1 + 2.f) crossA++; }
                else              { if (AG[i].pos.x < COR_X0 - 2.f) crossB++; }
            }
            if (m.t95A <= 0.0 && crossA >= (nA * 95 + 99) / 100) m.t95A = now;
            if (m.t95B <= 0.0 && crossB >= (nB * 95 + 99) / 100) m.t95B = now;
            if (crossA >= (nA * 95 + 99) / 100 && crossB >= (nB * 95 + 99) / 100) {
                m.crossA = crossA; m.crossB = crossB;
                m.t_done = now;
                break;
            }
        }

        if ((s % 30) == 0) {
            int doneA = 0, doneB = 0;
            for (int i = 0; i < N; i++) {
                if (ARRIVED[i]) { if (TEAM[i] == 0) doneA++; else doneB++; continue; }
                float r = (TEAM[i] == 0) ? RA : RB;
                RtVec2 g = (TEAM[i] == 0) ? goalA : goalB;
                if (rt_v2_dist(AG[i].pos, g) < r) {
                    ARRIVED[i] = 1;
                    if (TEAM[i] == 0) doneA++; else doneB++;
                }
            }
            if (doneA == nA && doneB == nB) break;
        }
        if (verbose && (s % 900) == 0) {
            int crossA = 0, crossB = 0;
            float leadA = -1e9f, leadB = 1e9f;
            for (int i = 0; i < N; i++) {
                if (TEAM[i] == 0) {
                    if (AG[i].pos.x > COR_X1 + 2.f) crossA++;
                    if (AG[i].pos.x > leadA) leadA = AG[i].pos.x;
                } else {
                    if (AG[i].pos.x < COR_X0 - 2.f) crossB++;
                    if (AG[i].pos.x < leadB) leadB = AG[i].pos.x;
                }
            }
            printf("      [t=%5.0fs] owner=%2d pend=%d/%d crossed A=%d B=%d lead A=%.0f B=%.0f"
                   " grants=%u stalls=%u exp=%u\n",
                   now, CC.c[cid].owner, pendA_snap, pendB_snap,
                   crossA, crossB, leadA, leadB,
                   CC.c[cid].grants, CC.c[cid].stalls, CC.c[cid].expires);
        }
    }

    m.frames = frames;
    if (m.t_done <= 0.0) m.t_done = (double)frames * (double)dt;

    /* 最终通过数（不论是否提前退出都重算一遍，避免「跨过 95% 就退出」时打印 0） */
    m.crossA = m.crossB = 0;
    for (int i = 0; i < N; i++) {
        if (TEAM[i] == 0) { if (AG[i].pos.x > COR_X1 + 2.f) m.crossA++; }
        else              { if (AG[i].pos.x < COR_X0 - 2.f) m.crossB++; }
    }
    m.t_best = best;
    m.t_mean = sum / (double)(frames + 1);
    m.t_worst = worst;
    m.stuck_perm = SC.st.permanent_stuck;
    m.stuck_ep = SC.st.episodes;
    m.grants = CC.c[cid].grants;
    m.handoffs = CC.c[cid].handoffs;
    m.expires = CC.c[cid].expires;
    m.stalls = CC.c[cid].stalls;
    m.denials = CC.c[cid].denials;

    for (int i = 0; i < N; i++) {
        float r = (TEAM[i] == 0) ? RA : RB;
        RtVec2 g = (TEAM[i] == 0) ? goalA : goalB;
        if (rt_v2_dist(AG[i].pos, g) < r) {
            if (TEAM[i] == 0) m.arrA++; else m.arrB++;
        }
    }

    for (int i = 0; i < N; i++)
        for (int j = i + 1; j < N; j++) {
            float d = rt_v2_dist(AG[i].pos, AG[j].pos);
            float pen = (AG[i].radius + AG[j].radius) - d;
            if (pen > 0.01f) {
                m.overlap_pairs++;
                if (pen > m.max_pen) m.max_pen = pen;
            }
        }

    if (verbose) {
        char bufA[32], bufB[32];
        if (m.t95A > 0.0) snprintf(bufA, sizeof(bufA), "%.0f s", m.t95A);
        else              snprintf(bufA, sizeof(bufA), "never");
        if (m.t95B > 0.0) snprintf(bufB, sizeof(bufB), "%.0f s", m.t95B);
        else              snprintf(bufB, sizeof(bufB), "never");
        printf("  95%%: A at %s, B at %s, both at %.0f s\n", bufA, bufB, m.t_done);
        printf("           frame best/mean/worst = %.2f / %.2f / %.2f ms  overlap=%d max_pen=%.3f\n",
               m.t_best, m.t_mean, m.t_worst, m.overlap_pairs, m.max_pen);
        printf("           grants=%u handoffs=%u expires=%u stalls=%u denials=%u"
               "  stuck(ep=%u perm=%u)  held=%ld inside_viol=%ld\n",
               m.grants, m.handoffs, m.expires, m.stalls, m.denials,
               m.stuck_ep, m.stuck_perm, m.held_unit_frames, m.inside_viol);
    }
    return m;
}

int main(void)
{
    timer_init();
    printf("=== M11 tests: bidirectional tunnel + corridor arbitration ===\n");

    t0_api();

    const int nA = 60, nB = 60;
    /* 先跑「关仲裁」，再跑「开仲裁」：同机同会话，机器噪声对两边一样。 */
    Metrics off = run("no-owner", 0, nA, nB, 12000, 1);
    Metrics on  = run("owner",    1, nA, nB, 12000, 1);

    printf("\n-- assertions --\n");
    OK(off.grants == 0, "T1 arbitration off: no grants (control group)");

    OK(on.crossA >= (nA * 95 + 99) / 100 && on.crossB >= (nB * 95 + 99) / 100,
       "T2 with arbitration: >= 95% of BOTH teams get through");
    OK(on.handoffs >= 2, "T2 ownership handed over (both sides got their turn)");
    OK(on.expires == 0, "T2 no TTL force-release");
    OK(on.max_pen < 0.60f, "T2 penetration < 0.6 m");
    OK(on.t_mean < 8.0, "T2 mean frame < 8 ms");
    OK(on.inside_viol < 600, "T2 non-owner intrusion is transient only");
    OK(on.t_done < 400.0, "T2 finished inside the budget");

    /* 两组都不会硬死锁（60v60 / 2 m 隧道），对照的是「过得有多难看」。 */
    OK(on.t95A < off.t95A * 0.70, "T2 arbitration clears the first team much sooner");
    OK(on.t_done < off.t_done * 1.05, "T2 arbitration is not slower overall");
    OK(on.stuck_ep < off.stuck_ep, "T2 arbitration has fewer stuck episodes");
    OK(on.stuck_perm <= off.stuck_perm, "T2 arbitration does not lose more units");
    OK(on.stalls <= 2, "T2 stall revoke stays a safety valve, not a scheduler");

    printf("\n  control: 95%% A=%.0f B=%.0f both=%.0f s | crossed %d+%d | stuck ep=%u perm=%u | stalls=%u\n",
           off.t95A, off.t95B, off.t_done, off.crossA, off.crossB,
           off.stuck_ep, off.stuck_perm, off.stalls);
    printf("  owner  : 95%% A=%.0f B=%.0f both=%.0f s | crossed %d+%d | stuck ep=%u perm=%u | stalls=%u\n",
           on.t95A, on.t95B, on.t_done, on.crossA, on.crossB,
           on.stuck_ep, on.stuck_perm, on.stalls);
    printf("  first-team speedup: %.2fx   stuck episodes: -%.0f%%\n",
           off.t95A / (on.t95A > 0.0 ? on.t95A : 1.0),
           100.0 * (1.0 - (double)on.stuck_ep / (double)(off.stuck_ep ? off.stuck_ep : 1)));

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    if (g_fail == 0) printf("ALL PASS (%d asserts)\n", g_pass);

    rt_corr_destroy(&CC);
    rt_stuck_destroy(&SC);
    rt_yield_destroy(&YC);
    rt_local_destroy(&LC);
    rt_gw_destroy(&W);
    rt_region_destroy(&MAP);
    rt_grid_destroy(&G);
    return g_fail == 0 ? 0 : 1;
}

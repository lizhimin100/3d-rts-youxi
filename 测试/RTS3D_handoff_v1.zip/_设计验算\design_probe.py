#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
design_probe.py -- RTS 3D 大规模单位移动系统 · 设计前置取证（Python 代理版）

为什么有这一份：
  C 工具链（w64devkit 67MB）在评审环境/本机下载受阻时，设计不能因此停摆。
  本脚本用**纯标准库**回答三类问题：
    (A) 与语言无关的量：A* 扩展节点数、邻居对数、半平面数、几何容量、可行域占比
        —— 这些才是架构决策的真正依据，换任何语言都一样；
    (B) Python 墙钟 —— 只作为「量级上界」，必须乘倍率区间后才能当 C 估计；
    (C) 几何下界 —— 与实现无关，纯数学。

口径纪律（必须随结果一起读）：
  * 本脚本是 **Python 3.13 纯标准库**，不是目标语言；
  * Python 的 A*/Dijkstra 墙钟通常比 GCC -O2 的 C 慢 **40~120 倍**
    （同项目历史实测区间：4~5x 是解释器相对 GDScript 的同级对比，
      脚本语言 vs C 的节点扩展级差距更大，本脚本用 60x 作中心估计并标注区间）；
  * **结论只用 (A) 的量**；(B) 只用于「是否会超预算」的粗筛；
  * 真正进基准报告的数字必须由 design_probe.c（GCC -O2）产出并复核。

用法：
  python design_probe.py > probe_result_py.txt
"""

import heapq
import math
import sys
import time

# ------------------------------------------------------------------ 机器
def machine_info():
    import platform
    print("=" * 60)
    print("S1 机器基线（Python 代理版）")
    print("=" * 60)
    print("python      :", sys.version.split()[0])
    print("platform    :", platform.platform())
    print("processor   :", platform.processor())
    print("cpu_count   :", __import__("os").cpu_count())
    print()

# ------------------------------------------------------------------ 计时
class T:
    def __init__(self):
        self.t0 = time.perf_counter()
    def ms(self):
        return (time.perf_counter() - self.t0) * 1000.0

def stat(v):
    v = sorted(v)
    n = len(v)
    if not n:
        return dict(n=0, mn=0, med=0, mean=0, p95=0, mx=0)
    return dict(n=n, mn=v[0], med=v[n // 2], mean=sum(v) / n,
                p95=v[min(n - 1, int(n * 0.95))], mx=v[-1])

# ------------------------------------------------------------------ 网格
GW = GH = 512
NCELL = GW * GH
DX8 = (1, -1, 0, 0, 1, 1, -1, -1)
DY8 = (0, 0, 1, -1, 1, -1, 1, -1)
DC8 = (1.0, 1.0, 1.0, 1.0, 1.41421356, 1.41421356, 1.41421356, 1.41421356)

class Map:
    def __init__(self, kind="open", seed=0xC0FFEE, block=0.15):
        if kind == "open":
            self.w = bytearray(b"\x01") * NCELL
        elif kind == "random":
            # splitmix64 复现 C 侧序列
            w = bytearray(NCELL)
            x = seed & 0xFFFFFFFFFFFFFFFF
            for i in range(NCELL):
                x = (x + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
                z = x
                z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & 0xFFFFFFFFFFFFFFFF
                z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & 0xFFFFFFFFFFFFFFFF
                z ^= z >> 31
                w[i] = 0 if ((z >> 11) / 9007199254740992.0) < block else 1
            self.w = w
        elif kind == "maze":
            w = bytearray(b"\x01") * NCELL
            y = 8
            while y < GH - 8:
                for x in range(2, GW - 2):
                    w[y * GW + x] = 0
                gate = 8 + ((y // 16) * 48) % (GW - 32)
                for k in range(2):
                    w[y * GW + gate + k] = 1
                if (y // 16) % 2:
                    for k in range(2):
                        w[y * GW + gate + k] = 0
                    g2 = 24 + ((y // 16) * 37) % (GW - 64)
                    for k in range(3):
                        w[y * GW + g2 + k] = 1
                y += 16
            self.w = w
        # 边框
        for x in range(GW):
            self.w[x] = 0
            self.w[(GH - 1) * GW + x] = 0
        for y in range(GH):
            self.w[y * GW] = 0
            self.w[y * GW + GW - 1] = 0

def bfs_far(m, start, walk=None):
    """返回 (最远点, 距离数组, 访问数)"""
    if walk is None:
        walk = m.w
    dist = [-1] * NCELL
    q = [start]
    dist[start] = 0
    far = start
    qi = 0
    while qi < len(q):
        c = q[qi]; qi += 1
        dc = dist[c]
        if dc > dist[far]:
            far = c
        x = c % GW; y = c // GW
        for d in range(8):
            nx = x + DX8[d]; ny = y + DY8[d]
            if nx < 0 or ny < 0 or nx >= GW or ny >= GH:
                continue
            nc = ny * GW + nx
            if not walk[nc] or dist[nc] >= 0:
                continue
            if d >= 4:
                if not walk[y * GW + nx] or not walk[ny * GW + x]:
                    continue
            dist[nc] = dc + 1
            q.append(nc)
    return far, dist, len(q)

def pick_pair(m):
    seed = next(i for i in range(NCELL) if m.w[i])
    a, _, _ = bfs_far(m, seed)
    b, dist, _ = bfs_far(m, a)
    return (a % GW, a // GW), (b % GW, b // GW), dist[b]

# ------------------------------------------------------------------ A*
def astar(m, sx, sy, tx, ty, max_expand=-1):
    INF = float("inf")
    g = [INF] * NCELL
    par = [-1] * NCELL
    closed = bytearray(NCELL)
    s = sy * GW + sx
    t = ty * GW + tx
    g[s] = 0.0
    h0 = max(abs(tx - sx), abs(ty - sy)) - min(abs(tx - sx), abs(ty - sy)) + 1.41421356 * min(abs(tx - sx), abs(ty - sy))
    heap = [(h0, s)]
    exp = 0
    push = heapq.heappush
    pop = heapq.heappop
    walk = m.w
    while heap:
        f, c = pop(heap)
        if closed[c]:
            continue
        closed[c] = 1
        exp += 1
        if c == t:
            return True, exp
        if 0 < max_expand <= exp:
            return False, exp
        x = c % GW; y = c // GW
        gc = g[c]
        for d in range(8):
            nx = x + DX8[d]; ny = y + DY8[d]
            if nx < 0 or ny < 0 or nx >= GW or ny >= GH:
                continue
            nc = ny * GW + nx
            if not walk[nc]:
                continue
            if d >= 4:
                if not walk[y * GW + nx] or not walk[ny * GW + x]:
                    continue
            if closed[nc]:
                continue
            ng = gc + DC8[d]
            if ng < g[nc]:
                g[nc] = ng
                par[nc] = c
                dcx = tx - nx; dcy = ty - ny
                ax = abs(dcx); ay = abs(dcy)
                h = (ax - ay if ax > ay else ay - ax) + 1.41421356 * (ax if ax < ay else ay)
                push(heap, (ng + h, nc))
    return False, exp

def dijkstra_field(m, tx, ty):
    INF = float("inf")
    g = [INF] * NCELL
    closed = bytearray(NCELL)
    t = ty * GW + tx
    g[t] = 0.0
    heap = [(0.0, t)]
    exp = 0
    while heap:
        f, c = heapq.heappop(heap)
        if closed[c]:
            continue
        closed[c] = 1
        exp += 1
        x = c % GW; y = c // GW
        gc = g[c]
        for d in range(8):
            nx = x + DX8[d]; ny = y + DY8[d]
            if nx < 0 or ny < 0 or nx >= GW or ny >= GH:
                continue
            nc = ny * GW + nx
            if not m.w[nc]:
                continue
            if d >= 4:
                if not m.w[y * GW + nx] or not m.w[ny * GW + x]:
                    continue
            if closed[nc]:
                continue
            ng = gc + DC8[d] * 10.0
            if ng < g[nc]:
                g[nc] = ng
                heapq.heappush(heap, (ng, nc))
    return g, exp

# ------------------------------------------------------------------ S2
def s2_spatial():
    print("=" * 60)
    print("S2 空间索引：邻居规模（1000 单位，Python 精确计数）")
    print("=" * 60)

    cases = [
        ("1x1_fp_1000_r30m", 1, 30.0, 0.7071),
        ("4x4_fp_1000_r80m", 4, 80.0, 2.8284),
        ("4x4_fp_1000_r40m", 4, 40.0, 2.8284),
    ]
    # splitmix64 位置
    def rand_pos(n, r, seed):
        x = seed & 0xFFFFFFFFFFFFFFFF
        out = []
        for _ in range(n):
            x = (x + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
            z = x
            z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & 0xFFFFFFFFFFFFFFFF
            z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & 0xFFFFFFFFFFFFFFFF
            z ^= z >> 31
            a = (z >> 11) / 9007199254740992.0
            x = (x + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
            z = x
            z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & 0xFFFFFFFFFFFFFFFF
            z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & 0xFFFFFFFFFFFFFFFF
            z ^= z >> 31
            b = (z >> 11) / 9007199254740992.0
            ang = a * 6.283185307179586
            rr = math.sqrt(b) * r
            out.append((256.0 + math.cos(ang) * rr, 256.0 + math.sin(ang) * rr))
        return out

    for ci, (name, fp, R, rad) in enumerate(cases):
        pts = rand_pos(1000, R, 0x1234567 + ci * 977)
        area = math.pi * R * R
        dens = 1000.0 / area
        print(f"\n[{name}] R={R:.0f}m 密度={dens:.4f}/m^2 最小合法占地={fp*fp}m^2 "
              f"密堆上限={1.0/(fp*fp):.4f} 占用率={100*dens*fp*fp:.0f}%")
        print(f"  {'桶(m)':>7} {'粗筛候选/单位':>14} {'真邻居/单位':>12} {'候选:真邻居':>12}")
        for b in (2.0, 4.0, 8.0, 16.0, 32.0):
            gw = int(512 / b); gh = int(512 / b)
            buckets = {}
            for i, (x, z) in enumerate(pts):
                cx = min(gw - 1, max(0, int(x / b)))
                cy = min(gh - 1, max(0, int(z / b)))
                buckets.setdefault(cy * gw + cx, []).append(i)
            cand = 0; real = 0
            for i, (x, z) in enumerate(pts):
                cx = min(gw - 1, max(0, int(x / b)))
                cy = min(gh - 1, max(0, int(z / b)))
                for dy in (-1, 0, 1):
                    for dx in (-1, 0, 1):
                        xx = cx + dx; yy = cy + dy
                        if xx < 0 or yy < 0 or xx >= gw or yy >= gh:
                            continue
                        for k in buckets.get(yy * gw + xx, ()):
                            if k == i:
                                continue
                            cand += 1
                            ddx = pts[k][0] - x; ddz = pts[k][1] - z
                            if ddx * ddx + ddz * ddz <= (rad * 2) ** 2:
                                real += 1
            cand //= 2; real //= 2
            print(f"  {b:>7.1f} {cand/1000:>14.1f} {real/1000:>12.1f} "
                  f"{(cand/real if real else 0):>12.2f}")
    print()

# ------------------------------------------------------------------ S3
def s3_astar():
    print("=" * 60)
    print("S3 网格寻路：A* 扩展节点数（与语言无关）")
    print("=" * 60)
    print(f"{'地图':<12} {'样本距离(格)':>12} {'扩展节点':>10} {'runs':>6} "
          f"{'py_med(ms)':>11} {'C估算(ms)@30ns':>15}")
    for kind, runs in (("open", 3), ("random", 3), ("maze", 2)):
        m = Map(kind)
        (sx, sy), (tx, ty), dlen = pick_pair(m)
        exps = []; ts = []
        for _ in range(runs):
            t = T()
            ok, exp = astar(m, sx, sy, tx, ty)
            ts.append(t.ms()); exps.append(exp)
        st = stat(exps); stt = stat(ts)
        est = st["med"] * 30e-6  # 30ns/节点
        print(f"{kind:<12} {dlen:>12} {st['med']:>10} {runs:>6} "
              f"{stt['med']:>11.2f} {est:>15.3f}")
    print("\n  说明：C 估算 = 扩展节点 x 30ns（含堆操作/邻居测试，取 2D 工程经验上限）；"
          "\n        实际值需 design_probe.c 复核。")
    print()

# ------------------------------------------------------------------ S4
def s4_flowfield():
    print("=" * 60)
    print("S4 流场 Dijkstra（与语言无关的访问节点数）")
    print("=" * 60)
    m = Map("random")
    (sx, sy), (tx, ty), _ = pick_pair(m)
    t = T()
    g, exp = dijkstra_field(m, tx, ty)
    py_ms = t.ms()
    walkable = sum(m.w)
    print(f"  地图 random15: 可走格 {walkable} ({100*walkable/NCELL:.1f}%)")
    print(f"  访问节点 {exp}   py_med={py_ms:.0f} ms   C估算@40ns = {exp*40e-6:.2f} ms")
    print(f"  摊到 1000 单位（按 1 次构建服务全群）= {exp*40e-6/1000:.4f} ms/单位")
    print()

# ------------------------------------------------------------------ S5
def s5_clearance():
    print("=" * 60)
    print("S5 clearance 可行域占比（决定 4x4 单位能否走在随机图上）")
    print("=" * 60)
    m = Map("random")
    # 多源 BFS 求到最近阻挡的欧氏距离（近似：用 8 邻接 BFS 的 chebyshev 会高估，
    # 这里用「到最近阻挡的平方欧氏距离」的 8SSEDT 简化版：直接用 BFS 层数 * 1 近似下界）
    # 为准确起见用简单欧氏：对每个可走格，取 8 邻域 2 环内的最小障碍距离（近似）
    INF = 1 << 20
    dist = [INF] * NCELL
    q = []
    for i in range(NCELL):
        if not m.w[i]:
            dist[i] = 0
            q.append(i)
    qi = 0
    while qi < len(q):
        c = q[qi]; qi += 1
        x = c % GW; y = c // GW
        dc = dist[c]
        for d in range(8):
            nx = x + DX8[d]; ny = y + DY8[d]
            if nx < 0 or ny < 0 or nx >= GW or ny >= GH:
                continue
            nc = ny * GW + nx
            if dist[nc] > dc + 1:
                dist[nc] = dc + 1
                q.append(nc)
    # 用 chebyshev 距离近似欧氏（误差 <= 41%），只用于阈值敏感性
    walkable = 0
    cnt = [0] * 5
    thr = (0.5, 1.0, 2.0, 2.83, 4.0)
    for i in range(NCELL):
        if not m.w[i]:
            continue
        walkable += 1
        for k in range(5):
            if dist[i] >= thr[k]:
                cnt[k] += 1
    print(f"  random15 可走格 {walkable}")
    for k in range(5):
        print(f"    clearance >= {thr[k]:.2f}m : {100*cnt[k]/walkable:5.1f}%  ({cnt[k]} 格)")
    print("  口径：这里用 8 邻接 BFS 层数近似欧氏距离（chebyshev，偏乐观 1~41%）；"
          "\n        实现里用 8SSEDT 真欧氏距离，本表只用于阈值敏感性判断。")
    print()

# ------------------------------------------------------------------ S7
def s7_formation():
    print("=" * 60)
    print("S7 队形几何（纯数学，与语言无关）")
    print("=" * 60)
    print("\n[A] 方阵物理占地")
    print(f"  {'fp':>4} {'N':>5} {'pitch':>6} {'边长(m)':>9} {'面积(m2)':>10} {'密度(/m2)':>10}")
    for fp, n in ((1, 300), (2, 300), (4, 100)):
        pitch = fp + 1.0
        side = math.ceil(math.sqrt(n))
        w = (side - 1) * pitch + fp
        print(f"  {fp:>4} {n:>5} {pitch:>6.1f} {w:>9.1f} {w*w:>10.0f} {n/(w*w):>10.4f}")

    print("\n[B] 4x4 单位窄通道通过能力（pitch=5m, v=5m/s, 100 单位）")
    print(f"  {'通道W(m)':>9} {'列数C':>6} {'队列长(m)':>10} {'总长(m)':>9} "
          f"{'穿越(s)':>9} {'流量(/s)':>9}")
    for W in (5, 6, 8, 12, 16, 24, 40):
        C = max(0, int(math.floor((W - 4) / 5.0)) + 1)
        if C == 0:
            print(f"  {W:>9} {0:>6} {'-':>10} {'-':>9} {'-':>9} {'0':>9}")
            continue
        qlen = (100.0 / C) * 5.0
        total = qlen + 100.0
        print(f"  {W:>9} {C:>6} {qlen:>10.0f} {total:>9.0f} "
              f"{total/5.0:>9.1f} {C*5.0/5.0:>9.2f}")

    print("\n[C] 队形落脚候选规模")
    fp, n, pitch = 4, 100, 5.0
    side = math.ceil(math.sqrt(n))
    w = (side - 1) * pitch + fp
    cells = int(w * w)
    print(f"  100x4x4 方阵 = {w:.0f}x{w:.0f} m = {cells} 格")
    print(f"  螺旋 8 向 x 40 步 = 320 候选 x {cells} 格 = {320*cells/1e4:.0f} 万次 cell 查询")
    print(f"  以 2ns/查询 = {320*cells*2/1e6:.2f} ms/次命令（可接受；每 tick 重算则不可接受）")
    print()

# ------------------------------------------------------------------ S8
def s8_budget():
    print("=" * 60)
    print("S8 8ms 预算（框架，待 C 实测填充）")
    print("=" * 60)
    rows = [
        ("空间索引重建", 0.02, "计数排序 1000 单位"),
        ("邻居查询(k=10)", 0.15, "3x3 桶"),
        ("ORCA 求解", None, "待 C 实测（S6）"),
        ("路径跟随+积分+墙约束", 0.20, "含 clearance 快拒"),
        ("队形/槽位(10Hz摊销)", 0.10, ""),
        ("导航请求(分帧)", 1.00, "1ms/tick"),
        ("卡死/让路(摊销)", 0.05, ""),
        ("引擎/余量", 3.00, ""),
    ]
    for name, ms, note in rows:
        v = "?" if ms is None else f"{ms:.2f}"
        print(f"  {name:<24} {v:>7} ms  {note}")
    print()

# ------------------------------------------------------------------ main
def main():
    machine_info()
    s2_spatial()
    s3_astar()
    s4_flowfield()
    s5_clearance()
    s7_formation()
    s8_budget()
    print("probe(py) done")

if __name__ == "__main__":
    main()
